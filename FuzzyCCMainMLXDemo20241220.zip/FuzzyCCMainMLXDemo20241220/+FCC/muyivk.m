function [mu_lk,d_lk]=muyivk(dataseti,NumClusters,Mu_A,m_fuzzifier,w_i)
%% 
% Outpt:
% d_lk:
% mu_lk: 
% Intpt:
% data_iris：
% NumClusters：
% Mu_A：
% m_fuzzifier：
% w_i:
% r: 
% $d\left(y_l, v_k\right)=\sum_{i=1}^r w_i f\left(\mu_{l .}^{(i)}, 
% v_k^{(i)}\right), l=1,2, \cdots, n ; k=1,2, \cdots, K_i$
d_lk=zeros(size(dataseti,1),NumClusters);          %  kxn
for li=1:size(dataseti,1) % l
    for ki=1:NumClusters   % k
        % U_fE
        for ir=1:NumClusters % symblo r
            mu_dotkm1=norm(Mu_A(:,ki,ir).^m_fuzzifier,1);
            % $\left(\mu_{: k}\right)^m$
            mu_dkm=(Mu_A(:,ki,ir).^m_fuzzifier);                 % nx1
            scale4Mu_A=(mu_dkm/mu_dotkm1)*ones(1,NumClusters);
            v_ki(:,ir)=sum(scale4Mu_A.*Mu_A(:,:,ir),1)';         % 150x1
            norm_i(ir,1)=norm(Mu_A(li,:,ir)-v_ki(:,ir)',2)^2;    % rx1
        end
        %vk=v_ki(:)
        d_lk(li,ki)=w_i*norm_i;
        d_lkscanum(1,ki)=d_lk(li,ki)^(-1/(m_fuzzifier-1));
    end
    % \mu_{l k}=\frac{d\left(y_l, v_k\right)^{-1 /(m-1)}}
    % {\sum_{k^{\prime}=1}^K d\left(y_l, v_{k^{\prime}}\right)
    % ^{-1 /(m-1)}},\forall l, k
    % mu_lk
    d_lkscaden=sum(d_lk(li,:).^(-1/(m_fuzzifier-1)),2);
    mu_lk(li,:)=d_lkscanum/d_lkscaden;
end
end