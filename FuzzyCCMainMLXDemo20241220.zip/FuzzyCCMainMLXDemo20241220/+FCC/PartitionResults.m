function indexs=PartitionResults(U1,NumClusters)
%% find the data sample indexs from fuzzy partition matrix
% 2010-01-10
% indexs for clusters
maxU1 = max(U1); 
class_flag=0;
%ind_tmp1=[];
ind_tmp1=cell(1,NumClusters);
for fcm_i=1:NumClusters
    class_flag=class_flag+1;
    index1 = find(U1(fcm_i,:) == maxU1);
    % data type: [index of class1, 1; index of class2, 2; ...
    %             index of classn, n]
    ind_tmp1{fcm_i}=index1;
end
indexs=ind_tmp1;
end