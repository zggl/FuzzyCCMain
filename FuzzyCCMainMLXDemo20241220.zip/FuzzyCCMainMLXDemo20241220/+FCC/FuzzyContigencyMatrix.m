function FuzzyContigentMatrixi= FuzzyContigencyMatrix(Algs_U1,Algs_U2,m)
% Fuzzified Contingency Matrix
% \begin{align}\label{FuzzyConcesusUFeqn08}
%     s_{k j}^{(i)}=\left(\mu_{\cdot k}^m\right)^{\top} \mu_{\cdot j}^{(i)}, \forall k, j.
% \end{align}
    FuzzyContigentMatrixi.mu=Algs_U1.^m*Algs_U2';
    mu_size=size(FuzzyContigentMatrixi.mu);
    FuzzyContigentMatrixi.splusKi=sum(FuzzyContigentMatrixi.mu,1)'; % s_{+Ki}: Ki x 1 
    FuzzyContigentMatrixi.skplus=sum(FuzzyContigentMatrixi.mu,2); % s_{K+}: K x 1
    FuzzyContigentMatrixi.Pki=FuzzyContigentMatrixi.mu./(ones(mu_size(1),1) ...
        *FuzzyContigentMatrixi.splusKi')
end