function [ContengencyMatrix]=ContengencyMatrixCal(U1,U2,idx1, idx2) 
%% Contengency Matrix 
%U_i's size: C x n, n is the sample size.
if size(U1,1)>size(U1,2)
    U1=U1';
end
if size(U2,1)>size(U2,2)
    U2=U2';
end
for ii=1:size(U1,1)
    for jj=1:size(U2,1)
        ContengencyMatrix.Matrix(ii,jj)=length(intersect (idx1{ii},idx2{jj}));
    end
end
ContengencyMatrix.size=[size(U1,1), size(U2,1)];
end
