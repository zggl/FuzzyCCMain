function [Algs_info]=FCCBPsCal(data,PartitionAlgName,PartitionAlgsParas)
% ii:                   indicate the index in the structure Algs_info.
% data:                 dataset 
% PartitionAlgsParas:   options for the algorithms
% To calculate the CONTINGENCY MATRIX for different basic partitions, 
% abbreviated as BPs.

% 2024-6-29
    switch PartitionAlgName
        % 1: Fuzzy c-means clustering
        case 'fcm'
        options_fcm=PartitionAlgsParas.options{1};
        % centers: cluster centers (centers)   
        % U:  and a fuzzy partition matrix (U)
        % objFcn: the objective function values at each optimization 
        % iteration for the optimal number of clusters.
        % info:   the clustering results for all numbers of clusters used 
        % along with the validity index used for determining the optimal 
        % number of clusters. When the distance metric specified in options 
        % is either "mahalanobis" or "fmle", info also contains the covari
        % ance matrices generated for each number of clusters.
        %releaseInfo = matlabRelease
        
        % Determine if current MATLAB release is older than 
        % specified MATLAB releaseSince R2020b.
        if isMATLABReleaseOlderThan("R2021b")
            [centers1,U1,objFcn] = fcm(data,options_fcm.NumClusters);
        else
            [centers1,U1,objFcn,info] = fuzzy.fcm(data,options_fcm);
        end
        maxU1 = max(U1); class_flag=0; % U1:
        %ind_tmp1=[];
        ind_tmp1=cell(1,options_fcm.NumClusters);
        for fcm_i=1:options_fcm.NumClusters
            class_flag=class_flag+1;
            index1 = find(U1(fcm_i,:) == maxU1);
            % data type: [index of class1, 1; index of class2, 2; ...
            %             index of classn, n]
            ind_tmp1{fcm_i}=index1;
            %ind_tmp1=[ind_tmp1;[index1',ones(length(index1),1)*class_flag]]
        end
        indx1=ind_tmp1;
        sprintf(strcat('The size of the index for FCM is: %s'), ...
            num2str(size(indx1)))
        Algs_info.name='fcm';
        Algs_info.idx=indx1;
        Algs_info.centers=centers1;
        Algs_info.U=U1;
        Algs_info.objFcn=objFcn;
        if ~exist('info')==0
            Algs_info.info=[];
        else
            Algs_info.info=info;
        end
        Algs_info.sumd=[];
        Algs_info.Dist=[];
        % 2: K-means clustering
        case 'kmeans'
            %idx: the cluster indices with additional options specified 
            % by one or more Name,Value pair arguments.
            % C:  the k cluster centroid locations in the k-by-p matrix C.
            % sumd:  the within-cluster sums of point-to-centroid distances 
            % in the k-by-1 vector sumd.
            % D: distances from each point to every centroid in the n-by-k 
            % matrix D.
            options_kmeans=PartitionAlgsParas.options{2};
            [idx2,centers2,sumd,Dist] = kmeans(data, ...
                                     options_kmeans.NumClusters, ...
                'MaxIter', options_kmeans.MaxIter, ...
                'Display',options_kmeans.Display, ...
                'Replicates',options_kmeans.Replicates);  
            % other not specified clustering algorithms
            for kmeans_i=1:options_kmeans.NumClusters
                index1 = find(idx2 == kmeans_i);
                % data type: [index of class1, 1; index of class2, 2; ...
                %             index of classn, n]
                ind_tmp2{kmeans_i}=index1;
                %ind_tmp2=[ind_tmp2;[index2',ones(length(index1),1)*class_flag]]
            end
            Algs_info.name='kmeans';
            Algs_info.idx=ind_tmp2;
            Algs_info.centers=centers2;
            Algs_info.U=[];
            Algs_info.sumd=sumd;
            Algs_info.Dist=Dist;
            Algs_info.objFcn=[];
            Algs_info.info=[];
        case 'fuzzykmeans'
            % run FuzzyKMeans
            [U3, centroid3, dist3, W3, obj3] = FuzzyKMeans(...
                PartitionAlgsParas.options{3}.NumClusters, ...
                data, ...
                PartitionAlgsParas.options{3}.phi, ...
                PartitionAlgsParas.options{3}.MaxIter, ...
                PartitionAlgsParas.options{3}.Display, ...
                PartitionAlgsParas.options{3}.toldif, ...
                PartitionAlgsParas.options{3}.scatter, ...
                PartitionAlgsParas.options{3}.ntry);  
            % output:
            %   U           = membership matrix
            %   centroid    = centroid              centroid(nclass, ndim)
            %   dist        = distance matrix       dist(ndata,nclass)
            %   W           = distance norm matrix
            %   obj         = objective function
            IRIS_B=PartitionAlgsParas.options{3}.IRIS_B;
            ndata=PartitionAlgsParas.options{3}.ndata;
            ind_tmp3=[];
            options_fkm=PartitionAlgsParas.options{3};
            U3=U3';
            maxU3 = max(U3); class_flag=0;
            for fkmeans_i=1:options_fkm.NumClusters
                class_flag=class_flag+1;
                index3 = find(U3(fkmeans_i,:) == maxU3);
                % data type: [index of class1, 1; index of class2, 2; ...
                %             index of classn, n]
                ind_tmp3{fkmeans_i}=index3;
                %ind_tmp3=[ind_tmp3;[index3',ones(length(index1),1)*class_flag]]
                for kk=1:options_fkm.NumClusters
                    Row_ind(kk,1)=length(intersect(index3,IRIS_B(kk,:)));
                end
                FkmNum(fkmeans_i,1)=max(Row_ind);
            end   
            indx3=ind_tmp3;
            sprintf(strcat(['The size of the index for Fuzzy K-Means ...' ...
                              'is: %s']), num2str(size(indx3)))
            Algs_info.name='fuzzykmeans';
            Algs_info.idx=indx3;
            Algs_info.centers=[];
            Algs_info.centroid=centroid3;
            Algs_info.U=U3';
            Algs_info.sumd=[];
            Algs_info.Dist=dist3;
            Algs_info.objFcn=obj3;
            Algs_info.W=W3;
            Algs_info.info=[];
            Algs_info.Accu=sum(FkmNum)/ndata;
        case 'roughfkms' 
            % A is the upper approximate limit 
            % expo is fuzzy number exponential 
            % tol is the torlerance
            [center4,U4]=RoughFuzzyKMeans(data,...
                PartitionAlgsParas.options{4}.NumClusters, ...
                PartitionAlgsParas.options{4}.A, ...
                PartitionAlgsParas.options{4}.expo, ...
                PartitionAlgsParas.options{4}.tol);
            maxU4 = max(U4); class_flag=0;
            options_rfkms=PartitionAlgsParas.options{4};
            for roughfkms_i=1:options_rfkms.NumClusters
                class_flag=class_flag+1;
                index4 = find(U4(roughfkms_i,:) == maxU4);
                % data type: [index of class1, 1; index of class2, 2; ...
                %             index of classn, n]
                ind_tmp4{roughfkms_i}=index4;
                %ind_tmp4=[ind_tmp4;[index4',ones(length(index1),1)...
                % *class_flag]]
            end
            indx4=ind_tmp4;
            sprintf(strcat(['The size of the index for Rough Fuzzy ' ...
                'K-Means ' 'is: %s']), num2str(size(indx4)))           
            Algs_info.name='roughfkms';
            Algs_info.idx=indx4;
            Algs_info.centers=center4;
            Algs_info.U=U4;
            Algs_info.U=[];
            Algs_info.sumd=[];
            Algs_info.Dist=[];
            Algs_info.objFcn=[];
            Algs_info.W=[];
            Algs_info.info=[];  
        case ''

        otherwise
            error('The clustering algorithm has been implemented yet') 
    end
end