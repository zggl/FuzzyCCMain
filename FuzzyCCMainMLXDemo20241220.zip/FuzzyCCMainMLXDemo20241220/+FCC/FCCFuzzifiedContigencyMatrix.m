function varargout = FCCFuzzifiedContigencyMatrix()
    varargout{1} = '';
end