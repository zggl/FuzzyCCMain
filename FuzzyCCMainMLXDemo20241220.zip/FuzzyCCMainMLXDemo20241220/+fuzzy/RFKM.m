function [center,member]=RFKM(D,k,A,expo,tol) 

% 
% With the assistance of the lower and upper approximation of rough sets, 
% the rough fuzzy k-means clustering algorithm may improve 
% the objective function and further the distribution 
% of membership function for the traditional fuzzy k-means clustering. 
% However, the algorithm only has theoretical ideas rather than concrete 
% realizations. To make it better applied to practice, using Matlab, 
% a mathematical programming tool, to implement rough fuzzy k-means 
% clustering algorithm is discussed. Moreover, steps of implementation 
% are given in detail. The foresaid contributions may provide clustering 
% learners and non-computer professional researchers with a simple, 
% convenient, efficient and feasible implementation method.
% 
% Clustering algorithms;Classification algorithms;Approximation algorithms;
% Algorithm design and analysis;Approximation methods;Presses;
% Machine learning;Fuzzy k-means;Rough fuzzy k-means;Matlab

% D is the data set 
% k is the number of cluster center 
% A is the upper approximate limit 
% expo is fuzzy number exponential 
[num,col]=size(D); 
% Initialize membership matrix 
member = rand(k, num); 
col_sum = sum(member); 
member = member./(col_sum(ones(k, 1), :)+eps); 
top=1E2; 
J=zeros(top,1); 
%main loop 
for sumsss=1:top

    % Seek cluster center 
    tmpmf=member.^expo; 
    center=tmpmf*D./((ones(size(D,2),1)*sum(tmpmf'))'+eps); 
    % Calculate the distance between clustering center and each sample point 
    distance = zeros(size(center, 1), size(D, 1)); 
     if size(center, 2) > 1 
         for c = 1:size(center, 1)
            distance(c, :) = sqrt(sum(((D-ones(size(D, 1), 1)...
                                                *center(c, :)).^2)')); 
         end 
    else 
         for c = 1:size(center, 1)
            distance(c, :) = abs(center(c)-D)'; 
         end 
     end 
 % Calculate termination condition 
 J(sumsss)=sum(sum((distance.^2).*tmpmf)); 
 % Update the new membership matrix 
 tmp=distance.^(-2/(expo-1));
 member_new=tmp./(ones(k,1)*sum(tmp)+eps); 
 A=median(distance(:));
 for i=1:num 
     for c=1:k 
         if distance(c,i)>A 
            member_new(c,i)=0; 
         end 
    end 
 end 
 member=member_new;
 col_sum = sum(member); 
 member = member./(col_sum(ones(k, 1), :)+eps); 
 if sumsss>1 
    if abs(J(sumsss)-J(sumsss-1))<tol, break; end 
 end 
end