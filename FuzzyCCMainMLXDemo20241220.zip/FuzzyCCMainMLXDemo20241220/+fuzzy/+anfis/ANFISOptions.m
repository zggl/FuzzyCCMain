classdef ANFISOptions
    %ANFISOptions - Creates options for ANFIS function.
    %
    %  ANFISOptions creates options to be used by ANFIS function.
    %
    %  Properties:
    %    InitialFIS              - Initial FIS for training
    %    EpochNumber             - Training epoch number
    %    ErrorGoal               - Training error goal
    %    InitialStepSize         - Initial step size for training
    %    StepSizeDecreaseRate    - Step size decrease rate
    %    StepSizeIncreaseRate    - Step size increase rate
    %    DisplayANFISInformation - Flag for displaying ANFIS information
    %    DisplayErrorValues      - Flag for displaying error values
    %    DisplayStepSize         - Flag for displaying step size
    %    DisplayFinalResults     - Flag for displaying final results
    %    ValidationData          - Validation data used for preventing overfitting
    %    OptimizationMethod      - Optimization method used in training
    %
    %  The property values can be specified at construction time as
    %  name/value pairs.
    %
    %    Example:
    %      options = fuzzy.anfis.ANFISOptions('EpochNumber',100);
    %      x = (0:0.1:10)';
    %      y = sin(2*x)./exp(x/5);
    %      fis = anfis([x y],options);
    %
    %    See also anfis

    % Copyright 2016-2022 The MathWorks, Inc.

    properties
        % InitialFIS - Initial FIS for training
        %
        %   A FIS used to provide an initial set of membership functions
        %   for training. The default value is 2, which indicates the
        %   number of membership functions used for each input.
        %
        %   InitialFIS must be one of the followings: 
        %     - A valid FIS object that satisfies the following conditions:
        %        -  First or zeroth order Sugeno-type system.
        %        -  Single output, obtained using weighted average
        %           defuzzification. All output membership functions must
        %           be the same type and be either linear or constant.
        %        -  No rule sharing. Different rules cannot use the same
        %           output membership function; that is the number of
        %           output membership functions must be equal to the number
        %           of rules.
        %        -  Unity weight for each rule.
        %        -  No custom membership functions or defuzzification methods.
        %     - A scalar positive integer specifying the same number of MFs
        %       for each input.
        %     - A vector of positive integers specifying individual MF
        %       number for each input.
        InitialFIS
        
        % EpochNumber - Training epoch number
        %
        %   Training epoch number with default value set to 10. The
        %   training process stops whenever the designated epoch number is
        %   reached.
        %
        %   EpochNumber must be a positive scalar integer less than intmax.
        EpochNumber
        
        % ErrorGoal - Training error goal
        %
        %  Training error goal with default value set to 0. The training
        %  process stops whenever the training error goal is achieved.
        %
        %  ErrorGoal must be a scalar real number.
        ErrorGoal
        
        % InitialStepSize - Initial step size for training
        %
        %   Initial step size for training. The default property value is
        %   set to 0.01.
        %
        %  InitialStepSize must be a scalar real number.
        InitialStepSize
        
        % StepSizeDecreaseRate - Step size decrease rate for training
        %
        %   Step size decrease rate with default value set to 0.9. The
        %   training step size is decreased by multiplying it with the step
        %   size decrease rate.
        %
        %  StepSizeDecreaseRate must be a scalar real number.
        StepSizeDecreaseRate
        
        % StepSizeIncreaseRate - Step size increase rate for training
        %
        %   Step size increase rate with default value set to 1.1. The
        %   training step size is increased by multiplying it with the step
        %   size increase rate.
        %
        %  StepSizeDecreaseRate must be a scalar real number.
        StepSizeIncreaseRate
        
        % DisplayANFISInformation - Flag for displaying ANFIS information
        %
        %   Flag for displaying ANFIS information. The default flag value
        %   is set to true.
        %
        %  DisplayANFISInformation must be either true (1) or false (0).
        DisplayANFISInformation
        
        % DisplayErrorValues - Flag for displaying error values
        %
        %   Flag for displaying error values. The default flag value is set
        %   to true.
        %
        %  DisplayErrorValues must be either true (1) or false (0).
        DisplayErrorValues
        
        % DisplayStepSize - Flag for displaying step size
        %
        %   Flag for displaying step size. The default flag value is set to
        %   true.
        %
        %  DisplayStepSize must be either true (1) or false (0).
        DisplayStepSize
        
        % DisplayFinalResults - Flag for displaying final results
        %
        %   Flag for displaying final training results. The default flag
        %   value is set to true.
        %
        %  DisplayFinalResults must be either true (1) or false (0).
        DisplayFinalResults
        
        % ValidationData - Validation data for preventing overfitting
        %
        %   Validation data used for preventing overfitting of the training
        %   data. It has the same format as training data. The default
        %   validation data is set to empty.
        %
        %   ValidationData must be finite real data having the same
        %   dimention as the training data used in ANFIS. The number
        %   of data points must be less than intmax.
        ValidationData
        
        % OptimizationMethod - Optimization method used in training
        %
        %   Optimization method used in membership function parameter
        %   training. Specify 0 to use backpropagation method or specify 1
        %   to use a hybrid method, which combines least squares estimation
        %   with backpropagation. The default value is set to 1.
        OptimizationMethod
    end
       
    properties(Hidden)
        OutputFcn = ''
    end

    properties(Constant,Access=private)
        DefaultInitialFIS = 2;
        
        DefaultEpochNumber = 10;
        DefaultErrorGoal = 0;
        DefaultInitialStepSize = 0.01;
        DefaultStepSizeDecreaseRate = 0.9;
        DefaultStepSizeIncreaseRate = 1.1;
        
        DefaultDisplayANFISInformation = true;
        DefaultDisplayErrorValues = true;
        DefaultDisplayStepSize = true;
        DefaultDisplayFinalResults = true;
        
        DefaultValidationData = [];
        DefaultOptimizationMethod = 1;
    end
    
    methods
        
        function obj = ANFISOptions(varargin)
            % ANFISOptions - Class constructor
            %
            %   ANFISOptions creates options with default values.
            %
            %   ANFISOptions(name1,value1, ...) creates options with the
            %   specified property values. Absence of a property name will
            %   select the default property value.
            
            p = inputParser();
            
            p.addParameter('InitialFIS',fuzzy.anfis.ANFISOptions.DefaultInitialFIS);
            p.addParameter('EpochNumber',fuzzy.anfis.ANFISOptions.DefaultEpochNumber);
            p.addParameter('ErrorGoal',fuzzy.anfis.ANFISOptions.DefaultErrorGoal);
            p.addParameter('InitialStepSize',fuzzy.anfis.ANFISOptions.DefaultInitialStepSize);
            p.addParameter('StepSizeDecreaseRate',fuzzy.anfis.ANFISOptions.DefaultStepSizeDecreaseRate);
            p.addParameter('StepSizeIncreaseRate',fuzzy.anfis.ANFISOptions.DefaultStepSizeIncreaseRate);
            p.addParameter('DisplayANFISInformation',fuzzy.anfis.ANFISOptions.DefaultDisplayANFISInformation);
            p.addParameter('DisplayErrorValues',fuzzy.anfis.ANFISOptions.DefaultDisplayErrorValues);
            p.addParameter('DisplayStepSize',fuzzy.anfis.ANFISOptions.DefaultDisplayStepSize);
            p.addParameter('DisplayFinalResults',fuzzy.anfis.ANFISOptions.DefaultDisplayFinalResults);
            p.addParameter('ValidationData',fuzzy.anfis.ANFISOptions.DefaultValidationData);
            p.addParameter('OptimizationMethod',fuzzy.anfis.ANFISOptions.DefaultOptimizationMethod);
            
            p.parse(varargin{:});
            
            obj.InitialFIS = p.Results.InitialFIS;
            obj.EpochNumber = p.Results.EpochNumber;
            obj.ErrorGoal = p.Results.ErrorGoal;
            obj.InitialStepSize = p.Results.InitialStepSize;
            obj.StepSizeDecreaseRate = p.Results.StepSizeDecreaseRate;
            obj.StepSizeIncreaseRate = p.Results.StepSizeIncreaseRate;
            obj.DisplayANFISInformation = p.Results.DisplayANFISInformation;
            obj.DisplayErrorValues = p.Results.DisplayErrorValues;
            obj.DisplayStepSize = p.Results.DisplayStepSize;
            obj.DisplayFinalResults = p.Results.DisplayFinalResults;
            obj.ValidationData = p.Results.ValidationData;
            obj.OptimizationMethod = p.Results.OptimizationMethod;
        end
        
        function obj = set.InitialFIS(obj,value)
            % Set method for InitialFIS. 
            %
            %   InitialFIS must be one of the followings: 
            %     - A valid FIS object that satisfies the following conditions:
            %        -  First or zeroth order Sugeno-type system.
            %        -  Single output, obtained using weighted average
            %           defuzzification. All output membership functions must
            %           be the same type and be either linear or constant.
            %        -  No rule sharing. Different rules cannot use the same
            %           output membership function; that is the number of
            %           output membership functions must be equal to the number
            %           of rules.
            %        -  Unity weight for each rule.
            %        -  No custom membership functions or defuzzification methods.
            %     - A scalar positive integer specifying the same number of MFs
            %       for each input.
            %     - A vector of positive integers specifying individual MF
            %       number for each input.
            
            validFISObject = ~isempty(value) && ...
                isa(value,'FuzzyInferenceSystem');
            validFISStructure = fuzzy.internal.utility.isNonemptyScalarFISStructure(value);
            if validFISObject || validFISStructure
                fuzzy.internal.utility.checkFISRequirementForANFIS(value)
            end
            validMFNumber = ~isempty(value) && isnumeric(value) && ...
                isreal(value) && all(isfinite(value)) && ...
                all(floor(value)==value) && all(value>1);
            
            if ~(validFISObject || validFISStructure || validMFNumber)
                error(message('fuzzy:general:errAnfisInitialFIS_InvalidValue'));
            end
            
            if validFISStructure
                warning(message('fuzzy:general:warnDeprecation_FISStructure'))
                value = convertfis(value);
            end
            
            obj.InitialFIS = value;
        end
        
        function obj = set.EpochNumber(obj,value)
            % Set method for EpochNumber.
            %
            %   EpochNumber must be a positive scalar integer less than
            %   intmax.
            
            validateReal('EpochNumber',value);
            validateattributes(value, ...
                {'numeric'}, ...
                {'positive','integer'}, ...
                '', ...
                'EpochNumber');
            
            if value > intmax
                error(message('fuzzy:general:errAnfisEpoch_invalidSize'))
            end
            
            obj.EpochNumber = value;
        end
        
        function obj = set.ErrorGoal(obj,value)
            % Set method for ErrorGoal.
            %
            %   ErrorGoal must be a scalar real number.
            
            validateReal('ErrorGoal',value);
            obj.ErrorGoal = value;
        end
        
        function obj = set.InitialStepSize(obj,value)
            % Set method for InitialStepSize.
            %
            %   InitialStepSize must be a positive scalar real number.
            param = 'InitialStepSize';
            validateReal(param,value);
            validateattributes(value, ...
                {'numeric'}, ...
                {'positive'}, ...
                '', ...
                param);
            obj.InitialStepSize = value;
        end
        
        function obj = set.StepSizeDecreaseRate(obj,value)
            % Set method for StepSizeDecreaseRate.
            %
            %   StepSizeDecreaseRate must be a scalar real number.
            
            validateattributes(value,...
                {'numeric'},...
                {'nonempty','scalar','real','finite','positive','<',1},...
                '',...
                'StepSizeDecreaseRate'...
                );
            obj.StepSizeDecreaseRate = value;
        end
        
        function obj = set.StepSizeIncreaseRate(obj,value)
            % Set method for StepSizeIncreaseRate.
            %
            %   StepSizeIncreaseRate must be a scalar real number.
            
            validateattributes(value,...
                {'numeric'},...
                {'nonempty','scalar','real','finite','>',1},...
                '',...
                'StepSizeIncreaseRate'...
                );
            obj.StepSizeIncreaseRate = value;
        end
        
        function obj = set.DisplayANFISInformation(obj, value)
            % Set method for DisplayANFISInformation.
            %
            %   DisplayANFISInformation must be true (1) or false (0).
            
            validateDisplayOption('DisplayANFISInformation',value);
            obj.DisplayANFISInformation = value;
        end
        
        function obj = set.DisplayErrorValues(obj, value)
            % Set method for DisplayErrorValues.
            %
            %   DisplayErrorValues must be true (1) or false (0).
            
            validateDisplayOption('DisplayErrorValues',value);
            obj.DisplayErrorValues = value;
        end
        
        function obj = set.DisplayStepSize(obj, value)
            % Set method for DisplayStepSize.
            %
            %   DisplayStepSize must be true (1) or false (0).
            
            validateDisplayOption('DisplayStepSize',value);
            obj.DisplayStepSize = value;
        end
        
        function obj = set.DisplayFinalResults(obj, value)
            % Set method for DisplayFinalResults.
            %
            %   DisplayFinalResults must be true (1) or false (0).
            
            validateDisplayOption('DisplayFinalResults',value);
            obj.DisplayFinalResults = value;
        end
        
        function obj = set.ValidationData(obj,value)
            % Set method for ValidationData.
            %
            %   ValidationData must be finite real data having the same
            %   dimension as the training data used in ANFIS. The number
            %   of data points must be less than intmax.
            
            validateattributes(value, ...
                {'numeric'}, ...
                {'real','finite'}, ...
                '', ...
                'ValidationData');
            if size(value,1)>intmax
                error(message('fuzzy:general:errAnfis_invalidDataPointSize'))
            end
            
            obj.ValidationData = value;
        end
        
        function obj = set.OptimizationMethod(obj,value)
            % Set method for OptimizationMethod.
            %   
            %   OptimizationMethod must be either 0 or 1.
            
            validateReal('OptimizationMethod',value);
            if ~(value==0 || value==1)
                error(message(...
                    'fuzzy:general:errAnfisOptimizationMethod_InvalidValue'));
            end
            obj.OptimizationMethod = value;
        end
        
    end
end
%% Helper functions -------------------------------------------------------
function validateReal(name,value)
validateattributes(value, ...
    {'numeric'}, ...
    {'nonempty','scalar','real','finite'}, ...
    '', ...
    name);
end

function validateDisplayOption(name,value)
validateattributes(value, ...
    {'numeric','logical'}, ...
    {'nonempty','scalar','real'}, ...
    '', ...
    name);

validValue = (value==1) | (value==0) | (value==true) | (value==false);

if ~validValue
    error(message('fuzzy:general:errLogicalFlag_InvalidValue',name));
end
end