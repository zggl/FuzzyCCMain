classdef ANFISState < int32
    % Enum for ANFIS states.
    
    %  Copyright 2022 The MathWorks, Inc.
    
    enumeration
        StopMessage(0)
        ParameterInfoMessage(1)
        TrainingStartMessage(2)
        DisplayErrorMessage(3)
        ErrorGoalReachedMessage(4)
        EpochGoalReachedMessage(5)
        MinimumErrorMessage(6)
        StepSizeIncreasedMessage(7)
        StepSizeDecreasedMessage(8)
    end
end