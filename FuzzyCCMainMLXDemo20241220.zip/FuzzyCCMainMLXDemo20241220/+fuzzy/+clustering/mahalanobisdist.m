function [dist, covMat, brkCond] = mahalanobisdist(centers, data, memFcnMat, clusterVolume)
%MAHALANOBISDIST Distance measure in the Gustafson-Kessel extension.
%
%	[DIST,COVMAT,BRKCOND] = MAHALANOBISDIST(CENTERS,DATA,MEMFCNMAT,CLUSTERVOLUME)
%   calculates the Mahalanobis distance DIST between each cluster center in
%   CENTERS and a data point in DATA.
%
%   DIST is an M-by-N matrix, where M and N are the number of clusters and
%   data points, respectively. DIST(I,J) is the distance between
%   CENTER(I,:) and DATA(J,:).
%
%   COVMAT includes the covariance matrices of each cluster in DATA. It is
%   a cell array of size 1-by-M. Each covariance matrix is of size K-by-K,
%   where K is the number of features (number of columns) of DATA.
%
%   BRKCOND is the breaking condition for the distance metric in case a
%   singularity is reached. The distance calculation uses the latest fuzzy
%   partition matrix MEMFCNMAT.
%
%     See also EUCLIDEANDIST, FMLE, FCM

%  Copyright 2022-2023 The MathWorks, Inc.

[dataSize, numFeatures] = size(data); %#ok<ASGLU>
sumMemFcnMat = sum(memFcnMat, 2);
numClusters = size(centers, 1);
dist = zeros(size(memFcnMat));
covMat = cell(numClusters, 1);

brkCond = struct('isTrue', 0,'description','');
for clusterId = 1:numClusters
    % Calculate covariance matrix
    dataDiff = data - centers(clusterId, :);
    covMat{clusterId} = (memFcnMat(clusterId, :).*dataDiff'*dataDiff)/sumMemFcnMat(clusterId);
    % ---------------------------------------------------------------------
    % NOTE: The vectorized calculation replaces the following computation:
    % ---------------------------------------------------------------------
    % cMat = zeros(numFeatures);
    % for dataPointId = 1:dataSize
    %     dDiff = dataDiff(dataPointId,:)';
    %     mu = memFcnMat(clusterId,dataPointId);
    %     cMat = cMat + mu*(dDiff*dDiff');
    % end
    % cMat = cMat./sumMemFcnMat(clusterId);
    % ---------------------------------------------------------------------

    % Check singularity condition for the covariance matrix
    rcondValue = rcond(covMat{clusterId});
    if rcondValue<=eps || isnan(rcondValue)
        if ~brkCond.isTrue
            brkCond.isTrue = true;
            brkCond.description = getString(message('fuzzy:general:errFcm_singularCovMat'));
        end
        f = @pinv;
    else
        f = @inv;
    end

    % Calculate distance
    W = clusterVolume(clusterId)*det(covMat{clusterId})^(1/numFeatures)*f(covMat{clusterId});
    dist(clusterId, :) = sum(dataDiff*W.*dataDiff,2);
    % ---------------------------------------------------------------------
    % NOTE: The vectorized calculation replaces the following computation:
    % ---------------------------------------------------------------------
    % d = zeros(1,dataSize);
    % for dataPointId = 1:dataSize
    %     dDiff = dataDiff(dataPointId,:)';
    %     W = clusterVolume(clusterId)*det(covMat{clusterId})^(1/numFeatures)*f(covMat{clusterId});
    %     d(dataPointId) = dDiff'*W*dDiff;
    % end
    % ---------------------------------------------------------------------
end

end