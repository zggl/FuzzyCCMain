function [dist,covMat,brkCond] = fmle(centers,data,memFcnMat)
%FMLE Distance measure using fuzzy maximum likelihood estimation.
%
%	[DIST,COVMAT,PRIORPROB,BRKCOND] = FMLE(CENTERS,DATA,MEMFCNMAT)
%   calculates distance DIST using the fuzzy maximum likelihood estimation
%   method.
%
%   DIST is calculated between each cluster center in CENTERS and a data
%   point in DATA. It is an M-by-N matrix, where M is the number cluster
%   centers and N is the number of data points. DIST(I,J) is the distance
%   between CENTER(I,:) and DATA(J,:). 
%
%   COVMAT includes the covariance matrices of each cluster in DATA. It is
%   a cell array of size 1-by-M. Each covariance matrix is of size K-by-K,
%   where K is the number of features (number of column) of DATA.
%
%   BRKCOND is the breaking condition for the distance metric in case a
%   singularity is reached. The distance calculation uses the latest fuzzy
%   partition matrix MEMFCNMAT.
%
%     See also EUCLIDEANDIST, MAHALANOBISDIST, FCM

%  Copyright 2023 The MathWorks, Inc.

[dataSize, numFeatures] = size(data); %#ok<ASGLU>
sumMemFcnMatClusterWise = sum(memFcnMat, 2);
sumMemFcnMat = sum(sumMemFcnMatClusterWise);
numClusters = size(centers, 1);
dist = zeros(size(memFcnMat));
covMat = cell(numClusters, 1);

brkCond = struct('isTrue', 0,'description','');

for clusterId = 1:numClusters
    % Calculate covariance matrix
    dataDiff = data - centers(clusterId, :);
    covMat{clusterId} = (memFcnMat(clusterId, :).*dataDiff'*dataDiff)/sumMemFcnMatClusterWise(clusterId);
    % ---------------------------------------------------------------------
    % NOTE: The vectorized calculation replaces the following computation:
    % ---------------------------------------------------------------------
    % cMat = zeros(numFeatures);
    % for dataPointId = 1:dataSize
    %     dDiff = dataDiff(dataPointId,:)';
    %     mu = memFcnMat(clusterId,dataPointId);
    %     cMat = cMat + mu*(dDiff*dDiff');
    % end
    % cMat = cMat./sumMemFcnMatClusterWise(clusterId);
    % ---------------------------------------------------------------------
    
    % Check singularity condition for the covariance matrix
    rcondValue = rcond(covMat{clusterId});
    if rcondValue<=eps || isnan(rcondValue)
        if ~brkCond.isTrue
            brkCond.isTrue = true;
            brkCond.description = getString(message('fuzzy:general:errFcm_singularCovMat'));
        end
        f = @pinv;
    else
        f = @inv;
    end

    % Calculate prior probability
    priorProb = sumMemFcnMatClusterWise(clusterId)/sumMemFcnMat;

    % Calculate distance
    A = sqrt(det(covMat{clusterId}))/priorProb; % amplitude
    W = f(covMat{clusterId});                   % Weight
    dist(clusterId,:) = A*exp(sum(0.5*(dataDiff*W.*dataDiff),2));
    % ---------------------------------------------------------------------
    % NOTE: The vectorized calculation replaces the following computation:
    % ---------------------------------------------------------------------
    % d = zeros(1,dataSize);
    % for dataPointId = 1:dataSize
    %     dDiff = dataDiff(dataPointId,:)';
    %     W = f(covMat{clusterId});
    %     d(dataPointId) = A*exp(0.5*dDiff'*W*dDiff);
    % end
    % ---------------------------------------------------------------------
end

end