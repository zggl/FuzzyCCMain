function fuzzyPartMat = initfcm(options,dataSize)
%INITFCM Generate initial fuzzy partition matrix for fuzzy c-means clustering.
%
%   FUZZYPARTMAT = INITFCM(OPTIONS, DATASIZE) randomly generates a fuzzy
%   partition matrix FUZZYPARTMAT that is OPTIONS.NUMCLUSTERS by DATASIZE,
%   where NUMCLUSTERS, a property of the OPTIONS object, is the number of
%   clusters and DATASIZE is number of data points. The summation of each
%   column of the generated FUZZYPARTMAT is equal to unity, as required
%   by fuzzy c-means clustering.
%
%     See also EUCLIDEANDIST, MAHALANOBISDIST, FMLE, STEPFCM, FCM

%  Copyright 2022-2023 The MathWorks, Inc.

numCluster = options.NumClusters;

% if isempty(options.ClusterCenters)
    fuzzyPartMat = rand(numCluster, dataSize);
% else
%     fuzzyPartMat = ones(numCluster, dataSize);
% end

col_sum = sum(fuzzyPartMat);
fuzzyPartMat = fuzzyPartMat./col_sum(ones(numCluster, 1), :);
end