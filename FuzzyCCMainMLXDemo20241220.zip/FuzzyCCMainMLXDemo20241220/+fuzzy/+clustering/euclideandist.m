function dist = euclideandist(center, data)
%EUCLIDEANDIST Distance measure in fuzzy c-mean clustering.
%	DIST = EUCLIDEANDIST(CENTER, DATA) calculates the Euclidean distance
%	between each row in CENTER and each row in DATA, and returns a
%	distance matrix DIST of size M by N, where M and N are row
%	dimensions of CENTER and DATA, respectively, and DIST(I, J) is
%	the distance between CENTER(I,:) and DATA(J,:).
%
%     See also MAHALANOBISDIST, FMLE, FCM

%  Copyright 2022-2023 The MathWorks, Inc.

dist = zeros(size(center, 1), size(data, 1));

% Fill the output matrix
for k = 1:size(center, 1)
    dist(k, :) = sqrt(sum(((data-ones(size(data, 1), 1)*center(k, :)).^2), 2));
end
end