function validityIndex = clusterValidityIndex(data,v,u)
%%

%  Copyright 2023 The MathWorks, Inc.

numClusters = size(v,1);
withinGroupVariance = 0;
clusterCenterSeparation = zeros(numClusters);
dataSize = size(data,1);

for clusterId = 1:numClusters
    dataDiff = data - v(clusterId,:);
    groupVariance = sum(u(clusterId,:)'.*sum(dataDiff.*dataDiff,2));
    withinGroupVariance = withinGroupVariance + groupVariance;

    centerSeparation = v - v(clusterId,:);
    clusterCenterSeparation(clusterId,:) = sum(centerSeparation.*centerSeparation,2);
end

id = clusterCenterSeparation==0;
minVal = min(clusterCenterSeparation(~id));
if isempty(minVal)
    minVal = 0;
end
validityIndex = withinGroupVariance/(dataSize*minVal(1));
end