function options = createFCMOptions(varargin)
%CREATEFCMOPTIONS generates options object for fuzzy c-means clustering.
%
%   OPTIONS = CREATEFCMOPTIONS(VARARGIN) generates an OPTIONS object
%   of type FCMOPTIONS that is passed as an input to the FCM function.
%   This function accepts inputs in three forms:
%   (1) No inputs: Creates a new OPTIONS object
%   (2) One input: If numeric, creates a new OPTIONS object with input
%   as NUMCLUSTERS. If input is an FCMOPTIONS object, it is returned
%   as is.
%   (3) Two inputs: If inputs are in legacy format, the OPTIONS
%   object is made according to the inputs.

%  Copyright 2022-2023 The MathWorks, Inc.

n = numel(varargin);

if n == 0
    options = fuzzy.clustering.FCMOptions;
elseif n == 1
    value = varargin{1};
    if isa(value,'fuzzy.clustering.FCMOptions')
        options = value;
    elseif isnumeric(value) || ischar(value) || isstring(value)
        options = fuzzy.clustering.FCMOptions;
        options.NumClusters = value;
    else
        error(message('fuzzy:general:errFcm_provideValidFCMOptionsSet'))
    end
elseif n == 2
    userOptions = preprocessUserOptions(varargin{2});
    options = createAndUpdateOptionsObject(varargin{1},userOptions);
end

end

%% Local functions
function finalOptions = preprocessUserOptions(userOptions)
%%
% Initialize output options.
finalOptions = [...
    fuzzy.clustering.FCMOptions.DefaultExponent ...
    fuzzy.clustering.FCMOptions.DefaultMaxNumIteration ...
    fuzzy.clustering.FCMOptions.DefaultMinImprovement ...
    fuzzy.clustering.FCMOptions.DefaultVerbose ...
    ];

% Assign non-nan user specified option values to output.
maxUserOptions = min(numel(userOptions),numel(finalOptions));
userOptions = userOptions(1:maxUserOptions);
nonNaNIndex = ~isnan(userOptions);
finalOptions(nonNaNIndex) = userOptions(nonNaNIndex);
end

function options = createAndUpdateOptionsObject(numCluster,userOptions)
%%
% Create & update options object.
options = fuzzy.clustering.FCMOptions;
options.NumClusters = numCluster;
options.Exponent = userOptions(1);
options.MaxNumIteration = userOptions(2);
options.MinImprovement = userOptions(3);
options.Verbose = logical(userOptions(4));
end