function varargout = fcm(data, options)
%FCM Data set clustering using fuzzy c-means clustering.
%
%   [CENTER, FUZZYPARTMAT, OBJFCN, INFO] = FCM(DATA,OPTIONS) finds
%   clusters in the data set DATA using options set OPTIONS. DATA size is M-by-N, 
%   where M is the number of data points and N is the number of
%   coordinates/features for each data point. If the number
%   of clusters in OPTIONS is set to 'auto', or it is specified as a vector
%   of multiple cluster numbers, the outputs CENTER, FUZZYPARTMAT, and
%   OBJFCN represent the results for the optimal number of clusters.
%
%   CENTER is a K-by-N matrix where K is the optimal cluster number in the
%   auto-generated cluster numbers. The coordinates for each cluster center
%   are returned in the rows of the matrix CENTER.
% 
%   The membership function matrix FUZZYPARTMAT contains the grade of
%   membership of each DATA point in each cluster. The values 0 and 1
%   indicate no membership and full membership, respectively. Grades between
%   0 and 1 indicate that the data point has partial membership in a
%   cluster. 
% 
%   At each iteration, an objective function is minimized to find
%   the best location for the clusters and its values are returned in
%   OBJFCN.
%
%   Output INFO includes results for each cluster number. INFO is a
%   structure having the following fields:
%       NumClusters         : Auto-generated or user-specified cluster
%                             numbers
%       ClusterCenters      : Cluster centers generated in each FCM
%                             clustering with a different cluster number
%       FuzzyPartitionMatrix: Fuzzy partition matrix generated in each FCM
%                             clustering with a different cluster number
%       ObjectiveFcnValue   : Objective function values generated in each
%                             FCM clustering with a different cluster
%                             number
%       ValidityIndex       : Cluster validity measure/index values
%                             generated in each FCM clustering with a
%                             different cluster number
%       OptimalNumClusters  : Optimal number of clusters K corresponding to
%                             the minimum validity index value
%   For 'mahalanobis'and 'fmle' distance metric (specified in FCMOPTIONS),
%   INFO also includes CovarianceMatrix field that includes covariance
%   matrices of each cluster generated for a specific cluster number.
%
%   Example
%       data = rand(100,2);
%       options = fcmOptions();
%       [center,fuzzyPartMat,objFcn] = fcm(data,options);
%       plot(data(:,1), data(:,2),'o');
%       hold on;
%       maxU = max(U);
%       % Find the data points with highest grade of membership in cluster 1
%       index1 = find(U(1,:) == maxU);
%       % Find the data points with highest grade of membership in cluster 2
%       index2 = find(U(2,:) == maxU);
%       line(data(index1,1),data(index1,2),'marker','*','color','g');
%       line(data(index2,1),data(index2,2),'marker','*','color','r');
%       % Plot the cluster centers
%       plot([center([1 2],1)],[center([1 2],2)],'*','color','k')
%       hold off;
%
%   See also EUCLIDEANDIST, MAHALANOBISDIST, FMLE

%   Copyright 2022-2023 The MathWorks, Inc.

dataSize = size(data, 1);
objFcn = zeros(options.MaxNumIteration, 1);        % Array for objective function
iterationProgressFormat = getString(message('fuzzy:general:lblFcm_iterationProgressFormat'));

maxAutoK = 10;
if isequal(options.NumClusters,fuzzy.clustering.FCMOptions.DefaultNumClusters)
    if dataSize>2
        if isempty(options.ClusterCenters)
            kStart = 2;
        else
            kStart = size(options.ClusterCenters,1);
        end
        maxNumClusters = min(kStart+maxAutoK-1,size(data,1)-1);
        kValues = [kStart kStart+1:maxNumClusters];
    else
        if isempty(options.ClusterCenters)
            kValues = dataSize;
        else
            kValues = size(options.ClusterCenters,1);
        end
    end
else
    kValues = options.NumClusters;
end
lastResults = [];
centers = options.ClusterCenters;
validityIndexOutput = zeros(numel(kValues),2);
ct = 0;
numFolds = numel(kValues);
infoVal = {cell(1,numFolds)};
info = struct(...
    'NumClusters',zeros(1,numFolds), ...
    'ClusterCenters',infoVal, ...
    'FuzzyPartitionMatrix',infoVal, ...
    'ObjectiveFcnValue',infoVal, ...
    'CovarianceMatrix',infoVal, ...
    'ValidityIndex',zeros(1,numFolds), ...
    'OptimalNumClusters',0 ...
    );
minKIndex = Inf;
for k = kValues
    ct = ct + 1;
    
    options.ClusterCenters = [];
    options.NumClusters = k;
    if numel(options.ClusterVolume)~=k 
        if isscalar(options.ClusterVolume)
            options.ClusterVolume = options.ClusterVolume(1,ones(1,k));
        else
            options.ClusterVolume = ones(1,k);
        end
    end
    numCenters = size(centers,1);
    if numCenters>0
        if numCenters<k
            options.ClusterCenters = fuzzy.clustering.addKMPPCenters(data, ...
                centers,k);
        else
            options.ClusterCenters = centers;
        end
    end
    fuzzyPartMat = fuzzy.clustering.initfcm(options,dataSize);  % Initial fuzzy partition matrix
    for iterId = 1:options.MaxNumIteration
        [center, fuzzyPartMat, objFcn(iterId), covMat, stepBrkCond] = fuzzy.clustering.stepfcm(data,fuzzyPartMat,options);

        % Check termination condition
        brkCond = checkBreakCondition(options,objFcn(iterId:-1:max(1,iterId-1)),iterId,stepBrkCond);

        % Check verbose condition
        if options.Verbose
            fprintf(iterationProgressFormat, iterId, objFcn(iterId));
            if ~isempty(brkCond.description)
                fprintf('%s\n',brkCond.description);
            end
        end

        % Break if early termination condition is true.
        if brkCond.isTrue
            objFcn(iterId+1:end) = [];
            break
        end
    end
    validityIndex = fuzzy.clustering.clusterValidityIndex(data,center,fuzzyPartMat);

    if options.Verbose && ~isscalar(kValues)
        fprintf(...
            getString(message('fuzzy:general:msgFCM_currNumClusterAndValidity')),...
            k,validityIndex);
    end

    if isempty(lastResults) || validityIndex<lastResults.validityIndex
        lastResults.center = center;
        lastResults.fuzzyPartMat = fuzzyPartMat;
        lastResults.objFcn = objFcn;
        lastResults.covMat = covMat;
        lastResults.validityIndex = validityIndex;
        lastResults.k = k;
        minKIndex = ct;
    end
    if options.Verbose && ~isscalar(kValues)
        fprintf(...
            getString(message('fuzzy:general:msgFCM_optNumClusterAndValidity')), ...
            lastResults.k,lastResults.validityIndex);
        fprintf('\n');
    end
    if ~isempty(options.ClusterCenters)
        centers = lastResults.center;
    end
    validityIndexOutput(ct,:) = [k validityIndex];

    info.NumClusters(ct) = k;
    info.ClusterCenters{ct} = center;
    info.FuzzyPartitionMatrix{ct} = fuzzyPartMat;
    info.ObjectiveFcnValue{ct} = objFcn;
    info.CovarianceMatrix{ct} = covMat;
    info.ValidityIndex(ct) = validityIndex;
    
end
lastResults.objFcn = objFcn;
lastResults.validityIndexOutput = validityIndexOutput;
info.OptimalNumClusters = lastResults.k;
if strcmp(options.DistanceMetric,getString(message('fuzzy:general:lblFcm_euclidean')))
    info = rmfield(info,"CovarianceMatrix");
end

[varargout{1:nargout}] = assignOutputs(info,minKIndex);
end

%% Local functions
function brkCond = checkBreakCondition(options,objFcn,iterId,stepBrkCond)
%%

if stepBrkCond.isTrue
    brkCond = stepBrkCond;
    return
end

brkCond = struct('isTrue',false,'description','');
improvement = diff(objFcn);
if ~isempty(improvement) && (abs(improvement)<=options.MinImprovement || isnan(improvement))
    brkCond.isTrue = true;
    brkCond.description = getString(message('fuzzy:general:msgFcm_minImprovementReached'));
    return
end

if iterId==options.MaxNumIteration
    brkCond.isTrue = true;
    brkCond.description = getString(message('fuzzy:general:msgFcm_maxIterationReached'));
end
end

function varargout = assignOutputs(info,minIndex)
%%

if nargout>3
    varargout{4} = info;
end
if nargout>2
    varargout{3} = info.ObjectiveFcnValue{minIndex};
end
if nargout>1
    varargout{2} = info.FuzzyPartitionMatrix{minIndex};
end
if nargout>0
    varargout{1} = info.ClusterCenters{minIndex};
end
end