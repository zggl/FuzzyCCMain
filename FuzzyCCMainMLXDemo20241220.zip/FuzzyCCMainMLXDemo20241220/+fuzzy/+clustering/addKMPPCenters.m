function centers = addKMPPCenters(data,centers,k)
%%

%  Copyright 2023 The MathWorks, Inc.

dataSize = size(data,1);
numCenters = size(centers,1);
if numCenters==0
    idx = randperm(dataSize,1);
    centers = [centers;data(idx,:)];
    numCenters = numCenters + 1;
end
% Select the remaining centers
for count = numCenters+1:k
    dist = zeros(dataSize,numCenters);
    for centerId = 1:numCenters
        dataDiff = data - centers(centerId,:);
        dist(:,centerId) = sum(dataDiff.*dataDiff,2);
    end
    dist = min(dist,[],2);
    sumDist = sum(dist);
    numCenters = numCenters + 1;
    if sumDist==0
        centers(numCenters,:) = centers(centerId,:);
        continue
    end
    dist = dist/sumDist;
    [dist,idx] = sort(dist);
    dist = cumsum(dist);
    rndVal = rand(1);
    rndValId = find(dist>=rndVal,1);
    centers(numCenters,:) = data(idx(rndValId),:);
end

end