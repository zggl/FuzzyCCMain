classdef (Sealed) SymbolicRuleKeyWords < fuzzy.internal.fis.RuleKeyWords
%% SymbolicRuleKeyWords - Symbolic keywords used in a fuzzy rule
%
%  SymbolicRuleKeyWords defines Symbolic keywords used in a text fuzzy rule.
%  It implemented the interface defined by RuleKeyWords.
% 
%  The following default property values are used for Symbolic keywords:
%
%    Property    Value 
%    --------    -----
%    If          ''
%    And         '&'
%    Or          '|'
%    Then        '=>'
%    Equal       '=='
%    Is          '='
%    Not         '~='
%    IsNot       '~='

%  Copyright 2017-2018 The MathWorks, Inc.
    
    properties(SetAccess=protected)
        %% If - Symbolic expression for 'if'
        %   Its default value is specified as ''.
        If = '';
        
        %% And - Symbolic expression for 'and'
        %   Its default value is specified as '&'.
        And = '&';
        
        %% Or - Symbolic expression for 'or'
        %   Its default value is specified as '|'.
        Or = '|';
        
        %% Then - Symbolic expression for 'then'
        %   Its default value is specified as '=>'.
        Then = '=>';
        
        %% Equal - Symbolic expression for 'equal'
        %   Its default value is specified as '=='.
        Equal = '==';
        
        %% Is - Symbolic expression for 'is'
        %   Its default value is specified as '='.
        Is = '=';
        
        %% Not - Symbolic expression for 'not'
        %   Its default value is specified as '~='.
        Not = '~=';
        
        %% IsNot- Symbolic expression for 'is not'
        %   Its default value is specified as '~='.
        IsNot = '~=';
    end
    
    %% Constructor
    methods
        function obj = SymbolicRuleKeyWords(varargin)            
            %% SymbolicRuleKeyWords - Constructor
            %
            %   OBJ = SymbolicRuleKeyWords(NAME,VALUE) constructs an
            %   SymbolicRuleKeyWords object.
            %
            %   You can specify the following parameter name/value pair:
            %
            %     WithSpace - A logical flag that specifies if the keywords
            %     are expressed with leading and trailing spaces. Its
            %     default value is 'false'.            
            
            obj = obj@fuzzy.internal.fis.RuleKeyWords(varargin{:});
            if obj.WithSpace
                obj.If = ' ';
                obj.Equal = strip(obj.Equal);
                obj.Is = strip(obj.Is);                
                obj.IsNot = strip(obj.IsNot);                
            end
        end
    end
end