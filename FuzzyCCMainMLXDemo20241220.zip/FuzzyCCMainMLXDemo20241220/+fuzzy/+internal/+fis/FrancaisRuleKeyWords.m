classdef (Sealed) FrancaisRuleKeyWords < fuzzy.internal.fis.RuleKeyWords
%% FrancaisRuleKeyWords - Francais keywords used in a fuzzy rule
%
%  FrancaisRuleKeyWords defines Francais keywords used in a text fuzzy
%  rule. It implemented the interface defined by RuleKeyWords.
% 
%  The following default property values are used for Francais keywords:
%
%    Property    Value 
%    --------    -----
%    If          'Si '
%    And         ' et '
%    Or          ' ou '
%    Then        ' alors '
%    Equal       ' est '
%    Is          ' est '
%    Not         ' n'est_pas '
%    IsNot       ' n'est_pas '

%  Copyright 2017-2018 The MathWorks, Inc.
    
    properties(SetAccess=protected)
        %% If - Francais expression for 'if'
        %   Its default value is specified as 'Si '.
        If = 'Si ';
        
        %% And - Francais expression for 'and'
        %   Its default value is specified as ' et '.
        And = ' et ';
        
        %% Or - Francais expression for 'or'
        %   Its default value is specified as ' ou '.
        Or = ' ou ';
        
        %% Then - Francais expression for 'then'
        %   Its default value is specified as ' alors '.
        Then = ' alors ';
        
        %% Equal - Francais expression for 'equal'
        %   Its default value is specified as ' est '.
        Equal = ' est ';
        
        %% Is - Francais expression for 'is'
        %   Its default value is specified as ' est '.
        Is = ' est ';
        
        %% Not - Francais expression for 'not'
        %   Its default value is specified as ' n'est_pas '.
        Not = ' n''est_pas ';
        
        %% IsNot- Francais expression for 'is not'
        %   Its default value is specified as ' n'est_pas '.
        IsNot = ' n''est_pas ';
    end

    methods
        function obj = FrancaisRuleKeyWords(varargin)            
            %% FrancaisRuleKeyWords - Constructor
            %
            %   OBJ = FrancaisRuleKeyWords(NAME,VALUE) constructs a
            %   FrancaisRuleKeyWords object.
            %
            %   You can specify the following parameter name/value pair:
            %
            %     WithSpace - A logical flag that specifies if the keywords
            %     are expressed with leading and trailing spaces. Its
            %     default value is 'false'.            
            obj = obj@fuzzy.internal.fis.RuleKeyWords(varargin{:});
        end
    end
    
end