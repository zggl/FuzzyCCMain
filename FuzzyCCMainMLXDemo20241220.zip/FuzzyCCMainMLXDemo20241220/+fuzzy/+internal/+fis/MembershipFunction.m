classdef MembershipFunction
    %% MembershipFunction - Abstract class for membership functions
    %
    %  MembershipFunction defines the common interface for type-1 and
    %  type-2 membership functions (MFs).
    %
    %  MembershipFunction properties:
    %    Name - MF name, which is a character vector or a scalar string
    %
    %  MembershipFunction methods:
    %    No public methods defined here.
    %
    %  Subclass of MembershipFunction must define the following abstract
    %  property:
    %    EvalfisData - Contains FIS data in structure format.
    %
    %  Subclass of MembershipFunction must define the following abstract
    %  methods:
    %    getMembershipValue - Evaluates an MF and returns the output value.
    %    plot               - Plots an MF.
    %
    %   See also
    %       fismf, fismftype2
    
    %  Copyright 2019-2020 The MathWorks, Inc.
   
    properties(Dependent)
        %Name Membership function name
        %
        %  Name is a string scalar that specifies the name of a membership
        %  function. If name is not provided at construction time, the
        %  default name "mf" is used.
        Name
    end

    properties(Access=private)
        LocalName
    end

    properties(Access={?fuzzy.internal.fis.MembershipFunction,?fisvar})
        UsingDefaultName = false;
    end

    properties(Abstract,Access=protected)
        % Adding this property to speed up structure conversion process for
        % FIS evaluation.
        EvalfisData
    end
    
    properties(SetAccess=immutable,GetAccess=protected)
        UnmatchedInputArguments
    end
    
    %% Constructor
    methods
        function mf = MembershipFunction(varargin)
                        
            p = inputParser;
            p.KeepUnmatched = 1;
            p.addParameter('Name',fuzzy.internal.utility.defaultMFPrefix)
            p.parse(varargin{:})
            
            if (fuzzy.internal.utility.isCharRowVector(p.Results.Name) || ...
                    isStringScalar(p.Results.Name)) && ...
                    p.Results.Name == fuzzy.internal.utility.defaultMFPrefix
                mf.LocalName = "mf";
                mf.UsingDefaultName = true;                
            else
                try
                    mf.Name = p.Results.Name;
                catch me
                    throw(me)
                end
            end            
            mf.UnmatchedInputArguments = p.Unmatched;
        end
    end
    
    %% Set/Get
    methods
        function mf = set.Name(mf,value)            
            try
                fuzzy.internal.utility.validCharOrString(...
                    'Membership function name',value);
                if ischar(value)
                    value = string(value);
                end
                % Not updating EvalfisData.name due to unicode
                % conversion problem in MEX.
                mf.LocalName = value;
                mf.UsingDefaultName = false;                
            catch me
                throw(me)
            end
        end
        
        function value = get.Name(mf)
            value = mf.LocalName;
        end
    end
   
    %% Hidden methods
    methods(Hidden,Abstract)
        varargout = getMembershipValue(mf,x)
        plot(mf,x,varargin)
    end

    methods(Hidden,Sealed)
        function value = convertToStruct(mf)
            for i = 1:numel(mf)
                value(i) = mf(i).EvalfisData; %#ok<AGROW>
            end
        end
    end
        
end