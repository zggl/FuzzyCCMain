classdef Type1FuzzyInferenceSystem
    %
    
    %
    
    %  Copyright 2019 The MathWorks, Inc.

    %% Public methods
    methods
        function s = convertToStruct(fis)
            %% CONVERTTOSTRUCT Converts a FIS object to a FIS structure.
            %
            %   FISOUT = convertToStruct(FISIN) converts FISIN object to
            %   FISOUT structure.
            %
            %   Examples
            %
            %     fisin = readfis('tipper');
            %     fisout = CONVERTTOSTRUCT(fisin);
            %
            %   Copyright 2018-2019 The MathWorks, Inc.
                        
            try
                checkFISScalar(fis)
                s = fuzzy.internal.utility.convertToStruct(fis);
            catch me
                throw(me)
            end
        end
        
        function fisout = convertToType2(fisin)
            %% CONVERTTOTYPE2 Converts a type-1 FIS to a type-2 FIS.
            %
            %   FISOUT = convertToType2(FISIN) converts type-1 FISIN object
            %   to type-2 FISOUT object. Each type-1 membership function
            %   (except Sugeno output membership functions) is converted to
            %   a type-2 membership function with default LowerScale and
            %   LowerLag values. FISOUT uses the default type reduction
            %   method, which is "karnikmendel".
            %
            %   Examples
            %
            %     fisin = readfis('tipper');
            %     fisout = CONVERTTOTYPE2(fisin);
            %
            %   Copyright 2019 The MathWorks, Inc.
            
            fisout = createYourType2(fisin);
            for i = 1:numel(fisin.Inputs)
                fisout = addInput(fisout,fisin.Inputs(i).Range, ...
                    "Name",fisin.Inputs(i).Name);
                for j = 1:numel(fisin.Inputs(i).MembershipFunctions)
                    fisout = addMF(fisout,fisin.Inputs(i).Name, ...
                        fisin.Inputs(i).MembershipFunctions(j).Type, ...
                        fisin.Inputs(i).MembershipFunctions(j).Parameters, ...
                        "Name",fisin.Inputs(i).MembershipFunctions(j).Name, ...
                        "VariableType","input" ...
                        );
                end
            end
            
            for i = 1:numel(fisin.Outputs)
                fisout = addOutput(fisout,fisin.Outputs(i).Range, ...
                    "Name",fisin.Outputs(i).Name);
                for j = 1:numel(fisin.Outputs(i).MembershipFunctions)
                    fisout = addMF(fisout,fisin.Outputs(i).Name, ...
                        fisin.Outputs(i).MembershipFunctions(j).Type, ...
                        fisin.Outputs(i).MembershipFunctions(j).Parameters, ...
                        "Name",fisin.Outputs(i).MembershipFunctions(j).Name, ...
                        "VariableType","output" ...
                        );
                end
            end
            
            fisout.Rules = fisin.Rules;
        end
    end
    
    %% Protected methods
    methods(Access=protected)
        function validateInputFuzzySetTypeLocal(~,value)
            for i = 1:numel(value)
                if ~any(class(value(i).MembershipFunctions) == "fismf")
                    error(message("fuzzy:general:errType1FIS_invalidT1FS"))
                end
            end
        end

        function validateOutputFuzzySetTypeLocal(fis,value)
            validateInputFuzzySetTypeLocal(fis,value)
        end
        
        function var = setDefaultInputFuzzySetTypeLocal(~,var)
            for i = 1:numel(var)
                if isempty(var(i).MembershipFunctions) && ...
                        ~isa(var(i).MembershipFunctions,'fismf')
                    var(i).MembershipFunctions = fismf.empty;
                end
            end
        end       
        
        function var = setDefaultOutputFuzzySetTypeLocal(fis,var)
            var = setDefaultInputFuzzySetTypeLocal(fis,var);
        end

        function paramValues = parseSettingsParamValuesLocal(~,mixedType,varargin)
            paramValues = [];
            if mixedType
                return
            end
            if ~isempty(varargin)
              error(message("fuzzy:general:errT1FIS_unrecognizedSettingInput"))
            end
        end
        
    end
    
    %% Abstract protected methods
    methods(Access=protected)
        fisout = createYourType2(fisin)            
    end
end
%% Helper functions -------------------------------------------------------
function checkFISScalar(fis)
if ~isscalar(fis)
    error(message("fuzzy:general:errFIS_NonscalarFIS"))
end
end