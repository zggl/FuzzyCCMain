classdef EvalFISOptions
    %EVALFISOPTIONS Abstract interface for EVALFIS options.
    %
    %  Methods:
    %    None
    %
    %  Abstract properties:
    %    NumSamplePoints             - Number of sample points used in output range
    %    OutOfRangeInputValueMessage - Diagnostic type for out of range input values
    %    NoRuleFiredMessage          - Diagnostic type for no-rule-fired codition
    %    EmptyOutputFuzzySetMessage  - Diagnostic type for empty output fuzzy sets
    %
    %  Subclass of EVALFISOPTIONS must implement abstract properties.
    %
    %  See also
    %    fuzzy.evalfis.EvalFISOptions fuzzy.internal.codegen.EvalFISOptions
    
    %  Copyright 2018 The MathWorks, Inc.
    
    %#codegen
    
    properties(Abstract)
        % NumSamplePoints - Number of sample points used in output range
        %
        %   NumSamplePoints is the number of sample points on which to
        %   evaluate the membership functions over the output range. The
        %   specified number of sample points must be greater than 1. The
        %   default value of NumSamplePoints is set to 101.
        %
        %   NumSamplePoints must be a finite, positive, integer value.
        NumSamplePoints
        
        % OutOfRangeInputValueMessage - Diagnostic type for out of range input values 
        %
        %   OutOfRangeInputValueMessage indicates the diagnostic type used
        %   for out of range input values. Diagnostic type is either
        %   "none", "warning", or "error". The default value is "warning".
        OutOfRangeInputValueMessage
        
        % NoRuleFiredMessage - Diagnostic type for no-rule-fired condition 
        %
        %   NoRuleFiredMessage indicates the diagnostic type used when no
        %   fuzzy rule is fired due to zero rule firing strengths.
        %   Diagnostic type is either "none", "warning", or "error". The
        %   default value is "warning".
        NoRuleFiredMessage
        
        % EmptyOutputFuzzySetMessage - Diagnostic type for empty output fuzzy sets 
        %
        %   EmptyOutputFuzzySetMessage indicates the diagnostic type used
        %   when an output fuzzy set is empty. Diagnostic type is either
        %   "none", "warning", or "error". The default value is "warning".
        EmptyOutputFuzzySetMessage
    end    
end