classdef UsesFISTree < handle
    %% This is a mixing class having friend access to FISTREE class.

    %  Copyright 2022 The MathWorks, Inc.
end