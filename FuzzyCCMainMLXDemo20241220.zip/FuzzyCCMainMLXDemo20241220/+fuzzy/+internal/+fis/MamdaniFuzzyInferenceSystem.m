classdef MamdaniFuzzyInferenceSystem
    %
    
    %
    
    %  Copyright 2019 The MathWorks, Inc.
    
    %% Constant properties
    properties(Constant,Hidden)
        DefaultTypeValue = "mamdani";
        DefaultAndValue = "min";
        DefaultOrValue = "max";
        DefaultImpValue = "min";
        DefaultAggValue = "max";
        DefaultDefuzzValue = "centroid";
        DefaultOutputMFTypeValue = getDefaultOutputMFType;
        DefaultOutputMFParametersValue = getDefaultOutputMFParameters;
    end
    
    %% Public methods
    methods
        function fis = convertToSugeno(fis,varargin)
            %CONVERTTOSUGENO Converts a Mamdani FIS to Sugeno type.
            %
            %   FISOUT = CONVERTTOSUGENO(FISIN) Converts Mamdani FISIN to
            %   Sugeno FISOUT using default parameter values.
            %
            %   FISOUT = CONVERTTOSUGENO(FISIN,NAME1,VALUE1,...) Converts
            %   Mamdani FISIN to Sugeno FISOUT using following parameter
            %   NAME/VALUE pairs:
            %
            %     NumSamplePoints       - Number of output sample points
            %                             used for defuzzification of
            %                             consequent membership functions
            %                             of FISIN. It must be greater
            %                             than 1. Default value is 101.
            %     DefuzzificationMethod - Defuzzification method of FISOUT.
            %                             It is either "wtsum" or "wtaver".
            %                             Default value is "wtaver".
            %     OutputMFType          - Output membership function type
            %                             of FISOUT. It is either
            %                             "constant" or "linear". Default
            %                             value is "constant".
            %
            %   FISOUT uses
            %     - "prod" implication method and
            %     - "sum" aggregation method.
            %
            %   The remaining parameters of FISOUT are the same as FISIN.
            %
            %   Examples
            %       fisin = mamfis('NumInputs',2,'NumInputMFs',2, ...
            %           'NumOutputs',2,'NumOutputMFs',3,'AddRules','none');
            %       fisin = addRule(fisin,[1 1 1 3 1 1;1 2 2 3 1 1; ...
            %           2 1 2 2 1 1;2 2 3 1 1 1]);
            %       fisout = convertToSugeno(fisin);
            %       subplot(2,2,1)
            %       gensurf(fisin,[1 2],1)
            %       title('Mamdani system (Output 1)')
            %       subplot(2,2,2)
            %       gensurf(fisout,[1 2],1)
            %       title('Sugeno system (Output 1)')
            %       subplot(2,2,3)
            %       gensurf(fisin,[1 2],2)
            %       title('Mamdani system (Output 2)')
            %       subplot(2,2,4)
            %       gensurf(fisout,[1 2],2)
            %       title('Sugeno system (Output 2)')
            %
            %   See also
            %     sugfis
            
            %   Copyright 2017-2022 The MathWorks, Inc.
            
            import fuzzy.internal.utility.validateNumOutputSample
            
            try
                p = inputParser();
                p.addParameter('NumSamplePoints',101,@(x)validateNumOutputSample(x));
                p.addParameter('DefuzzificationMethod','wtaver',@validateDefuzzMethodParam);
                p.addParameter('OutputMFType',"constant",@checkOutputMFType);
                p.parse(varargin{:});
                
                fisTemp = convertToSugenoAsPerType(fis);
                
                fisTemp.Name = fis.Name;
                fisTemp.AndMethod = fis.AndMethod;
                fisTemp.OrMethod = fis.OrMethod;
                fisTemp.Input = fis.Inputs;
                fisTemp.DefuzzificationMethod = p.Results.DefuzzificationMethod;
                outputMFType = fuzzy.internal.utility.convertToCharIfStringOrFcnHandle(...
                    p.Results.OutputMFType);
                
                coefs = zeros(1,length(fis.Inputs));
                for i = 1:length(fis.Outputs)
                    range = fis.Outputs(i).Range;
                    x = linspace(range(1),range(2),p.Results.NumSamplePoints);
                    fisTemp = addOutput(fisTemp,range,'Name',fis.Outputs(i).Name);
                    for j = 1:length(fis.Outputs(i).MembershipFunction)
                        memVal = evalmf(fis.Outputs(i).MembershipFunction(j),x);
                        defuzzVal = defuzz(x,memVal,fis.DefuzzificationMethod);
                        if outputMFType == "constant"
                            newParams = defuzzVal;
                            fisTemp.Output(i).MembershipFunction(j) = ...
                                fismf('constant',newParams, ...
                                'Name',fis.Outputs(i).MembershipFunction(j).Name);
                        else
                            newParams = [coefs defuzzVal];
                            fisTemp.Output(i).MembershipFunction(j) = ...
                                fismf('linear',newParams, ...
                                'Name',fis.Outputs(i).MembershipFunction(j).Name);
                        end
                    end
                end
                fisTemp.Rule = fis.Rule;
                fis = fisTemp;
                
            catch me
                throw(me)
            end
        end
    end
    
    %% Abstract protected methods
    methods(Abstract,Access=protected)
        fis = convertToSugenoAsPerType(fis);
    end
    
    %% Protected methods
    methods(Access=protected)
        function validateDefuzzificationMethodLocal(~,value,isFcnHandle)
            if any(value == ["wtaver" "wtsum"])
                if isFcnHandle
                    error(message("fuzzy:general:errMamfis_InvalidDefuzzMethodHandle"))
                else
                    error(message("fuzzy:general:errMamfis_InvalidDefuzzMethodName"))
                end
            end
        end
        
        function [refValue,msgKey] = getDefaultOutputMFTypeOptionsLocal(~,varargin)
            [refValue,msgKey] = fuzzy.internal.utility.defaultCommonMFTypeOptions(varargin{:});
        end
        
        function validateOutputMFTypeLocal(~,value,isFcnHandle)
            if any(ismember(value,["constant" "linear"]))
                if isFcnHandle
                    error(message("fuzzy:general:errMamfis_InvalidOutputMFTypeHandle"))
                else
                    error(message("fuzzy:general:errMamfis_InvalidOutputMFTypeName"))
                end
            end
        end
        
        function id = getNonExistenceImpMsgIDLocal(~,isFcnHandle)
            if isFcnHandle
                id = "fuzzy:general:errFIS_NonexistentMamImpMethodHandle";
            else
                id = "fuzzy:general:errFIS_NonexistentMamImpMethodName";
            end
        end
        
        function id = getNonExistenceAggMsgIDLocal(~,isFcnHandle)
            if isFcnHandle
                id = "fuzzy:general:errFIS_NonexistentMamAggMethodHandle";
            else
                id = "fuzzy:general:errFIS_NonexistentMamAggMethodName";
            end
        end
        
        function id = getNonExistenceDefuzzMsgIDLocal(~,isFcnHandle)
            if isFcnHandle
                id = "fuzzy:general:errFIS_NonexistentMamDefuzzMethodHandle";
            else
                id = "fuzzy:general:errFIS_NonexistentMamDefuzzMethodName";
            end
        end
    end
    
end
%% Helper functions -------------------------------------------------------
function mfType = getDefaultOutputMFType
options = fuzzy.internal.utility.defaultCommonMFTypeOptions;
mfType = options{1};
end

function params = getDefaultOutputMFParameters
params = fuzzy.internal.utility.createMFParams(getDefaultOutputMFType);
end

function validateDefuzzMethodParam(value)
fuzzy.internal.utility.validCharOrString('DefuzzificationMethod',value);

if ~any(strcmp(value,{'wtsum','wtaver'}))
    error(message('fuzzy:general:errSugenoFIS_InvalidDefuzzificationMethod', ...
        value));
end
end

function checkOutputMFType(value)
[refValue,msgKey] = fuzzy.internal.utility.defaultSugenoOutputMFTypeOptions;
fuzzy.internal.utility.validateMFTypeWithReference(value,refValue,msgKey)
end