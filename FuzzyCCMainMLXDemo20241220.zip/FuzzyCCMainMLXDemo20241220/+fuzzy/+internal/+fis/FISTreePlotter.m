classdef FISTreePlotter < fuzzy.internal.fis.UsesFISTree
    %% FISTreePlotter - Plot a visual representation of the FIS Tree
    %
    %  This class is called through the fistree private method plot

    %  Copyright 2020-2023 The MathWorks, Inc.
    properties(Access=private)
        Padding = 20;
        NumberYAxisThinLayers
        NumLayerWiseInputsOutputs
        DetailWidth
        DetailHeight
        MaxAxisHeight
        LineWidth = 2;
        LineStyle = '-';
        UnusedOutputLineStyle = '-.';
        LastLineSelected
        LastLineUnderMotion
        OutputToInputConnectionGap = 10;
        TopAndBottomConnectionGap = 10;
        NumIIConnectionInLayer
        NumBottomOIConnections = 0;
        NumTopIIConnections = 0;
        NumConsecOIBetweenEachLayer
        NumNonConsecOIBetweenEachLayer
        Marker = '.' % To keep all markers hidden. "None" or "." is used as a marker
        MarkerSize = 20
        OffsetFactor = 0.2;
        ShowLegend = false;
        Scrollable = false;
        LegendData
        LegendHeight
        InputOutputFontSize = 10;
        FISNameFontSize = 12;
        LegendPadding = 45;
        LegendButton
        LegendButtonDefaultCallback

        IsUpdate = false

        DefaultFISLineWidth = 0.5
        SelectWidth = 2

        UnusedArrows

        FISPrefix = "FIS"
        InputPrefix = "Input"
        OutputPrefix = "Output"
        ConnectionPrefix = "Connection"
        UnusedSuffix = "arrowhead"
        IIPrefix = "II"
        OIPrefix = "OI"

        MouseDownObject

        SemanticSelectColor = "--mw-graphics-colorOrder-10-primary"

        LocalAppMode = false
    end

    properties(SetAccess=private,GetAccess={?matlab.unittest.TestCase})
        OutputCenterMarkers
        InputMarkerBetweenLayers
        OutputPosition
        InputPosition
        InputMarkerXDirLayers
        OutputMarkerXDirLayers
        OutputMarkerBetweenLayers
        PreProcessedII
        PreProcessedOI
        FISLayerDistribution
        FISBlockPos
        LayerWidths
        InputToInputNamePadding = 15 % To prevent overlap between the i-i connection and the name text
        FISBoxNamePadding = 10
        FISBlockWidth = 60;
        InputToInputConnectionGap = 10
        TextToBoxPadding = 5 % To create gap between the name and edge of FIS block
        EachYAxisThinLayerWidth = 40;
        Layer
        LastSelectedObject
        SemanticDetailAxesColor = '--mw-graphics-backgroundColor-axes-primary'
        SemanticFISBlockColor = '--mw-graphics-backgroundColor-axes-primary'
        SemanticHiliteColor = '--mw-graphics-colorOrder-8-primary'
        SemanticInputColor = '--mw-graphics-colorOrder-1-primary'
        SemanticDefaultColor = '--mw-graphics-colorNeutral-region-secondary'
        SemanticOutputColor = '--mw-graphics-colorOrder-2-primary'
        SemanticUnusedOutputColor = '--mw-graphics-colorOrder-2-primary'
        SemanticConnectionColor = '--mw-graphics-colorNeutral-region-secondary'
    end
    
    properties(SetAccess=private,GetAccess={...
            ?fuzzy.app.utils.FuzzySystemAppComponent, ...
            ?matlab.unittest.TestCase})
        DetailLegend
        DetailAxes
        FISPatches
        InputText
        OutputText
        FISNameText
        OIMarkers
        IIMarkers
        FreeInputLines
        FreeInputObjects
        FreeOutputObjects
        IntermediateOutputObjects
        OIConnObjects
        IIConnObjects
        IIConnectionOrder
        OIConnectionOrder
        UnusedOutputObjects
    end

    properties(Access={?fuzzy.app.utils.FuzzySystemAppComponent, ...
            ?matlab.unittest.TestCase})
        FTREE
        SimMode = false
        OutputLegend = string(getString(message('fuzzy:general:labelFISTreePlotLegendOutput')))
    end

    properties(Dependent,Access={?fuzzy.app.utils.FuzzySystemAppComponent, ...
            ?matlab.unittest.TestCase})
        AppMode
    end
    
    events(NotifyAccess=private,ListenAccess=public)
        ComponentSelected
    end

    %% Constructor
    methods
        function obj = FISTreePlotter(tree)
            % Creates a FISTreePlotter object.
            %
            %   obj = FISTreePlotter(FISTree) returns obj, a FISTreePlotter
            %   object with FTREE property initialized to the provided FIS
            %   tree
            obj.FTREE = tree;
        end
    end

    %% Sets/Gets
    methods
        function set.FTREE(obj,value)
            %% Sets value of FTREE.

            obj.FTREE = value;
            updateVisiblePlot(obj)
        end

        function set.AppMode(obj,value)
            %%
            obj.LocalAppMode = value;
            if obj.AppMode
                obj.SemanticOutputColor = '--mw-graphics-colorSpace-rgb-green';
                obj.SemanticUnusedOutputColor = '--mw-graphics-colorSpace-rgb-green';
            else
                obj.SemanticOutputColor = '--mw-graphics-colorOrder-2-primary';
                obj.SemanticUnusedOutputColor = '--mw-graphics-colorOrder-2-primary';
            end
        end

        function value = get.AppMode(obj)
            %%
            value = obj.LocalAppMode;
        end
    end

    %% Public methods
    methods
        function plot(obj,varargin)
            %% Plots a visual representation of the fistree when called
            % through the plotfis command

            numVarArg = numel(varargin);

            if numVarArg > 0
                obj.ShowLegend = varargin{1};
                if numVarArg > 1
                    fig = varargin{2};
                    if isempty(fig)|| ~isvalid(fig) || ...
                            (isa(fig,'matlab.ui.Figure') && ...
                            ~matlab.ui.internal.isUIFigure(fig))
                        return
                    end
                end
            else
                obj.ShowLegend = false;
            end

            reset(obj)

            if ~obj.ShowLegend
                obj.LegendHeight = 0;
            end

            % Get number of layers and each FIS layer location
            getFISLayers(obj);

            % Preprocess connections
            getPreprocessedConnections(obj)

            % Get X-axis layer Widths based on the input,output and FIS
            % Names
            getLayerWidths(obj);

            % Generate dimensions for figure and axes
            getAxesDimensions(obj);

            % Generate figure and axes
            if numVarArg > 1
                setFigureAndAxesProps(obj,fig);
            else
                setFigureAndAxesProps(obj);
            end

            % Plot fis tree details
            plotDetails(obj);

            % Adjust name Y position in detail axes
            adjustNameHeights(obj)

            % Add a legend
            createLegends(obj)

            % Adjust Dialog Width
            adjustDialogAndAxesWidth(obj)

            % Set legend visibility
            obj.DetailLegend.Visible = obj.ShowLegend;

            obj.IsUpdate = true;
        end
    end

    %% Private methods
    methods(Access=private)

        function updateVisiblePlot(obj)
            %% Updates a visible plot.

            if obj.AppMode
                return
            end

            valid = @(x)~isempty(x)&&isvalid(x);
            if valid(obj.DetailAxes) && obj.DetailAxes.Visible
                if ~isempty(obj.DetailAxes.Parent) && isa(obj.DetailAxes.Parent,'matlab.ui.Figure')
                    plot(obj,obj.ShowLegend)
                else
                    plotWithExistingData(obj)
                end
            end
        end

        function plotWithExistingData(obj)
            %% Plots FISTREE with existing data.
            fig = gcf;
            clf(fig,'reset')
            if ~isequal(fig.MenuBar,'figure')
                fig.MenuBar = 'figure';
            end
            obj.DetailAxes.Parent = fig;
            legendButton = findall(fig,'Tag','Annotation.InsertLegend');
            if legendButton.State == matlab.lang.OnOffSwitchState.on
                legendButton.State = matlab.lang.OnOffSwitchState.off;
            end
            if isa(legendButton, 'matlab.ui.container.toolbar.ToggleTool')
                obj.LegendButtonDefaultCallback = legendButton.ClickedCallback;
                % Delete the handle collected from the previous figure.
                delete(obj.LegendButton)
                % Attach the legend button of the current figure.
                obj.LegendButton = legendButton;
                legendButton.ClickedCallback = @(s,e)cbLegendToggle(obj);
            end
        end

        function [highestCharLength,highestPixelLength] = ...
                getHighestCharPixelLength(obj,fisNumber,textObj,iter,highestCharLength,highestPixelLength)
            %% Get length of the longest input or output names in each layer

            iterable = obj.FTREE.FIS(fisNumber).(iter);
            for iterNumber = 1:numel(iterable)
                curName = iterable(iterNumber).Name;
                curLength = numel(char(curName));
                [highestCharLength, highestPixelLength] = getPixelSizeIfStrLengthIsHigher(...
                    textObj, curName, curLength, highestCharLength, highestPixelLength,obj.InputOutputFontSize);
            end
            % Maintain minimum width
            if highestPixelLength < obj.FISBlockWidth
                highestPixelLength = obj.FISBlockWidth;
            end

        end

        function getPreprocessedConnections(obj)
            %% Preprocess OI and II connections
            preProcessIIForPlotting(obj);
            preProcessOIForPlotting(obj);
        end

        function plotDetails(obj)
            %% Plots a detailed FIS tree structure with all the connections
            getFisBlockPositions(obj);
            plotFreeOutputs(obj);
            plotFreeInputs(obj);
            adjustInputOutputPositions(obj);
            determineTopBottomMarkers(obj,obj.PreProcessedII,"II")
            determineTopBottomMarkers(obj,obj.PreProcessedOI,"OI")
            determineInputOutputMarkers(obj,obj.PreProcessedII,"II")
            determineInputOutputMarkers(obj,obj.PreProcessedOI,"OI")
            determineConsecLayerOutputMarkers(obj)
            plotOutputToInputConnections(obj);
            plotInputToInputConnection(obj);
            plotFisBlocks(obj);
            adjustInputNames(obj);
            plotIntermediateAndUnusedOutputs(obj);

        end

        function adjustInputOutputPositions(obj)
            %% Adjust input and output position if they exactly align in consecutive layers
            gapToCheck = 3; % If the input and output are very close
            gapToCreate = 6; % Set them this distance apart (in pixels)
            inputPos = obj.InputPosition;
            outputPos = obj.OutputPosition;
            layer = obj.Layer;
            fisLayerDis = obj.FISLayerDistribution;
            for curlayer = 2:layer
                fisInCurrentLayer = find(fisLayerDis == (curlayer));
                fisInPrevLayer = find(fisLayerDis == (curlayer-1));
                for inputFisIdx = 1:numel(fisInCurrentLayer)
                    inputFIS = fisInCurrentLayer(inputFisIdx);
                    for inputNumber = 1:size(inputPos,2)
                        if isempty(inputPos{inputFIS,inputNumber})
                            continue;
                        end
                        for outputFisIdx = 1:numel(fisInPrevLayer)
                            outputFIS = fisInPrevLayer(outputFisIdx);
                            for outputNumber = 1:size(outputPos,2)
                                % Check Y value
                                if isempty(outputPos{outputFIS,outputNumber})
                                    continue;
                                end
                                % Get the gap between Y value of the input and output
                                gap = abs(inputPos{inputFIS,inputNumber}(3) - outputPos{outputFIS,outputNumber}(3));
                                if  gap <= gapToCheck
                                    inputPos{inputFIS,inputNumber}(3) = inputPos{inputFIS,inputNumber}(3) + gapToCreate/2;
                                    inputPos{inputFIS,inputNumber}(4) = inputPos{inputFIS,inputNumber}(3);
                                    outputPos{outputFIS,outputNumber}(3) = outputPos{outputFIS,outputNumber}(3) - gapToCreate/2;
                                    outputPos{outputFIS,outputNumber}(4) = outputPos{outputFIS,outputNumber}(3);
                                end
                            end
                        end
                    end
                end
            end
            obj.InputPosition = inputPos;
            obj.OutputPosition = outputPos;
        end

        function adjustInputNames(obj)
            %% Adjust name position based on the difference between actual
            % and expected name position
            numIIConnectionInLayer = obj.NumIIConnectionInLayer;
            fisLayerDistribution = obj.FISLayerDistribution;
            inputText = obj.InputText;
            fisBlockPos = obj.FISBlockPos;
            for fisNumber = 1:numel(obj.FTREE.FIS)
                currFISPosition = fisBlockPos{fisNumber};
                for inputNumber = 1:numel(obj.FTREE.FIS(fisNumber).Inputs)
                    mytext = inputText{fisNumber,inputNumber};
                    if isempty(mytext)
                        continue
                    end
                    if ~isempty(numIIConnectionInLayer)
                        % Add space for all the II connections and extra 15
                        % pixels to accommodate for space between FIS edge
                        % and first II connnection vertical line
                        adjForIIConn = (numIIConnectionInLayer(fisLayerDistribution(fisNumber))-1)*...
                            obj.InputToInputConnectionGap + obj.InputToInputNamePadding;
                    else
                        adjForIIConn = 0;
                    end
                    mytext.Position(1) = currFISPosition(1)-mytext.Extent(3)-adjForIIConn-obj.TextToBoxPadding;
                end
            end
        end

        function plotFisBlocks(obj)
            detailAxes = obj.DetailAxes;
            fisBlockPos = obj.FISBlockPos;
            layer = obj.Layer;
            fisLayerDistribution = obj.FISLayerDistribution;
            eachYAxisThinLayerWidth = obj.EachYAxisThinLayerWidth;
            fontSize = obj.FISNameFontSize;

            %% plot all the FIS blocks
            if obj.IsUpdate
                axHndl = obj.FISPatches;
            else
                axHndl = cell(numel(obj.FTREE.FIS),1);
            end
            for layerNum = 1:layer
                yAxisDownShiftBasedOnInputs = 0;
                for fisId = 1:numel(obj.FTREE.FIS)
                    if fisLayerDistribution(fisId) ~= layerNum % if currFis is not in cur layer. do not plot it.
                        continue
                    end
                    numThinLayersDownShift = 3+numel(obj.FTREE.FIS(fisId).Inputs);
                    yAxisDownShiftBasedOnInputs = yAxisDownShiftBasedOnInputs + ...
                        numThinLayersDownShift*eachYAxisThinLayerWidth;
                    x = fisBlockPos{fisId}(1);
                    y = fisBlockPos{fisId}(2);
                    w = fisBlockPos{fisId}(3);
                    h = fisBlockPos{fisId}(4);
                    xData = [x x+w x+w x];
                    yData = [y y y+h y+h];
                    tx = x+w/2;
                    ty = y+h/2;
                    if obj.IsUpdate
                        set(axHndl{fisId},'XData',xData,'YData',yData)
                        fisText = obj.FISNameText{fisId};
                        name = obj.FTREE.FIS(fisId).Name;
                        if fisText.String~=name
                            fisText.String = name;
                        end
                        fisText.Position(1:2) = [tx ty];
                        extent = fisText.Extent(3);
                        fisText.Position(1) = tx - extent/2 - obj.TextToBoxPadding;
                    else
                        tag = sprintf('%s.%d',obj.FISPrefix,fisId);
                        axHndl{fisId} = patch(detailAxes, ...
                            'XData',xData, ...
                            'YData',yData, ...
                            'LineWidth',obj.DefaultFISLineWidth, ...
                            'Tag',tag ...
                            );
                        specifyThemePropertyMappings(axHndl{fisId},'FaceColor',obj.SemanticFISBlockColor)

                        fisText = text(tx,ty,obj.FTREE.FIS(fisId).Name,...
                            'Parent',detailAxes,'FontSize',fontSize, ...
                            'UserData',axHndl{fisId}, ...
                            'Tag',tag,'Interpreter','none'...
                            ); % w/2 and h/2 are used to place the name close to the center
                        extent = fisText.Extent(3);
                        fisText.Position(1) = tx - extent/2 - obj.TextToBoxPadding;
                        obj.FISNameText{fisId} = fisText;
                    end

                end
            end
            obj.FISPatches = axHndl;
        end

        function adjustNameHeights(obj)
            %% Adjust Y position of all the plotted names in the detail axes
            % This method prevents overlap between arrow heads and text
            % objects using Extent property of the text object
            inputText = obj.InputText;
            for fisNumber = 1:size(inputText,1)
                for inputNumber = 1:size(inputText(fisNumber,:),2)
                    if ~isempty(inputText{fisNumber,inputNumber})
                        inputText{fisNumber,inputNumber}.Position(2) = ...
                            inputText{fisNumber,inputNumber}.Position(2) + ...
                            inputText{fisNumber,inputNumber}.Extent(4);
                    end
                end
            end
            outputText = obj.OutputText;
            for fisNumber = 1:size(outputText,1)
                for outputNumber = 1:size(outputText(fisNumber,:),2)
                    if ~isempty(outputText{fisNumber,outputNumber})
                        outputText{fisNumber,outputNumber}.Position(2) = ...
                            outputText{fisNumber,outputNumber}.Position(2) + ...
                            outputText{fisNumber,outputNumber}.Extent(4);
                    end
                end
            end
        end

        function cbFigure(obj,evt)
            %% Callback to provide highlighting upon hovering a line
            if ~isempty(obj.LastLineUnderMotion)
                tag = obj.LastLineUnderMotion.Tag;
                if startsWith(tag,obj.InputPrefix)
                    color = obj.SemanticInputColor;
                elseif startsWith(tag,obj.OutputPrefix)
                    color = obj.SemanticOutputColor;
                elseif startsWith(tag,obj.ConnectionPrefix)
                    color = obj.SemanticDefaultColor;
                end

                % Reset last line under motion.
                specifyThemePropertyMappings(obj.LastLineUnderMotion,'Color',color)


                % Revert the color of intermediate output and markers
                if ~isempty(obj.LastLineUnderMotion.UserData)
                    % If user data is not empty, then there could be
                    % markers and intermediate outputs to take care of
                    if  isa(obj.LastLineUnderMotion.UserData{1},'matlab.graphics.primitive.Line')
                        if numel(obj.LastLineUnderMotion.UserData)==3
                            % 3 items in user data mean there is a marker
                            % of a connection (first element in user data)
                            % and an intermediate output (3rd element)
                            curObj = obj.LastLineUnderMotion.UserData{1};
                            while curObj.UserData{2} ~= obj.LastLineUnderMotion.UserData{2}
                                % Continue the loop until cycling back to
                                % the original object
                                specifyThemePropertyMappings(curObj,'Color',color)
                                curObj = curObj.UserData{1}; % Marker or connection
                            end
                            specifyThemePropertyMappings(curObj.UserData{3},'Color',obj.SemanticOutputColor)
                        end
                        if numel(obj.LastLineUnderMotion.UserData)==2
                            % 2 items in user data mean there are markers
                            curObj = obj.LastLineUnderMotion.UserData{1};
                            while curObj.UserData{2} ~= obj.LastLineUnderMotion.UserData{2}
                                if startsWith(curObj.Tag,obj.ConnectionPrefix)
                                    specifyThemePropertyMappings(curObj,'Color',obj.SemanticDefaultColor)
                                elseif startsWith(curObj.Tag,obj.InputPrefix)
                                    specifyThemePropertyMappings(curObj,'Color',obj.SemanticInputColor)
                                end
                                curObj = curObj.UserData{1};
                            end
                        end
                        if numel(obj.LastLineUnderMotion.UserData)==1
                            % Only 1 item in user data means intermediate
                            % output. Hence using obj.OutputColor to revert
                            % the color after hovering is over
                            curObj = obj.LastLineUnderMotion.UserData{1};
                            specifyThemePropertyMappings(curObj,'Color',obj.SemanticOutputColor)
                        end
                    end
                end
                % Set last line under motion to empty.
                obj.LastLineUnderMotion = [];
            end

            % Return for a non-line object
            if ~isa(evt.HitObject,'matlab.graphics.primitive.Line')
                return
            end

            % Check if current line under motion is different than the previous one.
            if ~isequal(obj.LastLineUnderMotion,evt.HitObject)
                % Set highlight color.
                specifyThemePropertyMappings(evt.HitObject,'Color',obj.SemanticHiliteColor)
                % Take care of hiliting the intermediate output and markers
                if ~isempty(evt.HitObject.UserData) % If there are markers or intermediate outputs
                    if numel(evt.HitObject.UserData) == 3 % Markers + intermediate output
                        userDataIdx = 3;
                        if (startsWith(evt.HitObject.UserData{userDataIdx}.Tag,obj.OutputPrefix) && ...
                                isa(evt.HitObject.UserData{userDataIdx},'matlab.graphics.primitive.Line'))
                            specifyThemePropertyMappings(evt.HitObject.UserData{userDataIdx}, ...
                                'Color',obj.SemanticHiliteColor)
                            curObj = evt.HitObject.UserData{1};
                            while curObj.UserData{2} ~= evt.HitObject.UserData{2}
                                specifyThemePropertyMappings(curObj,'Color',obj.SemanticHiliteColor)
                                curObj = curObj.UserData{1};
                            end
                        end
                    elseif numel(evt.HitObject.UserData) == 1 % Only intermediate output
                        userDataIdx = 1;
                        if (startsWith(evt.HitObject.UserData{userDataIdx}.Tag,obj.OutputPrefix) && ...
                                isa(evt.HitObject.UserData{userDataIdx},'matlab.graphics.primitive.Line'))
                            specifyThemePropertyMappings(evt.HitObject.UserData{userDataIdx}, ...
                                'Color',obj.SemanticHiliteColor)
                        end
                    elseif numel(evt.HitObject.UserData) == 2 % Only Markers(both outputs and inputs)
                        if isa(evt.HitObject.UserData{1},'matlab.graphics.primitive.Line') && ...
                                (startsWith(evt.HitObject.UserData{1}.Tag,obj.ConnectionPrefix) || ...
                                startsWith(evt.HitObject.UserData{1}.Tag,obj.InputPrefix))
                            curObj = evt.HitObject.UserData{1};
                            while curObj.UserData{2} ~= evt.HitObject.UserData{2}
                                specifyThemePropertyMappings(curObj,'Color',obj.SemanticHiliteColor)
                                curObj = curObj.UserData{1};
                            end
                        end
                    end
                end
                % Update last line under motion.
                obj.LastLineUnderMotion = evt.HitObject;
            end
        end

        function cbSizeChangeFcn(obj,src)
            %% Callback function to resize the axes.

            if isempty(obj.DetailAxes) || ~isvalid(obj.DetailAxes)
                return
            end
            padding = obj.Padding;
            hPad = 0;
            vPad = 0;

            obj.DetailAxes.Position(3:4) = [...
                max(0,src.Position(3)-(1*padding + 1*hPad)) ...
                max(0,src.Position(4)-(1*padding + 1*vPad)) ...
                ] ;
        end

        function cbSizeChangeParent(obj,src)
            %% Callback function to resize the axes parent.

            padding = obj.Padding;
            obj.DetailAxes.Parent.Position(3:4) = [...
                src.Position(3)-padding ...
                src.Position(4)-padding ...
                ];

            pose = obj.DetailAxes.Parent.Position;

            if obj.Scrollable
                axesWidth = obj.DetailWidth+1*padding;
                axesHeight = obj.MaxAxisHeight+1*padding;
                startX = 1 + max(0,pose(3)-axesWidth)/2;
                startY = 1 + max(0,pose(4)-axesHeight)/2;
                obj.DetailAxes.Position = [...
                    startX startY axesWidth axesHeight];
            else
                obj.DetailAxes.Position(3:4) = [...
                    pose(3)-obj.DetailAxes.Position(1) ...
                    pose(4)-obj.DetailAxes.Position(2) ...
                    ];
            end
        end

        function cbResizeDetailAxes(obj,src)
            %%
            pose = src.Position;
            heightOffset = 0;
            if obj.AppMode
                heightOffset = obj.Padding/2;
            end
            obj.DetailAxes.Position(3:4) = [...
                pose(3)-obj.DetailAxes.Position(1) ...
                pose(4)-obj.DetailAxes.Position(2)-heightOffset ...
                ];
            updateWidgetPositions(obj)
        end

        function createLegends(obj)
            %% Add plot legends.

            data = [obj.LegendData.Input.Line obj.LegendData.Output.Line ...
                obj.LegendData.UnusedOutput.Line obj.LegendData.Connection.Line ...
                obj.LegendData.Joint.Line];
            label = [obj.LegendData.Input.Label obj.LegendData.Output.Label ...
                obj.LegendData.UnusedOutput.Label obj.LegendData.Connection.Label ...
                obj.LegendData.Joint.Label];

            obj.DetailLegend = legend(obj.DetailAxes, data, label,'Parent',[],...
                'Units','Pixels');
            obj.DetailLegend.Visible = 'off'; % Keep legend OFF
            obj.DetailLegend.Parent = obj.DetailAxes.Parent;

            % Spread the legends over as many layers as possible to reduce
            % Y-axis space used by the legend.
            if obj.Layer < 5
                obj.DetailLegend.NumColumns = obj.Layer;
            else
                obj.DetailLegend.NumColumns = 5;
            end
        end

        function lobj = plotLine(obj,xPos,yPos,axis,style,width,color,tag,marker)
            %% Plots line.
            % Plots:
            %     - open inputs,
            %     - open outputs,
            %     - intermediate outputs,
            %     - unused outputs, and
            %     - input-to-input and output-to-input connections.

            if isempty(obj.LegendData.Input) && isequal(color,obj.SemanticInputColor)
                obj.LegendData.Input(1).Line = drawLine;
                obj.LegendData.Input(1).Label = string(getString(message('fuzzy:general:labelFISTreePlotLegendInputs')));
                obj.LegendData.Input(1).Line.DeleteFcn = @(src,data)cbDeleteFcn(obj,src);
            elseif isempty(obj.LegendData.UnusedOutput) && isequal(style,obj.UnusedOutputLineStyle)
                obj.LegendData.UnusedOutput(1).Line = drawLine;
                obj.LegendData.UnusedOutput(1).Label = string(getString(message('fuzzy:general:labelFISTreePlotLegendUnusedOutputs')));
            elseif isempty(obj.LegendData.Output) && isequal(color,obj.SemanticOutputColor)
                obj.LegendData.Output(1).Line = drawLine;
                obj.LegendData.Output(1).Label = obj.OutputLegend;
            elseif isempty(obj.LegendData.Connection) && isequal(color,obj.SemanticConnectionColor) && marker=="None"
                obj.LegendData.Connection(1).Line = drawLine;
                obj.LegendData.Connection(1).Label = string(getString(message('fuzzy:general:labelFISTreePlotLegendConnections')));
            elseif marker~="None" && isempty(obj.LegendData.Joint)
                obj.LegendData.Joint(1).Line = drawLine;
                obj.LegendData.Joint(1).Label = string(getString(message('fuzzy:general:labelFISTreePlotLegendJoints')));
            end

            lobj = drawLine;

            function h = drawLine
                h = line(xPos, ...
                    yPos, ...
                    'Parent',axis,...
                    'LineStyle',style, ...
                    'LineWidth',width, ...
                    'SelectionHighlight','off',...
                    'Tag',tag,...
                    'Marker',marker,...
                    'MarkerSize',obj.MarkerSize ...
                    );
                specifyThemePropertyMappings(h,'Color',color)
            end
        end

        function adjustDialogAndAxesWidth(obj)
            %% Adjust dialog width if it is less than legend width
            legendWidth = obj.DetailLegend.Position(3);
            axesWidth = obj.DetailAxes.Position(3);
            widthDiff = axesWidth - legendWidth;
            if widthDiff<= 0
                widthDiff = abs(widthDiff) + obj.LegendPadding;
                obj.DetailAxes.Position(3) = obj.DetailAxes.Position(3) + widthDiff;
                if obj.SimMode
                    return
                end
                obj.DetailAxes.Parent.Position(3) = obj.DetailAxes.Parent.Position(3) + widthDiff;
            end
        end

        function cbDeleteFcn(obj,src)
            %% Callback function for deleting axes and its children.
            % This is to reduce interference with the next plot.
            if obj.AppMode
                return
            end
            if ~isempty(obj.LegendButton) && isvalid(obj.LegendButton)
                obj.LegendButton.ClickedCallback = obj.LegendButtonDefaultCallback;
            end
            fig = ancestor(src,{'figure'},'toplevel');
            fig.Name = '';
            fig.WindowButtonMotionFcn = [];
            fig.SizeChangedFcn = [];
            fig.NumberTitle = 'on';

        end

        function notifyComponentSelected(obj,type,id)
            %%
            data = struct('Type',type,'Index',id);
            eventData = matlab.ui.internal.databrowser.GenericEventData(data);
            notify(obj,'ComponentSelected',eventData)
        end

        function commonReset(obj)
            %%
            obj.InputText = [];
            obj.OutputText = [];
            obj.FreeInputObjects = [];
            obj.FreeOutputObjects = [];
            obj.IntermediateOutputObjects = [];
            obj.UnusedOutputObjects = [];
            obj.LastLineSelected = [];
            obj.LastLineUnderMotion = [];
            obj.NumIIConnectionInLayer = [];
            obj.PreProcessedII = [];
            obj.PreProcessedOI = [];
            obj.NumConsecOIBetweenEachLayer = [];
            obj.NumNonConsecOIBetweenEachLayer = [];
            obj.OIConnObjects = [];
            obj.IIConnObjects = [];
            obj.InputMarkerXDirLayers = [];
            obj.OutputMarkerXDirLayers = [];
            obj.InputMarkerBetweenLayers = [];
            obj.OutputMarkerBetweenLayers = [];
            obj.DetailLegend = [];
            obj.OIMarkers = [];
            obj.IIMarkers = [];
            obj.FreeInputLines = [];
            obj.FISPatches = [];
            obj.IsUpdate = false;
            obj.LastSelectedObject = [];
            obj.MouseDownObject = [];
            obj.UnusedArrows = [];
            obj.initLegend();
        end

        function cbNoAction(obj,evt) %#ok<INUSD,INUSD>
            %%
        end

        function cbMouseDown(obj,evt)
            %% Set flag for component selection
            % Set flag for open input/output, FIS, or connection selection.

            if obj.SimMode
                return
            end
            
            hitObject = evt.HitObject;
            setMouseDownObject(obj,hitObject)
        end

        function cbMouseUp(obj,evt)
            %% Trigger event for component selection

            if obj.SimMode
                return
            end
            
            if isempty(obj.MouseDownObject)
                return
            end
            
            hitObject = evt.HitObject;
            selectAndNotify(obj,hitObject)
        end

        function unselectFIS(obj)
            %%
            specifyThemePropertyMappings(obj.LastSelectedObject,'EdgeColor','remove')
            obj.LastSelectedObject.LineWidth = obj.DefaultFISLineWidth;
            obj.LastSelectedObject = [];
        end

        function unselectInput(obj)
            %%
            specifyThemePropertyMappings(obj.LastSelectedObject,'Color',obj.SemanticInputColor)
            obj.LastSelectedObject = [];
        end

        function unselectOutput(obj)
            %%
            specifyThemePropertyMappings(obj.LastSelectedObject,'Color',obj.SemanticOutputColor)
            obj.LastSelectedObject = [];
        end

        function unselectConnection(obj,id)
            %%
            [conn,markers] = getConnHandles(obj,id);
            specifyThemePropertyMappings(conn,'Color',obj.SemanticConnectionColor)
            for mId = 1:numel(markers)
                specifyThemePropertyMappings(markers{mId},'Color',obj.SemanticConnectionColor)
            end
            obj.LastSelectedObject = [];
        end

        function resetAxesChildren(obj)
            %%
            delete(obj.DetailAxes.Children)
            if ~isempty(obj.DetailLegend) && isvalid(obj.DetailLegend)
                delete(obj.DetailLegend)
            end

            commonReset(obj)
        end

        function selectAndNotify(obj,hitObject)
            %%
            tag = hitObject.Tag;
            if ~isequal(tag,obj.MouseDownObject.Tag)
                obj.MouseDownObject = [];
                return
            end
            if isa(hitObject,'matlab.graphics.primitive.Text')
                hitObject = hitObject.UserData;
            end

            obj.MouseDownObject = [];
            id = extract(tag,digitsPattern);
            if isempty(id)
                idValue = [];
            else
                idValue = str2double(id{1});
            end
            if startsWith(tag,obj.FISPrefix)
                if isFISSelected(obj,idValue)
                    return
                end
                selectComponent(obj,@()selectFIS(obj))
                type = obj.FISPrefix;
            elseif startsWith(tag,obj.InputPrefix)
                if isInputSelected(obj,idValue)
                    return
                end
                selectComponent(obj,@()selectInput(obj))
                type = obj.InputPrefix;
            elseif startsWith(tag,obj.OutputPrefix)
                if isOutputSelected(obj,idValue)
                    return
                end
                selectComponent(obj,@()selectOutput(obj))
                type = obj.OutputPrefix;
            else%if startsWith(tag,obj.ConnectionPrefix)
                if isConnectionSelected(obj,idValue)
                    return
                end
                selectComponent(obj,@()selectConnection(obj,idValue))
                type = obj.ConnectionPrefix;
            end
            notifyComponentSelected(obj,type,idValue)

            function selectComponent(obj,selectFcn)
                unselect(obj)
                obj.LastSelectedObject = hitObject;
                selectFcn()
            end
        end

        function ax = getPlotAxes(obj)
            %%
            ax = obj.DetailAxes;
        end

        function resizeDetailAxes(obj)
            %%
            cbResizeDetailAxes(obj,obj.DetailAxes.Parent)
        end

        function setMouseDownObject(obj,hitObject)
            %%
            if isequal(obj.LastSelectedObject,hitObject)
                return
            end
            if ~(isa(hitObject,'matlab.graphics.primitive.Line') || ...
                    isa(hitObject,'matlab.graphics.primitive.Patch') || ...
                    isa(hitObject,'matlab.graphics.primitive.Text'))
                return
            end
            if endsWith(hitObject.Tag,obj.UnusedSuffix)
                return
            end
            obj.MouseDownObject = hitObject;
        end

    end

    %% Methods with friend access to tests
    methods(Access=?matlab.unittest.TestCase)
        function plotInputToInputConnection(obj)
            %% Plot all the input to input connection
            deduct = false; % Handles connection position for subsequent FIS
            detailHeight = obj.DetailHeight;
            currTopConnection = obj.NumTopIIConnections - 1; % Handles top connection position
            inputPosition = obj.InputPosition;
            lineStyle = obj.LineStyle;
            lineWidth = obj.LineWidth;
            offsetForLegends = obj.LegendHeight;
            IIConnections = obj.PreProcessedII;
            numIIConnectionInLayer = obj.NumIIConnectionInLayer;
            fisLayerDistribution = obj.FISLayerDistribution;
            inputMarkerXDirLayers = obj.InputMarkerXDirLayers;
            inputMarkerBetweenLayers = obj.InputMarkerBetweenLayers;
            if obj.IsUpdate
                iiConnObjects = obj.IIConnObjects;
                markers = obj.IIMarkers;
                freeInputLines = obj.FreeInputLines;
            else
                iiConnObjects = {};
                markers = {};
                freeInputLines = {};
                iiConnOrder = zeros(numel(obj.FTREE.IIConnectionOrder),1);
            end
            mCt = 0;
            inCt = 0;
            if ~obj.FTREE.DisableStructuralChecks
                connections = obj.FTREE.Connections(obj.FTREE.IIConnectionOrder,:);
            end
            for iiConnId = 1:size(IIConnections,1)
                % Get the first input
                if isempty(IIConnections{iiConnId})
                    continue
                end

                % Store markers in the current II connection
                if obj.IsUpdate
                    if ~isempty(markers)
                        mCt = mCt + 1;
                        marker = markers{mCt};
                        mrkPnt = 0;
                    else
                        mrkPnt = 0;
                        marker = {};
                    end
                else
                    marker = {};
                end

                fis1InConnection = IIConnections{iiConnId}(1);
                fisLayersOfCurrentIIConnections = fisLayerDistribution(fis1InConnection); % Ensures no extra gap is created for continuous part of same connection
                input1InConnection = IIConnections{iiConnId}(2);
                input1Position = inputPosition{fis1InConnection,input1InConnection};
                x11 = input1Position(1);
                x21 = input1Position(2);
                y1 = input1Position(3);
                % Generate position for first input
                connectionPosForMainInput = x21-obj.InputToInputNamePadding - ...
                    (numIIConnectionInLayer(fisLayerDistribution(fis1InConnection))-1)*obj.InputToInputConnectionGap;
                posX = [x11 x21 x21-10 x21 x21-10 x21 connectionPosForMainInput];
                posY = [y1 y1 y1+4 y1 y1-4 y1 y1];
                freeInputX = posX;
                freeInputY = posY;
                if obj.IsUpdate
                    inCt = inCt + 1;
                    freeInputl = freeInputLines{inCt};
                    set(freeInputl,'XData',freeInputX,'YData',freeInputY)
                else
                    fisName = obj.FTREE.FIS(fis1InConnection).Name;
                    varName = obj.FTREE.FIS(fis1InConnection).Inputs(input1InConnection).Name;
                    id = find([obj.FTREE.Inputs]==fisName+"/"+varName,1);
                    tag = sprintf('%s.%d',obj.InputPrefix,id);
                    freeInputl = plotLine(obj,freeInputX,freeInputY,...
                        obj.DetailAxes,lineStyle,lineWidth, ...
                        obj.SemanticInputColor,tag,'None');
                    freeInputLines{end+1} = freeInputl;
                end
                if obj.IsUpdate
                    mrkPnt = mrkPnt + 1;
                    set(marker{mrkPnt},'XData',connectionPosForMainInput,'YData',y1)
                else
                    marker{end+1} = plotLine(obj,connectionPosForMainInput,y1, ...
                        obj.DetailAxes,obj.LineStyle,obj.LineWidth, ...
                        obj.SemanticDefaultColor,obj.ConnectionPrefix,obj.Marker);
                end
                numIIConnectionInLayer(fisLayerDistribution(fis1InConnection)) = ...
                    numIIConnectionInLayer(fisLayerDistribution(fis1InConnection))-1; % deduct one to show it is used

                posX = connectionPosForMainInput;
                posY = y1;
                % fromFISName = obj.FTREE.FIS(fis1InConnection).Name;
                fromVarName = obj.FTREE.FIS(fis1InConnection).Inputs(input1InConnection).Name;
                if obj.IsUpdate
                    inputText = obj.InputText{fis1InConnection,input1InConnection};
                    inputText.Position(1:2) = [0 y1];
                    if inputText.String~=fromVarName
                        inputText.String = fromVarName;
                    end
                else
                    if ~isempty(obj.InputText) && fis1InConnection<=size(obj.InputText,1) && ...
                            input1InConnection<=size(obj.InputText,2) && ...
                            isa(obj.InputText{fis1InConnection,input1InConnection},'matlab.graphics.primitive.Text')
                        delete(obj.InputText{fis1InConnection,input1InConnection})
                    end
                    obj.InputText{fis1InConnection,input1InConnection} = ...
                        text(obj.DetailAxes,0,y1, ...
                        fromVarName, ...
                        'Interpreter','none', ...
                        'Tag',freeInputl.Tag, ...
                        'UserData',freeInputl ...
                        ); % X position is adjusted later in adjustInputNames method
                end
                % fromConn = fromFISName + "/" + fromVarName;

                % Get subsequent inputs
                tmpTxt = {};
                for subsequentFISIndex = 3:2:numel(IIConnections{iiConnId})
                    subsequentInputIndex = subsequentFISIndex+1;
                    subsequentFIS = IIConnections{iiConnId}(subsequentFISIndex);
                    subsequentInput = IIConnections{iiConnId}(subsequentInputIndex);
                    input2Position = inputPosition{subsequentFIS,subsequentInput};
                    toFISName = obj.FTREE.FIS(subsequentFIS).Name;
                    toVarName = obj.FTREE.FIS(subsequentFIS).Inputs(subsequentInput).Name;
                    toConn = toFISName + "/" + toVarName;
                    % conn = [fromConn toConn];
                    if ~obj.FTREE.DisableStructuralChecks
                        % In a connection, toConn is unique since multiple
                        % incoming connections are not permitted. Hence,
                        % search only with toConn.
                        id = find(ismember(connections(:,2),toConn,'rows'),1);
                        tag = sprintf('%s.%s.%d',obj.ConnectionPrefix,obj.IIPrefix,obj.FTREE.IIConnectionOrder(id));
                        iiConnOrder(id) = iiConnId;
                    else
                        tag = '';
                    end
                    if subsequentFISIndex==3
                        marker{end}.Tag = tag;
                    end

                    if ~(any(fisLayersOfCurrentIIConnections == fisLayerDistribution(subsequentFIS)))
                        deduct = true;
                    end
                    fisLayersOfCurrentIIConnections = [fisLayersOfCurrentIIConnections ...
                        fisLayerDistribution(subsequentFIS)];
                    x22 = input2Position(2);
                    y2 = input2Position(3);
                    connectionPosForSecondInput = x22-obj.InputToInputNamePadding - ...
                        numIIConnectionInLayer(fisLayerDistribution(subsequentFIS))*obj.InputToInputConnectionGap;

                    % If subsequent FIS is not in same layer
                    if fisLayerDistribution(subsequentFIS) ~= fisLayerDistribution(fis1InConnection)
                        if deduct
                            numIIConnectionInLayer(fisLayerDistribution(subsequentFIS)) = ...
                                numIIConnectionInLayer(fisLayerDistribution(subsequentFIS))-1; % deduct one to show it is used
                            deduct = false;
                        end
                        connectionPosForSecondInput = x22-obj.InputToInputNamePadding - ...
                            numIIConnectionInLayer(fisLayerDistribution(subsequentFIS))*obj.InputToInputConnectionGap;

                        % Get position for subsequent input
                        startingYPos = detailHeight - offsetForLegends;
                        topConnectionYvalue = startingYPos - ...
                            (obj.NumTopIIConnections - currTopConnection + 1)*obj.TopAndBottomConnectionGap;
                        posX = [posX connectionPosForMainInput connectionPosForSecondInput...
                            connectionPosForSecondInput x22 x22-10 x22 x22-10 x22 ...
                            connectionPosForSecondInput connectionPosForSecondInput connectionPosForMainInput connectionPosForMainInput];
                        posY = [posY topConnectionYvalue topConnectionYvalue...
                            y2 y2 y2+4 y2 y2-4 y2 ...
                            y2 topConnectionYvalue topConnectionYvalue y1];
                        if inputMarkerXDirLayers(iiConnId, fisLayerDistribution(subsequentFIS))
                            % Plot marker on the II connection
                            if obj.IsUpdate
                                mrkPnt = mrkPnt + 1;
                                set(marker{mrkPnt},'XData',connectionPosForSecondInput, ...
                                    'YData',topConnectionYvalue)
                            else
                                marker{end+1} = plotLine(obj, ...
                                    connectionPosForSecondInput,topConnectionYvalue, ...
                                    obj.DetailAxes,obj.LineStyle,obj.LineWidth, ...
                                    obj.SemanticDefaultColor,tag,obj.Marker);
                            end
                        end
                        if inputMarkerBetweenLayers{iiConnId,subsequentFIS}(subsequentInput)
                            if obj.IsUpdate
                                mrkPnt = mrkPnt + 1;
                                set(marker{mrkPnt},'XData',connectionPosForSecondInput, ...
                                    'YData',y2)
                            else
                                marker{end+1} = plotLine(obj, ...
                                    connectionPosForSecondInput,y2, ...
                                    obj.DetailAxes,obj.LineStyle,obj.LineWidth, ...
                                    obj.SemanticDefaultColor,tag,obj.Marker);
                            end
                        end
                    else
                        % Get position for subsequent input
                        posX = [posX connectionPosForMainInput x22 x22-10 x22 x22-10 x22 connectionPosForMainInput];
                        posY = [posY y2 y2 y2+4 y2 y2-4 y2 y2];
                        % Add marker even if the subsequent FIS is in same
                        % layer
                        if inputMarkerBetweenLayers{iiConnId,subsequentFIS}(subsequentInput)
                            if obj.IsUpdate
                                mrkPnt = mrkPnt + 1;
                                set(marker{mrkPnt},'XData',connectionPosForSecondInput, ...
                                    'YData',y2)
                            else
                                marker{end+1} = plotLine(obj, ...
                                    connectionPosForSecondInput,y2, ...
                                    obj.DetailAxes,obj.LineStyle,obj.LineWidth, ...
                                    obj.SemanticDefaultColor,tag,obj.Marker);
                            end
                        end
                    end
                    % Plot name for the input
                    tx = (input2Position(1)+input2Position(2))/2 - 50;
                    ty = input2Position(3);
                    if obj.IsUpdate
                        inText = obj.InputText{subsequentFIS,subsequentInput};
                        inText.Position(1:2) = [tx ty];
                        if inText.String~=toVarName
                            inText.String = toVarName;
                        end
                    else
                        if ~isempty(obj.InputText) && subsequentFIS<=size(obj.InputText,1) && ...
                                subsequentInput<=size(obj.InputText,2) && ...
                                isa(obj.InputText{subsequentFIS,subsequentInput},'matlab.graphics.primitive.Text')
                            delete(obj.InputText{subsequentFIS,subsequentInput})
                        end
                        obj.InputText{subsequentFIS,subsequentInput} = text(...
                            obj.DetailAxes,tx,ty, ...
                            obj.FTREE.FIS(subsequentFIS).Inputs(subsequentInput).Name, ...
                            'Interpreter','none', ...
                            'Tag',tag ...
                            );
                    end
                    tmpTxt{end+1} = obj.InputText{subsequentFIS,subsequentInput};
                end
                currTopConnection = currTopConnection - 1;
                if obj.IsUpdate
                    l = iiConnObjects{iiConnId};
                    set(l,'XData',posX,'YData',posY)
                else
                    l = plotLine(obj,posX,posY,obj.DetailAxes,lineStyle, ...
                        lineWidth,obj.SemanticDefaultColor,tag,'None');
                    iiConnObjects{iiConnId} = l;
                end
                for txtId = 1:numel(tmpTxt)
                    tmpTxt{txtId}.UserData = l;
                end
                if ~obj.IsUpdate
                    % Add chain of markers for hiliting
                    cur = l;
                    for numMarker = 1:numel(marker)
                        % User Data has 2 elements
                        % 1st element is the object, 2nd is a number used to
                        % close the while loop in cbFigure
                        cur.UserData = {marker{numMarker} numMarker};
                        cur = cur.UserData{1};
                        % Add hiliting for free input part of the connection
                        if numMarker == numel(marker) % If last iteration of marker loop
                            cur.UserData = {freeInputl numMarker+1};
                        end
                    end
                    % Connect the free input back to rest of the connection
                    freeInputl.UserData = {l numMarker+2}; % Add the original II connection back to the free input to allow for hovering on the free input also
                end
                if ~obj.IsUpdate && ~isempty(marker)
                    markers{end+1} = marker;
                end
            end
            obj.IIConnObjects = iiConnObjects;
            obj.FreeInputLines = freeInputLines;
            obj.IIMarkers = markers;
            if ~obj.IsUpdate
                obj.IIConnectionOrder = iiConnOrder;
            end
        end
                
        function plotIntermediateAndUnusedOutputs(obj)
            % Plot any outputs that are added to list of outputs after
            % fistree construction
            freeOutputs = obj.FTREE.getFreeOutputs;
            outputSequence = obj.FTREE.OutputSequenceID;
            oiConns = obj.OIConnObjects;
            if obj.IsUpdate
                unusedOutputObjects = obj.UnusedOutputObjects;
                interOutputObjects = obj.IntermediateOutputObjects;
            else
                unusedOutputObjects = {};
                interOutputObjects = {};
                obj.UnusedArrows = [];
            end
            if isempty(outputSequence)
                outputSequence = double.empty(0,2);
            end
            outputPos = obj.OutputPosition;
            intermediateOutputs = setdiff(outputSequence,freeOutputs,'rows');
            for i = 1:size(intermediateOutputs,1)
                fisId = intermediateOutputs(i,1);
                varId = intermediateOutputs(i,2);
                curOutputPosition = outputPos{fisId,varId};
                x1 = curOutputPosition(1);
                x2 = curOutputPosition(2);
                y1 = curOutputPosition(3);
                y2 = curOutputPosition(4);
                posX = [x1 x2 x2-10 x2 x2-10 x2];
                posY = [y1 y2 y2+4 y2 y2-4 y2];
                fisName = obj.FTREE.FIS(fisId).Name;
                varName = obj.FTREE.FIS(fisId).Outputs(varId).Name;
                id = find([obj.FTREE.Outputs]==fisName+"/"+varName,1);
                tag = sprintf('%s.%d',obj.OutputPrefix,id);
                if obj.IsUpdate
                    l = interOutputObjects{fisId,varId};
                    set(l,'XData',posX,'YData',posY)
                else
                    l = plotLine(obj,posX,posY,...
                        obj.DetailAxes,obj.LineStyle, ...
                        obj.LineWidth,obj.SemanticOutputColor,tag,'None');
                    interOutputObjects{fisId,varId} = l;
                end
                set(obj.OutputText{fisId,varId},'UserData',l,'Tag',tag)
                % Attach the intermediate output to the OI connection for
                % hiliting
                if ~obj.IsUpdate
                    currOI = oiConns{intermediateOutputs(i,1),intermediateOutputs(i,2)};
                    if numel(currOI.UserData) == 2 % If current connection has markers
                        currOI.UserData{end+1} = l;
                        curObj = currOI.UserData{1};
                        while curObj.UserData{2} ~= currOI.UserData{2}
                            curObj.UserData{end+1} = l;
                            curObj = curObj.UserData{1};
                        end
                    else % If there are no markers in the connection, then intermediate output is the only object in UserData
                        currOI.UserData = {l};
                    end
                end
            end
            obj.IntermediateOutputObjects = interOutputObjects;
            % Plot unused outputs
            outputSequence = obj.FTREE.OutputSequenceID;
            if ~isempty(outputSequence)
                unusedOutputs = setdiff(freeOutputs,outputSequence,'rows');
                for i = 1:size(unusedOutputs,1)
                    curOutputPosition = ...
                        outputPos{unusedOutputs(i,1),unusedOutputs(i,2)};
                    x1 = curOutputPosition(1);
                    x2 = curOutputPosition(2);
                    y1 = curOutputPosition(3);
                    y2 = curOutputPosition(4);
                    posXDotted = [x1 x2];
                    posYDotted = [y1 y2];
                    posXArrowhead = [x2 x2-10 x2 x2-10 x2];
                    posYArrowhead = [y2 y2+4 y2 y2-4 y2];
                    if obj.IsUpdate
                        l1 = unusedOutputObjects{unusedOutputs(i,1),unusedOutputs(i,2)};
                        l2 = l1.UserData{1};
                        set(l1,'XData',posXDotted,'YData',posYDotted)
                        set(l2,'XData',posXArrowhead,'YData',posYArrowhead)
                        outputText = obj.OutputText{unusedOutputs(i,1), unusedOutputs(i,2)};
                        outputText.Position(1:2) = [x1+obj.TextToBoxPadding y1];
                    else
                        tag = sprintf('%s.%s',obj.OutputPrefix,obj.UnusedSuffix);
                        l1 = plotLine(obj,posXDotted,posYDotted,...
                            obj.DetailAxes,obj.UnusedOutputLineStyle, ...
                            obj.LineWidth,obj.SemanticUnusedOutputColor, ...
                            tag,'None');
                        l2 = plotLine(obj,posXArrowhead,posYArrowhead,...
                            obj.DetailAxes,obj.LineStyle,obj.LineWidth, ...
                            obj.SemanticUnusedOutputColor,tag,'None');
                        % Merge the complete arrow together for hiliting
                        l1.UserData = {l2};
                        l2.UserData = {l1};
                        obj.UnusedArrows(end+1) = l2;
                        obj.OutputText{unusedOutputs(i,1), unusedOutputs(i,2)} = ...
                            text(obj.DetailAxes,x1+obj.TextToBoxPadding,y1, ...
                            obj.FTREE.FIS(unusedOutputs(i,1)).Outputs(unusedOutputs(i,2)).Name, ...
                            'Tag',tag, ...
                            'UserData',l1, ...
                            'Interpreter','none' ...
                            ); % 10 pixels are added to bring the name above the output line
                        unusedOutputObjects{unusedOutputs(i,1),unusedOutputs(i,2)} = l1;
                    end
                end
            end
            obj.UnusedOutputObjects = unusedOutputObjects;

        end
        
        function plotOutputToInputConnections(obj)
            outputPosition = obj.OutputPosition;
            inputPosition = obj.InputPosition;
            lineStyle = obj.LineStyle;
            lineWidth = obj.LineWidth;
            layerWidths = obj.LayerWidths;
            fisLayerDistribution = obj.FISLayerDistribution;
            currBottomConnection = obj.NumBottomOIConnections; % Handles bottom connection position
            numNonConsec = obj.NumNonConsecOIBetweenEachLayer;
            numConsec = obj.NumConsecOIBetweenEachLayer;
            outputMarkerXDirLayers = obj.OutputMarkerXDirLayers;
            outputMarkerBetweenLayers = obj.OutputMarkerBetweenLayers;
            outputCenterMarkers = obj.OutputCenterMarkers;
            if obj.IsUpdate
                oiConnObject = obj.OIConnObjects;
                markers = obj.OIMarkers;
            else
                oiConnObject = {};
                markers = {};
                oiConnOrder = zeros(numel(obj.FTREE.OIConnectionOrder),3);
            end
            %% Plot all the output to input connections
            connectionsFromConnectionTable = obj.PreProcessedOI;
            connectionCount = numel(connectionsFromConnectionTable);
            ct = 0;
            if ~obj.FTREE.DisableStructuralChecks
                connections = obj.FTREE.Connections(obj.FTREE.OIConnectionOrder,:);
            end
            for connNumber = 1:connectionCount
                if isempty(connectionsFromConnectionTable{connNumber})
                    continue;
                end
                decrementInputSideOIGap = false;
                decrementBottomConnection = false;
                layerOfInputInCurrConn = [];
                fisWithOutput = connectionsFromConnectionTable{connNumber}(1);
                outputNumber = connectionsFromConnectionTable{connNumber}(2);
                outputConnPosition = outputPosition{fisWithOutput,outputNumber};
                o = outputConnPosition;
                if obj.IsUpdate
                    if numel(oiConnObject{fisWithOutput, outputNumber}.UserData)>1
                        ct = ct + 1;
                        marker = markers{ct};
                        mrkPnt = 0;
                    else
                        marker = {};
                    end
                else
                    marker = {};
                end

                % Find layer
                layerOfCurrFIS = fisLayerDistribution(fisWithOutput);
                o(2) = o(1) + ...
                    layerWidths(layerOfCurrFIS,6) - ...
                    numConsec(layerOfCurrFIS)*obj.OutputToInputConnectionGap - ...
                    obj.NumNonConsecOIBetweenEachLayer(layerOfCurrFIS)*obj.OutputToInputConnectionGap;
                numConsec(layerOfCurrFIS) = numConsec(layerOfCurrFIS) - 1;
                % Output connection position
                linePosX = o(1:2);
                linePosY = o(3:4);
                % fromFISName = obj.FTREE.FIS(fisWithOutput).Name;
                fromVarName = obj.FTREE.FIS(fisWithOutput).Outputs(outputNumber).Name;
                % fromConn = fromFISName + "/" + fromVarName;
                if obj.IsUpdate
                    outText = obj.OutputText{fisWithOutput,outputNumber};
                    outText.Position(1:2) = [o(1)+obj.TextToBoxPadding o(3)];
                    if outText.String~=fromVarName
                        outText.String = fromVarName;
                    end
                else
                    obj.OutputText{fisWithOutput, outputNumber} = text(obj.DetailAxes, ...
                        o(1)+obj.TextToBoxPadding,o(3), ...
                        fromVarName, ...
                        'Interpreter','none' ...
                        );
                end
                if outputCenterMarkers{connNumber,fisWithOutput}(outputNumber)
                    % Plot marker for center point
                    if obj.IsUpdate
                        mrkPnt = mrkPnt + 1;
                        set(marker{mrkPnt},'XData',o(2),'YData',o(4))
                    else
                        marker{end+1} = plotLine(obj,o(2),o(4),obj.DetailAxes,...
                            obj.LineStyle,obj.LineWidth,obj.SemanticDefaultColor, ...
                            obj.ConnectionPrefix,obj.Marker);
                    end
                end
                % This FOR loop takes care of output-to-multiinput
                % connections
                tmpTxt = {};
                for inputFIS = 3:2:numel(connectionsFromConnectionTable{connNumber})
                    fisWithInput = connectionsFromConnectionTable{connNumber}(inputFIS);
                    inputNumber = connectionsFromConnectionTable{connNumber}(inputFIS+1);
                    % Plot input connection
                    inputConnPosition = inputPosition{fisWithInput,inputNumber};
                    x2 = inputConnPosition(2);
                    y1 = inputConnPosition(3);
                    y2 = inputConnPosition(4);
                    layerOfInpFIS = fisLayerDistribution(fisWithInput);
                    x1 = x2 - layerWidths(layerOfInpFIS,2) - ...
                        numNonConsec(layerOfInpFIS-1)*obj.OutputToInputConnectionGap;
                    toFISName = obj.FTREE.FIS(fisWithInput).Name;
                    toVarName = obj.FTREE.FIS(fisWithInput).Inputs(inputNumber).Name;
                    toConn = toFISName + "/" + toVarName;
                    % conn = [fromConn toConn];
                    if ~obj.FTREE.DisableStructuralChecks
                        % In a connection, toConn is unique since multiple
                        % incoming connections are not permitted. Hence,
                        % search only with toConn.
                        id = find(ismember(connections(:,2),toConn,'rows'),1);
                        tag = sprintf('%s.%s.%d',obj.ConnectionPrefix,obj.OIPrefix,obj.FTREE.OIConnectionOrder(id));
                        oiConnOrder(id,:) = [fisWithOutput outputNumber numel(markers)+1];
                    else
                        id = [];
                        tag = '';
                    end
                    if inputFIS==3
                        obj.OutputText{fisWithOutput, outputNumber}.Tag = tag;
                        if ~isempty(marker)
                            marker{end}.Tag = tag;
                        end
                    end

                    if abs(fisLayerDistribution(fisWithInput) - fisLayerDistribution(fisWithOutput)) > 1
                        % Case: when output and input are not in
                        % consecutive layers
                        bottomConnValue = obj.TopAndBottomConnectionGap * currBottomConnection;
                        bcv = bottomConnValue;
                        linePosX = [linePosX o(2) x1 x1 x2 x2-10 x2 x2-10 x2 x1 x1 o(2) o(2)];
                        linePosY = [linePosY bcv bcv y1 y2 y2+4 y2 y2-4 y2 y1 bcv bcv o(4)];
                        decrementBottomConnection = true;
                        decrementInputSideOIGap = true;
                        layerOfInputInCurrConn = [layerOfInputInCurrConn ...
                            fisLayerDistribution(fisWithInput)];

                        if outputMarkerXDirLayers(connNumber, fisLayerDistribution(fisWithInput))
                            % Plot marker on OI connection if there is one
                            if obj.IsUpdate
                                mrkPnt = mrkPnt + 1;
                                set(marker{mrkPnt},'XData',x1,'YData',bottomConnValue)
                            else
                                marker{end+1} = plotLine(obj,x1,bottomConnValue, ...
                                    obj.DetailAxes,obj.LineStyle,obj.LineWidth, ...
                                    obj.SemanticDefaultColor,tag,obj.Marker);
                            end
                        end
                        % Add marker
                        if outputMarkerBetweenLayers{connNumber,fisWithInput}(inputNumber)
                            if obj.IsUpdate
                                mrkPnt = mrkPnt + 1;
                                set(marker{mrkPnt},'XData',x1,'YData',y1)
                            else
                                marker{end+1} = plotLine(obj,x1,y1,obj.DetailAxes,...
                                    obj.LineStyle,obj.LineWidth,obj.SemanticDefaultColor, ...
                                    tag,obj.Marker);
                            end
                        end
                    else
                        linePosX = [linePosX o(2) x2 x2-10 x2 x2-10 x2 o(2)];
                        linePosY = [linePosY y1 y2 y2+4 y2 y2-4 y2 y1];
                        % Add marker
                        if outputMarkerBetweenLayers{connNumber,fisWithInput}(inputNumber)
                            if obj.IsUpdate
                                mrkPnt = mrkPnt + 1;
                                set(marker{mrkPnt},'XData',o(2),'YData',y1)
                            else
                                marker{end+1} = plotLine(obj,o(2),y1,obj.DetailAxes,...
                                    obj.LineStyle,obj.LineWidth,obj.SemanticDefaultColor, ...
                                    tag,obj.Marker);
                            end
                        end
                    end
                    if obj.IsUpdate
                        mytext = obj.InputText{fisWithInput,inputNumber};
                        if mytext.String~=toVarName
                            mytext.String = toVarName;
                        end
                        mytext.Position(1:2) = inputConnPosition(2:3);
                        mytext.Position(1) = mytext.Position(1) - mytext.Extent(3);
                    else
                        mytext = text(obj.DetailAxes, ...
                            inputConnPosition(2),inputConnPosition(3), ...
                            toVarName,...
                            'Tag',tag, ...
                            'Interpreter','none' ...
                            );
                        mytext.Position = [inputConnPosition(2)-mytext.Extent(3) ...
                            mytext.Position(2) mytext.Position(3)];
                        obj.InputText{fisWithInput,inputNumber} = mytext;
                    end
                    tmpTxt{end+1} = mytext;
                end
                % Plot the complete connection
                if obj.IsUpdate
                    l = oiConnObject{fisWithOutput, outputNumber};
                    set(l,'XData',linePosX,'YData',linePosY)
                else
                    l = plotLine(obj, ...
                        linePosX,linePosY,obj.DetailAxes,lineStyle,lineWidth, ...
                        obj.SemanticDefaultColor,tag,'None');
                    oiConnObject{fisWithOutput, outputNumber} = l;
                end
                obj.OutputText{fisWithOutput, outputNumber}.UserData = l;
                for txtId = 1:numel(tmpTxt)
                    tmpTxt{txtId}.UserData = l;
                end
                % Add chain of markers for hiliting
                if isempty(marker)
                    if ~isempty(id)
                        oiConnOrder(id,3) = 0;
                    end
                else
                    cur = oiConnObject{fisWithOutput, outputNumber};
                    for numMarker = 1:numel(marker)
                        % User data is a 2x1 cell array
                        % 1st element is the object, 2nd is a number used
                        % to close the while loop in cbFigure
                        cur.UserData = {marker{numMarker} numMarker};
                        cur = cur.UserData{1};
                    end
                    cur.UserData = {oiConnObject{fisWithOutput,outputNumber} numMarker+1};
                    if ~obj.IsUpdate
                        markers{end+1} = marker;
                    end
                end
                % Decrement the bottom connection number after plotting
                if decrementBottomConnection
                    currBottomConnection = currBottomConnection - 1;
                end
                % Decrement the OI gap for all input layers used in the current
                % connection
                if decrementInputSideOIGap
                    layerOfInputInCurrConn = unique(layerOfInputInCurrConn);
                    for layerNum = 1:numel(layerOfInputInCurrConn)
                        numNonConsec(layerOfInputInCurrConn(layerNum)-1) = ...
                            numNonConsec(layerOfInputInCurrConn(layerNum)-1) - 1;
                    end
                end
            end
            obj.OIConnObjects = oiConnObject;
            obj.OIMarkers = markers;
            if ~obj.IsUpdate
                obj.OIConnectionOrder = oiConnOrder;
            end
        end
                
        function determineConsecLayerOutputMarkers(obj)
            outputMarkerBetweenLayers = obj.OutputMarkerBetweenLayers ;

            OIConnections = obj.PreProcessedOI;
            outputCenterMarkers = cell(numel(OIConnections),numel(obj.FTREE.FIS));
            for i = 1:numel(OIConnections)
                for j = 1:numel(obj.FTREE.FIS)
                    outputCenterMarkers{i,j} = false(1,numel(obj.FTREE.FIS(j).Outputs));
                end
            end
            fisLayerDistribution = obj.FISLayerDistribution;
            outputPos = obj.OutputPosition;
            inputPos = obj.InputPosition;
            for i = 1:numel(OIConnections)
                % Extract all FIS in connections
                if isempty(OIConnections{i})
                    continue
                end
                layerOfFirstFis = fisLayerDistribution(OIConnections{i}(1));
                inputFISs = OIConnections{i}(3:2:end); % Get all the FIS in connection
                inputs = OIConnections{i}(4:2:end);
                layersInCurConn = fisLayerDistribution(inputFISs); % Get layers of all FIS
                uniqueLayersInCurConn = unique(layersInCurConn); % Get each layer involved in the conn
                sortLayers = sort(uniqueLayersInCurConn); % Sort
                curOutputPos = outputPos{OIConnections{i}(1),OIConnections{i}(2)};
                curOutputPos = curOutputPos(3);
                consecLayerFISIdx = find(layersInCurConn == layerOfFirstFis+1);
                consecLayerFIS = inputFISs(consecLayerFISIdx);
                consecLayerFISInputs = inputs(consecLayerFISIdx);
                inputYPos = [];
                for inputFIS = 1:numel(consecLayerFIS)
                    inputYPos = [inputYPos inputPos{consecLayerFIS(inputFIS),...
                        consecLayerFISInputs(inputFIS)}(3)];
                end
                topInputPos = max(inputYPos);
                botInputPos = min(inputYPos);
                if numel(uniqueLayersInCurConn) == 1 && uniqueLayersInCurConn == layerOfFirstFis+1
                    % This connection has only consecutive layer
                    % connections
                    if numel(consecLayerFISInputs) == 1
                        % If only one input involved, no marker needed
                        continue;
                    elseif numel(consecLayerFISInputs) > 1
                        % If more than one inputs involved
                        if sum(inputYPos > curOutputPos) == numel(inputYPos)
                            % All inputs above output, ignore top input
                            topInputPos = max(inputYPos);
                            for inpNumber = 1:numel(consecLayerFISInputs)
                                if inputPos{consecLayerFIS(inpNumber),consecLayerFISInputs(inpNumber)}(3) ...
                                        < topInputPos - 1
                                    outputMarkerBetweenLayers{i,consecLayerFIS(inpNumber)}(consecLayerFISInputs(inpNumber)) = true;
                                end
                            end
                        elseif sum(inputYPos < curOutputPos) == numel(inputYPos)
                            % All inputs below output, ignore bottom input
                            botInputPos = min(inputYPos);
                            for inpNumber = 1:numel(consecLayerFISInputs)
                                if inputPos{consecLayerFIS(inpNumber),consecLayerFISInputs(inpNumber)}(3) ...
                                        > botInputPos + 1
                                    outputMarkerBetweenLayers{i,consecLayerFIS(inpNumber)}(consecLayerFISInputs(inpNumber)) = true;
                                end
                            end
                        elseif sum(curOutputPos > inputYPos) ~= numel(inputYPos)
                            % Inputs below and above output
                            % Center marker needed
                            % Ignore top and bottom inputs
                            outputCenterMarkers{i,OIConnections{i}(1)}(OIConnections{i}(2)) = true; % Center marker
                            topInputPos = max(inputYPos);
                            botInputPos = min(inputYPos);
                            for inpNumber = 1:numel(consecLayerFISInputs)
                                inputY = inputPos{consecLayerFIS(inpNumber),consecLayerFISInputs(inpNumber)}(3);
                                if  inputY > botInputPos + 1 && inputY < topInputPos - 1
                                    outputMarkerBetweenLayers{i,consecLayerFIS(inpNumber)}(consecLayerFISInputs(inpNumber)) = true;
                                end
                            end
                        end
                    end
                else
                    % This connection has Non-Consecutive layer connections
                    if numel(consecLayerFISInputs) == 1
                        % If only one input involved
                        if inputYPos > curOutputPos
                            % If input above output, center marker needed
                            outputCenterMarkers{i,OIConnections{i}(1)}(OIConnections{i}(2)) = true; % Center marker
                        elseif inputYPos < curOutputPos
                            % If input below output, input marker needed
                            outputMarkerBetweenLayers{i,consecLayerFIS}(consecLayerFISInputs) = true;
                        end
                    elseif numel(consecLayerFISInputs) > 1
                        % If multiple inputs involved
                        if sum(inputYPos > curOutputPos) == numel(inputYPos)

                            % All inputs above output
                            % Center marker needed, ignore top input
                            outputCenterMarkers{i,OIConnections{i}(1)}(OIConnections{i}(2)) = true; % Center marker
                            topInputPos = max(inputYPos);
                            for inpNumber = 1:numel(consecLayerFISInputs)
                                if inputPos{consecLayerFIS(inpNumber),consecLayerFISInputs(inpNumber)}(3) ...
                                        < topInputPos - 1
                                    outputMarkerBetweenLayers{i,consecLayerFIS(inpNumber)}(consecLayerFISInputs(inpNumber)) = true;
                                end
                            end

                        elseif sum(inputYPos < curOutputPos) == numel(inputYPos)
                            % All inputs below output
                            % Center marher not needed, no inputs ignored
                            for inpNumber = 1:numel(consecLayerFISInputs)
                                outputMarkerBetweenLayers{i,consecLayerFIS(inpNumber)}(consecLayerFISInputs(inpNumber)) = true;
                            end
                        elseif sum(curOutputPos > inputYPos) ~= numel(inputYPos)
                            outputCenterMarkers{i,OIConnections{i}(1)}(OIConnections{i}(2)) = true; % Center marker
                            % Inputs both below and above output
                            % Center marker needed
                            % Ignore top input
                            for inpNumber = 1:numel(consecLayerFISInputs)
                                if inputPos{consecLayerFIS(inpNumber),consecLayerFISInputs(inpNumber)}(3) ...
                                        < topInputPos - 1
                                    outputMarkerBetweenLayers{i,consecLayerFIS(inpNumber)}(consecLayerFISInputs(inpNumber)) = true;
                                end
                            end
                        end
                    end
                end
            end
            obj.OutputMarkerBetweenLayers = outputMarkerBetweenLayers;
            obj.OutputCenterMarkers = outputCenterMarkers;
        end
                
        function determineInputOutputMarkers(obj,conn,type)
            %% Calculate if a marker is needed for a specific input or output
            % Output is a cell matrix between connection number and FIS
            % Each index in the matrix is an array of logical values with
            % true meaning existence of a marker
            % Each index in the array corresponds to each input of the FIS
            inputPos = obj.InputPosition;
            IIConnections = conn;
            fisLayerDistribution = obj.FISLayerDistribution;
            %
            cellMatrix = cell(numel(IIConnections), numel(obj.FTREE.FIS));
            % Initialize cell matrix
            inputsOrOutputs = "Inputs";
            for i = 1:numel(IIConnections)
                for j = 1:numel(obj.FTREE.FIS)
                    cellMatrix{i,j} = false(1,numel(obj.FTREE.FIS(j).(inputsOrOutputs)));
                end
            end
            for i = 1:numel(IIConnections)
                % Extract all FIS in connections
                if isempty(IIConnections{i})
                    continue
                end
                layerOfFirstFis = fisLayerDistribution(IIConnections{i}(1));
                FISs = IIConnections{i}(1:2:end); % Get all the FIS in connection
                layersInCurConn = fisLayerDistribution(FISs); % Get layers of all FIS
                uniqueLayersInCurConn = unique(layersInCurConn); % Get each layer involved in the conn
                sortLayers = sort(uniqueLayersInCurConn); % Sort
                for layerIdx = 1:numel(sortLayers)
                    curLayer = sortLayers(layerIdx);
                    FISInCurLayer = find(layersInCurConn == curLayer); % Using find returns indices
                    allCurLayerFisInvolvedInConn = IIConnections{i}(2*FISInCurLayer-1);
                    correspondingInputs = IIConnections{i}(2*FISInCurLayer);
                    inputYPositions = [];
                    startingIdx = 1;
                    if type == "OI" && curLayer == layerOfFirstFis % To skip checking for the output FIS in OI connection
                        startingIdx = 2;
                    end
                    for idx = startingIdx:numel(allCurLayerFisInvolvedInConn)
                        inputYPositions = [inputYPositions ...
                            inputPos{allCurLayerFisInvolvedInConn(idx),correspondingInputs(idx)}(3)];
                    end
                    if type == "II"
                        positionOfInputToSkip = min(inputYPositions);
                    elseif type == "OI"
                        positionOfInputToSkip = max(inputYPositions);
                    end
                    for fisIdx = startingIdx:numel(FISInCurLayer)
                        curFIS = IIConnections{i}(2*FISInCurLayer(fisIdx)-1);
                        curInput = IIConnections{i}(2*FISInCurLayer(fisIdx));
                        curInputYPosition = inputPos{curFIS,curInput}(3);
                        if type == "II" && curInputYPosition > positionOfInputToSkip+1 % 1 pixel provides a threshold
                            cellMatrix{i,curFIS}(curInput) = true;
                        elseif type == "OI" && abs(layerOfFirstFis-curLayer) > 1 && curInputYPosition < positionOfInputToSkip-1
                            % This takes care non-consecutive layer OI
                            % connections (long OI connections)
                            cellMatrix{i,curFIS}(curInput) = true;
                        end
                    end
                end
            end
            if type == "II"
                obj.InputMarkerBetweenLayers = cellMatrix;
            elseif type == "OI"
                obj.OutputMarkerBetweenLayers = cellMatrix;
            end
        end
        
        function determineTopBottomMarkers(obj,conn,type)
            %% Calculate if a marker is needed in the top or bottom connections
            % Output is a matrix between connection number and layer with
            % true value signifying a marker is needed.
            layer = obj.Layer;
            IIConnections = conn;
            fisLayerDistribution = obj.FISLayerDistribution;
            % Determine X direction
            layersWhereMarkerNeeded = false(numel(IIConnections),layer);
            for i = 1:numel(IIConnections)
                % Extract all FIS in connections
                if isempty(IIConnections{i})
                    continue
                end
                FISs = IIConnections{i}(1:2:end);
                layersInCurConn = fisLayerDistribution(FISs);
                uniqueLayersInCurConn = unique(layersInCurConn);
                sortLayers = sort(uniqueLayersInCurConn);
                for layerIdx = 1:numel(sortLayers)
                    if sortLayers(layerIdx) == 1 || layerIdx == numel(sortLayers)
                        % Marker needed above(for top) and below(for bottom) all layers involved in the
                        % connection (other than first and last layer)
                        % No marker needed at the top for layer 1 and
                        % no marker needed for last layer in the connection
                        continue
                    end
                    layersWhereMarkerNeeded(i,sortLayers(layerIdx)) = true;
                end
            end
            if type == "II"
                obj.InputMarkerXDirLayers = layersWhereMarkerNeeded;
            elseif type == "OI"
                obj.OutputMarkerXDirLayers = layersWhereMarkerNeeded;
            end
        end

        function preProcessedII = preProcessIIForPlotting(obj)
            %% Preprocess input-to-input connections to find out if there exist
            % connections from one input to multiple inputs. If such connections
            % exist, group them together as a single connection
            % This function is used by getNumIIConnectionInLayer
            iiConnectionID = obj.FTREE.IIConnectionID;
            preProcessedII = {};
            skipRow = [];
            topConnections = 0;
            fislayerDistribution = obj.FISLayerDistribution;

            % Get all short-circuited connections together
            for connectionNum = 1:size(iiConnectionID,1)
                found = false;
                if any(skipRow == connectionNum)
                    continue
                end
                % Find in preprocessed connections
                for preProcessedConnNum = 1:size(preProcessedII,1)
                    for FIS = 1:2:numel(preProcessedII{preProcessedConnNum})
                        if iiConnectionID(connectionNum,1:2) == preProcessedII{preProcessedConnNum}(FIS:FIS+1)
                            preProcessedII{preProcessedConnNum} = ...
                                [preProcessedII{preProcessedConnNum},iiConnectionID(connectionNum,3:4)];
                            skipRow = [skipRow connectionNum];
                            found = true;
                            break;
                        end
                        if iiConnectionID(connectionNum,3:4) == preProcessedII{preProcessedConnNum}(FIS:FIS+1)
                            preProcessedII{preProcessedConnNum} = ...
                                [preProcessedII{preProcessedConnNum},iiConnectionID(connectionNum,1:2)];
                            skipRow = [skipRow connectionNum];
                            found = true;
                            break;
                        end
                    end
                end
                if ~found
                    if isempty(preProcessedII)
                        preProcessedII{end+1} = iiConnectionID(connectionNum,:); %#ok<*AGROW>
                    else
                        % This branch ensures we get a column instead of a
                        % row
                        preProcessedII{end+1,:} = iiConnectionID(connectionNum,:);
                    end
                end
                % Find in remaining connections
                if ~found
                    for j = connectionNum+1:size(iiConnectionID,1)
                        if iiConnectionID(connectionNum,1:2) == iiConnectionID(j,1:2)
                            skipRow = [skipRow j];
                            preProcessedII{end} = ...
                                [preProcessedII{end},iiConnectionID(j,3:4)];
                        end
                        if iiConnectionID(connectionNum,1:2) == iiConnectionID(j,3:4)
                            skipRow = [skipRow j];
                            preProcessedII{end} = ...
                                [preProcessedII{end} ,iiConnectionID(j,1:2)];
                        end
                        if iiConnectionID(connectionNum,3:4) == iiConnectionID(j,1:2)
                            skipRow = [skipRow j];
                            preProcessedII{end} = ...
                                [preProcessedII{end},iiConnectionID(j,3:4)];
                        end
                        if iiConnectionID(connectionNum,3:4) == iiConnectionID(j,3:4)
                            skipRow = [skipRow j];
                            preProcessedII{end} = ...
                                [preProcessedII{end},iiConnectionID(j,1:2)];
                        end
                    end
                end
            end
            % Find free input in each input-to-input connection
            for preProcessedIdx = 1:numel(preProcessedII)
                currentPreProcessedConn = preProcessedII{preProcessedIdx};
                for FISInputComboIdx = 1:2:numel(currentPreProcessedConn)
                    foundInRight = false;
                    for iiConnIdx = 1:size(iiConnectionID,1)
                        % Any FIS input found on the right side of
                        % iiConnectionID cannot be a free input
                        if currentPreProcessedConn(FISInputComboIdx:FISInputComboIdx+1) == ...
                                iiConnectionID(iiConnIdx,3:4)
                            foundInRight = true;
                            break;
                        end
                    end
                    if ~foundInRight
                        temp = preProcessedII{preProcessedIdx}(1:2);
                        preProcessedII{preProcessedIdx}(1:2) = ...
                            preProcessedII{preProcessedIdx}(FISInputComboIdx:FISInputComboIdx+1);
                        preProcessedII{preProcessedIdx}(FISInputComboIdx:FISInputComboIdx+1) = ...
                            temp;
                    end
                end
            end

            obj.PreProcessedII = preProcessedII;
            % Get top and bottom connections
            for k = 1:numel(preProcessedII)
                if ~isempty(preProcessedII{k})
                    for nextFis = 3:2:numel(preProcessedII{k})
                        if abs(fislayerDistribution(preProcessedII{k}(1)) - ...
                                fislayerDistribution(preProcessedII{k}(nextFis))) > 0
                            topConnections = topConnections +1;
                            break;
                        end
                    end
                end
            end
            obj.NumTopIIConnections = topConnections;
            % Get number of input-to-input connections in each layer
            IIConnections = preProcessedII;
            numIIConnectionInLayer = zeros(1,max(fislayerDistribution));
            for connection = 1:size(IIConnections,1)
                if isempty(IIConnections{connection})
                    continue
                end
                fislayer = fislayerDistribution(IIConnections{connection}(1:2:numel(IIConnections{connection})));
                fislayer = unique(fislayer);
                numIIConnectionInLayer(fislayer) = numIIConnectionInLayer(fislayer) + 1;
            end
            if all(numIIConnectionInLayer==0)
                numIIConnectionInLayer = {};
            end
            obj.NumIIConnectionInLayer = numIIConnectionInLayer;
        end

        function preProcessOIForPlotting(obj)
            %% This method adds to number of top and bottom connections
            % to provide space for routing the multi-layer OI signals.
            % It also determines the number of gaps needed between
            % consecutive layers to accomodate for OI connections.
            table = obj.FTREE.ConnectionTable;
            connectionsFromConnectionTable = [];
            connectionCount = 0;
            bottomConnections = 0;
            skipRow = [];
            preProcessedOI = {};
            fislayerDistribution = obj.FISLayerDistribution;
            for row = 1:size(table,1)
                for column = 1:size(table,2)
                    if ~isempty(table{row,column})
                        for conns = 1:size(table{row,column},1)
                            connectionCount = connectionCount + 1;
                            connectionsFromConnectionTable(connectionCount,:) = ...
                                [row,table{row,column}(conns,1),column,table{row,column}(conns,2)];
                        end
                    end
                end
            end
            % Get all short-circuited connections together
            for i = 1:size(connectionsFromConnectionTable,1)
                if any(skipRow == i)
                    continue
                end
                preProcessedOI{i,1} = connectionsFromConnectionTable(i,:);
                for j = i+1:size(connectionsFromConnectionTable,1)
                    if connectionsFromConnectionTable(i,1:2) == connectionsFromConnectionTable(j,1:2)
                        skipRow = [skipRow j];
                        preProcessedOI{i,1} = [preProcessedOI{i,1},connectionsFromConnectionTable(j,3:4)];
                    end
                end
            end

            obj.PreProcessedOI = preProcessedOI;
            % Get bottom connections
            for preProcessedOIIdx = 1:numel(preProcessedOI)
                if isempty(preProcessedOI{preProcessedOIIdx})
                    continue;
                end
                outputLayer = fislayerDistribution(preProcessedOI{preProcessedOIIdx}(1));
                for inputFISIdx = 3:2:numel(preProcessedOI{preProcessedOIIdx})
                    inputLayer = fislayerDistribution(preProcessedOI{preProcessedOIIdx}(inputFISIdx));
                    if abs(outputLayer-inputLayer) > 1
                        bottomConnections =  bottomConnections + 1;
                        break;
                    end
                end
            end
            obj.NumBottomOIConnections = bottomConnections;
            % Get number of gaps to add between each layer
            numGapsForConsecutiveOI = zeros(obj.Layer-1,1);
            numGapsForNonConsecutiveOI = zeros(obj.Layer-1,1);
            for i = 1:size(preProcessedOI,1)
                layersInvolved = [];
                if isempty(preProcessedOI{i})
                    continue;
                end
                outputFis = preProcessedOI{i}(1);
                layerOfOutputFis = fislayerDistribution(outputFis);
                layersInvolved = [layersInvolved layerOfOutputFis];
                for inputFisIdx = 3:2:numel(preProcessedOI{i})
                    inputFIS = preProcessedOI{i}(inputFisIdx);
                    layerOfinputFis = fislayerDistribution(inputFIS);
                    layersInvolved = [layersInvolved layerOfinputFis-1];
                end
                layersInvolved = unique(layersInvolved');
                numGapsForConsecutiveOI(layersInvolved(1)) = numGapsForConsecutiveOI(layersInvolved(1)) + 1;
                numGapsForNonConsecutiveOI(layersInvolved(2:end)) = numGapsForNonConsecutiveOI(layersInvolved(2:end)) + 1;
            end
            obj.NumConsecOIBetweenEachLayer = numGapsForConsecutiveOI;
            obj.NumNonConsecOIBetweenEachLayer = numGapsForNonConsecutiveOI;
        end
                
        function plotFreeInputs(obj)
            %% Plot the free inputs for FIS tree details
            % axes properties for the FIS blocks
            % Start plotting
            numIIConnectionInLayer = obj.NumIIConnectionInLayer;
            detailAxes = obj.DetailAxes;
            layer = obj.Layer;
            fisLayerDistribution = obj.FISLayerDistribution;
            fisBlockWidth = obj.FISBlockWidth;
            lineWidth = obj.LineWidth;
            lineStyle = obj.LineStyle;
            fisBlockPos = obj.FISBlockPos;
            IIConnections = obj.PreProcessedII;
            OIConnections = obj.PreProcessedOI;
            foundInputInPreprocessedII = false;
            foundInputInPreprocessedOI = false;
            if obj.IsUpdate
                freeInputObjects = obj.FreeInputObjects;
                inputPosition = obj.InputPosition;
                inputText = obj.InputText;
            else
                freeInputObjects = {};
                inputPosition = {};
                inputText = {};
            end
            for layerNum = 1:layer
                for fisId = 1:numel(obj.FTREE.FIS)
                    if fisLayerDistribution(fisId) ~= layerNum % if currFis is not in cur layer. do not plot it.
                        continue
                    end
                    % Plot free inputs
                    for inputNumber = 1:numel(obj.FTREE.FIS(fisId).Inputs)
                        currFISPosition = fisBlockPos{fisId};
                        if ~isempty(numIIConnectionInLayer)
                            adjForIIConn = (numIIConnectionInLayer(layerNum)-1)*...
                                obj.InputToInputConnectionGap;
                        else
                            adjForIIConn = 0;
                        end
                        x1 = currFISPosition(1) - fisBlockWidth*0.8 - adjForIIConn;
                        x2 = currFISPosition(1);
                        gapBetweenEachInput = currFISPosition(4)/(numel(obj.FTREE.FIS(fisId).Inputs)+1);
                        y1 = currFISPosition(2)+currFISPosition(4)-inputNumber*gapBetweenEachInput;
                        y2 = y1;
                        inputPosition{fisId,inputNumber} = [[x1 x2],[y1 y2]];
                        % Prevent input-to-input connections from printing
                        % Check if current input is in preprocessed II
                        % connections
                        for IIConnNum = 1:numel(IIConnections)
                            for FisInputComboIndex = 1:2:numel(IIConnections{IIConnNum})
                                if IIConnections{IIConnNum}(FisInputComboIndex) == fisId && ...
                                        IIConnections{IIConnNum}(FisInputComboIndex+1) == inputNumber
                                    foundInputInPreprocessedII = true;
                                    break;
                                end
                            end
                            if foundInputInPreprocessedII
                                break;
                            end
                        end
                        % Prevent Output-to-input connections from printing
                        for OIConnNum = 1:numel(OIConnections)
                            if ~isempty(OIConnections{OIConnNum})
                                for FisInputComboIndex = 3:2:numel(OIConnections{OIConnNum})
                                    if OIConnections{OIConnNum}(FisInputComboIndex) == fisId && ...
                                            OIConnections{OIConnNum}(FisInputComboIndex+1) == inputNumber
                                        foundInputInPreprocessedOI = true;
                                        break;
                                    end
                                end
                                if foundInputInPreprocessedOI
                                    break
                                end
                            end
                        end

                        if foundInputInPreprocessedII || foundInputInPreprocessedOI
                            foundInputInPreprocessedII = false;
                            foundInputInPreprocessedOI = false;
                            continue;
                        end

                        inputLineX = inputPosition{fisId,inputNumber}(1:2);
                        inputLineY = inputPosition{fisId,inputNumber}(3:4);
                        iX = [inputLineX inputLineX(2)-10 inputLineX(2) inputLineX(2)-10];
                        iY = [inputLineY inputLineY(2)+4 inputLineY(2) inputLineY(2)-4];
                        if obj.IsUpdate
                            set(freeInputObjects{fisId,inputNumber},'XData',iX,'YData',iY)
                            inText = inputText{fisId,inputNumber};
                            inText.Position(1:2) = [0 y1];
                            name = obj.FTREE.FIS(fisId).Inputs(inputNumber).Name;
                            if inText.String~=name
                                inText.String = name;
                            end
                        else
                            fisName = obj.FTREE.FIS(fisId).Name;
                            varName = obj.FTREE.FIS(fisId).Inputs(inputNumber).Name;
                            id = find([obj.FTREE.Inputs]==fisName+"/"+varName,1);
                            tag = sprintf('%s.%d',obj.InputPrefix,id);
                            freeInputObjects{fisId,inputNumber} = plotLine(obj, ...
                                iX,iY,detailAxes,lineStyle,lineWidth, ...
                                obj.SemanticInputColor,tag,'None');
                            inputText{fisId,inputNumber} = text(detailAxes,0,y1, ...
                                obj.FTREE.FIS(fisId).Inputs(inputNumber).Name, ...
                                'Interpreter','none', ...
                                'Tag',tag, ...
                                'UserData',freeInputObjects{fisId,inputNumber} ...
                                ); % X position is adjusted later in adjustInputNames method
                        end
                    end
                end
            end
            obj.InputPosition = inputPosition;
            obj.FreeInputObjects = freeInputObjects;
            obj.InputText = inputText;
        end        

        function plotFreeOutputs(obj)
            %% Plot free outputs for FIS tree details
            detailAxes = obj.DetailAxes;
            layer = obj.Layer;
            fisLayerDistribution = obj.FISLayerDistribution;
            fisBlockWidth = obj.FISBlockWidth;
            lineStyle = obj.LineStyle;
            lineWidth = obj.LineWidth;
            fisBlockPos = obj.FISBlockPos;
            freeOutputs = obj.FTREE.getFreeOutputs; % output IDs column has FIS number, 2nd column has output number
            OutputSequence = obj.FTREE.OutputSequenceID; % contains unused outputs
            if ~isempty(OutputSequence)
                unusedOutputs = setdiff(freeOutputs,OutputSequence,'rows'); % get unused outputs
                outputIDs = setdiff(freeOutputs,unusedOutputs,'rows'); % prevent unused outputs from plotting here
            else
                outputIDs = freeOutputs;
            end
            if obj.IsUpdate
                freeOutputObjects = obj.FreeOutputObjects;
                outputPosition = obj.OutputPosition;
                outputText = obj.OutputText;
            else
                freeOutputObjects = {};
                outputPosition = {};
                outputText = {};
            end
            for layerNum = 1:layer
                for fisId = 1:numel(obj.FTREE.FIS)
                    if fisLayerDistribution(fisId) ~= layerNum % if currFis is not in cur layer. do not plot it.
                        continue
                    end
                    % Plot free outputs
                    for outputNumber = 1:numel(obj.FTREE.FIS(fisId).Outputs)
                        currFisBlockPostion = fisBlockPos{fisId};
                        x1 = currFisBlockPostion(1)+ currFisBlockPostion(3);
                        x2 = x1 + fisBlockWidth*0.8; % taking 80% to prevent outputs touching next layer inputs
                        divisionHeightForOutputs = fisBlockPos{fisId}(4)/(numel(obj.FTREE.FIS(fisId).Outputs)+1);
                        y1 = fisBlockPos{fisId}(2)+fisBlockPos{fisId}(4)-outputNumber*divisionHeightForOutputs;
                        y2 = y1;
                        outputPosition{fisId,outputNumber} = [[x1 x2],[y1 y2]];
                        % Get free outputs for fis with id i
                        fisNumbers = outputIDs(:,1);
                        freeOutputs = outputIDs(fisNumbers == fisId,2);
                        if isempty(find(freeOutputs==outputNumber,1))
                            continue
                        end
                        outputLineX = outputPosition{fisId,outputNumber}(1:2);
                        outputLineY = outputPosition{fisId,outputNumber}(3:4);
                        oX = [outputLineX outputLineX(2)-10 outputLineX(2) outputLineX(2)-10];
                        oY = [outputLineY outputLineY(2)+4 outputLineY(2) outputLineY(2)-4];
                        if obj.IsUpdate
                            set(freeOutputObjects{fisId,outputNumber},'XData',oX,'YData',oY)
                            outText = outputText{fisId, outputNumber};
                            outText.Position(1:2) = [x1+obj.TextToBoxPadding y1];
                            name = obj.FTREE.FIS(fisId).Outputs(outputNumber).Name;
                            if outText.String~=name
                                outText.String = name;
                            end
                        else
                            fisName = obj.FTREE.FIS(fisId).Name;
                            varName = obj.FTREE.FIS(fisId).Outputs(outputNumber).Name;
                            id = find([obj.FTREE.Outputs]==fisName+"/"+varName,1);
                            tag = sprintf('%s.%d',obj.OutputPrefix,id);
                            freeOutputObjects{fisId,outputNumber} = plotLine(obj, ...
                                oX,oY,detailAxes,lineStyle,lineWidth, ...
                                obj.SemanticOutputColor,tag,'None');
                            outputText{fisId, outputNumber} = text(detailAxes, ...
                                x1+obj.TextToBoxPadding,y1, ...
                                obj.FTREE.FIS(fisId).Outputs(outputNumber).Name, ...
                                'Interpreter','none', ...
                                'Tag',tag, ...
                                'UserData',freeOutputObjects{fisId,outputNumber} ...
                                ); % 10 pixels are added to bring the name above the output line
                        end
                    end
                end
            end
            obj.OutputPosition = outputPosition;
            obj.FreeOutputObjects = freeOutputObjects;
            obj.OutputText = outputText;
        end
                
        function getFisBlockPositions(obj)
            %% Generate FIS block positions for each FIS in the FIS tree
            detailAxes = obj.DetailAxes;
            layer = obj.Layer;
            fisLayerDistribution = obj.FISLayerDistribution;
            layerWidths = obj.LayerWidths;
            eachYAxisThinLayerWidth = obj.EachYAxisThinLayerWidth;
            numberYAxisThinLayers = obj.NumberYAxisThinLayers;
            numInpOupEachFisEachLayer = obj.NumLayerWiseInputsOutputs;
            detailHeight = obj.DetailHeight;
            detailWidth = obj.DetailWidth;
            axesPosition = [detailAxes.XLim(1) detailAxes.YLim(1) diff(detailAxes.XLim) diff(detailAxes.YLim)];
            fisBlockPos = cell(numel(obj.FTREE.FIS),1);
            allFisPlotted = false;
            xAxisRightShiftBasedOnIpOpFISNameWidth = layerWidths(1,2); % add layer 1 input width
            while ~allFisPlotted
                for layerNum = 1:layer
                    numFisInCurLayer = sum(fisLayerDistribution == layerNum);
                    % Calc number of max connections (inputs or outputs) in
                    % current layer
                    numMaxConnectionCurLayer = 0;
                    for numFIS = 1:size(numInpOupEachFisEachLayer{layerNum},1)
                        numMaxConnectionCurLayer = numMaxConnectionCurLayer + ...
                            max(numInpOupEachFisEachLayer{layerNum}(numFIS,:));
                    end

                    totalThinLayersNeeded = numMaxConnectionCurLayer + ...
                        numFisInCurLayer*3;
                    numThinLayersToBeLeftAtTop = (numberYAxisThinLayers - ...
                        totalThinLayersNeeded)/2;
                    offsetForLegends = obj.LegendHeight;
                    offsetForTopAndBottomConnections = ...
                        obj.TopAndBottomConnectionGap * obj.NumTopIIConnections;
                    startingYPositionForPlotting = axesPosition(2) + (axesPosition(4)-detailHeight)/2 + detailHeight - ...
                        numThinLayersToBeLeftAtTop*eachYAxisThinLayerWidth - offsetForTopAndBottomConnections - offsetForLegends;
                    yAxisDownShiftBasedOnInputs = 0;

                    for i = 1:numel(obj.FTREE.FIS)
                        if fisLayerDistribution(i) ~= layerNum % If currFis is not in cur layer. do not plot it.
                            continue
                        end
                        numThinLayersDownShift = 3+max(numel(obj.FTREE.FIS(i).Inputs),numel(obj.FTREE.FIS(i).Outputs));
                        yAxisDownShiftBasedOnInputs = yAxisDownShiftBasedOnInputs+numThinLayersDownShift*eachYAxisThinLayerWidth;
                        fisBlockPos{i} = [axesPosition(1)+(axesPosition(3)-detailWidth)/2+xAxisRightShiftBasedOnIpOpFISNameWidth ...
                            startingYPositionForPlotting - yAxisDownShiftBasedOnInputs + eachYAxisThinLayerWidth...
                            layerWidths(layerNum,4) ...
                            (1+max(numel(obj.FTREE.FIS(i).Inputs),numel(obj.FTREE.FIS(i).Outputs)))*eachYAxisThinLayerWidth];

                    end
                    if layerNum ~= layer
                        xAxisRightShiftBasedOnIpOpFISNameWidth = xAxisRightShiftBasedOnIpOpFISNameWidth + ...
                            + layerWidths(layerNum,4) + layerWidths(layerNum,6) + layerWidths(layerNum+1,2);
                    end
                end
                if layerNum==layer
                    allFisPlotted = true;
                end
            end
            obj.FISBlockPos = fisBlockPos;
        end
                
        function initLegend(obj)
            %% Initialize legend data and height.
            obj.LegendData = struct(...
                'Input',struct('Line',{},'Label',{}), ...
                'Output',struct('Line',{},'Label',{}), ...
                'UnusedOutput',struct('Line',{},'Label',{}), ...
                'Connection',struct('Line',{},'Label',{}), ...
                'Joint',struct('Line',{},'Label',{}) ...
                );
            obj.LegendHeight = 65;
        end

        function getFISLayers(obj)
            %% Returns the number of horizontal layers needed to distribute
            % all the FIS blocks. Also returns a mapping between a FIS and
            % its layer number
            [obj.Layer,obj.FISLayerDistribution] = getFISLayers(obj.FTREE);
        end

        function getLayerWidths(obj)
            %% Get layer widths based on the lengths of the input, output
            % FIS names
            dummyFig = figure('Visible','off','Units','pixels');
            dummyAxes = axes(dummyFig,'Units','pixels','Visible','off');
            dummyText = text(dummyAxes,1,1,...
                'dummy','Units','pixels',...
                'Visible','off','Interpreter','none');
            layer = obj.Layer;
            layerDistribution = obj.FISLayerDistribution;
            layerWidths = zeros(layer,6);
            padding = obj.FISBoxNamePadding;
            for layerNumber = 1:layer
                fisInCurrentLayer = find(layerDistribution==layerNumber);
                highestFISNameCharLength = 0;
                highestInputCharLength = 0;
                highestOutputCharLength = 0;
                highestFISNamePixelLength = 0;
                highestInputPixelLength = 0;
                highestOutputPixelLength = 0;
                for fisNumber = fisInCurrentLayer'
                    % Input
                    [highestInputCharLength,highestInputPixelLength] = ...
                        getHighestCharPixelLength(obj,fisNumber,dummyText,"Inputs",...
                        highestInputCharLength,highestInputPixelLength);
                    % Output
                    [highestOutputCharLength,highestOutputPixelLength] = ...
                        getHighestCharPixelLength(obj,fisNumber,dummyText,"Outputs",...
                        highestOutputCharLength,highestOutputPixelLength);
                    % FIS
                    curFISLength = numel(char(obj.FTREE.FIS(fisNumber).Name));
                    [highestFISNameCharLength, highestFISNamePixelLength] = getPixelSizeIfStrLengthIsHigher(...
                        dummyText, obj.FTREE.FIS(fisNumber).Name, curFISLength, highestFISNameCharLength, highestFISNamePixelLength, obj.FISNameFontSize);
                end
                % Update variable with max input, output and FIS Name
                % length for the current layer
                highestFISNamePixelLength = padding + highestFISNamePixelLength + padding;
                % Maintain minimum width of the blocks
                if highestFISNamePixelLength < obj.FISBlockWidth
                    highestFISNamePixelLength = obj.FISBlockWidth;
                end
                % Adjust for input to input conn name overlap
                highestInputPixelLength = highestInputPixelLength + obj.InputToInputNamePadding;
                highestOutputPixelLength = highestOutputPixelLength + obj.InputToInputNamePadding;
                layerWidths(layerNumber,:) = [highestInputCharLength highestInputPixelLength...
                    highestFISNameCharLength highestFISNamePixelLength...
                    highestOutputCharLength highestOutputPixelLength];
            end

            % Add pixels if there are multiple ii connections in a layer
            numIIConnectionInLayer = obj.NumIIConnectionInLayer;
            for i = 1:numel(numIIConnectionInLayer)
                layerWidths(i,2) = layerWidths(i,2) + ...
                    numIIConnectionInLayer(i)*obj.InputToInputConnectionGap;
            end

            % Add pixels if there are oi connections in a layer
            numConsecOIConnections = obj.NumConsecOIBetweenEachLayer;
            numNonConsecOIConnections = obj.NumNonConsecOIBetweenEachLayer;
            for i = 1:numel(numConsecOIConnections) % i is the layer number
                layerWidths(i,6) = layerWidths(i,6) + ...
                    numConsecOIConnections(i)*obj.OutputToInputConnectionGap + ...
                    numNonConsecOIConnections(i)*obj.OutputToInputConnectionGap;
            end
            obj.LayerWidths = layerWidths;
            delete(dummyFig);

        end
        
        function cbLegendToggle(obj)
            %% Toggle legend visibility
            legendObj = obj.DetailLegend;
            legendObj.Visible = xor(legendObj.Visible,true);
        end

        function getAxesDimensions(obj)
            %% Returns the dimension of axes needed to plot the FIS details
            layer = obj.Layer;
            fisLayerDistribution = obj.FISLayerDistribution;
            layerWidths = obj.LayerWidths;
            % Divide each big layer into 3 thin layers. the FIS block then takes
            % the center layer, i.e. 33% of the space in x-direction
            detailWidth = 0;
            for rows = 1:size(layerWidths,1)
                % Add input,FIS Name, output width per layer
                detailWidth = detailWidth+ layerWidths(rows,2)+layerWidths(rows,4)+layerWidths(rows,6);
            end
            %% Calc FIS block height
            % Calc total inputs and outputs in a layer
            numInpOupEachFisEachLayer = cell(layer,1);
            for i = 1:numel(fisLayerDistribution)
                % Here i is FIS number
                layerNumberForFISi = fisLayerDistribution(i);
                numInpOupEachFisEachLayer{layerNumberForFISi} = ...
                    [numInpOupEachFisEachLayer{layerNumberForFISi};...
                    [numel(obj.FTREE.FIS(i).Inputs),numel(obj.FTREE.FIS(i).Outputs)]];
            end
            % Calculate the max height needed for detailAxes
            numBoxesInEachLayer = zeros(1,layer);
            YAxisThinLayersNeeded = zeros(1,layer);
            for layerNum = 1:layer
                numBoxesInEachLayer(layerNum) = ...
                    sum(fisLayerDistribution==layerNum);
                YAxisThinLayersNeeded(layerNum) =...
                    numBoxesInEachLayer(layerNum) + 2*numBoxesInEachLayer(layerNum);
                for numFIS = 1:size(numInpOupEachFisEachLayer{layerNum},1)
                    YAxisThinLayersNeeded(layerNum) = YAxisThinLayersNeeded(layerNum) + ...
                        max(numInpOupEachFisEachLayer{layerNum}(numFIS,:));
                end
            end
            maxYlayers = max(YAxisThinLayersNeeded);
            numberYAxisThinLayers = maxYlayers;
            eachYAxisThinLayerWidth = obj.EachYAxisThinLayerWidth;
            detailHeight = eachYAxisThinLayerWidth * maxYlayers + ...
                obj.TopAndBottomConnectionGap * (obj.NumBottomOIConnections + obj.NumTopIIConnections);
            obj.NumberYAxisThinLayers = numberYAxisThinLayers;
            obj.NumLayerWiseInputsOutputs = numInpOupEachFisEachLayer;
            obj.DetailWidth = detailWidth;
            obj.DetailHeight = detailHeight + obj.LegendHeight;
            obj.MaxAxisHeight = obj.DetailHeight;
        end        
                
        function setFigureAndAxesProps(obj,varargin)
            %% Generates the Figure, Axes and Tabs to plot the FIS details.
            detailWidth = obj.DetailWidth;
            maxAxisHeight = obj.MaxAxisHeight;
            padding = obj.Padding;

            % Find dialog size.
            screenSize = get(0,'ScreenSize');
            offsetH = obj.OffsetFactor*screenSize(3);
            offsetV = obj.OffsetFactor*screenSize(4);
            maxWidth = screenSize(3)-offsetH;
            maxHeight = screenSize(4)-offsetV;

            hPad = 0;
            vPad = 0;
            dialogWidth = detailWidth + 2*padding + 1*hPad;
            if dialogWidth > maxWidth
                dialogWidth = maxWidth;
            end
            dialogHeight = maxAxisHeight + 2*padding + 1*vPad;
            if dialogHeight > maxHeight
                dialogHeight = maxHeight;
            end

            % Get and prepare current figure and axes.
            if isempty(varargin)
                fig = gcf;
                detailAxes = gca;
                detailAxes.Parent = [];
                if fig.NextPlot == "new"
                    fig = figure;
                else
                    clf(fig,'reset')
                    if ~isequal(fig.MenuBar,'figure')
                        fig.MenuBar = 'figure';
                    end
                    legendButton = findall(fig,'Tag','Annotation.InsertLegend');
                    if ~isempty(legendButton) && legendButton.State==matlab.lang.OnOffSwitchState.on
                        legendButton.State = matlab.lang.OnOffSwitchState.off;
                    end
                end

                cla(detailAxes,'reset')
                detailAxes.Parent = fig;
                fig.NextPlot = 'replace';

                %fig.Position(1:2) = figXY;
                fig.Units = 'pixels';
                fig.NumberTitle = 'off';
                fig.Name = getString(message('fuzzy:general:labelFISTreePlotTitle',obj.FTREE.Name));
                fig.AutoResizeChildren = 'off';
                fig.SizeChangedFcn = @(s,e)cbSizeChangeFcn(obj,s);
                legendButton = findall(fig,'Tag','Annotation.InsertLegend');
                if isa(legendButton, 'matlab.ui.container.toolbar.ToggleTool')
                    obj.LegendButtonDefaultCallback = legendButton.ClickedCallback;
                    obj.LegendButton = legendButton;
                    legendButton.ClickedCallback = @(s,e)cbLegendToggle(obj);
                end
            else
                if isa(varargin{1},'matlab.ui.container.Panel')
                    fig = ancestor(varargin{1},'figure','toplevel');
                    panel = varargin{1};
                    delete(panel.Children)
                    detailAxes = uiaxes(panel,'Visible','off','Toolbar',[]);
                    panel.AutoResizeChildren = 'off';
                    panel.SizeChangedFcn = @(s,e)cbResizeDetailAxes(obj,s);
                    fig.WindowButtonDownFcn = @(s,e)cbMouseDown(obj,e);
                    fig.WindowButtonUpFcn = @(s,e)cbMouseUp(obj,e);
                else
                    fig = varargin{1};
                    delete(fig.Children)
                    panel = uipanel(fig,'Scrollable',obj.Scrollable, ...
                        'BorderType','none', ...
                        'BackgroundColor','white' ...
                        );
                    panel.Position = [0.5*padding 0.5*padding ...
                        fig.Position(3)-1*padding ...
                        fig.Position(4)-1*padding];
                    detailAxes = uiaxes(panel);
                    fig.AutoResizeChildren = 'off';
                    fig.SizeChangedFcn = @(s,e)cbSizeChangeParent(obj,s);
                end
            end

            detailAxes.Units = 'pixel';
            detailAxes.HandleVisibility = 'on';
            if isempty(varargin)
                fig.WindowButtonMotionFcn = @(s,e)cbFigure(obj,e);
                detailAxes.Visible = 'on';
                detailAxes.Position = [...
                    0.5*padding 0.5*padding ...
                    dialogWidth-(1*padding + 1*hPad) ...
                    dialogHeight-(1*padding + 1*vPad)];
            else
                fig.WindowButtonMotionFcn = @(s,e)cbNoAction(obj,e);
                pose = panel.Position;

                if obj.Scrollable
                    axesWidth = detailWidth+1*padding;
                    axesHeight = maxAxisHeight+1*padding;
                    startX = 1 + max(0,pose(3)-axesWidth)/2;
                    startY = 1 + max(0,pose(4)-axesHeight)/2;
                    detailAxes.Position = [...
                        startX startY axesWidth axesHeight];
                else
                    heightOffset = 0;
                    if obj.AppMode
                        heightOffset = obj.Padding/2;
                    end
                    detailAxes.Position(3:4) = [...
                        pose(3)-detailAxes.Position(1) ...
                        pose(4)-detailAxes.Position(2)-heightOffset ...
                        ];
                end
            end
            detailAxes.XLim = [1 detailWidth];
            detailAxes.YLim = [1 maxAxisHeight];
            detailAxes.Tag = 'fisTreeDetailPlotFisAxes';
            detailAxes.XTick = [];
            detailAxes.YTick = [];
            specifyThemePropertyMappings(detailAxes,'Color',obj.SemanticDetailAxesColor)
            specifyThemePropertyMappings(detailAxes,'XColor',obj.SemanticDetailAxesColor)
            specifyThemePropertyMappings(detailAxes,'YColor',obj.SemanticDetailAxesColor)
            detailAxes.DeleteFcn = @(src,data)cbDeleteFcn(obj,src);

            % Set figure dimension
            if isempty(varargin)
                fig.Position(1) = round(offsetH/2 + (maxWidth - dialogWidth)/2);
                fig.Position(2) = round(offsetV/2 + (maxHeight - dialogHeight)/2);
                fig.Position(3:4) = [dialogWidth dialogHeight];
            end

            obj.DetailAxes = detailAxes;
        end
                
        function reset(obj)
            %% Resets properties that store plot data.
            obj.DetailAxes = [];
            commonReset(obj)
        end

    end

    %% App access methods
    methods(Access=?fuzzy.app.utils.FuzzySystemAppComponent)
        function updateWidgetPositions(obj)
            %%
            if ~obj.IsUpdate
                return
            end

            % Generate dimensions for figure and axes
            getAxesDimensions(obj);
            obj.DetailAxes.XLim = [1 obj.DetailWidth];
            obj.DetailAxes.YLim = [1 obj.MaxAxisHeight];

            % Plot fis tree details
            plotDetails(obj);

            % Adjust name Y position in detail axes
            adjustNameHeights(obj)

            % Adjust Dialog Width
            adjustDialogAndAxesWidth(obj)
        end
        
        function updatePlot(obj)
            %% Update plot without changing parent.
            valid = @(x)~isempty(x)&&isvalid(x);
            if ~valid(obj.DetailAxes)
                return
            end

            resetAxesChildren(obj)

            % Get number of layers and each FIS layer location
            getFISLayers(obj);

            % Preprocess connections
            getPreprocessedConnections(obj)

            % Get X-axis layer Widths based on the input,output and FIS
            % Names
            getLayerWidths(obj);

            % Generate dimensions for figure and axes
            getAxesDimensions(obj);
            obj.DetailAxes.XLim = [1 obj.DetailWidth];
            obj.DetailAxes.YLim = [1 obj.MaxAxisHeight];

            % Plot fis tree details
            plotDetails(obj);

            % Adjust name Y position in detail axes
            adjustNameHeights(obj)

            % Add a legend
            createLegends(obj)

            % Adjust Dialog Width
            adjustDialogAndAxesWidth(obj)

            % Set legend visibility
            obj.DetailLegend.Visible = obj.ShowLegend;

            obj.IsUpdate = true;
        end

        function yes = isFISSelected(obj,id)
            %%
            fis = obj.FISPatches{id};
            yes = isequal(getThemePropertyMapping(fis,'EdgeColor'),obj.SemanticSelectColor);
        end

        function selectFIS(obj,varargin)
            %%
            if isempty(varargin)
                fis = obj.LastSelectedObject;
            else
                fis = obj.FISPatches{varargin{1}};
                obj.LastSelectedObject = fis;
            end

            specifyThemePropertyMappings(fis,'EdgeColor',obj.SemanticSelectColor)
            fis.LineWidth = obj.SelectWidth;
        end

        function yes = isInputSelected(obj,id)
            %%
            in = obj.FTREE.Inputs(id);
            tokens = strsplit(in,'/');
            fisName = tokens(1);
            varName = tokens(2);
            fisId = find([obj.FTREE.FIS.Name]==fisName,1);
            varId = find([obj.FTREE.FIS(fisId).Inputs.Name]==varName,1);
            h = obj.InputText{fisId,varId}.UserData;
            yes = isequal(getThemePropertyMapping(h,'Color'),obj.SemanticSelectColor);
        end

        function yes = isOutputSelected(obj,id)
            %%
            in = obj.FTREE.Outputs(id);
            tokens = strsplit(in,'/');
            fisName = tokens(1);
            varName = tokens(2);
            fisId = find([obj.FTREE.FIS.Name]==fisName,1);
            varId = find([obj.FTREE.FIS(fisId).Outputs.Name]==varName,1);
            h = obj.OutputText{fisId,varId}.UserData;
            yes = isequal(getThemePropertyMapping(h,'Color'),obj.SemanticSelectColor);
        end

        function selectInput(obj,varargin)
            %%
            if isempty(varargin)
                h = obj.LastSelectedObject;
            else
                in = obj.FTREE.Inputs(varargin{1});
                tokens = strsplit(in,'/');
                fisName = tokens(1);
                varName = tokens(2);
                fisId = find([obj.FTREE.FIS.Name]==fisName,1);
                varId = find([obj.FTREE.FIS(fisId).Inputs.Name]==varName,1);
                h = obj.InputText{fisId,varId}.UserData;
                obj.LastSelectedObject = h;
            end
            specifyThemePropertyMappings(h,'Color',obj.SemanticSelectColor)
        end

        function selectOutput(obj,varargin)
            %%
            if isempty(varargin)
                h = obj.LastSelectedObject;
            else
                in = obj.FTREE.Outputs(varargin{1});
                tokens = strsplit(in,'/');
                fisName = tokens(1);
                varName = tokens(2);
                fisId = find([obj.FTREE.FIS.Name]==fisName,1);
                varId = find([obj.FTREE.FIS(fisId).Outputs.Name]==varName,1);
                h = obj.OutputText{fisId,varId}.UserData;
                obj.LastSelectedObject = h;
            end
            specifyThemePropertyMappings(h,'Color',obj.SemanticSelectColor)
        end

        function yes = isConnectionSelected(obj,refId)
            %%
            yes = false;
            if isempty(obj.LastSelectedObject)
                return
            end

            tag = obj.LastSelectedObject.Tag;
            if ~startsWith(tag,obj.ConnectionPrefix)
                return
            end

            h = getConnHandles(obj,refId);
            yes = isequal(getThemePropertyMapping(h,'Color'),obj.SemanticSelectColor);
        end

        function [lne,mrk] = getConnHandles(obj,actId)
            %%
            connId = find(obj.FTREE.IIConnectionOrder==actId,1);
            if isempty(connId)
                connId = find(obj.FTREE.OIConnectionOrder==actId,1);
                plotConnId = obj.OIConnectionOrder(connId,:);
                if isempty(obj.OIMarkers)
                    mrk = {};
                else
                    mrkId = plotConnId(3);
                    if mrkId==0
                        mrk = {};
                    else
                        mrk = obj.OIMarkers{mrkId};
                    end
                end
                lne = obj.OIConnObjects{plotConnId(1),plotConnId(2)};
            else
                plotConnId = obj.IIConnectionOrder(connId);
                mrk = obj.IIMarkers{plotConnId};
                lne = obj.IIConnObjects{plotConnId};
            end
        end

        function selectConnection(obj,id)
            %%
            [conn,markers] = getConnHandles(obj,id);
            obj.LastSelectedObject = conn;
            specifyThemePropertyMappings(conn,'Color',obj.SemanticSelectColor)
            for mId = 1:numel(markers)
                specifyThemePropertyMappings(markers{mId},'Color',obj.SemanticSelectColor)
            end
        end

        function unselect(obj)
            %%
            if isempty(obj.LastSelectedObject)
                return
            end

            tag = obj.LastSelectedObject.Tag;
            if startsWith(tag,obj.FISPrefix)
                unselectFIS(obj)
            elseif startsWith(tag,obj.InputPrefix)
                unselectInput(obj)
            elseif startsWith(tag,obj.OutputPrefix)
                unselectOutput(obj)
            elseif startsWith(tag,obj.ConnectionPrefix)
                id = extract(tag,digitsPattern);
                idValue = str2double(id{1});
                unselectConnection(obj,idValue)
            end
        end
    
        function click(obj,comp)
            %%
            setMouseDownObject(obj,comp)
            if isempty(obj.MouseDownObject)
                return
            end
            selectAndNotify(obj,comp)
        end
        
        function addHiliteCallback(obj,fig)
            %%
            fig.WindowButtonMotionFcn = @(s,e)cbNoAction(obj,e);
        end
        
        function addSelectionCallback(obj,fig)
            %%
            fig.WindowButtonDownFcn = @(s,e)cbMouseDown(obj,e);
            fig.WindowButtonUpFcn = @(s,e)cbMouseUp(obj,e);
        end
    end
end
%% Helper functions -------------------------------------------------------
function [highestLength, highestPixelLength] = getPixelSizeIfStrLengthIsHigher(...
    textObj, name, curLength, highestLength, highestPixelLength,fontSize)
%% Returns the pixel length, either old value or length of the new string
% whichever is higher
if curLength > highestLength
    highestLength = curLength;
    textObj.FontSize = fontSize;
    textObj.String = name;
    pixelSize = textObj.Extent(3);
    if pixelSize > highestPixelLength
        highestPixelLength = pixelSize;
    end
end
end

function specifyThemePropertyMappings(varargin)
%%
matlab.graphics.internal.themes.specifyThemePropertyMappings(varargin{:})
end

function value = getThemePropertyMapping(varargin)
%%
value = matlab.graphics.internal.themes.getThemePropertyMapping(varargin{:});
end