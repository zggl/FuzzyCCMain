classdef RuleKeyWords
    %% RuleKeyWords Superclass of different keywords used in fuzzy rules.
    %
    %  RuleKeyWords defines keyword interfaces for parsing rules specified
    %  in text format.
    %
    %  RuleKeyWords properties:
    %    If    - Specifies expression for 'if'.
    %    And   - Specifies expression for 'and'.
    %    Or    - Specifies expression for 'or'.
    %    Then  - Specifies expression for 'then'.
    %    Equal - Specifies expression for 'equal'.
    %    Is    - Specifies expression for 'is'.
    %    Not   - Specifies expression for 'not'.
    %    IsNot - Specifies expression for 'is not'.
    %
    %  RuleKeyWords also defines the following protected property:
    %    WithSpace - A logical flag to specify keywords with leading and
    %                trailing spaces.
    
    %  Copyright 2017-2018 The MathWorks, Inc.
    
    properties(Abstract,SetAccess=protected)
        %% If - Expression for 'if'
        If
        
        %% And - Expression for 'and'
        And
        
        %% Or - Expression for 'or'
        Or
        
        %% Then - Expression for 'then'
        Then
        
        %% Equal - Expression for 'equal'
        Equal
        
        %% Is - Expression for 'is'
        Is
        
        %% Not - Expression for 'not'
        Not
        
        %% IsNot - Expression for 'is not'
        IsNot
    end
       
    properties(Access=protected)
        %% WithSpace - Flag for specifying keywords with leading and trailing spaces
        WithSpace
    end
    
    %% Protected constructor
    methods(Access=protected)
        function obj = RuleKeyWords(varargin)
            %% RuleKeyWords - Constructor
            %
            %   RuleKeyWords cannot be directly constructed. Its subclasse
            %   must invoke it.
            %   OBJ = RuleKeyWords(NAME,VALUE) Constructs a RuleKeyWords
            %   object.
            %
            %   You can specify the following parameter name/value pair:
            %
            %     WithSpace - A logical flag that specifies if the keywords
            %     are expressed with leading and trailing spaces. Its
            %     default value is 'false'.
            
            p = inputParser;
            p.addParameter('WithSpace',false)
            p.parse(varargin{:})
                        
            if p.Results.WithSpace
                obj.If = [' ' strip(obj.If) ' '];
                obj.And = [' ' strip(obj.And) ' '];
                obj.Or = [' ' strip(obj.Or) ' '];
                obj.Then = [' ' strip(obj.Then) ' '];
                obj.Equal = [' ' strip(obj.Equal) ' '];
                obj.Is = [' ' strip(obj.Is) ' '];
                obj.Not = [' ' strip(obj.Not) ' '];
                obj.IsNot = [' ' strip(obj.IsNot) ' '];
            end
            obj.WithSpace = p.Results.WithSpace;
        end
    end    
    
    methods
        function value = then(obj)
            %% THEN returns expression of 'then' keyword
            %
            %  VALUE = THEN(OBJ) returns expression of 'then' keyword. It
            %  is introduced to determine language type of a fuzzy rule
            %  without explicitly creating different keyword objects. For
            %  example, we can get 'then' expression by anonymously
            %  creating an object as follows:
            %   thenKeyWord = then(<Subclass of RuleKeyWords>);
            value = obj.Then;
        end
        
        function keys = getKeySet(obj)
            keys = [...
                string(strip(obj.If)) ...
                string(strip(obj.And)) ...
                string(strip(obj.Or)) ...
                string(strip(obj.Then)) ...
                string(strip(obj.Equal)) ...
                string(strip(obj.Is)) ...
                string(strip(obj.Not)) ...
                string(strip(obj.IsNot)) ...
                ];
        end
    end
    
end