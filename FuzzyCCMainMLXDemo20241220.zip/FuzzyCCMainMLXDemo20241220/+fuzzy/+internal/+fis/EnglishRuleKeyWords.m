classdef (Sealed) EnglishRuleKeyWords < fuzzy.internal.fis.RuleKeyWords
%% EnglishRuleKeyWords - English keywords used in a fuzzy rule
%
%  EnglishRuleKeyWords defines English keywords used in a text fuzzy rule.
%  It implemented the interface defined by RuleKeyWords.
% 
%  The following default property values are used for English keywords:
%
%    Property    Value 
%    --------    -----
%    If          'If '
%    And         ' and '
%    Or          ' or '
%    Then        ' then '
%    Equal       ' is '
%    Is          ' is '
%    Not         ' not '
%    IsNot       ' is not '

%  Copyright 2017-2018 The MathWorks, Inc.
    
    properties(SetAccess=protected)
        %% If - English expression for 'if'
        %   Its default value is specified as 'If '.
        If = 'If ';
        
        %% And - English expression for 'and'
        %   Its default value is specified as ' and '.
        And = ' and ';
        
        %% Or - English expression for 'or'
        %   Its default value is specified as ' or '.
        Or = ' or ';
        
        %% Then - English expression for 'then'
        %   Its default value is specified as ' then '.
        Then = ' then ';
        
        %% Equal - English expression for 'equal'
        %   Its default value is specified as ' is '.
        Equal = ' is ';
        
        %% Is - English expression for 'is'
        %   Its default value is specified as ' is '.
        Is = ' is ';
        
        %% Not - English expression for 'not'
        %   Its default value is specified as ' not '.
        Not = ' not ';
        
        %% IsNot- English expression for 'is not'
        %   Its default value is specified as ' is not '.
        IsNot = ' is not ';
    end
   
    %% Constructor
    methods
        function obj = EnglishRuleKeyWords(varargin)
            %% EnglishRuleKeyWords - Constructor
            %
            %   OBJ = EnglishRuleKeyWords(NAME,VALUE) constructs an
            %   EnglishRuleKeyWords object.
            %
            %   You can specify the following parameter name/value pair:
            %
            %     WithSpace - A logical flag that specifies if the keywords
            %     are expressed with leading and trailing spaces. Its
            %     default value is 'false'.            
            
            obj = obj@fuzzy.internal.fis.RuleKeyWords(varargin{:});
        end
    end
    
end