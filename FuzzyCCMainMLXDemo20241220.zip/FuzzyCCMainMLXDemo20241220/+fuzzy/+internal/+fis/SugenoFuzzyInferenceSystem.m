classdef SugenoFuzzyInferenceSystem

   %
   
   %
   
   %  Copyright 2019 The MathWorks, Inc.

   %% Constant
   properties(Constant,Hidden)
       DefaultTypeValue = "sugeno";
       DefaultAndValue = "prod";
       DefaultOrValue = "probor";
       DefaultImpValue = "prod";
       DefaultAggValue = "sum";
       DefaultDefuzzValue = "wtaver";
       DefaultOutputMFTypeValue = getDefaultOutputMFType;
       DefaultOutputMFParametersValue = getDefaultOutputMFParameters;
   end
   
   methods(Access=protected)
        function validateImplicationMethodLocal(~,value,isFcnHandle)
            if value ~= "prod"
                if isFcnHandle
                    error(message("fuzzy:general:errSugfis_InvalidImpMethodHandle"))
                else
                    error(message("fuzzy:general:errSugfis_InvalidImpMethodName"))
                end
            end            
        end

        function validateAggregationMethodLocal(~,value,isFcnHandle)
            if value ~= "sum"
                if isFcnHandle
                    error(message("fuzzy:general:errSugfis_InvalidAggMethodHandle"))
                else
                    error(message("fuzzy:general:errSugfis_InvalidAggMethodName"))
                end
            end
        end

        function validateDefuzzificationMethodLocal(~,value,isFcnHandle)
            if ~any(value == ["wtaver" "wtsum"])
                if isFcnHandle
                    error(message("fuzzy:general:errSugfis_InvalidDefuzzMethodHandle"))
                else
                    error(message("fuzzy:general:errSugfis_InvalidDefuzzMethodName"))
                end
            end
        end

        function [refValue,msgKey] = getDefaultOutputMFTypeOptionsLocal(~,value)
            [refValue,msgKey] = fuzzy.internal.utility.defaultSugenoOutputMFTypeOptions(value);
        end
        
        function validateOutputMFTypeLocal(~,value,isFcnHandle)
            if ~all(ismember(value,["constant" "linear"]))
                if isFcnHandle
                    error(message("fuzzy:general:errSugfis_InvalidSugenoOutputMFHandle"))
                else
                    error(message("fuzzy:general:errSugfis_InvalidSugenoOutputMFName"))
                end
            end
        end        
        
        function validateOutputMFParametersLocal(fis,mf)
            inputLength = length(getVariable(fis,'Inputs'));
            for i = 1:length(mf)                
                % Checking only for linear function, since it depends on
                % number of FIS inputs. Other known MF parameters can be
                % checked at construction-time without FIS context.
                if mf(i).Type == "linear"
                    if length(mf(i).Parameters) ~= inputLength+1
                        error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidLinearMFParam'))
                    end
                end
            end
        end
        
        function fis = addDefaultOutputMFsLocal(fis,id,numMFs,mfType)
            if numMFs > 0
                output = getVariable(fis,'Outputs',id);
                inputLength = length(getVariable(fis,'Inputs'));
                range = output.Range;
                params = fuzzy.internal.utility.createMFParams("constant",range,numMFs);
                mfType = fuzzy.internal.utility.convertToCharIfStringOrFcnHandle(mfType);
                for i = 1:numMFs
                    if mfType == "linear"
                        paramValue = [zeros(1,inputLength) params(i)];
                    else
                        paramValue = params(i);
                    end
                    output = addMF(output,mfType,paramValue);
                end
                fis = setVariable(fis,output,'Outputs',id);
            end
        end
        
        function fis = updateOutputMFParametersForAddingInputsLocal(fis)
            output = getVariable(fis,'Outputs');
            inputLength = length(getVariable(fis,'Inputs'));
            for outputID = 1:length(output)
                mf = output(outputID).MembershipFunction;
                updated = false;
                for mfID = 1:length(mf)
                    if mf(mfID).Type == "linear"
                        params = zeros(1,inputLength+1);
                        params(end) = mf(mfID).Parameters(end);
                        params(1:end-2) = mf(mfID).Parameters(1:end-1);
                        mf(mfID).Parameters = params;
                        if ~updated
                            updated = true;
                        end
                    end
                end
                if updated
                    output(outputID).MembershipFunction = mf;
                end
            end
            fis = setVariable(fis,output,'Outputs');
        end
        
        function fis = updateOutputMFParametersForRemovingInputsLocal(fis,id)
            output = getVariable(fis,'Outputs');
            input = getVariable(fis,'Inputs');
            for outputID = 1:length(output)
                mf = output(outputID).MembershipFunction;
                updated = false;
                for mfID = 1:length(mf)
                    if mf(mfID).Type == "linear"
                        if isempty(input)
                            error(message("fuzzy:general:errSugfis_LinearMFWithoutInput"))
                        end
                        mf(mfID).Parameters(id) = [];
                        if ~updated
                            updated = true;
                        end
                    end
                end
                if updated
                    output(outputID).MembershipFunction = mf;
                end
            end
            fis = setVariable(fis,output,'Outputs');
        end
        
        function fis = updateOutputMFParametersLocal(fis,preFIS)
            id = struct('output',[],'mf',[]);
            output = getVariable(fis,'Outputs');
            for outputID = 1:length(output)
                for mfID = 1:length(output(outputID).MembershipFunction)
                    if output(outputID).MembershipFunction(mfID).Type == "linear"
                        id.output = [id.output outputID];
                        id.mf = [id.mf mfID];
                    end
                end
            end
            
            if isempty(id.mf)
                return
            end

            input = getVariable(fis,'Inputs');
            if isempty(input)
                error(message("fuzzy:general:errSugfis_LinearMFWithoutInput"))
            end
            
            preInputNames = [preFIS.Inputs.Name];
            currInputNames = [fis.Inputs.Name];
            commonNames = intersect(preInputNames,currInputNames);
            
            coeffs = zeros(1,length(input));
            if isempty(commonNames)
                for i = 1:length(id)
                    const = output(id.output(i)).MembershipFunctions(id.mf(i)).Parameters(end);
                    output(id.output(i)).MembershipFunctions(id.mf(i)).Parameters = [coeffs const];
                end
            else
                preIndex = findIndex(preInputNames,commonNames);                
                currIndex = findIndex(currInputNames,commonNames);
                
                for i = 1:length(id.mf)
                    const = output(id.output(i)).MembershipFunctions(id.mf(i)).Parameters(end);
                    
                    for j = 1:length(preIndex)                    
                        coeffs(currIndex(j)) = output(id.output(i)).MembershipFunctions(id.mf(i)).Parameters(preIndex(j));
                    end
                    output(id.output(i)).MembershipFunctions(id.mf(i)).Parameters = [coeffs const];
                end
                
            end
            fis = setVariable(fis,output,'Outputs');
        end
        
        function var = updateDefaultOutputMFTypeLocal(fis,var)
            inputLength = length(getVariable(fis,'Inputs'));
            for i = 1:length(var)
                mfs = var(i).MembershipFunction;
                for j = 1:length(mfs)
                    mf = mfs(j);
                    if mf.UsingDefaultType                        
                        mf.Type = "constant";
                        mf.UsingDefaultType = false;                        
                    end
                    if mf.UsingDefaultParameterValue
                        if mf.Type == "linear"
                            n = inputLength + 1;
                            params = mf.Parameters;
                            paramLength = length(params);
                            if paramLength < n
                                numDiff = n - paramLength;
                                mf.Parameters = [zeros(1,numDiff) params];
                            elseif paramLength > n
                                mf.Parameters = params(1:n);
                            end
                            mf.UsingDefaultParameterValue = false;
                        end                                                
                    end
                    mfs(j) = mf;
                end
                var(i).MembershipFunction = mfs;
            end
        end

        function id = getNonExistenceImpMsgIDLocal(~,isFcnHandle)
            if isFcnHandle
                id = "fuzzy:general:errFIS_NonexistentSugImpMethodHandle";
            else
                id = "fuzzy:general:errFIS_NonexistentSugImpMethodName";
            end
        end
        
        function id = getNonExistenceAggMsgIDLocal(~,isFcnHandle)
            if isFcnHandle
                id = "fuzzy:general:errFIS_NonexistentSugAggMethodHandle";
            else
                id = "fuzzy:general:errFIS_NonexistentSugAggMethodName";
            end
        end
        
        function id = getNonExistenceDefuzzMsgIDLocal(~,isFcnHandle)
            if isFcnHandle
                id = "fuzzy:general:errFIS_NonexistentSugDefuzzMethodHandle";
            else
                id = "fuzzy:general:errFIS_NonexistentSugDefuzzMethodName";
            end
        end
              
   end
   
   methods(Static)
       function validateOutputFSType(var)
           for i = 1:numel(var)
               if ~any(class(var(i).MembershipFunctions) == "fismf")
                   error(message("fuzzy:general:errSugenoFIS_invalidOutputFS"))
               end
           end
       end
   end
   
    %% Abstract protecteted methods.
    methods(Abstract,Access=protected)
        var = getVariable(fis,varType,varargin)
        fis = setVariable(fis,value,varType,varargin)
    end
       
end
%% Helper functions -------------------------------------------------------
function index = findIndex(names,refNames)
index = [];
for i = 1:numel(refNames)
    index = [index find(refNames(i)==names,1)]; %#ok<AGROW>
end
end

function mfType = getDefaultOutputMFType
options = fuzzy.internal.utility.defaultSugenoOutputMFTypeOptions;
mfType = options{1};
end

function params = getDefaultOutputMFParameters
params = fuzzy.internal.utility.createMFParams(getDefaultOutputMFType);
end