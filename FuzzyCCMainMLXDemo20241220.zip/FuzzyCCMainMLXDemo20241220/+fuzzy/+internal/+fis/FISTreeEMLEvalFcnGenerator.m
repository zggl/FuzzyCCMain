classdef FISTreeEMLEvalFcnGenerator < fuzzy.internal.fis.UsesFISTree
    %% FISTreeEMLEvalFcnGenerator - utility class to generate an evaluation
    %  for a FIS tree in the form of text. This is used to support code
    %  generation

    % Copyright 2022 The MathWorks, Inc.

    properties(Access=private)
        FTREE;
    end

    %% Constructor
    methods
        function obj = FISTreeEMLEvalFcnGenerator(tree)
            %% Create a FISTreeEMLEvalFcnGenerator object
            obj.FTREE = tree;
        end
    end

    %% Hidden method
    methods(Hidden)
        function outputStr = createCodeGenFcn(obj, postfix)
            %% Generate a string representing a flattened tree structure
            outputStr = "";
            outputStr = outputStr + generateEvalfistreeMulitpleData(obj, postfix);
            outputStr = outputStr + ...
                sprintf('function y = evaluateSingleDataPoint(fis, x, opt)\n\ncoder.internal.prefer_const(fis)\n\n');

            strX = generateInputStringForCodegen(obj);
            outputStr = printEvalfisAndOutputsForCodegen(obj,strX,outputStr);
            outputStr = outputStr + sprintf('end\n');
        end
    end

    %% Private methods
    methods(Access=private)
        function outputStr =  generateEvalfistreeMulitpleData(obj,postfix)
            %% Print a string representing multiple data points evaluation
            outputStr =  sprintf(['function y = evalfistree_%s(file, fis, x, opt)\n' ...
                '%% This utility is used in code generation for FIS tree\n' ...
                '%% This specially handles more than one data points\n\n' ...                
                '%% Copyright %s The MathWorks, Inc.\n\n' ...                
                '%%#codegen\n' ...
                '%%#internal\n\n' ...
                'coder.internal.prefer_const(fis)\n' ...
                'coder.internal.prefer_const(opt)\n\n' ...  
                '[row, ~] = size(x);\n' ...
                'numOutputs = numel(fis.Outputs);\n' ...
                'y = zeros(row, numOutputs);\n' ...
                'for i = 1:row\n' ...
                'y(i,:) = evaluateSingleDataPoint(fis.FIS, x(i,:), opt);\n' ...
                'end\n' ...
            'end\n\n'], postfix, datestr(now,'yyyy'));
        end

        function outputStr = printEvalfisAndOutputsForCodegen(obj,strX,outputStr)
            %% Print flattened tree structure to a string
            numFIS = numel(obj.FTREE.FIS);
            fisOutputs = cell(numFIS,1); % To check whether the output is ready
            fisInputsStr = cell(numFIS,1);
            fisOutputsStr = cell(numFIS,1);

            % Extract input values.
            fisInputsStr = createInputString(obj, fisInputsStr, strX);

            outputStr = createOutputStr(obj, outputStr);

            % Evaluate FISs to generate tree output.
            outputReady = false;
            while ~outputReady
                for n = 1:numFIS
                    if ~isempty(fisOutputs{n})
                        continue
                    end

                    p = predecessors(obj.FTREE.ConnectionGraph,n); % Predecessors means if any inputs are connected to outputs of any FIS
                    if isempty(p)
                        fisOutputs{n} = true;
                        outputStr = printComment(obj, outputStr,n);
                        [outputStr,curFISInput] = printNumberOfInputs(obj, outputStr,n);
                        outputStr = assignEachIndexOfTheInput(obj,fisInputsStr,outputStr,curFISInput,n);
                        [outputStr,fisOutputsStr] = generateNamesForEachOutputOfCurrentFIS(obj,outputStr,fisOutputsStr,curFISInput,n);
                    else
                        preOutputReady = cell2mat(arrayfun(@(index)~isempty(fisOutputs{index}),p,'UniformOutput',false));
                        if all(preOutputReady)
                            inputsStr = constructInputStrForCurrentFIS(obj,fisInputsStr,fisOutputsStr,n,p);

                            % Set current output to true
                            fisOutputs{n} = true;

                            outputStr = printComment(obj, outputStr,n);
                            [outputStr,curFISInput] = printNumberOfInputs(obj, outputStr,n);
                            outputStr = assignEachIndexOfTheInput2(obj,inputsStr,outputStr,curFISInput,n);
                            [outputStr,fisOutputsStr] = generateNamesForEachOutputOfCurrentFIS(obj,outputStr,fisOutputsStr,curFISInput,n);

                        end
                    end
                end
                outputReady = all(cell2mat(cellfun(@(x)~isempty(x),fisOutputs,'UniformOutput',false)));
            end

            outputStr = setOutputValues(obj, outputStr,fisOutputsStr);
        end

        function inputStr = createInputString(obj, inputStr, strX)
            %% Generate string for free and short circuited inputs.
            x = zeros(1,numel(obj.FTREE.Inputs));
            index = 0;
            numFIS = numel(obj.FTREE.FIS);
            for n = 1:numFIS
                id = obj.FTREE.LocalInputs{n};
                inputStr{n} = cell(size(x,1),numel(id));
                for j = 1:numel(id)
                    if id(j) % Assign free and short circuited inputs, skip inputs connected to an output
                        index = index + 1;
                        inputStr{n}{:,j} = strX(:,index);
                    end
                end
            end
        end

        function outputStr = createOutputStr(obj, outputStr)
            %% Generate string to initialize output size for FIS tree
            x = zeros(1,numel(obj.FTREE.Inputs));
            if isempty(obj.FTREE.OutputSequenceID) % Output Sequence ID is free outputs
                outputIDs = obj.FTREE.getFreeOutputs;
            else
                outputIDs = obj.FTREE.OutputSequenceID;
            end
            outputStr = outputStr + sprintf('%% Initialize output size\n') + ...
                sprintf('y = zeros(' + string(size(x,1)) + ',' + ...
                string(size(outputIDs,1)) + ');\n\n');
        end

        function outputStr = assignEachIndexOfTheInput(obj,inStr,outputStr,curFISInput,fisNum)
            %% Generate string to assign inputs (free and short circuited)for FIS denoted by fisNum
            for inputIndex = 1:length(obj.FTREE.FIS(fisNum).Inputs)
                outputStr = outputStr + sprintf(curFISInput + '(' + string(inputIndex) + ')' + ...
                    ' = ' + inStr{fisNum}{inputIndex}{1} + ';\n');
            end
        end

        function outputStr = printComment(obj,outputStr,i)
            %% Print comment: setup and evaluate FIS
            outputStr = outputStr + sprintf('%% Setup and evaluate fis'+string(i)+'\n');
        end


        function [outputStr,curFISInput] = printNumberOfInputs(obj,outputStr,i)
            %% Print number of inputs
            curFISInput = 'x' + string(i);
            numCurFISInput = 'numInputs' + string(i);
            outputStr = outputStr + sprintf(numCurFISInput + ' = length(fis{' + ...
                string(i) + '}.input);\n') + sprintf( 'x' + string(i) + ' = zeros(1,' + ...
                numCurFISInput + ');\n');
        end

        function outputStr = assignEachIndexOfTheInput2(obj,inStr,outputStr,curFISInput,i)
            %% Generate string to assign inputs (connected to outputs) for FIS denoted by fisNum
            for inputIndex = 1:length(obj.FTREE.FIS(i).Inputs)
                outputStr = outputStr + sprintf(curFISInput + '(' + string(inputIndex) + ')' + ...
                    ' = ' + string(inStr{inputIndex}{1}) + ';\n');
            end
        end

        function [outputStr,fisOutputsStr] = generateNamesForEachOutputOfCurrentFIS(obj,outputStr,fisOutputsStr,curFISInput,i);
            %% Generate names for each output of current FIS
            currentFISOutputString =  'y' + string(i);
            curArray = [];
            for numCurFISOutput = 1:numel(obj.FTREE.FIS(i).Outputs)
                curArray = [curArray [currentFISOutputString + '(' ...
                    + string(numCurFISOutput) + ')']];
            end
            fisOutputsStr{i} = curArray;
            outputStr = outputStr + sprintf('y' + string(i) + ' = evalfis(fis{' + ...
                string(i) + '},' + curFISInput + ',opt' + ');\n\n');
        end

        function inputsStr = constructInputStrForCurrentFIS(obj,fisInputsStr,fisOutputsStr,i,pred)
            %% Construct input string for current FIS
            inputsStr = fisInputsStr{i};
            for index = 1:numel(pred)
                j = pred(index);
                con = obj.FTREE.ConnectionTable{j,i};
                for k = 1:size(con,1)
                    outID = con(k,1);
                    inID = con(k,2);
                    inputsStr{:,inID} = fisOutputsStr{j}(:,outID); % Assigning the inputs connected to outputs
                end
            end
        end

        function outputStr = setOutputValues(obj, outputStr,fisOutputsStr)
            %% Generate string to assign final output values
            if isempty(obj.FTREE.OutputSequenceID) % Output Sequence ID is free outputs
                outputIDs = obj.FTREE.getFreeOutputs;
            else
                outputIDs = obj.FTREE.OutputSequenceID;
            end
            outputStr = outputStr + sprintf('%% Output values\n');
            for n = 1:size(outputIDs,1) % outputIDs are free outputs
                id = outputIDs(n,:);
                % Print outputs
                outputStr = outputStr + sprintf('y(' + string(n) + ') = ' + ...
                    string(fisOutputsStr{id(1)}(:,id(2))) + ';\n');
            end
        end

        function strX = generateInputStringForCodegen(obj)
            %% Generate input string used in printEvalfisAndOutputsForCodegen

            if isempty(obj.FTREE.ShortCircuit)
                strX = createInputStringWithoutShortCircuit(obj);
            else
                strX = createInputStringWithShortCircuit(obj);
            end
        end

        function strX = createInputStringWithoutShortCircuit(obj)
            %% Generate input string for no short circuit case

            x = zeros(1,numel(obj.FTREE.Inputs));
            strX = repmat({''}, size(x));
            for ct = 1:numel(x)
                strX{:,ct} = "x(" + string(ct) + ")";
            end
        end

        function strX = createInputStringWithShortCircuit(obj)
            %% Generate input string for short circuit case

            [openInputIndex,openButNotShort] = findOpenInputConnectionTypes(obj);
            strX = createInputStrForOpenInputs(obj,openInputIndex,openButNotShort);
        end

        function [openInputIndex,openButNotShort] = findOpenInputConnectionTypes(obj)
            %% Find open inputs to create input string for

            openInputIndex = [];
            openButNotShort = [];
            numFIS = numel(obj.FTREE.FIS);
            index = 0;
            for i = 1:numFIS
                for j = 1:numel(obj.FTREE.FIS(i).Inputs)
                    index = index + 1;
                    if obj.FTREE.LocalInputs{i}(j)
                        openInputIndex = [openInputIndex index]; %#ok<AGROW>
                        if ~obj.FTREE.ShortCircuit{i}(j)
                            openButNotShort = [openButNotShort index]; %#ok<AGROW>
                        end
                    end
                end
            end
        end

        function strX = createInputStrForOpenInputs(obj,openInputIndex,openButNotShort)
            %% Generate input string for open inputs

            numInputs = numFreeInputs(obj.FTREE);
            strX = cell(1,numInputs);
            n = numel(openButNotShort);
            for i = 1:n
                % Get the inputs that are connected to this open input.
                inputID = successors(obj.FTREE.InputConnectionGraph,openButNotShort(i));
                id = find(openInputIndex == openButNotShort(i),1);
                strX{:,id} = "x(" + string(i) + ")";

                % Copy the same value to the connected inputs.
                for j = 1:numel(inputID)
                    id = find(openInputIndex == inputID(j),1);
                    strX{:,id} = "x(" + string(i) + ")";
                end
            end
        end
    end
end