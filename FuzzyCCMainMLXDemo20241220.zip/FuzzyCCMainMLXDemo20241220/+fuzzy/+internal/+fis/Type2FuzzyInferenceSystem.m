classdef Type2FuzzyInferenceSystem
    %%

    %   Copyright 2019-2022 The MathWorks, Inc.
    
    properties
        %TypeReductionMethod Type reduction method.
        %
        %  TypeReductionMethod specifies a type reduction method used in a
        %  type-2 fuzzy inference system. It is a name or handle for a
        %  function on the MATLAB path. Built-in options for
        %  TypeReductionMethod are "karnikmendel", "ekm", "iasc", and
        %  "eiasc". Default value is "karnikmendel".
        %
        %  A custom type reduction function must be specified on MATLAB
        %  path as a function having at least three input arguments and
        %  one output argument as follows:
        %
        %    function c = customTR(x,umf,lmf)
        %      c = zeros(1,2);
        %      ...
        %    end
        %
        %  where 
        %    - x is a set of sampled universe of discourse, 
        %    - umf is a set of upper membership function values,
        %    - lmf is a set of lower membership function values, and
        %    - c is an approximated centroid range [c_left c_right]
        %      obtained from x, umf, and lmf using TypeReductionMethod.
        %
        %  Example
        %
        %    fis = mamfistype2('TypeReductionMethod',@customTR);
        
        TypeReductionMethod = "karnikmendel";
    end
    
    %% Set/Get
    methods
        function fis = set.TypeReductionMethod(fis,value)
            try
                fuzzy.internal.utility.validateMethod('type reduction method',value)
                if isa(value,'function_handle')
                    fcnHandleInfo = functions(value);
                    if fcnHandleInfo.type == "anonymous"
                        error(message("fuzzy:general:errFIS_AnonymousFcnHandle", ...
                            "type reduction method"))
                    end
                    value = func2str(value);
                    value = string(value);
                    if ~any(value==["karnikmendel" "ekm" "iasc" "eiasc"])
                        fuzzy.internal.utility.validateExistence(value, ...
                            "fuzzy:general:errFIS_NonexistentTRMethodHandle")
                        fuzzy.internal.utility.validateFcnSignature(value,3,"Type reduction",true)
                    end
                else
                    fuzzy.internal.utility.validCharOrString('Type reduction method',value);
                    fuzzy.internal.utility.validatePathAndExtension(value,"type reduction")
                    if ischar(value)
                        value = string(value);
                    end
                    if ~any(value==["karnikmendel" "ekm" "iasc" "eiasc"])
                        fuzzy.internal.utility.validateExistence(value, ...
                            "fuzzy:general:errFIS_NonexistentTRMethodName")
                        fuzzy.internal.utility.validateFcnSignature(value,3,"Type reduction",false)
                    end
                end
                fis.TypeReductionMethod = value;
                evalfisData = getEvalfisData(fis);
                evalfisData.typeReductionMethod = char(fis.TypeReductionMethod);
                fis = setEvalfisData(fis,evalfisData);
            catch me
                throw(me)
            end
            
            
        end
    end
    
    %% Public methods
    methods
        function fisout = convertToType1(fisin)
            %% CONVERTTOTYPE1 Converts a type-2 FIS to a type-1 FIS.
            %
            %   FISOUT = convertToType1(FISIN) converts type-2 FISIN object
            %   to type-1 FISOUT object. Each type-2 membership function
            %   (except Sugeno output membership functions) is converted to
            %   a type-1 membership function using the upper membership
            %   function parameter values.
            %
            %   Examples
            %
            %     fisin = mamfistype2('NumInputs',2,'NumOutputs',1);
            %     fisout = CONVERTTOTYPE1(fisin);
            %
            %   Copyright 2019 The MathWorks, Inc.
            
            fisout = createYourType1(fisin);
            for i = 1:numel(fisin.Inputs)
                fisout = addInput(fisout,fisin.Inputs(i).Range, ...
                    "Name",fisin.Inputs(i).Name);
                for j = 1:numel(fisin.Inputs(i).MembershipFunctions)
                    fisout = addMF(fisout,fisin.Inputs(i).Name, ...
                        fisin.Inputs(i).MembershipFunctions(j).Type, ...
                        fisin.Inputs(i).MembershipFunctions(j).UpperParameters, ...
                        "Name",fisin.Inputs(i).MembershipFunctions(j).Name, ...
                        "VariableType","input" ...
                        );
                end
            end
            output = fisin.EvalfisData.output;
            for i = 1:numel(fisin.Outputs)
                fisout = addOutput(fisout,fisin.Outputs(i).Range, ...
                    "Name",fisin.Outputs(i).Name);
                for j = 1:numel(fisin.Outputs(i).MembershipFunctions)
                    fisout = addMF(fisout,fisin.Outputs(i).Name, ...
                        fisin.Outputs(i).MembershipFunctions(j).Type, ...
                        output(i).mf(j).umfparams, ...
                        "Name",fisin.Outputs(i).MembershipFunctions(j).Name, ...
                        "VariableType","output" ...
                        );
                end
            end
            
            fisout.Rules = fisin.Rules;
        end        
                
    end
    
    %% Protected methods
    methods(Access=protected)
        function validateInputFuzzySetTypeLocal(~,value)
            for i = 1:numel(value)
                if ~any(class(value(i).MembershipFunctions) == "fismftype2")
                    error(message("fuzzy:general:errT2FIS_invalidT2MF"))
                end
            end
        end

        function validateOutputFuzzySetTypeLocal(fis,value)
            validateInputFuzzySetTypeLocal(fis,value)
        end
        
        function var = setDefaultInputFuzzySetTypeLocal(~,var)
            for i = 1:numel(var)
                if isempty(var(i).MembershipFunctions) && ...
                        ~isa(var(i).MembershipFunctions,'fismftype2')
                    var(i).MembershipFunctions = fismftype2.empty;
                end
            end
        end      
        
        function var = setDefaultOutputFuzzySetTypeLocal(fis,var)
            var = setDefaultInputFuzzySetTypeLocal(fis,var);
        end
        
        function [varType,varID,args] = getArgsForMFConstructionLocal(fis,varName,varargin)
            if nargin == 2
                [varType,varID] = findVariableType(fis,varName);
                [mfType,mfParams] = getDefaultMF(fis,varType);
                args = {mfType,mfParams};
            else
                id = [];
                for i = 1:numel(varargin)
                    if (ischar(varargin{i})||isstring(varargin{i})) && ...
                            startsWith("VariableType",varargin{i},"IgnoreCase",true)
                        id = i;
                        break
                    end                    
                end
                if isempty(id)
                    [varType,varID] = findVariableType(fis,varName);
                    args = varargin;
                else
                    if length(varargin)==id
                        error(message("fuzzy:general:errMamfisType2_missingVarTypeValue"))
                    end                    
                    fuzzy.internal.utility.validCharOrString('Variable type',varargin{id+1});
                    [varType,varID] = findVariableType(fis,varName,varargin{id+1});
                    args = {varargin{1:id-1},varargin{id+2:end}};
                end
            end
        end

        function mfSettings = constructMFSettingsLocal(fis,varType,varID,varargin)
            var = getVariable(fis,varType,varID);
            numMFs = numel(var.MembershipFunctions);
            mfSettings = repmat(fuzzy.tuning.MembershipFunctionSettingsType2,[1 numMFs]);
            useAsymmetricLag = varargin{1};
            for i = 1:numMFs
                mf = var.MembershipFunctions(i);
                n = length(mf.UpperParameters);
                mfSettings(i).UpperParameters = fuzzy.tuning.NumericParameters(n);
                mfSettings(i).Name = var.MembershipFunctions(i).Name;
                mfSettings(i).Type = var.MembershipFunctions(i).Type;
                
                if useAsymmetricLag
                    if any(mf.Type==["gaussmf" "gbellmf" "sigmf" "smf" "zmf" "linsmf" "linzmf"])
                        mfSettings(i).LowerLag = fuzzy.tuning.NumericParameters(1,'Minimum',0,'Maximum',1);
                    else
                        mfSettings(i).LowerLag = fuzzy.tuning.NumericParameters(2,'Minimum',0,'Maximum',1);
                    end
                else
                    mfSettings(i).LowerLag = fuzzy.tuning.NumericParameters(1,'Minimum',0,'Maximum',1);
                end
                
                if ~any(mf.Type==fuzzy.internal.utility.builtinCommonMFs)
                    mfSettings(i).LowerLag.Free = false;
                end                
            end            
        end

        function values = getMFParameterValuesLocal(fis,varType,varID,varargin)
            var = getVariable(fis,varType,varID);
            mfs = var.MembershipFunctions;
            values = [];
            s = varargin{1};
            for i = 1:numel(mfs)
                mf = mfs(i);
                smf = s.MembershipFunction(i);
                lag = mf.LowerLag;
                if numel(smf.LowerLag.Free)==1
                    if ~isscalar(lag)
                        lag = mean(lag);
                    end
                end
                values = [values mf.UpperParameters mf.LowerScale lag]; %#ok<AGROW>
            end
        end

        function fis = setMFTunableValuesLocal(fis,p,varID,mfID,~,value)
            mfSettings = p.MembershipFunctions(mfID);
            
            umfFree = mfSettings.UpperParameters.Free;
            numUpperFreeParams = numel(find(umfFree==true));
            
            lmfScaleFree = mfSettings.LowerScale.Free;
            numLowerScaleFreeParams = numel(find(lmfScaleFree==true));

            lmfLagFree = mfSettings.LowerLag.Free;
            numLowerLagFreeParams = numel(find(lmfLagFree==true));
            
            var = getVariable(fis,p.Type,varID);
            mf = var.MembershipFunctions(mfID); 
            
            if numUpperFreeParams>0
                mf.UpperParameters(umfFree) = value(1:numUpperFreeParams);
            end
            
            if numLowerScaleFreeParams>0
                mf.LowerScale(lmfScaleFree) = value(...
                    numUpperFreeParams+1: ...
                    numUpperFreeParams+numLowerScaleFreeParams);
            end

            if numLowerLagFreeParams>0
                lag = value(numUpperFreeParams+numLowerScaleFreeParams+1: ...
                    numUpperFreeParams+numLowerScaleFreeParams+numLowerLagFreeParams);
                if numel(mfSettings.LowerLag.Free)==1
                    mf.LowerLag = lag;
                else
                    mf.LowerLag(lmfLagFree) = lag;
                end
            end
            
            var.MembershipFunctions(mfID) = mf;
            fis = setVariable(fis,var,p.Type,varID);
        end
        
        function paramValue = parseSettingsParamValuesLocal(fis,mixedType,varargin) %#ok<INUSL>
            p = inputParser;
            p.addParameter('AsymmetricLag',false)
            parse(p,varargin{:})
            
            validateAsymmetricLag(p.Results.AsymmetricLag)
            paramValue = p.Results.AsymmetricLag;
        end
        
        
    end
    
    %% Abstract protecteted methods.
    methods(Abstract,Access=protected)
        fisout = createYourType1(fisin)
        var = getVariable(fis,varType,varID)
        fis = setVariable(fis,value,varType,varID)
        [varType,varID] = findVariableType(fis,varName)
        [mfType,mfParams] = getDefaultMF(fis,varType)        
        evalfisData = getEvalfisData(fis)
        fis = setEvalfisData(fis,evalfisData)
    end
end
%% Helper functions -------------------------------------------------------
function validateAsymmetricLag(value)

if fuzzy.internal.utility.isNonemptyScalarLogical(value)
    return
end

error(message("fuzzy:general:errT2FIS_invalidUseAsymmetricLag"))
end