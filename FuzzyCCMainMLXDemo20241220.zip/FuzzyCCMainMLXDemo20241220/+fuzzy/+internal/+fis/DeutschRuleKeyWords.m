classdef (Sealed) DeutschRuleKeyWords < fuzzy.internal.fis.RuleKeyWords
%% DeutschRuleKeyWords - Deutsch keywords used in a fuzzy rule
%
%  DeutschRuleKeyWords defines Deutsch keywords used in a text fuzzy
%  rule. It implemented the interface defined by RuleKeyWords.
% 
%  The following default property values are used for Deutsch keywords:
%
%    Property    Value 
%    --------    -----
%    If          'Wenn '
%    And         ' und '
%    Or          ' oder '
%    Then        ' dann '
%    Equal       ' ist '
%    Is          ' ist '
%    Not         ' nicht '
%    IsNot       ' ist nicht '

%  Copyright 2017-2018 The MathWorks, Inc.
 
    properties(SetAccess=protected)
        %% If - Deutsch expression for 'if'
        %   Its default value is specified as 'Wenn '.
        If = 'Wenn ';
        
        %% And - Deutsch expression for 'and'
        %   Its default value is specified as ' und '.
        And = ' und ';
        
        %% Or - Deutsch expression for 'or'
        %   Its default value is specified as ' oder '.
        Or = ' oder ';
        
        %% Then - Deutsch expression for 'then'
        %   Its default value is specified as ' dann '.
        Then = ' dann ';
        
        %% Equal - Deutsch expression for 'equal'
        %   Its default value is specified as ' ist '.
        Equal = ' ist ';
        
        %% Is - Deutsch expression for 'is'
        %   Its default value is specified as ' ist '.
        Is = ' ist ';
        
        %% Not - Deutsch expression for 'not'
        %   Its default value is specified as ' nicht '.
        Not = ' nicht ';
        
        %% IsNot- Deutsch expression for 'is not'
        %   Its default value is specified as ' ist nicht '.
        IsNot = ' ist nicht ';
    end

    methods
        function obj = DeutschRuleKeyWords(varargin)            
            %% DeutschRuleKeyWords - Constructor
            %
            %   OBJ = DeutschRuleKeyWords(NAME,VALUE) constructs an
            %   DeutschRuleKeyWords object.
            %
            %   You can specify the following parameter name/value pair:
            %
            %     WithSpace - A logical flag that specifies if the keywords
            %     are expressed with leading and trailing spaces. Its
            %     default value is 'false'.            
            
            obj = obj@fuzzy.internal.fis.RuleKeyWords(varargin{:});
        end
    end
    
end