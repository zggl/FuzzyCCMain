function varargout = fcm(data, varargin)
%FCM Data set clustering using fuzzy c-means clustering.
%
%   [CENTER, FUZZYPARTMAT, OBJFCN, INFO] = FCM(DATA) finds clusters in the
%   data set DATA using a default FCMOPTIONS set. DATA size is M-by-N, 
%   where M is the number of data points and N is the number of
%   coordinates/features for each data point. A default options set results
%   in FCM clustering with multiple cluster numbers. Hence, outputs CENTER,
%   FUZZYPARTMAT, and OBJFCN represent the results for an optimal number
%   of clusters.
%
%   CENTER is a K-by-N matrix where K is the optimal cluster number in the
%   auto-generated cluster numbers. The coordinates for each cluster center
%   are returned in the rows of the matrix CENTER.
% 
%   The membership function matrix FUZZYPARTMAT contains the grade of
%   membership of each DATA point in each cluster. The values 0 and 1
%   indicate no membership and full membership respectively. Grades between
%   0 and 1 indicate that the data point has partial membership in a
%   cluster. 
% 
%   At each iteration, an objective function is minimized to find
%   the best location for the clusters and its values are returned in
%   OBJFCN.
%
%   Output INFO includes results for each cluster number. INFO is a
%   structure having the following fields:
%       NumClusters         : Auto-generated or user specified cluster
%                             numbers
%       ClusterCenters      : Cluster centers generated in each FCM
%                             clustering with a different cluster number
%       FuzzyPartitionMatrix: Fuzzy partition matrix generated in each FCM
%                             clustering with a different cluster number
%       ObjectiveFcnValue   : Objective function values generated in each
%                             FCM clustering with a different cluster
%                             number
%       ValidityIndex       : Cluster validity measure/index values
%                             generated in each FCM clustering with a
%                             different cluster number
%       OptimalNumClusters  : Optimal number of clusters K corresponding to
%                             the minimum validity index value
%   For 'mahalanobis'and 'fmle' distance metric (specified in FCMOPTIONS),
%   INFO also includes CovarianceMatrix field that includes covariance
%   matrices of each cluster generated for a specific cluster number.
%
%   [CENTER, FUZZYPARTMAT, OBJFCN, INFO] = FCM(DATA, OPTIONS) finds
%   clusters in the data set DATA using options set OPTIONS. If the number
%   of clusters in OPTIONS is set to 'auto', or it is specified as a vector
%   of multiple cluster numbers, the outputs CENTER, FUZZYPARTMAT, and
%   OBJFCN represent the results for the optimal number of clusters.
% 
%   Examples
%      %% FCM clustering with default options
%      data = [5+3*rand(20,1) 5+3*rand(20,1); ...
%          5+3*rand(20,1) 10 + 3*rand(20,1)];
%      centers = fcm(data)
%
%      %% FCM clustering with a custom options set
%      options = fcmOptions(NumClusters=[2 3 4],MaxNumIteration=25, ...
%          DistanceMetric='mahalanobis');
%      centers = fcm(data,options)
%      
%   See also FCMOPTIONS

%   Copyright 1994-2023 The MathWorks, Inc.

narginchk(1,3)
nargoutchk(0,4)

if isempty(data) || ~isnumeric(data) || ~ismatrix(data) || ...
        ~isreal(data) || ~all(isfinite(data), 'all') || ...
        any(isnan(data), 'all')
    error(message('fuzzy:general:errFcm_invalidClusteringData'))
end

if isinteger(data)
    data = double(data);
end

if fuzzy.clustering.FCMOptions.useDefaultRNG
    preRNGState = rng('default');
    restoreRNGState = onCleanup(@()rng(preRNGState));
end

options = fuzzy.clustering.createFCMOptions(varargin{:});

if ~isempty(options.ClusterCenters) && size(data,2)~=size(options.ClusterCenters,2)
    error(message('fuzzy:general:errFCM_inconsistentNumFeatures'))
end

if isnumeric(options.NumClusters) && any(options.NumClusters>size(data,1))
    error(message('fuzzy:general:errFCM_numClusterGtDataSize'))
end

if ~isempty(options.ClusterCenters)&&size(options.ClusterCenters,1)>size(data,1)
    error(message('fuzzy:general:errFCM_numClusterGtDataSize'))
end

[varargout{1:nargout}] = fuzzy.clustering.fcm(data, options);
end