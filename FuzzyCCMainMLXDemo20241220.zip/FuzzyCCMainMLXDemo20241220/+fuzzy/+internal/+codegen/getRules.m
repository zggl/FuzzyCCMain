function rules = getRules(fid,maxLineLength,newLine,numInputs,numOutputs)
%

%

%  Copyright 2019 The MathWorks, Inc.

%#codegen

% [Rules]
% 1 1, 1 (1) : 2
% 2 0, 2 (1) : 1
% 3 2, 3 (1) : 2

rule = struct(...
    'antecedent',zeros(1,numInputs),...
    'consequent',zeros(1,numOutputs),...
    'weight',zeros(1,1),...
    'connection',zeros(1,1)...
    );

topic = '[Rules]';
numRules = getNumRules(fid,maxLineLength,topic,newLine);
rules = repmat(rule,1,numRules);
if numRules == 0
    return
end
frewind(fid);
topicFound = false;
while ~topicFound
    nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
    if feof(fid)
        break
    end
    
    if ~strcmp(deblank(char(nextLineVar)),topic)
        continue;
    else
        topicFound = true;
    end
    
    for i=1:numRules
        nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine); %1 1, 1 (1) : 2
        if feof(fid)
            break;
        end
        
        id = find(nextLineVar==uint8(','),1);
        ant = zeros(1,id(1)-1,'uint8');
        ant(1:end) = nextLineVar(1:id(1)-1);
        
        nextLineVar(1:id(1)+1) = 0;
        id2 = find(nextLineVar==uint8('('),1);
        con = zeros(1,(id2(1)-1)-(id(1)+2));
        con(1:end) = nextLineVar(id(1)+2:id2(1)-2);
        nextLineVar(id(1)+2:id2(1)) = 0;
        
        id3 = find(nextLineVar==uint8(')'),1);
        wt = zeros(1,id3(1)-id2(1)-1);
        wt(1:end) = nextLineVar(id2(1)+1:id3(1)-1);
        rules(i).weight(1) = real(str2double(char(wt)));
        
        rules(i).connection(1) = real(str2double((char(nextLineVar(id3(1)+4)))));
        
        ids = find(ant==32);
        if isempty(ids)
            validateAntecedentLength(fid,numInputs,1)
            rules(i).antecedent(1) = real(str2double(char(ant)));
        else
            for k=1:length(ids)
                if k == length(ids)
                    if k == 1
                        startIndex = 1;
                    else
                        startIndex = ids(k-1) + 1;
                    end
                    val = real(str2double(char(ant(startIndex:ids(k)-1))));
                    validateAntecedentLength(fid,numInputs,k+1)
                    rules(i).antecedent(k) = val;
                    startIndex = ids(k) + 1;
                    val = real(str2double(deblank(char(ant(startIndex:end)))));
                    rules(i).antecedent(k+1) = val;
                else
                    if k == 1
                        startIndex = 1;
                    else
                        startIndex = ids(k-1) + 1;
                    end
                    val = real(str2double(char(ant(startIndex:ids(k)-1))));
                    validateAntecedentLength(fid,numInputs,k)
                    rules(i).antecedent(k) = val;
                end
            end
        end
        
        idCon = find(con==32);
        if isempty(idCon)
            validateConsequentLength(fid,numOutputs,1)
            rules(i).consequent(1) = real(str2double(char(con)));
        else
            for k=1:length(idCon)
                if k == length(idCon)
                    if k == 1
                        startIndex = 1;
                    else
                        startIndex = idCon(k-1) + 1;
                    end
                    val = real(str2double(char(con(startIndex:idCon(k)-1))));
                    validateConsequentLength(fid,numOutputs,k+1)
                    rules(i).consequent(k) = val;
                    startIndex = idCon(k) + 1;
                    val = real(str2double(deblank(char(con(startIndex:end)))));
                    rules(i).consequent(k+1) = val;
                else
                    if k == 1
                        startIndex = 1;
                    else
                        startIndex = idCon(k-1) + 1;
                    end
                    val = real(str2double(char(con(startIndex:idCon(k)-1))));
                    validateConsequentLength(fid,numOutputs,k)
                    rules(i).consequent(k) = val;
                end
            end
        end
        
    end
    
end
end

function numRules = getNumRules(fid,maxLineLength,topic,newLine)
numRules = 0;

topicFound = false;
while ~topicFound
    nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
    if feof(fid)
        break
    end
    
    if ~strcmp(deblank(char(nextLineVar)),topic)
        continue
    else
        topicFound = true;
    end
    
    ruleFound = false;
    while ~ruleFound
        nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
        if feof(fid)
            break
        end
        
        if any(nextLineVar) && nextLineVar(1)~=newLine
            numRules = numRules + 1;
        end
    end
end

end

function validateAntecedentLength(fid,numInputs,n)

coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if n > numInputs
    fclose(fid);
    if fuzzy.internal.codegen.isTargetMATLABOrMEX
        coder.internal.error(...
            'fuzzy:general:errCodegen_Readfis_NumInputsDoesNotMatch')
    else
        if fuzzy.internal.codegen.isRuntimeCheckOn
            format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                'fuzzy:general:errCodegen_Readfis_NumInputsDoesNotMatch_Format'));
            fprintf(format);
        end
        fuzzy.internal.codegen.runtimeExit
    end
end
end

function validateConsequentLength(fid,numOutputs,n)

coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if n > numOutputs
    fclose(fid);
    if fuzzy.internal.codegen.isTargetMATLABOrMEX
        coder.internal.error(...
            'fuzzy:general:errCodegen_Readfis_NumOutputsDoesNotMatch')
    else
        if fuzzy.internal.codegen.isRuntimeCheckOn
            format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                'fuzzy:general:errCodegen_Readfis_NumOutputsDoesNotMatch_Format'));
            fprintf(format);
        end
        fuzzy.internal.codegen.runtimeExit
    end
end
end