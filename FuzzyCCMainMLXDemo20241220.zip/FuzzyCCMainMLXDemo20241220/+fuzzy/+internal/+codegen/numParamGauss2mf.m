function n = numParamGauss2mf
%% numParamGauss2mf Returns number of parameter of gauss2mf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 4;
end