function result = isTargetMATLABOrMEX
%ISTARGETMATLABORMEX Returns true if coder target is MATLAB or MEX.

%  Copyright 2018, The MathWorks, Inc.

%#codegen

result = coder.target('MATLAB') || coder.target('MEX');
end