function [y,irr,orr,arr,rfs] = evaluateNonhomogenousFISType2(...
    inputs,fis,diagnostics,numSamples) %#codegen
%

% evaluateNonhomogenousFISType2 - Codegen version of EVALFIS for
% nonhomogenous type-2 FIS.
%
%     FIS is a nonhomogenous type-2 structure.
%
%     DIAGNOSTICS provides user specified levels for showing diagnostics.
%     See fuzzy.internal.utility.createDiagnosticLevels for further detail.
%
%     The outputs are similar to EVALFIS outputs.
%
% See also EVALFIS, EVALFISOPTIONS.

%  Copyright 2019-2023 The MathWorks, Inc.

%% Evaluate FIS
% To avoid method selection in each loop at run-time, we need 1152 number
% of switch statements (see below).
%
%     N = NumAndMethod(3) x 
%         NumOrMethod(4) x 
%         NumImpMethod(3) x 
%         NumAggMethod(4) x 
%         NumTypeReductionMethod(4)
%       = 576
%
% (Excluded number of defuzzification methods since we currently only use
% centroid/weighted-average based type reductions in Mamdani and Sugeno
% FIS.)
%
% The implementation will be error prone and difficult to maintain. The
% generated code will also include N number copies of runFIS function.
% Hence, using only type reduction method selection here since it has the
% highest number of options as compared to other methods.

% NOTE: 
%   - Removing output 'unImpSugRuleOut' since output orr in a type-2 Sugeno
%     FIS provides unscaled rule outputs.
%   - Output arr is also unscaled, however, it is sorted in ascending order

if strcmp(fis.typeReductionMethod,'karnikmendel')
    [y,irr,orr,arr,rfs] = ...
        runFISNH(inputs,fis,diagnostics,true,@karnikmendel,numSamples);
elseif strcmp(fis.typeReductionMethod,'ekm')
    [y,irr,orr,arr,rfs] = ...
        runFISNH(inputs,fis,diagnostics,true,@ekm,numSamples);
elseif strcmp(fis.typeReductionMethod,'iasc')
    [y,irr,orr,arr,rfs] = ...
        runFISNH(inputs,fis,diagnostics,true,@iasc,numSamples);
elseif strcmp(fis.typeReductionMethod,'eiasc')
    [y,irr,orr,arr,rfs] = ...
        runFISNH(inputs,fis,diagnostics,true,@eiasc,numSamples);
else
    [y,irr,orr,arr,rfs] = ...
        runFISNH(inputs,fis,diagnostics,false,@feval,numSamples);
end


end
%% Helper functions -------------------------------------------------------
function [y,irr,orr,arr,w] = ...
    runFISNH(inputs,fis,diagnostics,trmIsBuiltin,trm,numSamples)

%% Output data declaration
numInputs = length(fis.input);
numOutputs = length(fis.output);
numRules = length(fis.rule);
numOutputMFs = zeros(1,numOutputs);
totalNumOutputMFs = 0;
for i = 1:numOutputs
    n = length(fis.output(i).mf);
    numOutputMFs(i) = n;
    totalNumOutputMFs = totalNumOutputMFs + n;
end
numCumOutputMFs =  cumsum(numOutputMFs) - numOutputMFs;
[y,irr,orr,arr,w,outputMFCache,numInputDataSets,outputSamplePoints] = ...
    initVariablesNH(fis,inputs,numInputs,numOutputs,numRules,numSamples,totalNumOutputMFs);
%% Pre-computed/allocated variables to speed-up MEX execution.
%inVarMF = extractVarMF(fis.inputMF);
numInputMFs = zeros(1,numInputs);
totalNumInputMFs = 0;
for i = 1:numInputs
    n = length(fis.input(i).mf);
    numInputMFs(i) = n;
    totalNumInputMFs = totalNumInputMFs + n;
end
numCumInputMFs =  cumsum(numInputMFs) - numInputMFs;
inputMFCache = zeros(2,totalNumInputMFs,'like',inputs);
irrOfOneRule = zeros(numInputs,2,'like',inputs);
%% Output data calculation
for i = 1:numInputDataSets
    
    x = inputs(i,:);
    [irr(:),inputMFCache(:)] = fuzzifyInputsNH(...
        x,fis,diagnostics,numInputs,numRules,numCumInputMFs,irr,inputMFCache);    
    [w(:),sw,irrOfOneRule(:)] = applyOperatorsNH(...
        irr,fis,numInputs,numRules,w,irrOfOneRule);
    if strcmp(char(fis.type),'mamdani')
        orr(:) = applyMamdaniImplicationMethodNH(...
            w,fis,outputMFCache,numCumOutputMFs,numOutputs,numRules,numSamples,orr);        
        arr(:) = applyMamdaniAggregationMethodNH(orr,fis,numOutputs, ...
            numRules,numSamples,arr);
        y(i,:) = applyMamdaniDefuzzificationMethodNH(...
            outputSamplePoints,sw,arr,fis,diagnostics,trmIsBuiltin,trm,...
            numOutputs,y(i,:))';
    else
        orr(:) = applySugenoImplicationMethodNH(x,w,fis,numRules,numOutputs, ...
            numOutputMFs,numCumOutputMFs,outputMFCache,orr);        
        arr(:) = applySugenoAggregationMethodNH(orr,numOutputs,numRules,arr);
        y(i,:) = applySugenoDefuzzificationMethodNH(sw,arr,fis,diagnostics, ...
            trmIsBuiltin,trm,numOutputs,y(i,:))';
    end
    
end
end

function [y,irr,orr,arr,rfs,outputMFCache,numInputDataSets,...
    outputSamplePoints] = initVariablesNH(fis,inputs,numInputs,numOutputs, ...
    numRules,numSamples,totalNumOutputMFs)

numInputDataSets = size(inputs,1);
y = zeros(numInputDataSets,numOutputs,'like',inputs);
irr = zeros(numRules,2*numInputs,'like',inputs);

if strcmp(fis.type,'mamdani')
    orrSize = [numSamples 2*numRules*numOutputs];
    orr = zeros(orrSize,'like',inputs);
    arrSize = [numSamples 2*numOutputs];
    arr = zeros(arrSize,'like',inputs);
    [outputMFCache,outputSamplePoints] = createMamdaniOutputMFCacheNH(fis, ...
        inputs,numSamples,numOutputs,totalNumOutputMFs);
else
    orrSize = [numRules,3*numOutputs];
    orr = zeros(orrSize,'like',inputs);
    arrSize = [numRules,3*numOutputs];
    arr = zeros(arrSize,'like',inputs);
    outputMFCache = zeros(totalNumOutputMFs,1,'like',inputs);
    outputSamplePoints = zeros('like',inputs);
end

rfs = zeros(numRules,2,'like',inputs);
end

function [outputMFCache,outputSamplePoints] = createMamdaniOutputMFCacheNH(...
    fis,inputs,numSamplePoints,numOutputs,totalNumOutputMFs)

outputSamplePoints = zeros(numOutputs,numSamplePoints,'like',inputs);
outputMFCache = zeros(totalNumOutputMFs,2*numSamplePoints,...
    'like',inputs);

index = 0;
for outputID = 1:numOutputs
    range = fis.output(outputID).range;
    numSamplesMinus1 = numSamplePoints-1;
    outputSamplePoints(outputID,:) = range(1) + ...
        (0:numSamplesMinus1).*(range(2)-range(1))./numSamplesMinus1;
    numMFs = length(fis.output(outputID).mf);
    for mfID = 1:numMFs
        index = index + 1;
        outputMFCache(index,1:numSamplePoints) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            fis.output(outputID).mf(mfID).umftype,...
            outputSamplePoints(outputID,:),...
            fis.output(outputID).mf(mfID).umfparams);
        outputMFCache(index,numSamplePoints+1:end) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            fis.output(outputID).mf(mfID).lmftype,...
            outputSamplePoints(outputID,:),...
            fis.output(outputID).mf(mfID).lmfparams)*fis.output(outputID).mf(mfID).lmfscale;
    end
end

end

function [fuzzifiedInputs,inputMFCache] = fuzzifyInputsNH(...
    inputs,fis,diagnostic,numInputs,numRules, ...
    numCumInputMFs,fuzzifiedInputs,inputMFCache)

mfIndex = zeros('like',numCumInputMFs);
inputMFCache(:) = createInputMFCacheNH(fis,inputs,diagnostic, ...
    inputMFCache,numInputs);

for ruleID = 1:numRules
    for inputID = 1:numInputs
        mfIndex(1) = abs(fis.rule(ruleID).antecedent(inputID));

        % The jth input has no effect in the ith rule if the MF index value
        % is set to 0.
        if mfIndex == 0
            defaultValue = (fis.rule(ruleID).connection == 1);
            fuzzifiedInputs(ruleID,inputID) = defaultValue;
            fuzzifiedInputs(ruleID,numInputs+inputID) = defaultValue;
            continue;
        end

        % Determine the degree of membership according to the specified
        % membership function.
        if fis.rule(ruleID).antecedent(inputID)>=0
            % For positive index value, use the cache value as it's.
            fuzzifiedInputs(ruleID,inputID) = inputMFCache(1,abs(...
                numCumInputMFs(inputID))+mfIndex);
            fuzzifiedInputs(ruleID,numInputs+inputID) = inputMFCache(2,abs(...
                numCumInputMFs(inputID))+mfIndex);
        else
            % If the membership function index is negative (NOT logic),
            % take the complement of the cache value. Also the complement
            % operation switches the upper and lower bound values. 
            fuzzifiedInputs(ruleID,inputID) = ...
                ones('like',inputs) - inputMFCache(2,abs(...
                numCumInputMFs(inputID))+mfIndex);
            fuzzifiedInputs(ruleID,numInputs+inputID) = ...
                ones('like',inputs) - inputMFCache(1,abs(...
                numCumInputMFs(inputID))+mfIndex);
        end
    end
end    

end

function inputMFCache = createInputMFCacheNH(fis,inputs,diagnostic, ...
    inputMFCache, numInputs)

index = 0;
for inputID =1:numInputs
    throwOutOfRangeDiagnostic(inputID,inputs(inputID), ...
        fis.input(inputID).range,diagnostic);
    numMFs = length(fis.input(inputID).mf);
    for mfID = 1:numMFs
        index = index + 1;
        inputMFCache(1,index) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            fis.input(inputID).mf(mfID).umftype,...
            inputs(inputID),...
            fis.input(inputID).mf(mfID).umfparams);
        inputMFCache(2,index) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            fis.input(inputID).mf(mfID).lmftype,...
            inputs(inputID),...
            fis.input(inputID).mf(mfID).lmfparams)*fis.input(inputID).mf(mfID).lmfscale;
    end
end

end

function [antecedentOutputs,sumAntecedentOutputs,irrOfOneRule] = ...
    applyOperatorsNH(fuzzifiedInputs,fis, ...
    numInputs,numRules,antecedentOutputs,irrOfOneRule)

sumAntecedentOutputs = zeros(1,2,'like',fuzzifiedInputs);

for ruleID = 1:numRules
    for inputID = 1:numInputs
        irrOfOneRule(inputID,1) = fuzzifiedInputs(ruleID,inputID);
        irrOfOneRule(inputID,2) = fuzzifiedInputs(ruleID,numInputs+inputID);
    end
    
    if fis.rule(ruleID).connection == 1        
        antecedentOutputs(ruleID,1) = fuzzy.internal.codegen.evaluateAndMethod(...
            fis.andMethod,irrOfOneRule(:,1));
        antecedentOutputs(ruleID,2) = fuzzy.internal.codegen.evaluateAndMethod(...
            fis.andMethod,irrOfOneRule(:,2));
    else
        antecedentOutputs(ruleID,1) = fuzzy.internal.codegen.evaluateOrMethod(...
            fis.orMethod,irrOfOneRule(:,1));
        antecedentOutputs(ruleID,2) = fuzzy.internal.codegen.evaluateOrMethod(...
            fis.orMethod,irrOfOneRule(:,2));
    end
    
    antecedentOutputs(ruleID,:) = antecedentOutputs(ruleID,:)*fis.rule(ruleID).weight;
    sumAntecedentOutputs(1) = sumAntecedentOutputs(1) + antecedentOutputs(ruleID,1);
    sumAntecedentOutputs(2) = sumAntecedentOutputs(2) + antecedentOutputs(ruleID,2);
end

end

function consequentOutputs = applyMamdaniImplicationMethodNH(...
    antecedentOutputs,fis,outputMFCache,...
    numCumOutputMFs,numOutputs,numRules,numSamples,consequentOutputs)

if strcmp(fis.impMethod,'min')
    consequentOutputs(:) = applyImplication(true,@min,antecedentOutputs, ...
        fis,outputMFCache,consequentOutputs,...
        numCumOutputMFs,numOutputs,numRules,numSamples);
elseif strcmp(fis.impMethod,'prod')
    consequentOutputs(:) = applyImplication(true,@prod,antecedentOutputs, ...
        fis,outputMFCache,consequentOutputs,...
        numCumOutputMFs,numOutputs,numRules,numSamples);
else
    consequentOutputs(:) = applyImplication(false,@feval,antecedentOutputs, ...
        fis,outputMFCache,consequentOutputs,...
        numCumOutputMFs,numOutputs,numRules,numSamples);
end

end

function consequentOutputs = applyImplication(isConstOrBuiltin,fh, ...
    antecedentOutputs,fis,outputMFCache,consequentOutputs,...
    numCumOutputMFs,numOutputs,numRules,numSamples)

mfIndex = zeros('like',numCumOutputMFs);

for outputID = 1:numOutputs
    indexOffset1 = (outputID-1)*numRules;
    indexOffset2 = numRules*numOutputs+(outputID-1)*numRules;
    for ruleID = 1:numRules
        mfIndex(1) = abs(fis.rule(ruleID).consequent(outputID));
        ruleOutputIndex1 = indexOffset1+ruleID;
        ruleOutputIndex2 = indexOffset2+ruleID;
        
        % The jth rule has no effect in ith output calculation if MF index
        % is zero.
        if mfIndex == 0
            consequentOutputs(:,ruleOutputIndex1) = 0;
            consequentOutputs(:,ruleOutputIndex2) = 0;
            continue;
        end
        
        for sampleID=1:numSamples
            % Determine output membership values at the sample point.
            if fis.rule(ruleID).consequent(outputID)>=0
                % Use cache value as it's for positive index.
                consequentOutputs(sampleID,ruleOutputIndex1) = ...
                    outputMFCache(abs(numCumOutputMFs(outputID))+...
                    mfIndex,sampleID);
                consequentOutputs(sampleID,ruleOutputIndex2) = ...
                    outputMFCache(abs(numCumOutputMFs(outputID))+...
                    mfIndex,numSamples+sampleID);
            else
                % If the membership function index is negative (NOT logic),
                % switch the cache value and take its complement.
                consequentOutputs(sampleID,ruleOutputIndex1) = max([0;...
                    (ones('like',antecedentOutputs) - ...
                    outputMFCache(abs(numCumOutputMFs(outputID))+...
                    mfIndex,numSamples+sampleID))]);
                consequentOutputs(sampleID,ruleOutputIndex2) = max([0;...
                    (ones('like',antecedentOutputs) - ...
                    outputMFCache(abs(numCumOutputMFs(outputID))+...
                    mfIndex,sampleID))]);            
            end
            
            if isConstOrBuiltin
                consequentOutputs(sampleID,ruleOutputIndex1) = fh(...
                    [consequentOutputs(sampleID,ruleOutputIndex1);...
                    antecedentOutputs(ruleID,1)]);
                consequentOutputs(sampleID,ruleOutputIndex2) = fh(...
                    [consequentOutputs(sampleID,ruleOutputIndex2);...
                    antecedentOutputs(ruleID,2)]);
            end
        end
        
        if ~isConstOrBuiltin
            consequentOutputs(:,ruleOutputIndex1) = fh(...
                char(fis.impMethod), ...
                consequentOutputs(:,ruleOutputIndex1), ...
                repmat(antecedentOutputs(ruleID,1),numSamples,1) ...
                );
            consequentOutputs(:,ruleOutputIndex2) = fh(...
                char(fis.impMethod), ...
                consequentOutputs(:,ruleOutputIndex2), ...
                repmat(antecedentOutputs(ruleID,2),numSamples,1) ...
                );
        end
    end
end
end

function aggregatedOutputs = applyMamdaniAggregationMethodNH(...
    consequentOutputs,fis,numOutputs,numRules,numSamples,aggregatedOutputs)

if strcmp(fis.aggMethod,'max')
    aggregatedOutputs(:) = applyAggregation(true,@max,consequentOutputs,fis,...
        aggregatedOutputs,numOutputs,numRules,numSamples);
elseif strcmp(fis.aggMethod,'probor')
    aggregatedOutputs(:) = applyAggregation(true,@probor,consequentOutputs,fis,...
        aggregatedOutputs,numOutputs,numRules,numSamples);
elseif strcmp(fis.aggMethod,'sum')
    aggregatedOutputs(:) = applyAggregation(true,@sum,consequentOutputs,fis,...
        aggregatedOutputs,numOutputs,numRules,numSamples);
else
    aggregatedOutputs(:) = applyAggregation(false,@feval,consequentOutputs,fis,...
        aggregatedOutputs,numOutputs,numRules,numSamples);
end

end

function aggregatedOutputs = applyAggregation(isConstOrBuiltin,fh, ...
    consequentOutputs,fis,aggregatedOutputs,numOutputs,numRules,numSamples)

aggVal = zeros('like',consequentOutputs);

for outputID = 1:numOutputs
    indexOffset1 = (outputID-1)*numRules;
    startIndex1 = indexOffset1 + 1;
    endIndex1 = indexOffset1 + numRules;

    indexOffset2 = numRules*numOutputs+(outputID-1)*numRules;
    startIndex2 = indexOffset2 + 1;
    endIndex2 = indexOffset2 + numRules;
    
    if isConstOrBuiltin
        for sampleID = 1:numSamples
            aggVal(1) = consequentOutputs(sampleID,startIndex1);
            for id = startIndex1+1:endIndex1
                aggVal(1) = fh([aggVal;consequentOutputs(sampleID,id)]);
            end
            aggregatedOutputs(sampleID,outputID) = aggVal;
            
            aggVal(1) = consequentOutputs(sampleID,startIndex2);
            for id = startIndex2+1:endIndex2
                aggVal(1) = fh([aggVal;consequentOutputs(sampleID,id)]);
            end
            aggregatedOutputs(sampleID,numOutputs+outputID) = aggVal;
            
        end
    else
        aggregatedOutputs(:,outputID) = fh(...
            fis.aggMethod, ...
            consequentOutputs(:,startIndex1:endIndex1)' ...
            )';
        aggregatedOutputs(:,numOutputs+outputID) = fh(...
            fis.aggMethod, ...
            consequentOutputs(:,startIndex2:endIndex2)' ...
            )';
    end
end

end

function defuzzifiedOutputs = applyMamdaniDefuzzificationMethodNH(...
    outputSamplePoints,sumAntecedentOutputs,aggregatedOutputs,fis, ...
    diagnostic,isConstOrBuiltin,fh,numOutputs,defuzzifiedOutputs)

for outputID = 1:numOutputs
    
    if sumAntecedentOutputs(1)==0 && sumAntecedentOutputs(2)==0
        defuzzifiedOutputs(outputID) = mean(fis.output(outputID).range);
        throwNoRuleFiredDiagnostic(outputID,defuzzifiedOutputs(outputID),diagnostic);
        continue
    end

    umf = aggregatedOutputs(:,outputID);
    if sum(umf)==0
        defuzzifiedOutputs(outputID) = mean(fis.output(outputID).range);
        throwEmptyFuzzySetDiagnostic(outputID,umf,fis.defuzzMethod, ...
            defuzzifiedOutputs(outputID),diagnostic);
        continue
    end    
    x = outputSamplePoints(outputID,:)';
    lmf = aggregatedOutputs(:,numOutputs+outputID);
    
    if isConstOrBuiltin
        defuzzifiedOutputs(outputID) = mean(fh(x,umf,lmf));
    else
        % Valid for MATLAB simulation and MEX target.
        defuzzifiedOutputs(outputID) = mean(fh(fis.typeReductionMethod,x,umf,lmf));
    end
    
end


end

function consequentOutputs = applySugenoImplicationMethodNH(inputs,rfs,fis, ...
    numRules,numOutputs,numOutputMFs,numCumOutputMFs,outputMFCache, ...
    consequentOutputs)

mfIndex = zeros('like',numCumOutputMFs);
outputMFCache(:) = createSugenoOutputMFCacheNH(inputs,fis,...
    numOutputs,numOutputMFs,numCumOutputMFs,outputMFCache);

for ruleID = 1:numRules
    for outputID = 1:numOutputs
        mfIndex(1) = fis.rule(ruleID).consequent(outputID);
        
        % The jth rule has no effect in ith output calculation if MF
        % index is zero. mfIndex cannot be negative in a Sugeno FIS.
        if mfIndex ~= 0
            consequentOutputs(ruleID,outputID) = outputMFCache(...
                numCumOutputMFs(outputID)+mfIndex);
        end

        consequentOutputs(ruleID,numOutputs+outputID) = rfs(ruleID,1);
        consequentOutputs(ruleID,2*numOutputs+outputID) = rfs(ruleID,2);
    end
end

end

function aggregatedOutputs = applySugenoAggregationMethodNH(...
    consequentOutputs,numOutputs,numRules,aggregatedOutputs)

aggregatedOutputs(:) = consequentOutputs;
for outputID = 1:numOutputs
    for i = 1:numRules-1
        refVal1 = aggregatedOutputs(i,outputID);
        refVal2 = aggregatedOutputs(i,numOutputs+outputID);
        refVal3 = aggregatedOutputs(i,2*numOutputs+outputID);
        for j = i+1:numRules
            if aggregatedOutputs(j,outputID)<refVal1
                aggregatedOutputs(i,outputID) = aggregatedOutputs(j,outputID);
                aggregatedOutputs(i,numOutputs+outputID) = aggregatedOutputs(j,numOutputs+outputID);
                aggregatedOutputs(i,2*numOutputs+outputID) = aggregatedOutputs(j,2*numOutputs+outputID);
                               
                aggregatedOutputs(j,outputID) = refVal1;
                aggregatedOutputs(j,numOutputs+outputID) = refVal2;
                aggregatedOutputs(j,2*numOutputs+outputID) = refVal3;
                
                refVal1 = aggregatedOutputs(i,outputID);
                refVal2 = aggregatedOutputs(i,numOutputs+outputID);
                refVal3 = aggregatedOutputs(i,2*numOutputs+outputID);
            end
        end
    end    
end

end

function outputMFCache = createSugenoOutputMFCacheNH(inputs,fis,...
    numOutputs,numOutputMFs,numCumOutputMFs,outputMFCache)

for outputID = 1:numOutputs
    numMFs = numOutputMFs(outputID);
    for mfID = 1:numMFs
        outputMFCache(numCumOutputMFs(outputID)+mfID) = ...
            fuzzy.internal.codegen.evaluateSugenoOutputMembershipFcn(...
            fis.output(outputID).mf(mfID).umftype,...
            inputs,fis.output(outputID).mf(mfID).umfparams);
    end
end

end

function defuzzifiedOutputs = applySugenoDefuzzificationMethodNH(...
    sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic, ...
    isConstOrBuiltin,fh,numOutputs,defuzzifiedOutputs)

for outputID = 1:numOutputs
    
    if sumAntecedentOutputs(1)==0 && sumAntecedentOutputs(2)==0
        defuzzifiedOutputs(outputID) = mean(fis.output(outputID).range);
        throwNoRuleFiredDiagnostic(outputID,defuzzifiedOutputs(outputID),diagnostic);
        continue
    end
    
    % NOTE: If we support unnormalized Sugeno output, we need a branch at
    % this point based on the defuzzification method. Currently we only
    % support 'wtaver', which is equivalent to 'centroid' approach.
    x = aggregatedOutputs(:,outputID);
    umf = aggregatedOutputs(:,numOutputs+outputID);
    lmf = aggregatedOutputs(:,2*numOutputs+outputID);
    if isConstOrBuiltin
        defuzzifiedOutputs(outputID) = mean(fh(x,umf,lmf));
    else
        defuzzifiedOutputs(outputID) = mean(fh(fis.typeReductionMethod,x,umf,lmf));
    end
    
    % NOTE: No need to check empty fuzzy output set. Zero check for
    % sumAntecedentOutputs will take care this condition.
end

end