function defuzzifiedOutputs = applyMamdaniDefuzzificationMethodType2(...
    outputSamplePoints,sumAntecedentOutputs,aggregatedOutputs,fis, ...
    diagnostic,varargin) %#codegen
%

% applyMamdaniDefuzzificationMethodType2 - Defuzzifies aggreagted outputs using
% 'mamdani' defuzzification methods.

%   Copyright 2019 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(outputSamplePoints)
coder.internal.prefer_const(diagnostic)
coder.internal.prefer_const(varargin{:})
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if fuzzy.internal.codegen.generateConstantCode(fis.typeReductionMethod)
    fh = str2func(char(fis.typeReductionMethod));
    
    defuzzifiedOutputs = defuzzifyOutput(true,fh,outputSamplePoints, ...
        sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
else
    if isempty(varargin) || length(varargin)<3
        if isequal(fis.typeReductionMethod,uint8('karnikmendel'))
            defuzzifiedOutputs = defuzzifyOutput(true,@karnikmendel,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        elseif isequal(fis.typeReductionMethod,uint8('ekm'))
            defuzzifiedOutputs = defuzzifyOutput(true,@ekm,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        elseif isequal(fis.typeReductionMethod,uint8('iasc'))
            defuzzifiedOutputs = defuzzifyOutput(true,@iasc,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        elseif isequal(fis.typeReductionMethod,uint8('eiasc'))
            defuzzifiedOutputs = defuzzifyOutput(true,@eiasc,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        else
            if fuzzy.internal.codegen.isTargetMATLABOrMEX
                % Valid for MATLAB simulation and MEX target.
                defuzzifiedOutputs = defuzzifyOutput(false,@feval,outputSamplePoints, ...
                    sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
            else
                defuzzifiedOutputs = zeros(fis.numOutputs,1,'like',aggregatedOutputs);
                if coder.internal.hasRuntimeErrors()
                    format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                        'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                    fprintf(format,'type reduction',char(fis.typeReductionMethod)); %#ok<CTPCT>
                end
                fuzzy.internal.codegen.runtimeExit
            end
        end
    else
        defuzzifiedOutputs = defuzzifyOutput(varargin{1},varargin{2},outputSamplePoints, ...
            sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,varargin{3});
    end
end

end
%% Helper functions -------------------------------------------------------
function defuzzifiedOutputs = defuzzifyOutput(isConstOrBuiltin,fh,outputSamplePoints, ...
    sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,notCustomEval)

coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

n = fis.numOutputs;
defuzzifiedOutputs = zeros(n,1,'like',aggregatedOutputs);

for outputID = 1:n
    if sumAntecedentOutputs(1)==0 && sumAntecedentOutputs(2)==0
        defuzzifiedOutputs(outputID) = mean(fis.outputRange(outputID,:));
        throwNoRuleFiredDiagnostic(outputID,defuzzifiedOutputs(outputID),diagnostic);
        continue
    end        
    
    umf = aggregatedOutputs(:,outputID);
    if sum(umf)==0
        defuzzifiedOutputs(outputID) = mean(fis.outputRange(outputID,:));
        throwEmptyFuzzySetDiagnostic(outputID,umf, ...
            fis.defuzzMethod,defuzzifiedOutputs(outputID),diagnostic);
        continue
    end
    x = outputSamplePoints(outputID,:)';
    lmf = aggregatedOutputs(:,n+outputID);
    
    if isConstOrBuiltin
        if notCustomEval
            defuzzifiedOutputs(outputID) = mean(fh(x,umf,lmf));
        else
            defuzzifiedOutputs(outputID) = mean(fh(...
                fis.typeReductionMethod,x,umf,lmf));
        end
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX
            % Valid for MATLAB simulation and MEX target.
            defuzzifiedOutputs(outputID) = mean(fh(...
                char(fis.typeReductionMethod),x,umf,lmf));
        else
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'type reduction',char(fis.typeReductionMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end