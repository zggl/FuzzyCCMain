function y = evaluateOrMethod(orMethod,x) %#codegen
%

% evaluateOrMethod - Evaluates the specified OR method, which is unknown
% at code generation time.

%   Copyright 2017-2018 The MathWorks, Inc.

coder.internal.prefer_const(orMethod)
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

y = zeros('like',x);

% Switch based on using a constant FIS structure, i.e. the FIS structure
% value is known at code generation time, or a variable FIS structure where
% the structure value is not known at code generation time. A variable FIS
% structure is used to compile a MEX library from this function.
if fuzzy.internal.codegen.generateConstantCode(orMethod)
    % A function handle to 'orMethod' can only be used in case
    % of a constant FIS structure.
    fh = str2func(char(orMethod));
    y(1) = fh(x);
else
    % An appropriate 'orMethod' is called at run-time in case of a variable
    % FIS structure.
    
    [y(1),hasOrMethod] = evaluateCustomOrMethod(orMethod,x);    
    if hasOrMethod%y(1) ~= -ones('like',x)
        return
    end    
    
    if isequal(orMethod,uint8('max'))
        y(1) = max(x);
    elseif isequal(orMethod,uint8('probor'))
        y(1) = probor(x);
    elseif isequal(orMethod,uint8('sum'))
        y(1) = sum(x);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX        
            % Valid for MATLAB simulation and MEX target.
            y(1) = feval(char(orMethod),x);
        else
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'OR',char(orMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end