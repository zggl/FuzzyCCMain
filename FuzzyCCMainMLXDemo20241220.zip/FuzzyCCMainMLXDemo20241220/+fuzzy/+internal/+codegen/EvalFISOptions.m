classdef EvalFISOptions < fuzzy.internal.fis.EvalFISOptions
    %EVALFISOPTIONS Codegen version of EVALFIS options.
    
    % Copyright 2018 The MathWorks, Inc.
    
    %#codegen
    
    properties
        NumSamplePoints;
        OutOfRangeInputValueMessage
        NoRuleFiredMessage
        EmptyOutputFuzzySetMessage
    end
    
    methods
        function obj = EvalFISOptions(varargin)
            
            coder.internal.prefer_const(varargin{:})
            
            obj.NumSamplePoints = 101;
            
            value = 'warning';
            coder.varsize('value',[1 7],[0 1])
            
            diagnosticType = value;
            obj.OutOfRangeInputValueMessage = diagnosticType;
            obj.NoRuleFiredMessage = diagnosticType;
            obj.EmptyOutputFuzzySetMessage = diagnosticType;            
            
            numVarargin = length(varargin);
            for i = 1:2:numVarargin
                if varargin{i} == "NumSamplePoints"
                    obj.NumSamplePoints = varargin{i+1};
                elseif varargin{i} == "OutOfRangeInputValueMessage"
                    obj.OutOfRangeInputValueMessage = varargin{i+1};
                elseif varargin{i} == "NoRuleFiredMessage"
                    obj.NoRuleFiredMessage = varargin{i+1};
                elseif varargin{i} == "EmptyOutputFuzzySetMessage"
                    obj.EmptyOutputFuzzySetMessage = varargin{i+1};
                end
            end
        end
        
        function obj = set.NumSamplePoints(obj,value)
            obj.NumSamplePoints = value;
        end

        function obj = set.OutOfRangeInputValueMessage(obj,value)
            obj.OutOfRangeInputValueMessage = char(value);
        end
        
        function obj = set.NoRuleFiredMessage(obj,value)
            obj.NoRuleFiredMessage = char(value);
        end
        
        function obj = set.EmptyOutputFuzzySetMessage(obj,value)
            obj.EmptyOutputFuzzySetMessage = char(value);
        end        
    end

end