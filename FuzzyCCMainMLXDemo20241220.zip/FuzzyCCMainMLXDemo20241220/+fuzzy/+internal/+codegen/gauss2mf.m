function y = gauss2mf(x, params) %#codegen
%%

%  Copyright 2022 The MathWorks, Inc.

sigma1 = cast(params(1),'like',x);
c1 = cast(params(2),'like',x);
sigma2 = cast(params(3),'like',x);
c2 = cast(params(4),'like',x);

c1Index=(x<=c1);
c2Index=(x>=c2);
y1 = exp(-(x-c1).^2/(2*sigma1^2)).*c1Index + (1-c1Index);
y2 = exp(-(x-c2).^2/(2*sigma2^2)).*c2Index + (1-c2Index);

y = y1.*y2;

end