function n = numParamZmf
%% numParamZmf Returns number of parameter of zmf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 2;
end