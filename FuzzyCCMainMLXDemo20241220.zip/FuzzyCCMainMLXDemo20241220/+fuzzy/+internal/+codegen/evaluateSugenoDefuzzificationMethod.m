function y = evaluateSugenoDefuzzificationMethod(defuzzMethod,x,w) %#codegen
%

% evaluateSugenoDefuzzificationMethod - Evaluates a Sugeno defuzzification
% method using specified input values. The value of defuzzification method
% is unknown at code generation time.

%   Copyright 2017-2018 The MathWorks, Inc.

coder.internal.prefer_const(defuzzMethod)

y = zeros('like',x);

% Switch based on using a constant FIS structure, i.e. the FIS structure
% value is known at code generation time, or a variable FIS structure where
% the structure value is not known at code generation time. A variable FIS
% structure is used to compile a MEX library from this function.
if fuzzy.internal.codegen.generateConstantCode(defuzzMethod)
    % A function handle to 'defuzzMethod' can only be used in case of a
    % constant FIS structure.
    fh = str2func(char(defuzzMethod));
    y(1) = fh(x,w);
else    
    % An appropriate defuzzification method is called at run-time in case
    % of a variable FIS structure.
    if isequal(defuzzMethod,uint8('wtsum'))
        y(1) = wtsum(x,w);
    else
        y(1) = wtaver(x,w);
    end
end

end