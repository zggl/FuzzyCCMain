function [y,irr,orr,arr,rfs,unImpSugRuleOut] = evaluateFIS(inputs,fis,diagnostics) %#codegen
%

% evaluateFIS - Codegen version of EVALFIS used for MEX generation. 
%
%     FIS is a homogenous structure. See fuzzy.internal.utility.packageData
%     for further detail.
%
%     DIAGNOSTICS provides user specified levels for showing diagnostics.
%     See fuzzy.internal.utility.createDiagnosticLevels for further detail.
%
%     The outputs are similar to EVALFIS outputs.
%
% See also EVALFIS, EVALFISOPTIONS.

%  Copyright 2017-2023 The MathWorks, Inc.

%% Expected constant input arguments
coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostics)

%% Evaluate FIS
% To avoid method selection in each loop at run-time, we need 1152 number
% of switch statements (see below).
%
%     N = NumAndMethod(3) x 
%         NumOrMethod(4) x 
%         NumImpMethod(3) x 
%         NumAggMethod(4) x 
%         NumDefuzzMethod(8)
%       = 1152
%
% The implementation will be error prone and difficult to maintain. The
% generated code will also include N number copies of runFIS function.
% Hence, using only defuzz method selection here since it has more options
% as compared to other methods.

% NOTE: Outputs 'rfs' and 'unImpSugRuleOut' are required for graphical
% representation of Sugeno FIS outputs in a RULEVIEWER. This is not a
% customer visible output argument in EVALFIS function.

coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if fuzzy.internal.codegen.generateConstantCode(fis)
    fh = str2func(char(fis.defuzzMethod));    
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFIS(inputs,fis,diagnostics,true,fh,true);
else
    [~,hasDefuzzMethod] = evaluateCustomDefuzzMethod(fis.defuzzMethod,ones('like',inputs),ones('like',inputs));
    if hasDefuzzMethod
        [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
            runFIS(inputs,fis,diagnostics,true,@evaluateCustomDefuzzMethod,false);
        return
    end
    
    if isequal(fis.defuzzMethod,uint8('centroid'))
        [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
            runFIS(inputs,fis,diagnostics,true,@centroid,true);
    elseif isequal(fis.defuzzMethod,uint8('bisector'))
        [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
            runFIS(inputs,fis,diagnostics,true,@bisector,true);
    elseif isequal(fis.defuzzMethod,uint8('mom'))
        [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
            runFIS(inputs,fis,diagnostics,true,@mom,true);
    elseif isequal(fis.defuzzMethod,uint8('som'))
        [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
            runFIS(inputs,fis,diagnostics,true,@som,true);
    elseif isequal(fis.defuzzMethod,uint8('lom'))
        [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
            runFIS(inputs,fis,diagnostics,true,@lom,true);
    elseif isequal(fis.defuzzMethod,uint8('wtaver'))
        [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
            runFIS(inputs,fis,diagnostics,true,@wtaver,true);
    elseif isequal(fis.defuzzMethod,uint8('wtsum'))
        [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
            runFIS(inputs,fis,diagnostics,true,@wtsum,true);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX
            [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
                runFIS(inputs,fis,diagnostics,false,@feval,true);
        else
            [y,irr,orr,arr,rfs,unImpSugRuleOut] = initVariables(fis,inputs);
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'defuzzification',char(fis.defuzzMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end
%% Helper functions -------------------------------------------------------
function [y,irr,orr,arr,w,unImpSugRuleOut] = ...
    runFIS(inputs,fis,diagnostics,defuzzIsBuiltin,defuzz,notCustomEval)

coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostics)
coder.internal.prefer_const(defuzzIsBuiltin)
coder.internal.prefer_const(defuzz)

%% Output data declaration
[y,irr,orr,arr,w,unImpSugRuleOut,outputMFCache,numInputDataSets] = ...
    initVariables(fis,inputs);
%% Pre-computed/allocated variables to speed-up MEX execution.
inVarMF = extractVarMF(fis.inputMF);
inputMFCache = zeros(1,sum(fis.numInputMFs),'like',inputs);
irrOfOneRule = zeros(fis.numInputs,1,'like',inputs);
%% Output data calculation
for i = 1:numInputDataSets
    
    x = inputs(i,:);
    [irr(:),inputMFCache(:)] = fuzzy.internal.codegen.fuzzifyInputs(...
        x,fis,diagnostics,inVarMF,inputMFCache,irr);
    [w(:),sw,irrOfOneRule(:)] = fuzzy.internal.codegen.applyOperators(...
        irr,fis,w,irrOfOneRule);
    if strcmp(char(fis.type),'mamdani')
        orr(:) = fuzzy.internal.codegen.applyMamdaniImplicationMethod(...
            w,fis,fis.outputSamplePoints,outputMFCache);
        arr(:) = fuzzy.internal.codegen.applyMamdaniAggregationMethod(orr,fis);
        y(i,:) = fuzzy.internal.codegen.applyMamdaniDefuzzificationMethod(...
            fis.outputSamplePoints,sw,arr,fis,diagnostics,defuzzIsBuiltin,defuzz,notCustomEval)';
    else
        [orr(:),unImpSugRuleOut(:)] = ...
            fuzzy.internal.codegen.applySugenoImplicationMethod(x,w,fis);
        arr(:) = fuzzy.internal.codegen.applySugenoAggregationMethod(orr);
        y(i,:) = fuzzy.internal.codegen.applySugenoDefuzzificationMethod(sw,...
            arr,fis,diagnostics,defuzzIsBuiltin,defuzz)';
    end
    
end
end

function [y,irr,orr,arr,rfs,unImpSugRuleOut,outputMFCache,numInputDataSets] = ...
    initVariables(fis,inputs)

coder.internal.prefer_const(fis)

numInputDataSets = size(inputs,1);
y = zeros(numInputDataSets,fis.numOutputs,'like',inputs);
irr = zeros(fis.numRules,fis.numInputs,'like',inputs);
orr = zeros(fis.orrSize,'like',inputs);
arr = zeros(fis.aggSize,'like',inputs);
rfs = zeros(fis.numRules,1,'like',inputs);
if strcmp(char(fis.type),'mamdani')
    outputMFCache = createMamdaniOutputMFCache(fis,fis.outputSamplePoints);
    unImpSugRuleOut = zeros('like',inputs);
else
    outputMFCache = zeros('like',inputs);
    unImpSugRuleOut = zeros(fis.orrSize,'like',inputs);
end
end