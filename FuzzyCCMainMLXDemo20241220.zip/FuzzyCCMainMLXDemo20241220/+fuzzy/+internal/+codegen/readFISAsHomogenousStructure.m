function fis = readFISAsHomogenousStructure(name)
%% READFISASHOMOGENOUSSTRUCTURE Reads a FIS file as a homogenous structure
%
%   FIS = READFISASHOMOGENOUSSTRUCTURE(FILENAME,NAME1,VALUE1,...) Reads a
%   fuzzy inference system with the specified FILENAME and returns FIS as a
%   homogenous structure for code generation.
%
%   Example
%     fis = READFISASHOMOGENOUSSTRUCTURE('tipper.fis');

%  Copyright 2018-2020 The MathWorks, Inc.

%#codegen

coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')
coder.internal.prefer_const(name)

[fid,maxLineLength,newLine] = fuzzy.internal.codegen.getFileID(name);

if maxLineLength < 8
    % Setting to a higher value so that we can assign default system
    % descriptions in case of a FIS file without system descriptions.
    maxLineLength(1) = 8;
end

% Structure
systemSectionHeader = '[System]';
systemSectionHeaderFound = false;
while ~systemSectionHeaderFound
    nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
    if feof(fid)
        break
    end
    if strcmp(deblank(char(nextLineVar)),systemSectionHeader)
        systemSectionHeaderFound = true;
    end
end

if systemSectionHeaderFound
    name = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Name=');
    type = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Type=');
    andMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'AndMethod=');
    orMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'OrMethod=');
    impMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'ImpMethod=');
    aggMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'AggMethod=');
    defuzzMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'DefuzzMethod=');
else
    name = zeros(1,maxLineLength,'uint8');
    type = zeros(1,maxLineLength,'uint8');
    andMethod = zeros(1,maxLineLength,'uint8');
    orMethod = zeros(1,maxLineLength,'uint8');
    impMethod = zeros(1,maxLineLength,'uint8');
    aggMethod = zeros(1,maxLineLength,'uint8');
    defuzzMethod = zeros(1,maxLineLength,'uint8');
end
frewind(fid);

inputInfo = getVarInfo(fid,maxLineLength,newLine,'[Input',false);
frewind(fid);

checkForSugenoMFs = (~systemSectionHeaderFound || ~any(type));
outputInfo = getVarInfo(fid,maxLineLength,newLine,'[Output',checkForSugenoMFs);
frewind(fid);
if checkForSugenoMFs
    isSugeno = outputInfo.hasSugenoMFs;
    if isSugeno
        type(1:6) = uint8('sugeno');
    else
        type(1:7) = uint8('mamdani');
    end
else
    isSugeno = strcmp(deblank(char(type)),'sugeno');
end

inputs = getVar(fid,maxLineLength,newLine,'[Input',inputInfo,false); % ,fcn.customMF
outputs = getVar(fid,maxLineLength,newLine,'[Output',outputInfo,isSugeno); % ,fcn.customMF

rules = fuzzy.internal.codegen.getRules(fid,maxLineLength,newLine,inputInfo.numVars,outputInfo.numVars);

if ~any(name)
    name(1:8) = uint8('Untitled');
end

if isSugeno % force
    impMethod(:) = 0;
    impMethod(1:4) = uint8('prod');
    aggMethod(:) = 0;
    aggMethod(1:3) = uint8('sum');
end

if ~any(andMethod)
    if isSugeno
        andMethod(1:4) = uint8('prod');
    else
        andMethod(1:3) = uint8('min');
    end
end

if ~any(orMethod)
    if isSugeno
        orMethod(1:6) = uint8('probor');
    else
        orMethod(1:3) = uint8('max');
    end
end

if ~any(impMethod)
    if ~isSugeno
        impMethod(1:3) = uint8('min');
    end
end

if ~any(aggMethod)
    if ~isSugeno
        aggMethod(1:3) = uint8('max');
    end
end

if ~any(defuzzMethod)
    if isSugeno
        defuzzMethod(1:6) = uint8('wtaver');
    else
        defuzzMethod(1:8) = uint8('centroid');
    end
end

fis = struct(...
    'name',char(name(name~=0)),...
    'type',char(type(type~=0)),...
    'andMethod',char(andMethod(andMethod~=0)),...
    'orMethod',char(orMethod(orMethod~=0)),...
    'defuzzMethod',char(defuzzMethod(defuzzMethod~=0)),...
    'impMethod',char(impMethod(impMethod~=0)),...
    'aggMethod',char(aggMethod(aggMethod~=0)),...
    'input',inputs,...
    'output',outputs,...
    'rule',rules...
    );

fclose(fid);
end

function info = getVarInfo(fid,maxLineLength,newLine,topic,checkForSugenoMFs)

coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

numVars = 0;
maxInputNameLength = 0;
maxNumMF = 0;
maxMFNameLength = 0;
maxMFTypeLength = 0;
maxMFParamLength = 0;
hasSugenoMFs = false;
info = struct(...
    'maxInputNameLength',maxInputNameLength,...
    'maxNumMF',maxNumMF,...
    'maxMFNameLength',maxMFNameLength,...
    'maxMFTypeLength',maxMFTypeLength,...
    'maxMFParamLength',maxMFParamLength,...
    'numVars',numVars,...
    'hasSugenoMFs',hasSugenoMFs...
    );

buffer = zeros(1,maxLineLength,'uint8');
template = buffer;
template(1:length(topic)) = uint8(topic);
while ~feof(fid)
    nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
    bufferEqual = nextLineVar==template;
    if ~all(bufferEqual(1:length(topic)))
        continue;
    end
    numVars = numVars + 1;
    name = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Name=');
    n = length(deblank(char(name)));
    if n > maxInputNameLength
        maxInputNameLength = n;
    end
    
    origNumMF = real(str2double(deblank(char(fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'NumMFs=',true)))));
    if origNumMF > maxNumMF
        maxNumMF = origNumMF;
    end
    
    for j=1:origNumMF
        mfInfo = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'MF');
        mfInfo2 = buffer;
        mfInfo2(1:length(mfInfo(3:end))) = mfInfo(3:end);
        id = find(mfInfo2==39,1);
        name = buffer;
        name(1:length(mfInfo2(1:id(1)-1))) = mfInfo2(1:id(1)-1);
        n = length(deblank(char(name)));
        if n > maxMFNameLength
            maxMFNameLength = n;
        end
        
        mfInfo3 = buffer;
        mfInfo3(1:length(mfInfo2(id(1)+3:end))) = mfInfo2(id(1)+3:end);
        id = find(mfInfo3==39,1);
        
        type = buffer;
        type(1:length(mfInfo3(1:id(1)-1))) = mfInfo3(1:id(1)-1);
        n = length(deblank(char(type)));
        if n > maxMFTypeLength
            maxMFTypeLength = n;
        end
        
        if checkForSugenoMFs && ~hasSugenoMFs && ...
                (strcmp(deblank(char(type)),'constant') ...
                || strcmp(deblank(char(type)),'linear'))
            hasSugenoMFs(1) = true;
        end
        
        mfInfo4 = buffer;
        mfInfo4(1:length(mfInfo3(id(1)+3:end))) = mfInfo3(id(1)+3:end);
        
        if ~isempty(find(mfInfo4==44,1))
            fclose(fid);
            if fuzzy.internal.codegen.isTargetMATLABOrMEX
                coder.internal.error('fuzzy:general:errCodegen_invalidMFParameters')
            else
                if fuzzy.internal.codegen.isRuntimeCheckOn
                    msg = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                        'fuzzy:general:errCodegen_invalidMFParameters'));
                    fprintf('%s\n',msg);
                end
                fuzzy.internal.codegen.runtimeExit
            end            
        end
        
        numParams = length(find(mfInfo4==32)) + 1;
        if numParams > maxMFParamLength
            maxMFParamLength = numParams;
        end
    end
end

info.maxInputNameLength(1) = maxInputNameLength;
info.maxNumMF(1) = maxNumMF;
info.maxMFNameLength(1) = maxMFNameLength;
info.maxMFTypeLength(1) = maxMFTypeLength;
info.maxMFParamLength(1) = maxMFParamLength;
info.numVars(1) = numVars;
info.hasSugenoMFs(1) = hasSugenoMFs;
end

function var = getVar(fid,maxLineLength,newLine,topic,info,updateOutputRange) % ,customMF
mfTemplate = struct(...
    'name',char(zeros(1,info.maxMFNameLength)),...
    'origNameLength',zeros(1,1),...
    'type',char(zeros(1,info.maxMFTypeLength)),...
    'origTypeLength',zeros(1,1),...
    'params',zeros(1,info.maxMFParamLength),...
    'origParamLength',zeros(1,1)...
    );

varTemplate = struct(...
    'name',char(zeros(1,info.maxInputNameLength)),...
    'origNameLength',zeros(1,1),...
    'range',zeros(1,2),...
    'mf',repmat(mfTemplate,1,info.maxNumMF),...
    'origNumMF',zeros(1,1)...
    );

var = repmat(varTemplate,1,info.numVars);

buffer = zeros(1,maxLineLength,'uint8');
for i=1:info.numVars
    template = buffer;
    template(1:length(topic)) = uint8(topic);
    topicFound = false;
    while ~topicFound
        nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
        if feof(fid)
            break
        end
        bufferEqual = nextLineVar==template;
        if all(bufferEqual(1:length(topic)))
            topicFound = true;
        else
            continue;
        end
        name = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Name=');
        var(i).name(1:end) = name(1:info.maxInputNameLength);
        var(i).origNameLength(1) = length(deblank(char(var(i).name)));
        
        range = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Range=');
        idR = find(range == 32,1);
        var(i).range(1) = real(str2double(deblank(char(range(1:idR(1)-1)))));
        var(i).range(2) = real(str2double(deblank(char(range(idR(1)+1:end)))));
        if updateOutputRange
            if var(i).range(2) <= var(i).range(1)
                var(i).range(2) = var(i).range(1) + 1;
            end
        end
        
        origNumMF = real(str2double(deblank(char(fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'NumMFs=',true)))));
        var(i).origNumMF = origNumMF;
        
        for j=1:origNumMF
            mfInfo = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'MF');
            mfInfo2 = buffer;
            mfInfo2(1:length(mfInfo(3:end))) = mfInfo(3:end);
            id = find(mfInfo2==39,1);
            name = buffer;
            name(1:length(mfInfo2(1:id(1)-1))) = mfInfo2(1:id(1)-1);
            var(i).mf(j).name(1:end) = name(1:info.maxMFNameLength);
            var(i).mf(j).origNameLength(1) = length(deblank(char(var(i).mf(j).name)));
            
            mfInfo3 = buffer;
            mfInfo3(1:length(mfInfo2(id(1)+3:end))) = mfInfo2(id(1)+3:end);
            id = find(mfInfo3==39,1);
            
            type = buffer;
            type(1:length(mfInfo3(1:id(1)-1))) = mfInfo3(1:id(1)-1);
            var(i).mf(j).type(1:end) = type(1:info.maxMFTypeLength);
            var(i).mf(j).origTypeLength(1) = length(deblank(char(var(i).mf(j).type)));
            
            mfInfo4 = buffer;
            mfInfo4(1:length(mfInfo3(id(1)+3:end))) = mfInfo3(id(1)+3:end);
            ids = find(mfInfo4==32);
            numParams = length(ids)+1;
            startIndex = 1;
            for k=1:numParams
                if k == numParams
                    endIndex = length(deblank(char(mfInfo4)));
                else
                    endIndex = ids(k) - 1;
                end
                val = real(str2double(char(mfInfo4(startIndex:endIndex))));
                var(i).mf(j).params(k) = val;
                startIndex = endIndex + 2;
            end
            var(i).mf(j).origParamLength(1) = numParams;
        end
    end
end
end