function y = evaluateCommonMembershipFcn(mfType,x,params) %#codegen
%

% evaluateCommonMembershipFcn - Evaluates input values X with the
% membership function MFTYPE using parameters PARAMS. The value of MFTYPE
% is unknown at code generation time. MFTYPE can be a Mamdani input/output
% membership function or a Sugeno input membership function.

%   Copyright 2017-2021 The MathWorks, Inc. 

coder.internal.prefer_const(mfType)
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

y = zeros(size(x),'like',x);

% Switch based on using a constant FIS structure, i.e. the FIS structure
% value is known at code generation time, or a variable FIS structure where
% the structure value is not known at code generation time. A variable FIS
% structure is used to compile a MEX library from this function.
if fuzzy.internal.codegen.generateConstantCode(mfType)
    % A function handle to a membership function can only be used in case
    % of a constant FIS structure. 
    fh = str2func(char(mfType));
    y(:) = fh(x,params);
else    
    % An appropriate membership function is called at run-time in case of a
    % variable FIS structure.

    [y(:),hasMFType] = evaluateCustomMF(mfType,x,params);    
    if hasMFType%all(y ~= -ones('like',x))
        return
    end
    
    if isequal(mfType,uint8('trimf'))
        y(:) = trimf(x,params);
    elseif isequal(mfType,uint8('trapmf'))
        y(:) = trapmf(x,params);
    elseif isequal(mfType,uint8('gaussmf'))
        y(:) = gaussmf(x,params);
    elseif isequal(mfType,uint8('gbellmf'))
        y(:) = gbellmf(x,params);
    elseif isequal(mfType,uint8('sigmf'))
        y(:) = sigmf(x,params);
    elseif isequal(mfType,uint8('smf'))
        y(:) = smf(x,params);
    elseif isequal(mfType,uint8('zmf'))
        y(:) = zmf(x,params);
    elseif isequal(mfType,uint8('linsmf'))
        y(:) = linsmf(x,params);
    elseif isequal(mfType,uint8('linzmf'))
        y(:) = linzmf(x,params);
    elseif isequal(mfType,uint8('gauss2mf'))
        y(:) = gauss2mf(x,params);
    elseif isequal(mfType,uint8('dsigmf'))
        y(:) = dsigmf(x,params);
    elseif isequal(mfType,uint8('psigmf'))
        y(:) = psigmf(x,params);
    elseif isequal(mfType,uint8('pimf'))
        y(:) = pimf(x,params);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX        
            % Valid for MATLAB simulation and MEX target.
            y(:) = feval(char(mfType),x,params);
        else
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'membership',char(mfType)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end