function n = numParamTrapmf
%% numParamTrapmf Returns number of parameter of trapmf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 4;
end