function [antecedentOutputs,sumAntecedentOutputs] = ...
    evaluateRuleAntecedentType2(inputs,fis,diagnostic) %#codegen
%

% evaluateRuleAntecedentType2 - Generates rule outputs using input values and
% rule antecedents.

%   Copyright 2019-2023 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostic)

antecedentOutputs = zeros(fis.rfsSize,'like',inputs);
sumAntecedentOutputs = zeros(fis.sumSize,'like',inputs);
mfIndex = zeros('like',fis.numCumInputMFs);
mVal = zeros(1,2,'like',inputs);

inputMFCache = createInputMFCacheType2(fis,inputs,diagnostic);

for ruleID = 1:fis.numRules
    defaultValue = (fis.connection(ruleID) == 1);
    antecedentOutputs(ruleID,1) = defaultValue;
    antecedentOutputs(ruleID,2) = defaultValue;
    for inputID = 1:fis.numInputs
        mfIndex(1) = abs(fis.antecedent(ruleID,inputID));
        
        % The jth input has no effect in the ith rule if the MF index value
        % is set to 0.
        if mfIndex == 0
            continue;
        end
        
        % If the membership function index is negative, take the complement
        % of the previously calculated value. This corresponds to the NOT
        % logic. Also, switch UMF and LMF.
        if fis.antecedent(ruleID,inputID)>=0
            mVal(1) = inputMFCache(1,abs(fis.numCumInputMFs(inputID))+mfIndex);
            mVal(2) = inputMFCache(2,abs(fis.numCumInputMFs(inputID))+mfIndex);
        else
            mVal(1) = ones('like',inputs) - ...
                inputMFCache(2,abs(fis.numCumInputMFs(inputID))+mfIndex);
            mVal(2) = ones('like',inputs) - ...
                inputMFCache(1,abs(fis.numCumInputMFs(inputID))+mfIndex);
        end
                
        if fis.connection(ruleID) == 1
            antecedentOutputs(ruleID,1) = fuzzy.internal.codegen.evaluateAndMethod(...
                fis.andMethod,[antecedentOutputs(ruleID,1);mVal(1)]);
            antecedentOutputs(ruleID,2) = fuzzy.internal.codegen.evaluateAndMethod(...
                fis.andMethod,[antecedentOutputs(ruleID,2);mVal(2)]);
        else
            antecedentOutputs(ruleID,1) = fuzzy.internal.codegen.evaluateOrMethod(...
                fis.orMethod,[antecedentOutputs(ruleID,1);mVal(1)]);
            antecedentOutputs(ruleID,2) = fuzzy.internal.codegen.evaluateOrMethod(...
                fis.orMethod,[antecedentOutputs(ruleID,2);mVal(2)]);
        end                
    end
    antecedentOutputs(ruleID,:) = antecedentOutputs(ruleID,:)*fis.weight(ruleID);
    sumAntecedentOutputs(1) = sumAntecedentOutputs(1) + antecedentOutputs(ruleID,1);
    sumAntecedentOutputs(2) = sumAntecedentOutputs(2) + antecedentOutputs(ruleID,2);
end

end