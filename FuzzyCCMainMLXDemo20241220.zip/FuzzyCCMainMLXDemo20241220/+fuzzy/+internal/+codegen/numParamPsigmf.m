function n = numParamPsigmf
%% numParamPsigmf Returns number of parameter of psigmf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 4;
end