function y = evaluateTypeReductionMethod(x,umf,lmf,trMethod) %#codegen
%

% EVALUATETYPEREDUCTIONMETHOD - Evaluates the specified type reduction
% method, which is unknown at code generation time.

%   Copyright 2019 The MathWorks, Inc.

coder.internal.prefer_const(trMethod)
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

y = zeros(1,2,'like',x);

if fuzzy.internal.codegen.generateConstantCode(trMethod)
    fh = str2func(char(trMethod));
    y(:) = fh(x,umf,lmf);
else
    % An appropriate 'trMethod' is called at run-time in case of a variable
    % FIS structure.    
    [y(:),hasTRMethod] = evaluateCustomTRMethod(trMethod,x,umf,lmf);    
    if hasTRMethod
       return
    end    
    
    if isequal(trMethod,uint8('karnikmendel'))
        y(:) = karnikmendel(x,umf,lmf);
    elseif isequal(trMethod,uint8('ekm'))
        y(:) = ekm(x,umf,lmf);
    elseif isequal(trMethod,uint8('iasc'))
        y(:) = iasc(x,umf,lmf);
    elseif isequal(trMethod,uint8('eiasc'))
        y(:) = eiasc(x,umf,lmf);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX        
            % Valid for MATLAB simulation and MEX target.
            y(:) = feval(char(trMethod),x,umf,lmf);
        else
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'type reduction',char(trMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end