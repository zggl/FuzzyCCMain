function n = numParamGaussmf
%% numParamGaussmf Returns number of parameter of gaussmf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 2;
end