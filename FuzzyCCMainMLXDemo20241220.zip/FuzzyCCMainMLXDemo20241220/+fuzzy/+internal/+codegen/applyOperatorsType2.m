function [antecedentOutputs,sumAntecedentOutputs,irrOfOneRule] = ...
    applyOperatorsType2(fuzzifiedInputs,fis,varargin) %#codegen
%

% applyOperators - Generates antecedent outputs.

%   Copyright 2019-2023 The MathWorks, Inc.

coder.internal.prefer_const(fis)

if isempty(varargin) || length(varargin)<2
    antecedentOutputs = zeros(fis.rfsSize,'like',fuzzifiedInputs);
    irrOfOneRule = zeros(fis.numInputs,2,'like',fuzzifiedInputs);
else
    antecedentOutputs = varargin{1};
    irrOfOneRule = varargin{2};
end
sumAntecedentOutputs = zeros(fis.sumSize,'like',fuzzifiedInputs);

for ruleID = 1:fis.numRules
    for inputID = 1:fis.numInputs
        irrOfOneRule(inputID,1) = fuzzifiedInputs(ruleID,inputID);
        irrOfOneRule(inputID,2) = fuzzifiedInputs(ruleID,fis.numInputs+inputID);
    end
    
    if fis.connection(ruleID) == 1        
        antecedentOutputs(ruleID,1) = fuzzy.internal.codegen.evaluateAndMethod(...
            fis.andMethod,irrOfOneRule(:,1));
        antecedentOutputs(ruleID,2) = fuzzy.internal.codegen.evaluateAndMethod(...
            fis.andMethod,irrOfOneRule(:,2));
    else
        antecedentOutputs(ruleID,1) = fuzzy.internal.codegen.evaluateOrMethod(...
            fis.orMethod,irrOfOneRule(:,1));
        antecedentOutputs(ruleID,2) = fuzzy.internal.codegen.evaluateOrMethod(...
            fis.orMethod,irrOfOneRule(:,2));
    end
    
    antecedentOutputs(ruleID,:) = antecedentOutputs(ruleID,:)*fis.weight(ruleID);
    sumAntecedentOutputs(1) = sumAntecedentOutputs(1) + antecedentOutputs(ruleID,1);
    sumAntecedentOutputs(2) = sumAntecedentOutputs(2) + antecedentOutputs(ruleID,2);
end

end