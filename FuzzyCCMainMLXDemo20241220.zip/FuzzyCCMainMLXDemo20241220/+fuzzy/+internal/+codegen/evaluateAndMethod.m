function y = evaluateAndMethod(andMethod,x) %#codegen
%

% evaluateAndMethod - Evaluates the specified AND method, which is unknown
% at code generation time.

%   Copyright 2017-2019 The MathWorks, Inc. 

coder.internal.prefer_const(andMethod)
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

y = zeros('like',x);

% Switch based on using a constant FIS structure, i.e. the FIS structure
% value is known at code generation time, or a variable FIS structure where
% the structure value is not known at code generation time. A variable FIS
% structure is used to compile a MEX library from this function.
if fuzzy.internal.codegen.generateConstantCode(andMethod)
    % A function handle to 'andMethod' can only be used in case
    % of a constant FIS structure.
    fh = str2func(char(andMethod));
    y(1) = fh(x);
else
    % An appropriate 'andMethod' is called at run-time in case of a
    % variable FIS structure.

    [y(1),hasAndMethod] = evaluateCustomAndMethod(andMethod,x);    
    if hasAndMethod
        return
    end    
           
    if isequal(andMethod,uint8('min'))
        y(1) = min(x);
    elseif isequal(andMethod,uint8('prod'))
        y(1) = prod(x);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX                
            % Valid for MATLAB simulation and MEX target.
            y(1) = feval(char(andMethod),x);
        else
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'AND',char(andMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end