function consequentOutputs = applyMamdaniImplicationMethod(...
    antecedentOutputs,fis,outputSamplePoints,varargin) %#codegen
%

% applyMamdaniImplicationMethod - Generates rule outputs from antecedent
% outputs using 'mamdani' implication methods.

%   Copyright 2017-2023 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(outputSamplePoints)
coder.internal.prefer_const(varargin{:})
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if isempty(varargin)
    outputMFCache = createMamdaniOutputMFCache(fis,outputSamplePoints);
else
    outputMFCache = varargin{1};
end

if fuzzy.internal.codegen.generateConstantCode(fis.impMethod)
    fh = str2func(char(fis.impMethod));
    consequentOutputs = applyImplication(true,fh,antecedentOutputs,fis, ...
        outputMFCache,true);
else

    [~,hasImpMethod] = evaluateCustomImpMethod(fis.impMethod,zeros('like',antecedentOutputs));
    if hasImpMethod
        consequentOutputs = applyImplication(true,@evaluateCustomImpMethod, ...
            antecedentOutputs,fis,outputMFCache,false);
       return
    end
        
    if isequal(fis.impMethod,uint8('min'))
        consequentOutputs = applyImplication(true,@min,antecedentOutputs, ...
            fis,outputMFCache,true);
    elseif isequal(fis.impMethod,uint8('prod'))
        consequentOutputs = applyImplication(true,@prod,antecedentOutputs, ...
            fis,outputMFCache,true);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX
            consequentOutputs = applyImplication(false,@feval,antecedentOutputs, ...
                fis,outputMFCache,true);
        else
            consequentOutputs = zeros(fis.orrSize,'like',antecedentOutputs);
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'implication',char(fis.impMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end
%% Helper functions -------------------------------------------------------
function consequentOutputs = applyImplication(isConstOrBuiltin,fh, ...
    antecedentOutputs,fis,outputMFCache,notCustomEval)

consequentOutputs = zeros(fis.orrSize,'like',antecedentOutputs);
mfIndex = zeros('like',fis.numCumOutputMFs);

for outputID = 1:fis.numOutputs
    indexOffset = (outputID-1)*fis.numRules;
    for ruleID = 1:fis.numRules
        mfIndex(1) = abs(fis.consequent(ruleID,outputID));
        ruleOutputIndex = indexOffset+ruleID;
        
        % The jth rule has no effect in ith output calculation if MF index
        % is zero.
        if mfIndex == 0
            consequentOutputs(:,ruleOutputIndex) = 0;
            continue;
        end
        
        for sampleID=1:fis.numSamples
            % Determine output membership values at the sample point.
            consequentOutputs(sampleID,ruleOutputIndex) = ...
                outputMFCache(abs(fis.numCumOutputMFs(outputID))+...
                mfIndex,sampleID);
            
            % If the membership function index is negative, take the
            % complement of the previously calculated value. This
            % corresponds to the NOT logic.
            if fis.consequent(ruleID,outputID)<0
                consequentOutputs(sampleID,ruleOutputIndex) = max([0;...
                    (ones('like',antecedentOutputs) - ...
                    consequentOutputs(sampleID,ruleOutputIndex))]);
            end
            
            if isConstOrBuiltin
                if notCustomEval
                    consequentOutputs(sampleID,ruleOutputIndex) = fh(...
                        [consequentOutputs(sampleID,ruleOutputIndex);...
                        antecedentOutputs(ruleID)]);
                else
                    consequentOutputs(sampleID,ruleOutputIndex) = fh(...
                        fis.impMethod, ...
                        [consequentOutputs(sampleID,ruleOutputIndex);...
                        antecedentOutputs(ruleID)]);                
                end
            end
        end
        
        if ~isConstOrBuiltin
            consequentOutputs(:,ruleOutputIndex) = fh(...
                char(fis.impMethod), ...
                consequentOutputs(:,ruleOutputIndex), ...
                repmat(antecedentOutputs(ruleID),fis.numSamples,1) ...
                );
        end
    end
end
end