function y = evaluateSugenoOutputMembershipFcn(mfType,x,params) %#codegen
%

% evaluateSugenoOutputMembershipFcn - Evaluates input values X with the
% Sugeno output membership function MFTYPE using parameters PARAMS. The
% value of MFTYPE is unknown at code generation time.

%   Copyright 2017-2018 The MathWorks, Inc. 

coder.internal.prefer_const(mfType)

y = zeros('like',x);

% Switch based on using a constant FIS structure, i.e. the FIS structure
% value is known at code generation time, or a variable FIS structure where
% the structure value is not known at code generation time. A variable FIS
% structure is used to compile a MEX library from this function.
if fuzzy.internal.codegen.generateConstantCode(mfType)
    % A function handle to a membership function can only be used in case
    % of a constant FIS structure. 
    fh = str2func(char(mfType));
    y(1) = fh(x,params);
else    
    % An appropriate membership function is called at run-time in case of a
    % variable FIS structure.
    if isequal(mfType,uint8('constant'))
        y(1) = constant(x,params);
    else
        y(1) = linear(x,params);
    end
end

end