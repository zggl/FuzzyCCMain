function n = numParamLinsmf
%% numParamLinsmf Returns number of parameter of linsmf.

%  Copyright 2021 The MathWorks, Inc.

%#codegen

n = 2;
end