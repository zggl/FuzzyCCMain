function defuzzifiedOutputs = applySugenoDefuzzificationMethod(...
    sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,varargin) %#codegen
%

% applySugenoDefuzzificationMethod - Defuzzifies aggreagted outputs using
% 'sugeno' defuzzification methods.

%   Copyright 2017-2018 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostic)
coder.internal.prefer_const(varargin{:})

if fuzzy.internal.codegen.generateConstantCode(fis.defuzzMethod)
    fh = str2func(char(fis.defuzzMethod));
    
    defuzzifiedOutputs = defuzzifyOutput(fh,sumAntecedentOutputs, ...
        aggregatedOutputs,fis,diagnostic);
else
    if isempty(varargin) || length(varargin)<2
        if isequal(fis.defuzzMethod,uint8('wtaver'))
            defuzzifiedOutputs = defuzzifyOutput(@wtaver, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic);
        else
            defuzzifiedOutputs = defuzzifyOutput(@wtsum, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic);
        end
    else
        defuzzifiedOutputs = defuzzifyOutput(varargin{2}, ...
            sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic);
    end
end

end
%% Helper functions -------------------------------------------------------
function defuzzifiedOutputs = defuzzifyOutput(fh,sumAntecedentOutputs, ...
    aggregatedOutputs,fis,diagnostic)

n = fis.numOutputs;
defuzzifiedOutputs = zeros(n,1,'like',aggregatedOutputs);

for outputID = 1:n
    if sumAntecedentOutputs == 0
        defuzzifiedOutputs(outputID) = mean(fis.outputRange(outputID,:));
        throwNoRuleFiredDiagnostic(outputID,defuzzifiedOutputs(outputID), ...
            diagnostic);
    else
        defuzzifiedOutputs(outputID) = fh(...
            aggregatedOutputs(outputID),sumAntecedentOutputs);
    end
end

end