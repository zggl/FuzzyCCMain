function aggregatedOutputs = applyMamdaniAggregationMethod(...
    consequentOutputs,fis) %#codegen
%

% applyMamdaniAggregationMethod - Aggreagtes rule outputs using 'mamdani'
% aggregation methods.

%   Copyright 2017-2023 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if fuzzy.internal.codegen.generateConstantCode(fis.aggMethod)
    fh = str2func(char(fis.aggMethod));
    aggregatedOutputs = applyAggregation(true,fh,consequentOutputs,fis,true);
else
    [~,hasAggMethod] = evaluateCustomAggMethod(fis.aggMethod,zeros('like',consequentOutputs));
    if hasAggMethod%all(aggregatedOutputs ~= -ones('like',x))
        aggregatedOutputs = applyAggregation(true,@evaluateCustomAggMethod, ...
            consequentOutputs,fis,false);
        return
    end
            
    if isequal(fis.aggMethod,uint8('max'))
        aggregatedOutputs = applyAggregation(true,@max,consequentOutputs,fis,true);
    elseif isequal(fis.aggMethod,uint8('probor'))
        aggregatedOutputs = applyAggregation(true,@probor,consequentOutputs,fis,true);
    elseif isequal(fis.aggMethod,uint8('sum'))
        aggregatedOutputs = applyAggregation(true,@sum,consequentOutputs,fis,true);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX        
            aggregatedOutputs = applyAggregation(false,@feval,consequentOutputs,fis,true);
        else
            aggregatedOutputs = zeros(fis.aggSize,'like',consequentOutputs);            
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'aggregation',char(fis.aggMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end    
end            

end
%% Helper functions -------------------------------------------------------
function aggregatedOutputs = applyAggregation(isConstOrBuiltin,fh, ...
    consequentOutputs,fis,notCustomEval)

aggregatedOutputs = zeros(fis.aggSize,'like',consequentOutputs);
aggVal = zeros('like',consequentOutputs);

for outputID = 1:fis.numOutputs
    indexOffset = (outputID-1)*fis.numRules;
    startIndex = indexOffset + 1;
    endIndex = indexOffset + fis.numRules;
    
    if isConstOrBuiltin
        for sampleID = 1:fis.numSamples
            aggVal(1) = consequentOutputs(sampleID,startIndex);
            for id = startIndex+1:endIndex
                if notCustomEval
                    aggVal(1) = fh([aggVal;consequentOutputs(sampleID,id)]);
                else
                    aggVal(1) = fh(fis.aggMethod,[aggVal;consequentOutputs(sampleID,id)]);
                end
            end
            aggregatedOutputs(sampleID,outputID) = aggVal;
        end
    else
        aggregatedOutputs(:,outputID) = fh(...
            char(fis.aggMethod), ...
            consequentOutputs(:,startIndex:endIndex)' ...
            )';
    end
end

end