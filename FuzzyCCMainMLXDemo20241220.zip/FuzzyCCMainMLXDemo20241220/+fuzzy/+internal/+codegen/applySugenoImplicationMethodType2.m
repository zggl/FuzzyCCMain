function consequentOutputs = ...
    applySugenoImplicationMethodType2(inputs,rfs,fis) %#codegen
%

% applySugenoImplicationMethodType2 - Generates rule outputs from antecedent
% outputs using 'sugeno' implication method.

%   Copyright 2019 The MathWorks, Inc. 

coder.internal.prefer_const(fis)

consequentOutputs = zeros(fis.orrSize,'like',inputs);
mfIndex = zeros('like',fis.numCumOutputMFs);
outputMFCache = createSugenoOutputMFCacheType2(inputs,fis);
n = fis.numOutputs;
for ruleID = 1:fis.numRules
    for outputID = 1:fis.numOutputs
        mfIndex(1) = fis.consequent(ruleID,outputID);
        
        % The jth rule has no effect in ith output calculation if MF
        % index is zero. mfIndex cannot be negative in a Sugeno FIS.
        if mfIndex ~= 0
            consequentOutputs(ruleID,outputID) = outputMFCache(...
                fis.numCumOutputMFs(outputID)+mfIndex);
        end

        consequentOutputs(ruleID,n+outputID) = rfs(ruleID,1);
        consequentOutputs(ruleID,2*n+outputID) = rfs(ruleID,2);
    end
end

end