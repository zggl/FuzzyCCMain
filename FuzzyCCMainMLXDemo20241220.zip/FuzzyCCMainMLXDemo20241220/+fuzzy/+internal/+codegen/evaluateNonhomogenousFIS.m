function [y,irr,orr,arr,rfs,unImpSugRuleOut] = evaluateNonhomogenousFIS(...
    inputs,fis,diagnostics,numSamples) %#codegen
%

% evaluateNonhomogenousFIS - Codegen version of EVALFIS for nonhomogenous FIS. 
%
%     FIS is a nonhomogenous structure.
%
%     DIAGNOSTICS provides user specified levels for showing diagnostics.
%     See fuzzy.internal.utility.createDiagnosticLevels for further detail.
%
%     The outputs are similar to EVALFIS outputs.
%
% See also EVALFIS, EVALFISOPTIONS.

%  Copyright 2018-2023 The MathWorks, Inc.

%% Evaluate FIS
% To avoid method selection in each loop at run-time, we need 1152 number
% of switch statements (see below).
%
%     N = NumAndMethod(3) x 
%         NumOrMethod(4) x 
%         NumImpMethod(3) x 
%         NumAggMethod(4) x 
%         NumDefuzzMethod(8)
%       = 1152
%
% The implementation will be error prone and difficult to maintain. The
% generated code will also include N number copies of runFIS function.
% Hence, using only defuzz method selection here since it has more options
% as compared to other methods.

% NOTE: Outputs 'rfs' and 'unImpSugRuleOut' are required for graphical
% representation of Sugeno FIS outputs in a RULEVIEWER. This is not a
% customer visible output argument in EVALFIS function.



if strcmp(fis.defuzzMethod,'centroid')
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFISNH(inputs,fis,diagnostics,true,@centroid,numSamples);
elseif strcmp(fis.defuzzMethod,'bisector')
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFISNH(inputs,fis,diagnostics,true,@bisector,numSamples);
elseif strcmp(fis.defuzzMethod,'mom')
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFISNH(inputs,fis,diagnostics,true,@mom,numSamples);
elseif strcmp(fis.defuzzMethod,'som')
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFISNH(inputs,fis,diagnostics,true,@som,numSamples);
elseif strcmp(fis.defuzzMethod,'lom')
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFISNH(inputs,fis,diagnostics,true,@lom,numSamples);
elseif strcmp(fis.defuzzMethod,'wtaver')
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFISNH(inputs,fis,diagnostics,true,@wtaver,numSamples);
elseif strcmp(fis.defuzzMethod,'wtsum')
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFISNH(inputs,fis,diagnostics,true,@wtsum,numSamples);
else
    [y,irr,orr,arr,rfs,unImpSugRuleOut] = ...
        runFISNH(inputs,fis,diagnostics,false,@feval,numSamples);
end

end
%% Helper functions -------------------------------------------------------
function [y,irr,orr,arr,w,unImpSugRuleOut] = ...
    runFISNH(inputs,fis,diagnostics,defuzzIsBuiltin,defuzz,numSamples)

%% Output data declaration
numInputs = length(fis.input);
numOutputs = length(fis.output);
numRules = length(fis.rule);
numOutputMFs = zeros(1,numOutputs);
totalNumOutputMFs = 0;
for i = 1:numOutputs
    n = length(fis.output(i).mf);
    numOutputMFs(i) = n;
    totalNumOutputMFs = totalNumOutputMFs + n;
end
numCumOutputMFs =  cumsum(numOutputMFs) - numOutputMFs;
[y,irr,orr,arr,w,unImpSugRuleOut,outputMFCache,numInputDataSets,outputSamplePoints] = ...
    initVariablesNH(fis,inputs,numInputs,numOutputs,numRules,numSamples,totalNumOutputMFs);
%% Pre-computed/allocated variables to speed-up MEX execution.
%inVarMF = extractVarMF(fis.inputMF);
numInputMFs = zeros(1,numInputs);
totalNumInputMFs = 0;
for i = 1:numInputs
    n = length(fis.input(i).mf);
    numInputMFs(i) = n;
    totalNumInputMFs = totalNumInputMFs + n;
end
numCumInputMFs =  cumsum(numInputMFs) - numInputMFs;
inputMFCache = zeros(1,totalNumInputMFs,'like',inputs);
irrOfOneRule = zeros(numInputs,1,'like',inputs);
%% Output data calculation
for i = 1:numInputDataSets
    
    x = inputs(i,:);
    [irr(:),inputMFCache(:)] = fuzzifyInputsNH(...
        x,fis,diagnostics,numInputs,numRules,numCumInputMFs,irr,inputMFCache);    
    [w(:),sw,irrOfOneRule(:)] = applyOperatorsNH(...
        irr,fis,numInputs,numRules,w,irrOfOneRule);
    if strcmp(char(fis.type),'mamdani')
        orr(:) = applyMamdaniImplicationMethodNH(...
            w,fis,outputMFCache,numCumOutputMFs,numOutputs,numRules,numSamples,orr);        
        arr(:) = applyMamdaniAggregationMethodNH(orr,fis,numOutputs, ...
            numRules,numSamples,arr);
        y(i,:) = applyMamdaniDefuzzificationMethodNH(...
            outputSamplePoints,sw,arr,fis,diagnostics,defuzzIsBuiltin,defuzz,...
            numOutputs,y(i,:))';
    else
        [orr(:),unImpSugRuleOut(:)] = ...
            applySugenoImplicationMethodNH(x,w,fis,numRules,numOutputs, ...
            numOutputMFs,numCumOutputMFs,outputMFCache,orr,unImpSugRuleOut);        
        arr(:) = fuzzy.internal.codegen.applySugenoAggregationMethod(orr);        
        y(i,:) = applySugenoDefuzzificationMethodNH(sw,...
            arr,fis,diagnostics,defuzz,numOutputs,y(i,:))';
    end
    
end
end

function [y,irr,orr,arr,rfs,unImpSugRuleOut,outputMFCache,numInputDataSets,...
    outputSamplePoints] = initVariablesNH(fis,inputs,numInputs,numOutputs, ...
    numRules,numSamples,totalNumOutputMFs)

numInputDataSets = size(inputs,1);
y = zeros(numInputDataSets,numOutputs,'like',inputs);
irr = zeros(numRules,numInputs,'like',inputs);

if strcmp(fis.type,'mamdani')
    orrSize = [numSamples numRules*numOutputs];
    orr = zeros(orrSize,'like',inputs);
    arrSize = [numSamples numOutputs];
    arr = zeros(arrSize,'like',inputs);
    [outputMFCache,outputSamplePoints] = createMamdaniOutputMFCacheNH(fis, ...
        inputs,numSamples,numOutputs,totalNumOutputMFs);
    unImpSugRuleOut = zeros('like',inputs);
else
    orrSize = [numRules,numOutputs];
    orr = zeros(orrSize,'like',inputs);
    arrSize = [1 numOutputs];
    arr = zeros(arrSize,'like',inputs);
    outputMFCache = zeros(totalNumOutputMFs,1,'like',inputs);
    outputSamplePoints = zeros('like',inputs);
    unImpSugRuleOut = zeros(orrSize,'like',inputs);
end

rfs = zeros(numRules,1,'like',inputs);
end

function [outputMFCache,outputSamplePoints] = createMamdaniOutputMFCacheNH(...
    fis,inputs,numSamplePoints,numOutputs,totalNumOutputMFs)

outputSamplePoints = zeros(numOutputs,numSamplePoints,'like',inputs);
outputMFCache = zeros(totalNumOutputMFs,numSamplePoints,...
    'like',inputs);

index = 0;
for outputID = 1:numOutputs
    range = fis.output(outputID).range;
    numSamplesMinus1 = numSamplePoints-1;
    outputSamplePoints(outputID,:) = range(1) + ...
        (0:numSamplesMinus1).*(range(2)-range(1))./numSamplesMinus1;
    numMFs = length(fis.output(outputID).mf);
    for mfID = 1:numMFs
        index = index + 1;
        outputMFCache(index,:) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            fis.output(outputID).mf(mfID).type,...
            outputSamplePoints(outputID,:),...
            fis.output(outputID).mf(mfID).params);
    end
end

end

function [fuzzifiedInputs,inputMFCache] = fuzzifyInputsNH(...
    inputs,fis,diagnostic,numInputs,numRules, ...
    numCumInputMFs,fuzzifiedInputs,inputMFCache)

mfIndex = zeros('like',numCumInputMFs);
inputMFCache(:) = createInputMFCacheNH(fis,inputs,diagnostic, ...
    inputMFCache,numInputs);

for ruleID = 1:numRules
    for inputID = 1:numInputs
        mfIndex(1) = abs(fis.rule(ruleID).antecedent(inputID));

        % The jth input has no effect in the ith rule if the MF index value
        % is set to 0.
        if mfIndex == 0
            fuzzifiedInputs(ruleID,inputID) = (fis.rule(ruleID).connection == 1);
            continue;
        end

        % Determine the degree of membership according to the specified
        % membership function.
        fuzzifiedInputs(ruleID,inputID) = inputMFCache(abs(...
            numCumInputMFs(inputID))+mfIndex);

        % If the membership function index is negative, take the complement
        % of the previously calculated value. This corresponds to the NOT
        % logic.
        if fis.rule(ruleID).antecedent(inputID)<0
            fuzzifiedInputs(ruleID,inputID) = ...
                ones('like',inputs) - fuzzifiedInputs(ruleID,inputID);
        end
    end
end    

end

function inputMFCache = createInputMFCacheNH(fis,inputs,diagnostic, ...
    inputMFCache, numInputs)

index = 0;
for inputID =1:numInputs
    throwOutOfRangeDiagnostic(inputID,inputs(inputID), ...
        fis.input(inputID).range,diagnostic);
    numMFs = length(fis.input(inputID).mf);
    for mfID = 1:numMFs
        index = index + 1;
        inputMFCache(index) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            fis.input(inputID).mf(mfID).type,...
            inputs(inputID),...
            fis.input(inputID).mf(mfID).params);
    end
end

end

function [antecedentOutputs,sumAntecedentOutputs,irrOfOneRule] = ...
    applyOperatorsNH(fuzzifiedInputs,fis, ...
    numInputs,numRules,antecedentOutputs,irrOfOneRule)

sumAntecedentOutputs = zeros('like',fuzzifiedInputs);

for ruleID = 1:numRules
    for inputID = 1:numInputs
        irrOfOneRule(inputID) = fuzzifiedInputs(ruleID,inputID);
    end
    
    if fis.rule(ruleID).connection == 1        
        antecedentOutputs(ruleID) = fuzzy.internal.codegen.evaluateAndMethod(...
            fis.andMethod,irrOfOneRule);
    else
        antecedentOutputs(ruleID) = fuzzy.internal.codegen.evaluateOrMethod(...
            fis.orMethod,irrOfOneRule);
    end
    
    antecedentOutputs(ruleID) = antecedentOutputs(ruleID)*fis.rule(ruleID).weight;
    sumAntecedentOutputs(1) = sumAntecedentOutputs + antecedentOutputs(ruleID);
end

end

function consequentOutputs = applyMamdaniImplicationMethodNH(...
    antecedentOutputs,fis,outputMFCache,...
    numCumOutputMFs,numOutputs,numRules,numSamples,consequentOutputs)

if strcmp(fis.impMethod,'min')
    consequentOutputs(:) = applyImplication(true,@min,antecedentOutputs, ...
        fis,outputMFCache,consequentOutputs,...
        numCumOutputMFs,numOutputs,numRules,numSamples);
elseif strcmp(fis.impMethod,'prod')
    consequentOutputs(:) = applyImplication(true,@prod,antecedentOutputs, ...
        fis,outputMFCache,consequentOutputs,...
        numCumOutputMFs,numOutputs,numRules,numSamples);
else
    consequentOutputs(:) = applyImplication(false,@feval,antecedentOutputs, ...
        fis,outputMFCache,consequentOutputs,...
        numCumOutputMFs,numOutputs,numRules,numSamples);
end

end

function consequentOutputs = applyImplication(isConstOrBuiltin,fh, ...
    antecedentOutputs,fis,outputMFCache,consequentOutputs,...
    numCumOutputMFs,numOutputs,numRules,numSamples)

mfIndex = zeros('like',numCumOutputMFs);

for outputID = 1:numOutputs
    indexOffset = (outputID-1)*numRules;
    for ruleID = 1:numRules
        mfIndex(1) = abs(fis.rule(ruleID).consequent(outputID));
        ruleOutputIndex = indexOffset+ruleID;
        
        % The jth rule has no effect in ith output calculation if MF index
        % is zero.
        if mfIndex == 0
            consequentOutputs(:,ruleOutputIndex) = 0;
            continue;
        end
        
        for sampleID=1:numSamples
            % Determine output membership values at the sample point.
            consequentOutputs(sampleID,ruleOutputIndex) = ...
                outputMFCache(abs(numCumOutputMFs(outputID))+...
                mfIndex,sampleID);
            
            % If the membership function index is negative, take the
            % complement of the previously calculated value. This
            % corresponds to the NOT logic.
            if fis.rule(ruleID).consequent(outputID)<0
                consequentOutputs(sampleID,ruleOutputIndex) = max([0;...
                    (ones('like',antecedentOutputs) - ...
                    consequentOutputs(sampleID,ruleOutputIndex))]);
            end
            
            if isConstOrBuiltin
                consequentOutputs(sampleID,ruleOutputIndex) = fh(...
                    [consequentOutputs(sampleID,ruleOutputIndex);...
                    antecedentOutputs(ruleID)]);
            end
        end
        
        if ~isConstOrBuiltin
            consequentOutputs(:,ruleOutputIndex) = fh(...
                char(fis.impMethod), ...
                consequentOutputs(:,ruleOutputIndex), ...
                repmat(antecedentOutputs(ruleID),numSamples,1) ...
                );
        end
    end
end
end

function aggregatedOutputs = applyMamdaniAggregationMethodNH(...
    consequentOutputs,fis,numOutputs,numRules,numSamples,aggregatedOutputs)

if strcmp(fis.aggMethod,'max')
    aggregatedOutputs(:) = applyAggregation(true,@max,consequentOutputs,fis,...
        aggregatedOutputs,numOutputs,numRules,numSamples);
elseif strcmp(fis.aggMethod,'probor')
    aggregatedOutputs(:) = applyAggregation(true,@probor,consequentOutputs,fis,...
        aggregatedOutputs,numOutputs,numRules,numSamples);
elseif strcmp(fis.aggMethod,'sum')
    aggregatedOutputs(:) = applyAggregation(true,@sum,consequentOutputs,fis,...
        aggregatedOutputs,numOutputs,numRules,numSamples);
else
    aggregatedOutputs(:) = applyAggregation(false,@feval,consequentOutputs,fis,...
        aggregatedOutputs,numOutputs,numRules,numSamples);
end

end

function aggregatedOutputs = applyAggregation(isConstOrBuiltin,fh, ...
    consequentOutputs,fis,aggregatedOutputs,numOutputs,numRules,numSamples)

aggVal = zeros('like',consequentOutputs);

for outputID = 1:numOutputs
    indexOffset = (outputID-1)*numRules;
    startIndex = indexOffset + 1;
    endIndex = indexOffset + numRules;
    
    if isConstOrBuiltin
        for sampleID = 1:numSamples
            aggVal(1) = consequentOutputs(sampleID,startIndex);
            for id = startIndex+1:endIndex
                aggVal(1) = fh([aggVal;consequentOutputs(sampleID,id)]);
            end
            aggregatedOutputs(sampleID,outputID) = aggVal;
        end
    else
        aggregatedOutputs(:,outputID) = fh(...
            fis.aggMethod, ...
            consequentOutputs(:,startIndex:endIndex)' ...
            )';
    end
end

end

function defuzzifiedOutputs = applyMamdaniDefuzzificationMethodNH(...
    outputSamplePoints,sumAntecedentOutputs,aggregatedOutputs,fis, ...
    diagnostic,isConstOrBuiltin,fh,numOutputs,defuzzifiedOutputs)

for outputID = 1:numOutputs
    if sumAntecedentOutputs == 0
        defuzzifiedOutputs(outputID) = mean(fis.output(outputID).range);
        throwNoRuleFiredDiagnostic(outputID,defuzzifiedOutputs(outputID),diagnostic);
    else
        if isConstOrBuiltin
            defuzzifiedOutputs(outputID) = fh(...
                outputSamplePoints(outputID,:)',aggregatedOutputs(:,outputID));
        else
            % Valid for MATLAB simulation and MEX target.
            defuzzifiedOutputs(outputID) = fh(...
                fis.defuzzMethod,...
                outputSamplePoints(outputID,:)',aggregatedOutputs(:,outputID));
        end
        throwEmptyFuzzySetDiagnostic(outputID,aggregatedOutputs(:,outputID), ...
            fis.defuzzMethod,defuzzifiedOutputs(outputID),diagnostic);
    end
end

end

function [consequentOutputs,unscaledOutputs] = ...
    applySugenoImplicationMethodNH(inputs,antecedentOutputs,fis, ...
    numRules,numOutputs,numOutputMFs,numCumOutputMFs,outputMFCache, ...
    consequentOutputs,unscaledOutputs)

mfIndex = zeros('like',numCumOutputMFs);
outputMFCache(:) = createSugenoOutputMFCacheNH(inputs,fis,...
    numOutputs,numOutputMFs,numCumOutputMFs,outputMFCache);

for ruleID = 1:numRules
    for outputID = 1:numOutputs
        mfIndex(1) = fis.rule(ruleID).consequent(outputID);
        
        % The jth rule has no effect in ith output calculation if MF
        % index is zero.
        if mfIndex == 0
            continue;
        end

        unscaledOutputs(ruleID,outputID) = outputMFCache(...
            numCumOutputMFs(outputID)+mfIndex);
        consequentOutputs(ruleID,outputID) = outputMFCache(...
            numCumOutputMFs(outputID)+mfIndex)*antecedentOutputs(ruleID);
    end
end

end

function outputMFCache = createSugenoOutputMFCacheNH(inputs,fis,...
    numOutputs,numOutputMFs,numCumOutputMFs,outputMFCache)

for outputID = 1:numOutputs
    numMFs = numOutputMFs(outputID);
    for mfID = 1:numMFs
        outputMFCache(numCumOutputMFs(outputID)+mfID) = ...
            fuzzy.internal.codegen.evaluateSugenoOutputMembershipFcn(...
            fis.output(outputID).mf(mfID).type,...
            inputs,fis.output(outputID).mf(mfID).params);
    end
end

end

function defuzzifiedOutputs = applySugenoDefuzzificationMethodNH(...
    sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,fh, ...
    numOutputs,defuzzifiedOutputs)

for outputID = 1:numOutputs
    if sumAntecedentOutputs == 0
        defuzzifiedOutputs(outputID) = mean(fis.output(outputID).range);
        throwNoRuleFiredDiagnostic(outputID,defuzzifiedOutputs(outputID), ...
            diagnostic);
    else
        defuzzifiedOutputs(outputID) = fh(...
            aggregatedOutputs(outputID),sumAntecedentOutputs);
    end
end

end

