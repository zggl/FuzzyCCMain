function aggregatedOutputs = applySugenoAggregationMethod(...
    consequentOutputs) %#codegen
%

% applySugenoAggregationMethod - Aggreagtes rule outputs using 'sugeno'
% aggregation method.

%   Copyright 2017 The MathWorks, Inc. 

aggregatedOutputs = cast(sum(consequentOutputs,1),...
    'like',consequentOutputs);

end