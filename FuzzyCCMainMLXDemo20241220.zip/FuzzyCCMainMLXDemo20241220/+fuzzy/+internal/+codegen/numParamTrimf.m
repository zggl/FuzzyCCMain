function n = numParamTrimf
%% numParamTrimf Returns number of parameter of trimf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 3;
end