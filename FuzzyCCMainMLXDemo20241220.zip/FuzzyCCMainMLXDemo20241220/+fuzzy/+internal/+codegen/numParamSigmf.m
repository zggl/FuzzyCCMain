function n = numParamSigmf
%% numParamSigmf Returns number of parameter of sigmf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 2;
end