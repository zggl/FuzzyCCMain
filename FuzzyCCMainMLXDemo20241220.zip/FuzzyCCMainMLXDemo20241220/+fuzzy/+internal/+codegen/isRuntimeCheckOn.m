function result = isRuntimeCheckOn
%ISRUNTIMECHECKON Returns true if run-time error check is set in coder
%configuration.

%  Copyright 2018, The MathWorks, Inc.

%#codegen

result = coder.internal.hasRuntimeErrors;
end