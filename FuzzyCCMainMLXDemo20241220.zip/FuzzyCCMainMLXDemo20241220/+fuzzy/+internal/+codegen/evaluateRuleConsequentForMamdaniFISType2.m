function aggregatedOutputs = evaluateRuleConsequentForMamdaniFISType2(...
    antecedentOutputs,fis,outputSamplePoints) %#codegen
%

% evaluateRuleConsequentForMamdaniFISType2 - Generates aggregated output
% values using 'mamdani' implication and aggregation methods.

%   Copyright 2019-2021 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(outputSamplePoints)

aggregatedOutputs = zeros(fis.aggSize,'like',antecedentOutputs);
mfIndex = zeros('like',fis.numCumOutputMFs);
mfVal = zeros(1,2,'like',antecedentOutputs);

outputMFCache = createMamdaniOutputMFCacheType2(fis,outputSamplePoints);

% Determine output membership values at the sample points
for outputID = 1:fis.numOutputs
    for ruleID = 1:fis.numRules
        mfIndex(1) = abs(fis.consequent(ruleID,outputID));
        
        % The jth rule has no effect in ith output calculation if MF index
        % is zero.
        if mfIndex == 0
            continue;
        end
        
        for sampleID=1:fis.numSamples
            % Determine output membership values at the sample point.
            if fis.consequent(ruleID,outputID)>=0
                mfVal(1) = outputMFCache(abs(...
                    fis.numCumOutputMFs(outputID))+mfIndex,sampleID);
                mfVal(2) = outputMFCache(abs(...
                    fis.numCumOutputMFs(outputID))+mfIndex,fis.numSamples+sampleID);
            else
                % If the membership function index is negative, take the
                % complement of the previously calculated value. This
                % corresponds to the NOT logic. Also switch UMF and LMF.
                mfVal(1) = ones('like',antecedentOutputs) - outputMFCache(abs(...
                    fis.numCumOutputMFs(outputID))+mfIndex,fis.numSamples+sampleID);
                mfVal(2) = ones('like',antecedentOutputs) - outputMFCache(abs(...
                    fis.numCumOutputMFs(outputID))+mfIndex,sampleID);
            end
            
            mfVal(1) = fuzzy.internal.codegen.evaluateAndMethod(...
                fis.impMethod,[mfVal(1);antecedentOutputs(ruleID,1)]);
            mfVal(2) = fuzzy.internal.codegen.evaluateAndMethod(...
                fis.impMethod,[mfVal(2);antecedentOutputs(ruleID,2)]);
            aggregatedOutputs(sampleID,outputID) = ...
                fuzzy.internal.codegen.evaluateOrMethod(fis.aggMethod, ...
                [aggregatedOutputs(sampleID,outputID);mfVal(1)]);
            aggregatedOutputs(sampleID,fis.numOutputs+outputID) = ...
                fuzzy.internal.codegen.evaluateOrMethod(fis.aggMethod, ...
                [aggregatedOutputs(sampleID,fis.numOutputs+outputID);mfVal(2)]);
        end
    end
end

end