function topicValue = findTopic(fid,maxLineLength,newLine,topic,varargin)
%

%  Copyright 2019-2020 The MathWorks, Inc.

%#codegen

if isempty(varargin)
    numericValue = false;
else
    numericValue = varargin{1};
end

buffer = zeros(1,maxLineLength,'uint8');
topicValue = buffer;
n = length(topic);

buffer(1:n) = uint8(topic);
topicFound = false;
while ~topicFound
    nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
    if feof(fid)
        break
    end
    
    bufferEqual = nextLineVar==buffer;
    if all(bufferEqual(1:length(topic)))
        topicFound = true;
        ids = xor(nextLineVar,buffer);
        token = nextLineVar(ids);
        if numericValue
            topicValue(1:length(token)) = token;
        else
            equalId = find(token==61,1);
            if isempty(equalId)
                topicValue(1:length(token)-2) = token(2:end-1);
            else
                topicValue(1:length(token)-equalId(1)) = token(equalId(1):end-1);
            end
        end
    end
end
end