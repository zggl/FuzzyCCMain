function result = getNextLine(fid,maxLength,newLine)
%

%

%  Copyright 2019 The MathWorks, Inc.

%#codegen

result = getLine(fid,maxLength,newLine);
stopFlag = 0;
while ~stopFlag
    if any(result)
        if ~strcmp(char(result(1)),'%') && result(1)~=newLine
            % This line has real content or the end of the file; stop and return outLine
            stopFlag=1;
        else
            % This line must be a comment; keep going
            result = getLine(fid,maxLength,newLine);
        end
    else
        % End of file
        stopFlag=1;
    end
end
end
%% Helper functions -------------------------------------------------------
function result = getLine(fid,maxLength,newLine)
result = zeros(1,maxLength,'uint8');

notDone = true;
count = 0;
while notDone
    value = cast(fread(fid,1),'uint8');
    if isempty(value)
        notDone = false;
    else
        if value == newLine
            notDone = false;
            if count == 0
                result(1) = value(1);
            end
        else
            count = count + 1;
            result(count) = value(1);
        end
    end
end

end
