function y = evaluateMamdaniDefuzzificationMethod(defuzzMethod,x,w) %#codegen
%

% evaluateMamdaniDefuzzificationMethod - Evaluates a Mamdani
% defuzzification method using specified input values. The value of
% defuzzification method is unknown at code generation time.

%   Copyright 2017-2018 The MathWorks, Inc.

coder.internal.prefer_const(defuzzMethod)

y = zeros('like',x);

% Switch based on using a constant FIS structure, i.e. the FIS structure
% value is known at code generation time, or a variable FIS structure where
% the structure value is not known at code generation time. A variable FIS
% structure is used to compile a MEX library from this function.
if fuzzy.internal.codegen.generateConstantCode(defuzzMethod)
    % A function handle to 'defuzzMethod' can only be used in case of a
    % constant FIS structure.
    fh = str2func(char(defuzzMethod));
    y(1) = fh(x,w);
else    
    % An appropriate defuzzification method is called at run-time in case
    % of a variable FIS structure.
    if isequal(defuzzMethod,uint8('centroid'))
        y(1) = centroid(x,w);
    elseif isequal(defuzzMethod,uint8('bisector'))
        y(1) = bisector(x,w);
    elseif isequal(defuzzMethod,uint8('mom'))
        y(1) = mom(x,w);
    elseif isequal(defuzzMethod,uint8('som'))
        y(1) = som(x,w);
    elseif isequal(defuzzMethod,uint8('lom'))
        y(1) = lom(x,w);
    else
        % Valid for MATLAB simulation and MEX target.
        y(1) = feval(char(defuzzMethod),x,w);
    end
end

end