function [x,umf,lmf,n] = putNonzeroUMFAtBeginning(x,umf,lmf)
%

% PUTNONZEROUMFATBEGINNING Puts nonzero UMF elements at the beginning with
% their orders unchanged. X and LMF are changed according to UMF. Output N
% represents the number of nonzero UMF elements.

%  Copyright 2019 The MathWorks, Inc.

%#codegen

temp = zeros('like',x);
n = int32(0);
for i = 1:length(x)
    if umf(i)>0
        n(1) = n + 1;
        if i~=n
            temp(1) = x(n);
            x(n) = x(i);
            x(i) = temp;
            
            temp(1) = umf(n);
            umf(n) = umf(i);
            umf(i) = temp;
            
            temp(1) = lmf(n);
            lmf(n) = lmf(i);
            lmf(i) = temp;
        end
    end
end

end