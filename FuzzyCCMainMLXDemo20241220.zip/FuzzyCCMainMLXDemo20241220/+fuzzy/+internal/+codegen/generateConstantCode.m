function y = generateConstantCode(inputValue) %#codegen
%

% GENERATECONSTANTCODE - Returns true if INPUTVALUE is constant and not of
% type 'coder.Type'.
%
%   GENERATECONSTANTCODE ensures that an input value (which is either a FIS
%   structure or its field value) is constant as well as not a 'coder.Type'
%   input for optimized constant-folded code generation using function
%   handles.
%
%   GENERATECONSTANTCODE is also used as a testing hook, which can be
%   overloaded to test the code generation path using a variable FIS
%   structure in MATLAB.
%
%   Additional notes on constantness of a FIS structure:
%   ===================================================
%   1) Constant FIS for code generation in Simulink
%   -----------------------------------------------
%   Code generation from a Fuzzy Logic Controller (FLC) block in Simulink
%   always uses a constant FIS structure, i.e. the FIS structure is known
%   at code generation time. 
%
%   2) Constant FIS for simulation
%   ------------------------------
%   The FLC block provides two options for simulation: 'Interpreted
%   execution' and 'Code generation' modes. In case of 'Code generation'
%   mode, a constant FIS is used. 
%
%   3) Variable FIS for simulation
%   ------------------------------
%   In case of 'Interpreted execution' mode, the FLC block uses
%   pre-compiled MEX libraries generated from codegen functions. In order
%   to make a generelized MEX library, a variable FIS structure must be
%   used as an input to a codegen function during code generation.

%  Copyright 2017 The MathWorks, Inc.

coder.internal.prefer_const(inputValue);
y = coder.internal.isConst(inputValue) && ~isa(inputValue,'coder.Type');
end