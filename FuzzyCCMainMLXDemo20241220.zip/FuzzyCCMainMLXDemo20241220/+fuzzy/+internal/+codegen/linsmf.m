function y = linsmf(x,params) %#codegen
%

% linsmf - Codegen version of linsmf.

%   Copyright 2021 The MathWorks, Inc.

a = cast(params(1),'like',x);
b = cast(params(2),'like',x);
y = zeros(size(x),'like',x);

for i=1:numel(x)
    if x(i) >= b
        y(i) = 1;
    elseif x(i)>=a
        y(i) = (x(i)-a)*(1/(b-a));
    end
end

end