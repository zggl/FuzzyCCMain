function validateConstantParams(varargin)
%

%

%  Copyright 2019 The MathWorks, Inc.

%#codegen

coder.internal.prefer_const(varargin{:})

for i = 1:numel(varargin)
    coder.internal.errorIf(~fuzzy.internal.codegen.generateConstantCode(varargin{i}), ...
        'fuzzy:general:errCodegen_nonconstantParamValues')
end

end