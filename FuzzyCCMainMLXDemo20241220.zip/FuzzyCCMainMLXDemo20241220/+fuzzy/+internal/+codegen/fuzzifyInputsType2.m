function [fuzzifiedInputs,inputMFCache] = fuzzifyInputsType2(inputs,fis,diagnostic,varargin) %#codegen
%

% fuzzifyInputsType2 - Fuzzifies input values using input MFs.

%   Copyright 2019-2023 The MathWorks, Inc. 

coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostic)

mfIndex = zeros('like',fis.numCumInputMFs);
if isempty(varargin) || length(varargin)<3
    fuzzifiedInputs = zeros(fis.irrSize,'like',inputs);
    inputMFCache = createInputMFCacheType2(fis,inputs,diagnostic);
else
    coder.internal.prefer_const(varargin{1})
    
    fuzzifiedInputs = varargin{3};
    inputMFCache = varargin{2};
    inputMFCache(:) = createInputMFCacheType2(fis,inputs,diagnostic,varargin{1},inputMFCache);
end

for ruleID = 1:fis.numRules
    for inputID = 1:fis.numInputs
        mfIndex(1) = abs(fis.antecedent(ruleID,inputID));

        % The jth input has no effect in the ith rule if the MF index value
        % is set to 0.
        if mfIndex == 0
            defaultValue = (fis.connection(ruleID) == 1);
            fuzzifiedInputs(ruleID,inputID) = defaultValue;
            fuzzifiedInputs(ruleID,fis.numInputs+inputID) = defaultValue;
            continue;
        end

        % Determine the degree of membership according to the specified
        % membership function.
        if fis.antecedent(ruleID,inputID)>=0
            % For positive index value, use the cache value as it's.
            fuzzifiedInputs(ruleID,inputID) = inputMFCache(1,abs(...
                fis.numCumInputMFs(inputID))+mfIndex);
            fuzzifiedInputs(ruleID,fis.numInputs+inputID) = inputMFCache(2,abs(...
                fis.numCumInputMFs(inputID))+mfIndex);
        else
            % If the membership function index is negative (NOT logic),
            % take the complement of the cache value. Also the complement
            % operation switches the upper and lower bound values. 
            fuzzifiedInputs(ruleID,inputID) = ...
                ones('like',inputs) - inputMFCache(2,abs(...
                fis.numCumInputMFs(inputID))+mfIndex);
            fuzzifiedInputs(ruleID,fis.numInputs+inputID) = ...
                ones('like',inputs) - inputMFCache(1,abs(...
                fis.numCumInputMFs(inputID))+mfIndex);
        end
    end
end    

end