function fis = readType2FISAsHomogenousStructure(name)
%% READFISASHOMOGENOUSSTRUCTURE Reads a FIS file as a homogenous structure
%
%   FIS = READFISASHOMOGENOUSSTRUCTURE(FILENAME,NAME1,VALUE1,...) Reads a
%   fuzzy inference system with the specified FILENAME and returns FIS as a
%   homogenous structure for code generation.
%
%   Example
%     fis = READFISASHOMOGENOUSSTRUCTURE('tipper.fis');

%  Copyright 2019 The MathWorks, Inc.

%#codegen

coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')
coder.internal.prefer_const(name)

[fid,maxLineLength,newLine] = fuzzy.internal.codegen.getFileID(name);

% Structure
systemSectionHeader = '[System]';
systemSectionHeaderFound = false;
while ~systemSectionHeaderFound
    nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
    if feof(fid)
        break
    end
    if strcmp(deblank(char(nextLineVar)),systemSectionHeader)
        systemSectionHeaderFound = true;
    end
end

fisname = zeros(1,maxLineLength,'uint8');
type = zeros(1,maxLineLength,'uint8');
andMethod = zeros(1,maxLineLength,'uint8');
orMethod = zeros(1,maxLineLength,'uint8');
impMethod = zeros(1,maxLineLength,'uint8');
aggMethod = zeros(1,maxLineLength,'uint8');
defuzzMethod = zeros(1,maxLineLength,'uint8');
typeReductionMethod = zeros(1,maxLineLength,'uint8');

if systemSectionHeaderFound
    fisname = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Name=');
    if ~any(fisname)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','FIS name')
    end
    type = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Type=');
    if ~any(type)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','FIS type')
    end    
    format = real(str2double(deblank(char(fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Version=',true)))));
    if ~any(format)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','Version')
    else
        if format~=3
            throwError(fid,'fuzzy:general:errCodegen_incorrectVersionMEX', ...
                'fuzzy:general:errCodegen_incorrectVersion')
        end
    end        
    andMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'AndMethod=');
    if ~any(andMethod)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','AND method')
    end        
    orMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'OrMethod=');
    if ~any(orMethod)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','OR method')
    end        
    impMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'ImpMethod=');
    if ~any(impMethod)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','Implication method')
    end        
    aggMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'AggMethod=');
    if ~any(aggMethod)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','Aggregation method')
    end        
    defuzzMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'DefuzzMethod=');
    if ~any(defuzzMethod)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','Defuzzification method')
    end        
    typeReductionMethod = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'TypeReductionMethod=');
    if ~any(typeReductionMethod)
        throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
            'fuzzy:general:errCodegen_topicNotFound','Type reduction method')
    end        
else
    throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
        'fuzzy:general:errCodegen_topicNotFound','System description')
end
frewind(fid);

inputInfo = getVarInfo(fid,maxLineLength,newLine,'[Input',false);
frewind(fid);

outputInfo = getVarInfo(fid,maxLineLength,newLine,'[Output',false);
frewind(fid);
isSugeno = strcmp(deblank(char(type)),'sugeno');

inputs = getVar(fid,maxLineLength,newLine,'[Input',inputInfo,false); % ,fcn.customMF
outputs = getVar(fid,maxLineLength,newLine,'[Output',outputInfo,isSugeno); % ,fcn.customMF

rules = fuzzy.internal.codegen.getRules(fid,maxLineLength,newLine,inputInfo.numVars,outputInfo.numVars);

fis = struct(...
    'name',char(fisname(fisname~=0)),...
    'type',char(type(type~=0)),...
    'andMethod',char(andMethod(andMethod~=0)),...
    'orMethod',char(orMethod(orMethod~=0)),...
    'defuzzMethod',char(defuzzMethod(defuzzMethod~=0)),...
    'impMethod',char(impMethod(impMethod~=0)),...
    'aggMethod',char(aggMethod(aggMethod~=0)),...
    'input',inputs,...
    'output',outputs,...
    'rule',rules,...
    'typeReductionMethod',char(typeReductionMethod(typeReductionMethod~=0))...
    );

fclose(fid);
end

function info = getVarInfo(fid,maxLineLength,newLine,topic,checkForSugenoMFs)
numVars = 0;
maxInputNameLength = 0;
maxNumMF = 0;
maxMFNameLength = 0;
hasSugenoMFs = false;
maxUMFTypeLength = 0;
maxUMFParamLength = 0;
maxLMFTypeLength = 0;
maxLMFParamLength = 0;
info = struct(...
    'maxInputNameLength',maxInputNameLength,...
    'maxNumMF',maxNumMF,...
    'maxMFNameLength',maxMFNameLength,...
    'maxUMFTypeLength',maxUMFTypeLength,...
    'maxUMFParamLength',maxUMFParamLength,...
    'maxLMFTypeLength',maxLMFTypeLength,...
    'maxLMFParamLength',maxLMFParamLength,...
    'numVars',numVars,...
    'hasSugenoMFs',hasSugenoMFs...
    );

buffer = zeros(1,maxLineLength,'uint8');
template = buffer;
template(1:length(topic)) = uint8(topic);
while ~feof(fid)
    nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
    bufferEqual = nextLineVar==template;
    if ~all(bufferEqual(1:length(topic)))
        continue;
    end
    numVars = numVars + 1;
    name = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Name=');
    if ~any(name)
        if isequal(topic,'[Input')
            throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
                'fuzzy:general:errCodegen_topicNotFound','Input name')
        else
            throwError(fid,'fuzzy:general:errCodegen_topicNotFoundMEX', ...
                'fuzzy:general:errCodegen_topicNotFound','Output name')
        end
    end
    n = length(deblank(char(name)));
    if n > maxInputNameLength
        maxInputNameLength = n;
    end
    
    origNumMF = real(str2double(deblank(char(fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'NumMFs=',true)))));
    if origNumMF > maxNumMF
        maxNumMF = origNumMF;
    end
    
    for j=1:origNumMF
        mfInfo = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'MF');
        mfInfo2 = buffer;
        mfInfo2(1:length(mfInfo(3:end))) = mfInfo(3:end);
        id = find(mfInfo2==39,1);
        name = buffer;
        name(1:length(mfInfo2(1:id(1)-1))) = mfInfo2(1:id(1)-1);
        n = length(deblank(char(name)));
        if n > maxMFNameLength
            maxMFNameLength = n;
        end
        
        mfInfo3 = buffer;
        mfInfo3(1:length(mfInfo2(id(1)+3:end))) = mfInfo2(id(1)+3:end);
        id = find(mfInfo3==39,1);
        
        umftype = buffer;
        umftype(1:length(mfInfo3(1:id(1)-1))) = mfInfo3(1:id(1)-1);
        n = length(deblank(char(umftype)));
        if n > maxUMFTypeLength
            maxUMFTypeLength = n;
        end
        
        mfInfo4 = buffer;
        mfInfo4(1:length(mfInfo3(id(1)+3:end))) = mfInfo3(id(1)+3:end);
        sep = find(mfInfo4==44);
        
        if isempty(sep)
            n = length(find(deblank(char(mfInfo4))==32)) + 1;
            if n > maxUMFParamLength
                maxUMFParamLength = n;
            end
            continue
        end
        
        n = length(find(mfInfo4(1:sep(1)-2)==32)) + 1;
        if n > maxUMFParamLength
            maxUMFParamLength = n;
        end
        
        if checkForSugenoMFs && ~hasSugenoMFs && ...
                (strcmp(deblank(char(umftype)),'constant') ...
                || strcmp(deblank(char(umftype)),'linear'))
            hasSugenoMFs(1) = true;
            continue
        end
        
        maxLMFTypeLength = maxUMFTypeLength;
        maxLMFParamLength = maxUMFParamLength;
    end
end

info.maxInputNameLength(1) = maxInputNameLength;
info.maxNumMF(1) = maxNumMF;
info.maxMFNameLength(1) = maxMFNameLength;
info.maxUMFTypeLength(1) = maxUMFTypeLength;
info.maxUMFParamLength(1) = maxUMFParamLength;
info.maxLMFTypeLength(1) = maxLMFTypeLength;
info.maxLMFParamLength(1) = maxLMFParamLength;
info.numVars(1) = numVars;
info.hasSugenoMFs(1) = hasSugenoMFs;
end

function var = getVar(fid,maxLineLength,newLine,topic,info,isSugeno) % ,customMF
mfTemplate = struct(...
    'name',char(zeros(1,info.maxMFNameLength)),...
    'origNameLength',zeros(1,1),...
    'umftype',char(zeros(1,info.maxUMFTypeLength)),...
    'origUMFTypeLength',zeros(1,1),...
    'umfparams',zeros(1,info.maxUMFParamLength),...
    'origUMFParamLength',zeros(1,1),...
    'lmftype',char(zeros(1,info.maxLMFTypeLength)),...
    'origLMFTypeLength',zeros(1,1),...
    'lmfparams',zeros(1,info.maxLMFParamLength),...
    'origLMFParamLength',zeros(1,1),...
    'lmfscale',zeros(1,1), ...
    'lmflag',zeros(1,2) ...
    );

varTemplate = struct(...
    'name',char(zeros(1,info.maxInputNameLength)),...
    'origNameLength',zeros(1,1),...
    'range',zeros(1,2),...
    'mf',repmat(mfTemplate,1,info.maxNumMF),...
    'origNumMF',zeros(1,1)...
    );

var = repmat(varTemplate,1,info.numVars);

buffer = zeros(1,maxLineLength,'uint8');
for i=1:info.numVars
    template = buffer;
    template(1:length(topic)) = uint8(topic);
    topicFound = false;
    while ~topicFound
        nextLineVar = fuzzy.internal.codegen.getNextLine(fid,maxLineLength,newLine);
        if feof(fid)
            break
        end
        bufferEqual = nextLineVar==template;
        if all(bufferEqual(1:length(topic)))
            topicFound = true;
        else
            continue;
        end
        name = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Name=');
        var(i).name(1:end) = name(1:info.maxInputNameLength);
        var(i).origNameLength(1) = length(deblank(char(var(i).name)));
        
        range = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'Range=');
        idR = find(range == 32,1);
        var(i).range(1) = real(str2double(deblank(char(range(1:idR(1)-1)))));
        var(i).range(2) = real(str2double(deblank(char(range(idR(1)+1:end)))));
        if isSugeno
            if var(i).range(2) <= var(i).range(1)
                var(i).range(2) = var(i).range(1) + 1;
            end
        end
        
        origNumMF = real(str2double(deblank(char(fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'NumMFs=',true)))));
        var(i).origNumMF = origNumMF;
        
        for j=1:origNumMF
            mfInfo = fuzzy.internal.codegen.findTopic(fid,maxLineLength,newLine,'MF');
            mfInfo2 = buffer;
            mfInfo2(1:length(mfInfo(3:end))) = mfInfo(3:end);
            id = find(mfInfo2==39,1);
            name = buffer;
            name(1:length(mfInfo2(1:id(1)-1))) = mfInfo2(1:id(1)-1);
            var(i).mf(j).name(1:end) = name(1:info.maxMFNameLength);
            var(i).mf(j).origNameLength(1) = length(deblank(char(var(i).mf(j).name)));
            
            mfInfo3 = buffer;
            mfInfo3(1:length(mfInfo2(id(1)+3:end))) = mfInfo2(id(1)+3:end);
            id = find(mfInfo3==39,1);
            
            umftype = buffer;
            umftype(1:length(mfInfo3(1:id(1)-1))) = mfInfo3(1:id(1)-1);
            var(i).mf(j).umftype(1:end) = umftype(1:info.maxUMFTypeLength);
            var(i).mf(j).origUMFTypeLength(1) = length(deblank(char(var(i).mf(j).umftype)));
            
            mfInfo4 = buffer;
            mfInfo4(1:length(mfInfo3(id(1)+3:end))) = mfInfo3(id(1)+3:end);
            sep = find(mfInfo4==44);
            
            if isempty(sep)
                ids = find(deblank(char(mfInfo4))==32);
                if isempty(ids)
                    val = real(str2double(deblank(char(mfInfo4))));
                    var(i).mf(j).umfparams(1) = val;
                end
            else
                ids = find(mfInfo4(1:sep(1)-2)==32);
            end
                    
            for k=1:length(ids)
                if k == length(ids)
                    if k == 1
                        startIndex = 1;
                    else
                        startIndex = ids(k-1) + 1;
                    end
                    val = real(str2double(char(mfInfo4(startIndex:ids(k)-1))));
                    var(i).mf(j).umfparams(k) = val;
                    startIndex = ids(k) + 1;
                    if isempty(sep)
                        val = real(str2double(deblank(char(mfInfo4(startIndex:end)))));
                    else
                        val = real(str2double(deblank(char(mfInfo4(startIndex:sep(1)-2)))));
                    end
                    var(i).mf(j).umfparams(k+1) = val;
                else
                    if k == 1
                        startIndex = 1;
                    else
                        startIndex = ids(k-1) + 1;
                    end
                    val = real(str2double(char(mfInfo4(startIndex:ids(k)-1))));
                    var(i).mf(j).umfparams(k) = val;
                end
            end
            var(i).mf(j).origUMFParamLength(1) = length(ids)+1;
            
            if isempty(sep)%isSugeno
                continue
            end
            
            var(i).mf(j).lmftype(:) = var(i).mf(j).umftype;
            var(i).mf(j).origLMFTypeLength(1) = var(i).mf(j).origUMFTypeLength;
            
            var(i).mf(j).lmfscale(1) = real(str2double(deblank(char(mfInfo4(sep(end-1)+2:sep(end)-2)))));            
            mfInfo4(1:length(sep(end)+2:end)) = mfInfo4(sep(end)+2:end);
            ids = find(mfInfo4==32);
            var(i).mf(j).lmflag(1) = real(str2double(deblank(char(mfInfo4(1:ids(1)-1)))));
            var(i).mf(j).lmflag(2) = real(str2double(deblank(char(mfInfo4(ids(1)+1:end)))));
            
            var(i).mf(j).lmfparams(:) = fuzzy.internal.codegen.applyLowerLag(...
                var(i).mf(j).umftype,var(i).mf(j).umfparams,var(i).mf(j).lmflag,true);
            var(i).mf(j).origLMFParamLength(1) = var(i).mf(j).origUMFParamLength;
        end
    end
end


end

function throwError(fid,id1,id2,varargin)
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')
fclose(fid);
if fuzzy.internal.codegen.isTargetMATLABOrMEX
    coder.internal.error(id1,varargin{:})
else
    if fuzzy.internal.codegen.isRuntimeCheckOn
        format = coder.const(fuzzy.internal.utility.getEnglishMessage(id2));
        fprintf(format,varargin{:});
    end
    fuzzy.internal.codegen.runtimeExit
end
end