function y = trapmf(x, params) %#codegen
%

% trapmf - Codegen version of trapmf.

%   Copyright 2017 The MathWorks, Inc.

a = cast(params(1),'like',x); 
b = cast(params(2),'like',x);
c = cast(params(3),'like',x);
d = cast(params(4),'like',x);

y = zeros(size(x),'like',x);
y1 = zeros(size(x),'like',x);
y2 = zeros(size(x),'like',x);

for i = 1:numel(x)
    if x(i) >= b
        y1(i) = 1;
    end
    
    if x(i) < a
        y1(i) = 0;
    end
    
    if (a<=x(i) && x(i)<b) && a~=b
        y1(i) = (x(i)-a)*(1/(b-a));
    end
    
    if x(i) <= c
        y2(i) = 1;
    end
    
    if x(i) > d
        y2(i) = 0;
    end
    
    if (c<x(i) && x(i)<=d) && c~=d
        y2(i) = (d-x(i))*(1/(d-c));
    end
    
    y(i) = min(y1(i), y2(i));    
end

end