function throwNoRuleFiredDiagnostic(id,value,diagnostic) %#codegen
%

% throwNoRuleFiredWarning - Throws warning when no fuzzy rule is fired.

% Copyright 2017-2019 The MathWorks, Inc.

if coder.target('MEX') || coder.target('MATLAB')
    
    if diagnostic.NoRuleFired == 2 % warning
        feval('fuzzy.internal.utility.throwWarning',diagnostic, ...
            'warnEvalfis_NoRuleFired',id,sprintf('%g',value));
    elseif diagnostic.NoRuleFired == 3 % error
        feval('fuzzy.internal.utility.throwError',diagnostic, ...
            'errEvalfis_NoRuleFired',id);
    end
    
end
end