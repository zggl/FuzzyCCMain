function outputMFCache = createSugenoOutputMFCache(inputs,fis) %#codegen
%

% createSugenoOutputMFCache - Evaluates output MFs with the input values.
%
%     The evaluated values are used to generate rule outputs.

%   Copyright 2017-2018 The MathWorks, Inc.

coder.internal.prefer_const(fis)

outputMFCache = zeros(sum(fis.numOutputMFs),1,'like',inputs);
outVarMF = extractVarMF(fis.outputMF);
isConstant = fuzzy.internal.codegen.generateConstantCode(fis);

for outputID = coder.unroll(1:fis.numOutputs,isConstant)
    numMFs = fis.numOutputMFs(outputID);
    for mfID = coder.unroll(1:numMFs,isConstant)
        outputMFCache(fis.numCumOutputMFs(outputID)+mfID) = ...
            fuzzy.internal.codegen.evaluateSugenoOutputMembershipFcn(...
            outVarMF{outputID}{mfID}.type,...
            inputs,outVarMF{outputID}{mfID}.params);
    end
end

end