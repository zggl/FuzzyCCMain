function inputMFCache = createInputMFCache(fis,inputs,diagnostic,varargin) %#codegen
%

% createInputMFCache - Evaluates input values with the corresponding input
% MFs.
%
%     The evaluated fuzzified values are used to generate antecedent
%     outputs.

%   Copyright 2017-2018 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostic)

if isempty(varargin) || length(varargin)<2
    inVarMF = extractVarMF(fis.inputMF);
    inputMFCache = coder.nullcopy(zeros(1,sum(fis.numInputMFs),'like',inputs));
else
    coder.internal.prefer_const(varargin{1})
    
    inVarMF = varargin{1};
    inputMFCache = varargin{2};
end
isConstant = fuzzy.internal.codegen.generateConstantCode(fis);

for inputID = coder.unroll(1:fis.numInputs,isConstant)
    throwOutOfRangeDiagnostic(inputID,inputs(inputID), ...
        fis.inputRange(inputID,:),diagnostic);
    numMFs = fis.numInputMFs(inputID);
    for mfID = coder.unroll(1:numMFs,isConstant)
        inputMFCache(fis.numCumInputMFs(inputID)+mfID) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            inVarMF{inputID}{mfID}.type,...
            inputs(inputID),...
            inVarMF{inputID}{mfID}.params);
    end
end

end
