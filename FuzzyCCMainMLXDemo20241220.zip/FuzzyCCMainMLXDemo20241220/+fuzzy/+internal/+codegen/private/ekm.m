function soln = ekm(x,umf,lmf)
%

% EKM - Enhanced Karnik-Mendel algorithm for type reduction.

%  Copyright 2019 The MathWorks, Inc.

%#codegen

[x,umf,lmf,n] = fuzzy.internal.codegen.putNonzeroUMFAtBeginning(x,umf,lmf);
soln = zeros(1,2,'like',x);
if n == 1
    soln(1) = x(1);
    soln(2) = x(1);
    return
end
sumLMF = zeros('like',x);
for i = 1:n
    sumLMF(1) = sumLMF + lmf(i);
end
if sumLMF==0
    soln(1) = x(1);
    soln(2) = x(n);
    return
end
soln(1) = localekmleft(x,umf,lmf,2.4,n);
soln(2) = localekmright(x,lmf,umf,1.7,n);
end
%% Local functions --------------------------------------------------------
function soln = localekmleft(x,umf,lmf,m,n)

soln = zeros('like',x);
refK = int32(round(n*(1/m)));
id = int32(0);
refVal = zeros('like',x);

a = zeros('like',x);
b = zeros('like',x);
for i = 1:refK
    a(1) = a(1) + x(i)*umf(i);
    b(1) = b(1) + umf(i);
end
for i = refK+1:n
    a(1) = a(1) + x(i)*lmf(i);
    b(1) = b(1) + lmf(i);
end
refVal(1) = a*(1/b);

while true
    
    soln(1) = a*(1/b);
    if soln>refVal
       soln(1) = refVal;
       break
    end
    
    for k = 1:n-1
        id(1) = k;
        if soln>=x(k) && soln<=x(k+1)
            break
        end
    end
    
    if refK==id
        break
    end
    
    if refK>id
        for i = id+1:refK
            a(1) = a(1) - x(i)*(umf(i)-lmf(i));
            b(1) = b(1) - (umf(i)-lmf(i));
        end
    else
        for i = refK+1:id
            a(1) = a(1) + x(i)*(umf(i)-lmf(i));
            b(1) = b(1) + (umf(i)-lmf(i));
        end
    end
    
    refK(1) = id;
    refVal(1) = soln;
end

end

function soln = localekmright(x,umf,lmf,m,n)

soln = zeros('like',x);
refK = int32(round(n*(1/m)));
id = int32(0);
refVal = zeros('like',x);

a = zeros('like',x);
b = zeros('like',x);
for i = 1:refK
    a(1) = a(1) + x(i)*umf(i);
    b(1) = b(1) + umf(i);
end
for i = refK+1:n
    a(1) = a(1) + x(i)*lmf(i);
    b(1) = b(1) + lmf(i);
end
refVal(1) = a*(1/b);

while true
    
    soln(1) = a*(1/b);
    if soln<refVal
       soln(1) = refVal;
       break
    end
    
    for k = 1:n-1
        id(1) = k;
        if soln>=x(k) && soln<=x(k+1)
            break
        end
    end
    
    if refK==id
        break
    end
    
    if refK>id
        for i = id+1:refK
            a(1) = a(1) + x(i)*(lmf(i)-umf(i));
            b(1) = b(1) + (lmf(i)-umf(i));
        end
    else
        for i = refK+1:id
            a(1) = a(1) - x(i)*(lmf(i)-umf(i));
            b(1) = b(1) - (lmf(i)-umf(i));
        end
    end
    
    refK(1) = id;
end

end