function y = mom(x,membershipValueOfX) %#codegen
%

% mom - Codegen version of MOM defuzzification method.

%   Copyright 2017 The MathWorks, Inc. 

maxMFValue = max(membershipValueOfX);

maxValueInX = zeros(size(x),'like',x);
maxValueIdsInX = zeros(size(x),'like',x);

sumMaxValueInX = zeros('like',x);
sumMaxValueIdsInX = zeros('like',x);

for i=1:length(membershipValueOfX)
    if membershipValueOfX(i) == maxMFValue
        maxValueInX(i) = x(i);
        maxValueIdsInX(i) = 1;
    end
    sumMaxValueInX(1) = sumMaxValueInX + maxValueInX(i);
    sumMaxValueIdsInX(1) = sumMaxValueIdsInX + maxValueIdsInX(i);
end

y = zeros('like',x); 
y(1) = sumMaxValueInX*(1/sumMaxValueIdsInX);

end