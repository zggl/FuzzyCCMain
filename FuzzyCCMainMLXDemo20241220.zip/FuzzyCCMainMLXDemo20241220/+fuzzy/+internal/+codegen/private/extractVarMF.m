function varout = extractVarMF(varin) %#codegen
%

% extractVarMF - Extract MF structure values for code generation.
%
%     The input argument is a homogenous MF array structures, which contain
%     redundant values. This function removes the redundant data for
%     efficient code generation.

%   Copyright 2017 The MathWorks, Inc.

varout = coder.nullcopy(cell(1,length(varin)));
for i=1:length(varin)
    mf = coder.nullcopy(cell(1,varin(i).origNumMF));
    for j=1:varin(i).origNumMF
        mf{j} = struct(...
            'type',varin(i).mf(j).type(1:varin(i).mf(j).origTypeLength), ...
            'params',varin(i).mf(j).params(1:varin(i).mf(j).origParamLength) ...
            );
    end
    varout{i} = mf;
end
end