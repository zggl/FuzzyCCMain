function throwOutOfRangeDiagnostic(id,value,range,diagnostic) %#codegen
%

% throwOutOfRangeDiagnostic - Throws warning in case of out of range input
% values.

% Copyright 2018-2019 The MathWorks, Inc.

if coder.target('MEX') || coder.target('MATLAB')
    if value<range(1) || value>range(2)
        
        if diagnostic.OutOfRangeInputValue == 2 % warning
            feval('fuzzy.internal.utility.throwWarning',diagnostic, ...
                'diagEvalfis_OutOfRangeInput', ...
                id,sprintf('[%g %g]',range(1),range(2)),sprintf('%g',value));
        elseif diagnostic.OutOfRangeInputValue == 3 % error
            feval('fuzzy.internal.utility.throwError',diagnostic, ...
                'diagEvalfis_OutOfRangeInput', ...
                id,sprintf('[%g %g]',range(1),range(2)),sprintf('%g',value));
        end
        
    end
end
end
