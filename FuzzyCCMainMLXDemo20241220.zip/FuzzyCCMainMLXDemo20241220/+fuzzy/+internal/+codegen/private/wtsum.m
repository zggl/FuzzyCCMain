function y = wtsum(x,~) %#codegen
%

% wtsum - Codegen version of WTSUM defuzzification method.

%   Copyright 2017 The MathWorks, Inc. 
y = x;
end