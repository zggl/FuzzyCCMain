function soln = iasc(x,umf,lmf)
%

% IASC - Iterative algorithm with stopping condition.

%  Copyright 2019 The MathWorks, Inc.

%#codegen

[x,umf,lmf,n] = fuzzy.internal.codegen.putNonzeroUMFAtBeginning(x,umf,lmf);
soln = zeros(1,2,'like',x);
if n == 1
    soln(1) = x(1);
    soln(2) = x(1);
    return
end
soln(1) = iascleft(x,umf,lmf,n);
soln(2) = iascright(x,umf,lmf,n);
end
%% Local functions --------------------------------------------------------
function ref = iascleft(x,umf,lmf,n)
soln = zeros('like',x);
a = zeros('like',x);
b = zeros('like',x);
ref = x(n);
for i = 1:n
    a(1) = a(1) + x(i)*lmf(i);
    b(1) = b(1) + lmf(i);
end
if b==0
    ref(1) = x(1);
    return
end
for L = 1:n-1
    a(1) = a(1) + x(L)*(umf(L)-lmf(L));
    b(1) = b(1) + (umf(L)-lmf(L));
    soln(1) = a*(1/b);
    if soln < ref
        ref(1) = soln;
    elseif soln > ref
        break
    end
end
end

function ref = iascright(x,umf,lmf,n)
soln = zeros('like',x);
a = zeros('like',x);
b = zeros('like',x);
ref = x(1);
for i = 1:n
    a(1) = a(1) + x(i)*umf(i);
    b(1) = b(1) + umf(i);
end
for R = 1:n-1
    a(1) = a(1) - x(R)*(umf(R)-lmf(R));
    b(1) = b(1) - (umf(R)-lmf(R));
    soln(1) = a*(1/b);
    if soln > ref
        ref(1) = soln;
    elseif soln < ref
        break
    end
end
end
