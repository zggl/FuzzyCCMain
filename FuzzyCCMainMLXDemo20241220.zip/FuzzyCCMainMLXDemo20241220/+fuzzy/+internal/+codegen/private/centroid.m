function y = centroid(x,membershipValueOfX,varargin) %#codegen
%

% centroid - Codegen version of CENTROID defuzzification method.

%   Copyright 2017 The MathWorks, Inc. 

y = zeros('like',x);
area = zeros('like',x);
n = int32(0);
if isempty(varargin)
    n(1) = length(x);
else
    n(1) = varargin{1};
end
for i = 1:n
    area(1) = area + membershipValueOfX(i);
end
%area = cast(sum(membershipValueOfX),'like',x);

if area == 0
    y(1) = mean([x(1);x(n)]);
else
    for i = 1:n
        y(1) = y + x(i)*membershipValueOfX(i);
    end
    y(1) = y*(1/area);
end

end