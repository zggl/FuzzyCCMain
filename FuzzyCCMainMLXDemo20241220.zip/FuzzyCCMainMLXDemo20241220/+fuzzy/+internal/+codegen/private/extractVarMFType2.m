function varout = extractVarMFType2(varin) %#codegen
%

% extractVarMFType2 - Extract MF structure values for code generation.
%
%     The input argument is a homogenous MF array structures, which contain
%     redundant values. This function removes the redundant data for
%     efficient code generation.

%   Copyright 2019 The MathWorks, Inc.

varout = coder.nullcopy(cell(1,length(varin)));
for i=1:length(varin)
    mf = coder.nullcopy(cell(1,varin(i).origNumMF));
    for j=1:varin(i).origNumMF
        mf{j} = struct(...
            'umftype',varin(i).mf(j).umftype(1:varin(i).mf(j).origUMFTypeLength), ...
            'umfparams',varin(i).mf(j).umfparams(1:varin(i).mf(j).origUMFParamLength), ...
            'lmftype',varin(i).mf(j).lmftype(1:varin(i).mf(j).origLMFTypeLength), ...
            'lmfparams',varin(i).mf(j).lmfparams(1:varin(i).mf(j).origLMFParamLength), ...
            'lmfscale',varin(i).mf(j).lmfscale ...
            );
    end
    varout{i} = mf;
end

end