function outputMFCache = createMamdaniOutputMFCacheType2(fis,outputSamplePoints) %#codegen
%

% createMamdaniOutputMFCacheType2 - Evaluates output sample points with the
% corresponding output MFs.
%
%     The evaluated fuzzified values are used to generate rule outputs.

%   Copyright 2019 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(outputSamplePoints)

outputMFCache = coder.nullcopy(zeros(sum(fis.numOutputMFs),2*fis.numSamples,...
    'like',outputSamplePoints));
outVarMF = extractVarMFType2(fis.outputMF);
isConstant = fuzzy.internal.codegen.generateConstantCode(fis);

for outputID = coder.unroll(1:fis.numOutputs,isConstant)
    numMFs = fis.numOutputMFs(outputID);
    for mfID = coder.unroll(1:numMFs,isConstant)        
        outputMFCache(fis.numCumOutputMFs(outputID)+mfID,1:fis.numSamples) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            outVarMF{outputID}{mfID}.umftype,...
            outputSamplePoints(outputID,:),...
            outVarMF{outputID}{mfID}.umfparams);
        outputMFCache(fis.numCumOutputMFs(outputID)+mfID,fis.numSamples+1:end) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            outVarMF{outputID}{mfID}.lmftype,...
            outputSamplePoints(outputID,:),...
            outVarMF{outputID}{mfID}.lmfparams)*outVarMF{outputID}{mfID}.lmfscale;
    end
end

end