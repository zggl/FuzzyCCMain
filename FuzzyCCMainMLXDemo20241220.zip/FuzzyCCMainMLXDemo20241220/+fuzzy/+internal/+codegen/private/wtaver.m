function y = wtaver(x,sumWeight) %#codegen
%

% wtaver - Codegen version of WTAVER defuzzification method.

%   Copyright 2017 The MathWorks, Inc. 

y = zeros('like',x);

y(1) = x*(1/sumWeight);

end