function inputMFCache = createInputMFCacheType2(fis,inputs,diagnostic,varargin) %#codegen
%

% createInputMFCache - Evaluates input values with the corresponding input
% MFs.
%
%     The evaluated fuzzified values are used to generate antecedent
%     outputs.

%   Copyright 2019 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostic)

if isempty(varargin) || length(varargin)<2
    inVarMF = extractVarMFType2(fis.inputMF);
    inputMFCache = coder.nullcopy(zeros(2,sum(fis.numInputMFs),'like',inputs));
else
    coder.internal.prefer_const(varargin{1})
    
    inVarMF = varargin{1};
    inputMFCache = varargin{2};
end
isConstant = fuzzy.internal.codegen.generateConstantCode(fis);

for inputID = coder.unroll(1:fis.numInputs,isConstant)
    throwOutOfRangeDiagnostic(inputID,inputs(inputID), ...
        fis.inputRange(inputID,:),diagnostic);
    numMFs = fis.numInputMFs(inputID);
    for mfID = coder.unroll(1:numMFs,isConstant)
        inputMFCache(1,fis.numCumInputMFs(inputID)+mfID) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            inVarMF{inputID}{mfID}.umftype,...
            inputs(inputID),...
            inVarMF{inputID}{mfID}.umfparams);
        inputMFCache(2,fis.numCumInputMFs(inputID)+mfID) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            inVarMF{inputID}{mfID}.lmftype,...
            inputs(inputID),...
            inVarMF{inputID}{mfID}.lmfparams)*inVarMF{inputID}{mfID}.lmfscale;
    end
end

end
