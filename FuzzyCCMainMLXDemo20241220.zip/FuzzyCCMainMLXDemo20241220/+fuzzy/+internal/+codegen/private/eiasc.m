function soln = eiasc(x,umf,lmf)
%

% EIASC - Enhanced iterative algorithm with stopping condition.

%  Copyright 2019 The MathWorks, Inc.

%#codegen

[x,umf,lmf,n] = fuzzy.internal.codegen.putNonzeroUMFAtBeginning(x,umf,lmf);
soln = zeros(1,2,'like',x);
if n == 1
    soln(1) = x(1);
    soln(2) = x(1);
    return
end
a = zeros('like',x);
b = zeros('like',x);
for i = 1:n
    a(1) = a(1) + x(i)*lmf(i);
    b(1) = b(1) + lmf(i);
end
if b==0
    soln(1) = x(1);
    soln(2) = x(n);
    return
end

soln(1) = eiascleft(x,umf,lmf,n,a,b);
soln(2) = eiascright(x,umf,lmf,n,a,b);
end
%% Local functions --------------------------------------------------------
function soln = eiascleft(x,umf,lmf,n,a,b)
soln = zeros('like',x);
for L = 1:n-1
    a(1) = a(1) + x(L)*(umf(L)-lmf(L));
    b(1) = b(1) + (umf(L)-lmf(L));
    soln(1) = a*(1/b);
    if soln <= x(L+1)
        break
    end
end
end

function soln = eiascright(x,umf,lmf,n,a,b)
soln = zeros('like',x);
for R = n:-1:2
    a(1) = a(1) + x(R)*(umf(R)-lmf(R));
    b(1) = b(1) + (umf(R)-lmf(R));
    soln(1) = a*(1/b);
    if soln >= x(R-1)
        break
    end
end
end
