function outputMFCache = createSugenoOutputMFCacheType2(inputs,fis) %#codegen
%

% createSugenoOutputMFCacheType2 - Evaluates output MFs with the input values.
%
%     The evaluated values are used to generate rule outputs.

%   Copyright 2019 The MathWorks, Inc.

coder.internal.prefer_const(fis)

outputMFCache = zeros(sum(fis.numOutputMFs),1,'like',inputs);
outVarMF = extractVarMFType2(fis.outputMF);
isConstant = fuzzy.internal.codegen.generateConstantCode(fis);

for outputID = coder.unroll(1:fis.numOutputs,isConstant)
    numMFs = fis.numOutputMFs(outputID);
    for mfID = coder.unroll(1:numMFs,isConstant)
        outputMFCache(fis.numCumOutputMFs(outputID)+mfID) = ...
            fuzzy.internal.codegen.evaluateSugenoOutputMembershipFcn(...
            outVarMF{outputID}{mfID}.umftype,...
            inputs,outVarMF{outputID}{mfID}.umfparams);
    end
end

end