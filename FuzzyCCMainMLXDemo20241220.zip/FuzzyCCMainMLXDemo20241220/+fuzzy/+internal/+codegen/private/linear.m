function y = linear(x,params) %#codegen
%

% linear - Codegen version of LINEAR MF.

%   Copyright 2017 The MathWorks, Inc.

y = zeros('like',x);

for i = 1:length(x)
    y(1) = y + x(i)*params(i);
end

y(1) = y + params(length(x)+1);

end