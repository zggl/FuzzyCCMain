function y = som(x,membershipValueOfX) %#codegen
%

% som - Codegen version of SOM defuzzification method.

%   Copyright 2017-2022 The MathWorks, Inc. 

[maxMFValue,id] = max(membershipValueOfX);

refX = abs(x(id));
y = x(id);
for i=1:length(membershipValueOfX)
    if membershipValueOfX(i) == maxMFValue
        if abs(x(i)) < refX
            refX = abs(x(i));
            y = x(i);
        end
    end
end

end