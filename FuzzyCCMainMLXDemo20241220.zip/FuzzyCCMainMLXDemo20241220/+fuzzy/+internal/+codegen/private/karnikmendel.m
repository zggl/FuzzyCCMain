function soln = karnikmendel(x,umf,lmf)
%

% KM - Karnik-Mendel algorithm for type reduction.

%  Copyright 2019 The MathWorks, Inc.

%#codegen
[x,umf,lmf,n] = fuzzy.internal.codegen.putNonzeroUMFAtBeginning(x,umf,lmf);
soln = zeros(1,2,'like',x);
if n == 1
    soln(1) = x(1);
    soln(2) = x(1);
    return
end

sumLMF = zeros('like',x);
for i = 1:n
    sumLMF(1) = sumLMF + lmf(i);
end
if sumLMF==0
    soln(1) = x(1);
    soln(2) = x(n);
    return
end
mf = (umf+lmf)*(ones('like',x)/cast(2,'like',x));
soln(1) = localkmleft(x,umf,lmf,mf,n);
soln(2) = localkmright(x,umf,lmf,mf,n);
end
%% Local functions --------------------------------------------------------
function soln = localkmleft(x,umf,lmf,mf,n)

soln = centroid(x,mf,n);
refVal = soln+ones('like',x);
id = int32(0);
while soln~=refVal
    for k = 1:n-1
        id(1) = k;
        if soln>=x(k) && soln<=x(k+1)
            break
        end
    end
    refVal(1) = soln;
    if id>=1
        for i = 1:id
            mf(i) = umf(i);
        end
    end
    for i = id+1:n
        mf(i) = lmf(i);
    end
    soln(1) = centroid(x,mf,n);
    if soln>refVal
       soln(1) = refVal;
       break
    end
end
end

function soln = localkmright(x,umf,lmf,mf,n)

soln = centroid(x,mf,n);
refVal = soln+ones('like',x);
id = int32(0);
while soln~=refVal
    for k = 1:n-1
        id(1) = k;
        if soln>=x(k) && soln<=x(k+1)
            break
        end
    end
    refVal(1) = soln;

    if id>=1
        for i = 1:id
            mf(i) = lmf(i);
        end
    end
    for i = id+1:n
        mf(i) = umf(i);
    end
    
    soln(1) = centroid(x,mf,n);
    if soln<refVal
       soln(1) = refVal;
       break
    end
    
end
end