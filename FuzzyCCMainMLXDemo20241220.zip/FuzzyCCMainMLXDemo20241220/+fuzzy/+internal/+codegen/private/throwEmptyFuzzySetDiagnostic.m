function throwEmptyFuzzySetDiagnostic(id,x,defuzzMethod,value,diagnostic) %#codegen
%

% throwEmptyFuzzySetDiagnostic - Throws warning in case of a fuzzy set
% having zero membership value.

% Copyright 2017-2019 The MathWorks, Inc.

if coder.target('MEX') || coder.target('MATLAB')
    
    if (isequal(defuzzMethod,uint8('centroid')) || ...
            isequal(defuzzMethod,uint8('bisector'))) && sum(x) == 0
        if diagnostic.EmptyOutputFuzzySet == 2 % warning
            feval('fuzzy.internal.utility.throwWarning',diagnostic, ...
                'warnEvalfis_ZeroMembershipValue', ...
                char(defuzzMethod),id,sprintf('%g',value));
        elseif diagnostic.EmptyOutputFuzzySet == 3 % error
            feval('fuzzy.internal.utility.throwError',diagnostic, ...
                'errEvalfis_ZeroMembershipValue', ...
                char(defuzzMethod),id);
        end
    end
    
end

end