function outputMFCache = createMamdaniOutputMFCache(fis,outputSamplePoints) %#codegen
%

% createMamdaniOutputMFCache - Evaluates output sample points with the
% corresponding output MFs.
%
%     The evaluated fuzzified values are used to generate rule outputs.

%   Copyright 2017-2018 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(outputSamplePoints)

outputMFCache = coder.nullcopy(zeros(sum(fis.numOutputMFs),fis.numSamples,...
    'like',outputSamplePoints));
outVarMF = extractVarMF(fis.outputMF);
isConstant = fuzzy.internal.codegen.generateConstantCode(fis);

for outputID = coder.unroll(1:fis.numOutputs,isConstant)
    numMFs = fis.numOutputMFs(outputID);
    for mfID = coder.unroll(1:numMFs,isConstant)
        outputMFCache(fis.numCumOutputMFs(outputID)+mfID,:) = ...
            fuzzy.internal.codegen.evaluateCommonMembershipFcn(...
            outVarMF{outputID}{mfID}.type,...
            outputSamplePoints(outputID,:),...
            outVarMF{outputID}{mfID}.params);
    end
end

end