function y = bisector(x,membershipValueOfX) %#codegen
%

% bisector - Codegen version of BISECTOR defuzzification method.

%   Copyright 2017 The MathWorks, Inc. 

y = zeros('like',x);
area = cast(sum(membershipValueOfX),'like',x);

if area == 0
    y(1) = mean([x(1);x(end)]);
else
    halfArea = cast(area/2,'like',x);
    halfAreaID = 1;
    area(1) = 0;
    for i = 1:length(x)
        area(1) = area + membershipValueOfX(i);
        if area >= halfArea
            halfAreaID = i;
            break;
        end
    end
    y(1) = x(halfAreaID);
end

end