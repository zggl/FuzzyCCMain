function y = constant(x,params) %#codegen
%

% constant - Codegen version of CONSTANT MF.

%   Copyright 2017 The MathWorks, Inc.

y = cast(params(1),'like',x);

end