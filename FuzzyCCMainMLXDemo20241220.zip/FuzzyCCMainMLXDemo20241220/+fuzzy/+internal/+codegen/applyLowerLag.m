function [params,lag] = applyLowerLag(type,uparams,lag,isDefaultLag)
%

%

%  Copyright 2019-2021 The MathWorks, Inc.

%#codegen

params = uparams;
switch(deblank(char(type)))
    case 'trimf'
        d = diff(uparams);
        params = [uparams(2)-d(1)*(1-lag(1)) ...
            uparams(2) uparams(2)+d(2)*(1-lag(2))];
    case "trapmf"
        d = diff(uparams);
        rightShift = d(1)*lag(1);
        leftShift = d(3)*lag(2);
        
        params = [uparams(1)+rightShift ...
            uparams(2)+rightShift uparams(3)-leftShift ...
            uparams(4)-leftShift];
    case "gaussmf"
        params(1) = updateSigma(uparams,lag(1));
    case "gbellmf"
        if lag(1)==0
            return
        end
        yp = [lag(1) 0.01];
        
        f = @(a,b,c,y)(c+abs(a)*(1/y-1)^(1/(2*b)));
        g = @(b,c,x,y)abs(x-c)/((1/y-1)^(1/(2*b)));
        
        xp = f(uparams(1),uparams(2),uparams(3),yp(1));
        params(1) = g(uparams(2),uparams(3),xp,yp(2));
    case "sigmf"
        params(2) = updateSigmoidMean(uparams,lag(1));
    case "smf"
        if uparams(2) > uparams(1)
            d = diff(params);
            params(1) = uparams(1)+d(1)*lag(1);
            params(2) = uparams(2)+d(1)*lag(1);
        end
    case "linsmf"
        if uparams(2) > uparams(1)
            d = diff(params);
            params(1) = uparams(1)+d(1)*lag(1);
            params(2) = uparams(2)+d(1)*lag(1);
        end
    case "zmf"
        if uparams(2) > uparams(1)
            d = diff(params);
            params(1) = uparams(1)-d(1)*lag(1);
            params(2) = uparams(2)-d(1)*lag(1);
        end
    case "linzmf"
        if uparams(2) > uparams(1)
            d = diff(params);
            params(1) = uparams(1)-d(1)*lag(1);
            params(2) = uparams(2)-d(1)*lag(1);
        end
    case "gauss2mf"
        params(1) = updateSigma(uparams(1:2),lag(1));
        params(3) = updateSigma(uparams(3:4),lag(2));
    case "pimf"
        d = diff(params);
        if uparams(2) > uparams(1)
            params(1) = uparams(1)+d(1)*lag(1);
            params(2) = uparams(2)+d(1)*lag(1);
        end
        if uparams(4) > uparams(3)
            params(3) = uparams(3)-d(3)*lag(2);
            params(4) = uparams(4)-d(3)*lag(2);
        end
    case "psigmf"
        params(2) = updateSigmoidMean(uparams(1:2),lag(1));
        params(4) = updateSigmoidMean(uparams(3:4),lag(2));
    case "dsigmf"
        params(2) = updateSigmoidMean(uparams(1:2),lag(1));
        params(4) = updateSigmoidMean([-uparams(3) uparams(4)],lag(2));
        if params(2) > params(4)
            if ~isDefaultLag
                coder.internal.error('fuzzy:general:errFismftype2_lagProducedInvalidDsigmf')
            end
            val = mean(params([2 4]));
            lag(:) = calculateLowerLag(uparams,[params(1) val params(3) val]);
            params(2) = updateSigmoidMean(uparams(1:2),lag(1));
            params(4) = updateSigmoidMean([-uparams(3) uparams(4)],lag(2));            
        end
    otherwise
        if ~all(lag==0)
            coder.internal.error('fuzzy:general:errFismftype2_noLagForCustomMF')
        end
end


end
%% Helper functions -------------------------------------------------------
function s = updateSigma(params,lag)
if lag==0
    s = params(1);
    return
end

p = params./params(1);

del = 0.01;

xp = p(2) + delXGauss(lag);
s = params(1)*sGauss(p(2),xp,del);
end

function dx = delXGauss(y)
dx = sqrt(log(1/y^2));
end

function s = sGauss(m,x,y)
s = (x-m)/sqrt(log(1/y^2));
end

function c = updateSigmoidMean(p,lag)
if lag == 0
    c = p(2);
    return
end
del = 0.01;
if p(1) <0
    yp = [0.99 1-lag];
else
    yp = [lag del];
end

xp = p(2) + delxSigmf(p(1),yp(1));
c = xp - delxSigmf(p(1),yp(2));

end
function lag = calculateLowerLag(uparams,lparams)

% Step 1: Get (x,y) of the lower MF at the minimum and maximum
% postive membership values.
[x,yL] = getMinMaxXY(lparams,0.01);

% Step 3: Get the membership values of the upper MF at x
% obtained in step 1.
yU = dsigmf(x,uparams);

% Step3: Approximate lag values.
lag = yU(1:2)-yL(1:2);
end

function [x,y] = getMinMaxXY(params,val)
x = zeros(1,2);
x(1) = params(2) + delxSigmf(params(1),val);
x(2) = params(4) + delxSigmf(params(3),1-val);
y = dsigmf(x,params);       
end

function dx = delxSigmf(a,y)
dx = (1/a)*log(y/(1-y));
end