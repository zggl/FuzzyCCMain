function y = pimf(x,params) %#codegen
%%

%   Copyright 2022 The MathWorks, Inc.

y = cast(fuzzy.internal.codegen.smf(...
    x, params(1:2)).*fuzzy.internal.codegen.zmf(x, params(3:4)),'like',x);

end