function y = smf(x, params) %#codegen
%

% smf - Codegen version of smf.

%   Copyright 2017 The MathWorks, Inc.

x0 = cast(params(1),'like',x);
x1 = cast(params(2),'like',x);

if x0 >= x1
    y = cast(x>=(x0+x1)/2,'like',x);
    return;
end

y = zeros(size(x),'like',x);
value = zeros('like',x);
for i = 1:numel(x)
    
    % Skipping y(x<=x0) = 0, since y is already initialized to zero.
    
    if (x0 < x(i)) && (x(i) <= (x0+x1)/2)
        value(1) = (x(i)-x0)*(1/(x1-x0));
        y(i) = 2*value*value;
    end
    
    if ((x0+x1)/2 < x(i)) && (x(i) <= x1)
        value(1) = (x1-x(i))*(1/(x1-x0));
        y(i) = ones('like',x) - 2*value*value;
    end
    
    if x1 <= x(i)
        y(i) = 1;
    end
end

end