function [antecedentOutputs,sumAntecedentOutputs,irrOfOneRule] = ...
    applyOperators(fuzzifiedInputs,fis,varargin) %#codegen
%

% applyOperators - Generates antecedent outputs.

%   Copyright 2017-2023 The MathWorks, Inc.

coder.internal.prefer_const(fis)

if isempty(varargin) || length(varargin)<2
    antecedentOutputs = zeros(fis.numRules,1,'like',fuzzifiedInputs);
    irrOfOneRule = zeros(fis.numInputs,1,'like',fuzzifiedInputs);
else
    antecedentOutputs = varargin{1};
    irrOfOneRule = varargin{2};
end
sumAntecedentOutputs = zeros('like',fuzzifiedInputs);

for ruleID = 1:fis.numRules
    for inputID = 1:fis.numInputs
        irrOfOneRule(inputID) = fuzzifiedInputs(ruleID,inputID);
    end
    
    if fis.connection(ruleID) == 1        
        antecedentOutputs(ruleID) = fuzzy.internal.codegen.evaluateAndMethod(...
            fis.andMethod,irrOfOneRule);
    else
        antecedentOutputs(ruleID) = fuzzy.internal.codegen.evaluateOrMethod(...
            fis.orMethod,irrOfOneRule);
    end
    
    antecedentOutputs(ruleID) = antecedentOutputs(ruleID)*fis.weight(ruleID);
    sumAntecedentOutputs(1) = sumAntecedentOutputs + antecedentOutputs(ruleID);
end

end