function [y,irr,orr,arr,rfs] = evaluateType2FIS(inputs,fis,diagnostics) %#codegen
%

% evaluateFIS - Codegen version of EVALFIS used for MEX generation. 
%
%     FIS is a homogenous structure. See fuzzy.internal.utility.packageData
%     for further detail.
%
%     DIAGNOSTICS provides user specified levels for showing diagnostics.
%     See fuzzy.internal.utility.createDiagnosticLevels for further detail.
%
%     The outputs are similar to EVALFIS outputs.
%
% See also EVALFIS, EVALFISOPTIONS.

%  Copyright 2019-2023 The MathWorks, Inc.

%% Expected constant input arguments
coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostics)

%% Evaluate FIS
% To avoid method selection in each loop at run-time, we need 1152 number
% of switch statements (see below).
%
%     N = NumAndMethod(3) x 
%         NumOrMethod(4) x 
%         NumImpMethod(3) x 
%         NumAggMethod(4) x 
%         NumDefuzzMethod(8)
%       = 1152
%
% The implementation will be error prone and difficult to maintain. The
% generated code will also include N number copies of runFIS function.
% Hence, using only defuzz method selection here since it has more options
% as compared to other methods.

% NOTE: Outputs 'rfs' and 'unImpSugRuleOut' are required for graphical
% representation of Sugeno FIS outputs in a RULEVIEWER. This is not a
% customer visible output argument in EVALFIS function.

coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if fuzzy.internal.codegen.generateConstantCode(fis)
    fh = str2func(char(fis.typeReductionMethod));    
    [y,irr,orr,arr,rfs] = runFIS(inputs,fis,diagnostics,true,fh,true);
else
    [~,hasTRMethod] = evaluateCustomTRMethod(fis.typeReductionMethod, ...
        ones('like',inputs),ones('like',inputs),ones('like',inputs));
    if hasTRMethod
        [y,irr,orr,arr,rfs] = ...
            runFIS(inputs,fis,diagnostics,true,@evaluateCustomTRMethod,false);
        return
    end
    
    if isequal(fis.typeReductionMethod,uint8('karnikmendel'))
        [y,irr,orr,arr,rfs] = ...
            runFIS(inputs,fis,diagnostics,true,@karnikmendel,true);
    elseif isequal(fis.typeReductionMethod,uint8('ekm'))
        [y,irr,orr,arr,rfs] = ...
            runFIS(inputs,fis,diagnostics,true,@ekm,true);
    elseif isequal(fis.typeReductionMethod,uint8('iasc'))
        [y,irr,orr,arr,rfs] = ...
            runFIS(inputs,fis,diagnostics,true,@iasc,true);
    elseif isequal(fis.typeReductionMethod,uint8('eiasc'))
        [y,irr,orr,arr,rfs] = ...
            runFIS(inputs,fis,diagnostics,true,@eiasc,true);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX
            [y,irr,orr,arr,rfs] = ...
                runFIS(inputs,fis,diagnostics,false,@feval,true);
        else
            [y,irr,orr,arr,rfs] = initVariables(fis,inputs);
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'type reduction',char(fis.typeReductionMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end
%% Helper functions -------------------------------------------------------
function [y,irr,orr,arr,w] = ...
    runFIS(inputs,fis,diagnostics,trIsBuiltin,trm,notCustomEval)

coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostics)
coder.internal.prefer_const(trIsBuiltin)
coder.internal.prefer_const(trm)

%% Output data declaration
[y,irr,orr,arr,w,outputMFCache,numInputDataSets] = ...
    initVariables(fis,inputs);
%% Pre-computed/allocated variables to speed-up MEX execution.
inVarMF = extractVarMFType2(fis.inputMF);
inputMFCache = zeros(2,sum(fis.numInputMFs),'like',inputs);
irrOfOneRule = zeros(fis.numInputs,2,'like',inputs);
%% Output data calculation
for i = 1:numInputDataSets
    
    x = inputs(i,:);
    [irr(:),inputMFCache(:)] = fuzzy.internal.codegen.fuzzifyInputsType2(...
        x,fis,diagnostics,inVarMF,inputMFCache,irr);
    [w(:),sw,irrOfOneRule(:)] = fuzzy.internal.codegen.applyOperatorsType2(...
        irr,fis,w,irrOfOneRule);
    if strcmp(char(fis.type),'mamdani')
        orr(:) = fuzzy.internal.codegen.applyMamdaniImplicationMethodType2(...
            w,fis,fis.outputSamplePoints,outputMFCache);
        arr(:) = fuzzy.internal.codegen.applyMamdaniAggregationMethodType2(orr,fis);
        y(i,:) = fuzzy.internal.codegen.applyMamdaniDefuzzificationMethodType2(...
            fis.outputSamplePoints,sw,arr,fis,diagnostics,trIsBuiltin,trm,notCustomEval)';
    else
        orr(:) = fuzzy.internal.codegen.applySugenoImplicationMethodType2(x,w,fis);
        arr(:) = fuzzy.internal.codegen.applySugenoAggregationMethodType2(orr,fis);
        y(i,:) = fuzzy.internal.codegen.applySugenoDefuzzificationMethodType2(sw,...
            arr,fis,diagnostics,trIsBuiltin,trm,notCustomEval)';
    end
    
end
end

function [y,irr,orr,arr,rfs,outputMFCache,numInputDataSets] = ...
    initVariables(fis,inputs)

coder.internal.prefer_const(fis)

numInputDataSets = size(inputs,1);
y = zeros(numInputDataSets,fis.numOutputs,'like',inputs);
irr = zeros(fis.irrSize,'like',inputs);
orr = zeros(fis.orrSize,'like',inputs);
arr = zeros(fis.aggSize,'like',inputs);
rfs = zeros(fis.rfsSize,'like',inputs);
if strcmp(char(fis.type),'mamdani')
    outputMFCache = createMamdaniOutputMFCacheType2(fis,fis.outputSamplePoints);
else
    outputMFCache = zeros(sum(fis.numOutputMFs),1,'like',inputs);
end
end
