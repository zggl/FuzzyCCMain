function n = numParamSmf
%% numParamSmf Returns number of parameter of smf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 2;
end