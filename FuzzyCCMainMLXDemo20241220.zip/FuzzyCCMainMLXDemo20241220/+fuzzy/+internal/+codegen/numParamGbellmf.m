function n = numParamGbellmf
%% numParamGbellmf Returns number of parameter of gbellmf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 3;
end