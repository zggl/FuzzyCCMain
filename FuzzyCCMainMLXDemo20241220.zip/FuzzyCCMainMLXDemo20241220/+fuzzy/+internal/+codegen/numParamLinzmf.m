function n = numParamLinzmf
%% numParamLinzmf Returns number of parameter of linzmf.

%  Copyright 2021 The MathWorks, Inc.

%#codegen

n = 2;
end