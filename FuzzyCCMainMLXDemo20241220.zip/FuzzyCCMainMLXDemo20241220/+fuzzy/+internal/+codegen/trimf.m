function y = trimf(x, params) %#codegen
%

% trimf - Codegen version of trimf.

%   Copyright 2017 The MathWorks, Inc.

a = cast(params(1),'like',x);
b = cast(params(2),'like',x);
c = cast(params(3),'like',x);

y = zeros(size(x),'like',x);

for i=1:numel(x)
    % Left slope
    if (a ~= b) && (a<x(i) && x(i)<b)
        y(i) = (x(i)-a)*(1/(b-a));
    end
    
    % right slope
    if (b ~= c) && (b<x(i) && x(i)<c)
        y(i) = (c-x(i))*(1/(c-b));
    end
    
    % Center (y = 1)
    if x(i) == b
        y(i) = 1;
    end
end

end