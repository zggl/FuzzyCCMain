function y = psigmf(x, params) %#codegen
%%

%   Copyright 2022 The MathWorks, Inc. 

y = fuzzy.internal.codegen.sigmf(...
    x, params(1:2)).*fuzzy.internal.codegen.sigmf(x, params(3:4));

end