function [fid,maxLineLength,newLine] = getFileID(name)
%

%

%  Copyright 2019 The MathWorks, Inc.

%#codegen

coder.extrinsic('fuzzy.internal.utility.convertToCharArrayIfInputIsString')
coder.extrinsic('fuzzy.internal.utility.validCharOrString')
coder.extrinsic('endsWith','which')
coder.extrinsic('sprintf')
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')
coder.internal.prefer_const(name)

if fuzzy.internal.codegen.generateConstantCode(name)
    
    fuzzy.internal.utility.validCharOrString('File name', name);
    fileName = coder.const(fuzzy.internal.utility.convertToCharArrayIfInputIsString(name));
    
    extension = '.fis';
    hasExtension = coder.const(endsWith(fileName,extension));
    if hasExtension
        fileNameWithExtension = fileName;
    else
        fileNameWithExtension = [fileName extension];
    end
    
    if isempty(coder.const(which(fileNameWithExtension)))
        fileNameWithPath = fileNameWithExtension;
    else
        fileNameWithPath = coder.const(which(fileNameWithExtension));
    end
    
    fid = fopen(fileNameWithPath,'r');
    coder.internal.errorIf(fid<0,'fuzzy:general:errFileIO_CanNotOpen',fileNameWithExtension)
else
    fid = fopen(char(name),'r');
    if fid < 0
        if fuzzy.internal.codegen.isTargetMATLABOrMEX
            coder.internal.error(...
                'fuzzy:general:errFileIO_CanNotOpen',char(name))
        else
            if fuzzy.internal.codegen.isRuntimeCheckOn
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Readfis_CanNotOpenFIS'));
                fprintf(format,char(name));
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

newLine = coder.const(cast(sprintf('\n'),'uint8')); %#ok<SPRINTFN>
maxLineLength = getMaxLineLength(fid,newLine);
if maxLineLength == 0
    fclose(fid);
    if fuzzy.internal.codegen.isTargetMATLABOrMEX
        coder.internal.error(...
            'fuzzy:general:errCodegen_Readfis_EmptyContents',char(name))
    else
        if fuzzy.internal.codegen.isRuntimeCheckOn
            format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                'fuzzy:general:errCodegen_Readfis_EmptyContents_Format'));
            fprintf(format,char(name));
        end
        fuzzy.internal.codegen.runtimeExit
    end
end
frewind(fid);

end
%% Helper functions -------------------------------------------------------
function maxLength = getMaxLineLength(fid,newLine)
contents = cast(fread(fid),'uint8');
maxLength = 0;
lastIndex = 1;
for i=1:numel(contents)
    if contents(i) == newLine
        if (i-lastIndex)>maxLength
            maxLength = (i-lastIndex);
            lastIndex = i;
        end
    end
end
end