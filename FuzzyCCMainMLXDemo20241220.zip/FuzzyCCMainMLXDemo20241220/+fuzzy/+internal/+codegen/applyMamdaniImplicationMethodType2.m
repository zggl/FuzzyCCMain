function consequentOutputs = applyMamdaniImplicationMethodType2(...
    antecedentOutputs,fis,outputSamplePoints,varargin) %#codegen
%

% applyMamdaniImplicationMethodType2 - Generates rule outputs from
% antecedent outputs using 'mamdani' implication methods.

%   Copyright 2019-2023 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(outputSamplePoints)
coder.internal.prefer_const(varargin{:})
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if isempty(varargin)
    outputMFCache = createMamdaniOutputMFCacheType2(fis,outputSamplePoints);
else
    outputMFCache = varargin{1};
end

if fuzzy.internal.codegen.generateConstantCode(fis.impMethod)
    fh = str2func(char(fis.impMethod));
    consequentOutputs = applyImplication(true,fh,antecedentOutputs,fis, ...
        outputMFCache,true);
else

    [~,hasImpMethod] = evaluateCustomImpMethod(fis.impMethod,zeros('like',antecedentOutputs));
    if hasImpMethod
        consequentOutputs = applyImplication(true,@evaluateCustomImpMethod, ...
            antecedentOutputs,fis,outputMFCache,false);
       return
    end
        
    if isequal(fis.impMethod,uint8('min'))
        consequentOutputs = applyImplication(true,@min,antecedentOutputs, ...
            fis,outputMFCache,true);
    elseif isequal(fis.impMethod,uint8('prod'))
        consequentOutputs = applyImplication(true,@prod,antecedentOutputs, ...
            fis,outputMFCache,true);
    else
        if fuzzy.internal.codegen.isTargetMATLABOrMEX
            consequentOutputs = applyImplication(false,@feval,antecedentOutputs, ...
                fis,outputMFCache,true);
        else
            consequentOutputs = zeros(fis.orrSize,'like',antecedentOutputs);
            if coder.internal.hasRuntimeErrors()
                format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                    'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                fprintf(format,'implication',char(fis.impMethod)); %#ok<CTPCT>
            end
            fuzzy.internal.codegen.runtimeExit
        end
    end
end

end
%% Helper functions -------------------------------------------------------
function consequentOutputs = applyImplication(isConstOrBuiltin,fh, ...
    antecedentOutputs,fis,outputMFCache,notCustomEval)

consequentOutputs = zeros(fis.orrSize,'like',antecedentOutputs);
mfIndex = zeros('like',fis.numCumOutputMFs);

for outputID = 1:fis.numOutputs
    indexOffset1 = (outputID-1)*fis.numRules;
    indexOffset2 = fis.numRules*fis.numOutputs+(outputID-1)*fis.numRules;
    for ruleID = 1:fis.numRules
        mfIndex(1) = abs(fis.consequent(ruleID,outputID));
        ruleOutputIndex1 = indexOffset1+ruleID;
        ruleOutputIndex2 = indexOffset2+ruleID;
        
        % The jth rule has no effect in ith output calculation if MF index
        % is zero.
        if mfIndex == 0
            consequentOutputs(:,ruleOutputIndex1) = 0;
            consequentOutputs(:,ruleOutputIndex2) = 0;
            continue;
        end
        
        for sampleID=1:fis.numSamples
            % Determine output membership values at the sample point.
            if fis.consequent(ruleID,outputID)>=0
                % Use cache value as it's for positive index.
                consequentOutputs(sampleID,ruleOutputIndex1) = ...
                    outputMFCache(abs(fis.numCumOutputMFs(outputID))+...
                    mfIndex,sampleID);
                consequentOutputs(sampleID,ruleOutputIndex2) = ...
                    outputMFCache(abs(fis.numCumOutputMFs(outputID))+...
                    mfIndex,fis.numSamples+sampleID);
            else
                % If the membership function index is negative (NOT logic),
                % switch the cache value and take its complement.
                consequentOutputs(sampleID,ruleOutputIndex1) = max([0;...
                    (ones('like',antecedentOutputs) - ...
                    outputMFCache(abs(fis.numCumOutputMFs(outputID))+...
                    mfIndex,fis.numSamples+sampleID))]);
                consequentOutputs(sampleID,ruleOutputIndex2) = max([0;...
                    (ones('like',antecedentOutputs) - ...
                    outputMFCache(abs(fis.numCumOutputMFs(outputID))+...
                    mfIndex,sampleID))]);            
            end
            
            if isConstOrBuiltin
                if notCustomEval
                    consequentOutputs(sampleID,ruleOutputIndex1) = fh(...
                        [consequentOutputs(sampleID,ruleOutputIndex1);...
                        antecedentOutputs(ruleID,1)]);
                    consequentOutputs(sampleID,ruleOutputIndex2) = fh(...
                        [consequentOutputs(sampleID,ruleOutputIndex2);...
                        antecedentOutputs(ruleID,2)]);
                else
                    consequentOutputs(sampleID,ruleOutputIndex1) = fh(...
                        fis.impMethod, ...
                        [consequentOutputs(sampleID,ruleOutputIndex1);...
                        antecedentOutputs(ruleID,1)]);                
                    consequentOutputs(sampleID,ruleOutputIndex2) = fh(...
                        fis.impMethod, ...
                        [consequentOutputs(sampleID,ruleOutputIndex2);...
                        antecedentOutputs(ruleID,2)]);                
                end
            end
        end
        
        if ~isConstOrBuiltin
            consequentOutputs(:,ruleOutputIndex1) = fh(...
                char(fis.impMethod), ...
                consequentOutputs(:,ruleOutputIndex1), ...
                repmat(antecedentOutputs(ruleID,1),fis.numSamples,1) ...
                );
            consequentOutputs(:,ruleOutputIndex2) = fh(...
                char(fis.impMethod), ...
                consequentOutputs(:,ruleOutputIndex2), ...
                repmat(antecedentOutputs(ruleID,2),fis.numSamples,1) ...
                );
        end
    end
end
end