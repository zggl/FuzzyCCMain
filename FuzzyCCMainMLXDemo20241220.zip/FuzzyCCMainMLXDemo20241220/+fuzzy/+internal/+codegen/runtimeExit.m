function runtimeExit
%RUNTIMEEXIT Exits at run-time

%  Copyright 2018, The MathWorks, Inc.

%#codegen

coder.ceval('exit',int32(0));
end