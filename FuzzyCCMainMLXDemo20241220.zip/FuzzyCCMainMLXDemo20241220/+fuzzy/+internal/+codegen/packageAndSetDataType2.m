function fis = packageAndSetDataType2(fis,numSamplePoints,dataType)
%

%PACKAGEANDSETDATATYPE2 Packages type-2 FIS data and sets numeric data types.
%
%  FISOUT = PACKAGEANDSETDATATYPE2(FISIN,NUMSAMPLEPOINTS,DATATYPE) Creates
%  FISOUT from FISIN for code generation. It uses NUMSAMPLEPOINTS to
%  precalculate output membersship values at the output sample points. The
%  numeric data type is set to DATATYPE.

%  Copyright 2019 The MathWorks, Inc.

%#codegen

coder.internal.prefer_const(fis)
coder.internal.prefer_const(numSamplePoints)
coder.internal.prefer_const(dataType)

fis = packageData(fis,numSamplePoints);
fis = setDataType(fis,dataType);

end
%% Helper functions -------------------------------------------------------
function fisout = packageData(fisin,numSamples)

coder.internal.prefer_const(fisin)
coder.internal.prefer_const(numSamples)


fisout.type = fisin.type;
fisout.andMethod = fisin.andMethod;
fisout.orMethod = fisin.orMethod;
fisout.defuzzMethod = fisin.defuzzMethod;
fisout.impMethod = fisin.impMethod;
fisout.aggMethod = fisin.aggMethod;
fisout.typeReductionMethod = fisin.typeReductionMethod;

fisout.inputMF = makeHomogenousMF(fisin.input);
fisout.outputMF = makeHomogenousMF(fisin.output);

fisout.inputRange = createRangeMatrix(fisin.input);
fisout.outputRange = createRangeMatrix(fisin.output);

numInputs = length(fisin.input);
numOutputs = length(fisin.output);
numRules = length(fisin.rule);
numInputMFs = createMFVector(fisin.input);
numOutputMFs = createMFVector(fisin.output);

fisout.antecedent = createAntecedentMatrix(fisin.rule,numInputs);
fisout.consequent = createConsequentMatrix(fisin.rule,numOutputs);
fisout.connection = createConnectionVector(fisin.rule);
fisout.weight = createWeightVector(fisin.rule);

fisout.numSamples = numSamples;
fisout.numInputs = numInputs;
fisout.numOutputs = numOutputs;
fisout.numRules = numRules;

fisout.numInputMFs = numInputMFs;
fisout.numCumInputMFs = cumsum(numInputMFs) - numInputMFs;

fisout.numOutputMFs = numOutputMFs;
fisout.numCumOutputMFs = cumsum(numOutputMFs) - numOutputMFs;

fisout.outputSamplePoints = createOutputSamplePoints(fisin,numSamples);

if strcmp(fisin.type,'mamdani')
    fisout.orrSize = [numSamples 2*numRules*numOutputs];
    fisout.aggSize = [numSamples 2*numOutputs];
else
    fisout.orrSize = [numRules 3*numOutputs];
    fisout.aggSize = [numRules 3*numOutputs];
end
fisout.irrSize = [numRules 2*numInputs];
fisout.rfsSize = [numRules 2];
fisout.sumSize = [1 2];
fisout.inputFuzzySetType = 2;

end

function fisout = setDataType(fisin,dataType)

coder.internal.prefer_const(fisin)
coder.internal.prefer_const(dataType)

fisout.type = uint8(fisin.type);
fisout.andMethod = uint8(fisin.andMethod);
fisout.orMethod = uint8(fisin.orMethod);
fisout.defuzzMethod = uint8(fisin.defuzzMethod);
fisout.impMethod = uint8(fisin.impMethod);
fisout.aggMethod = uint8(fisin.aggMethod);
fisout.typeReductionMethod = uint8(fisin.typeReductionMethod);

fisout.inputRange = cast(fisin.inputRange,dataType);
fisout.outputRange = cast(fisin.outputRange,dataType);
fisout.inputMF = setMFDataType(fisin.inputMF,dataType);
fisout.outputMF = setMFDataType(fisin.outputMF,dataType);

fisout.antecedent = cast(fisin.antecedent,dataType);
fisout.consequent = cast(fisin.consequent,dataType);
fisout.connection = cast(fisin.connection,dataType);
fisout.weight = cast(fisin.weight,dataType);

fisout.numSamples = int32(fisin.numSamples);
fisout.numInputs = int32(fisin.numInputs);
fisout.numOutputs = int32(fisin.numOutputs);
fisout.numRules = int32(fisin.numRules);
fisout.numInputMFs = int32(fisin.numInputMFs);
fisout.numCumInputMFs = int32(fisin.numCumInputMFs);
fisout.numOutputMFs = int32(fisin.numOutputMFs);
fisout.numCumOutputMFs = int32(fisin.numCumOutputMFs);

fisout.outputSamplePoints = cast(fisin.outputSamplePoints,dataType);

fisout.orrSize = int32(fisin.orrSize);
fisout.aggSize = int32(fisin.aggSize);
fisout.irrSize = int32(fisin.irrSize);
fisout.rfsSize = int32(fisin.rfsSize);
fisout.sumSize = int32(fisin.sumSize);
fisout.inputFuzzySetType = int32(fisin.inputFuzzySetType);

end

function out = setMFDataType(in,dataType)

numVar = length(in);
numMF = length(in(1).mf);
umfTypeLength = length(in(1).mf(1).umftype);
umfParamLength = length(in(1).mf(1).umfparams);
lmfTypeLength = length(in(1).mf(1).lmftype);
lmfParamLength = length(in(1).mf(1).lmfparams);

mfStruct = struct(...
    'umftype',char(zeros(1,umfTypeLength)),...
    'origUMFTypeLength',int32(0), ...
    'umfparams',cast(zeros(1,umfParamLength),dataType),...
    'origUMFParamLength',int32(0), ...
    'lmftype',char(zeros(1,lmfTypeLength)),...
    'origLMFTypeLength',int32(0), ...
    'lmfparams',cast(zeros(1,lmfParamLength),dataType),...
    'origLMFParamLength',int32(0), ...
    'lmfscale',cast(1,dataType), ...
    'lmflag',cast([0 0],dataType) ...
    );

varStruct = struct(...
    'mf',repmat(mfStruct,1,numMF),...
    'origNumMF',int32(0) ...
    );

out = repmat(varStruct,1,numVar);

for varID=1:numVar
    out(varID).origNumMF(1) = in(varID).origNumMF;
    for mfID = 1:numMF
        out(varID).mf(mfID).umftype(:) = in(varID).mf(mfID).umftype;
        out(varID).mf(mfID).umfparams(:) = in(varID).mf(mfID).umfparams;
        out(varID).mf(mfID).origUMFTypeLength(1) = in(varID).mf(mfID).origUMFTypeLength;
        out(varID).mf(mfID).origUMFParamLength(1) = in(varID).mf(mfID).origUMFParamLength;
        out(varID).mf(mfID).lmftype(:) = in(varID).mf(mfID).lmftype;
        out(varID).mf(mfID).lmfparams(:) = in(varID).mf(mfID).lmfparams;
        out(varID).mf(mfID).origLMFTypeLength(1) = in(varID).mf(mfID).origLMFTypeLength;
        out(varID).mf(mfID).origLMFParamLength(1) = in(varID).mf(mfID).origLMFParamLength;
        out(varID).mf(mfID).lmfscale(1) = in(varID).mf(mfID).lmfscale;
        out(varID).mf(mfID).lmflag(:) = in(varID).mf(mfID).lmflag;
    end
end

end

function range = createRangeMatrix(var)

numVar = length(var);
range = zeros(numVar,2);

for varID = 1:length(var)
    range(varID,:) = var(varID).range;
end

end

function output = createMFVector(var)

numVar = length(var);
output = zeros(1,numVar);

for id = 1:numVar
    output(id) = var(id).origNumMF;
end

end

function antecedent = createAntecedentMatrix(rule,numInputs)

numRules = length(rule);
antecedent = zeros(numRules,numInputs);

for ruleID = 1:length(rule)
    antecedent(ruleID,:) = rule(ruleID).antecedent;
end

end

function consequent = createConsequentMatrix(rule,numOutputs)

numRules = length(rule);
consequent = zeros(numRules,numOutputs);

for ruleID = 1:length(rule)
    consequent(ruleID,:) = rule(ruleID).consequent;
end

end

function connection = createConnectionVector(rule)

numRules = length(rule);
connection = zeros(1,numRules);

for ruleID = 1:length(rule)
    connection(ruleID) = rule(ruleID).connection;
end

end

function weight = createWeightVector(rule)

numRules = length(rule);
weight = zeros(1,numRules);

for ruleID = 1:length(rule)
    weight(ruleID) = rule(ruleID).weight;
end

end

function out = makeHomogenousMF(in)

mfStruct = struct(...
    'umftype',char(zeros(1,1)),...
    'origUMFTypeLength',0, ...
    'umfparams',0,...
    'origUMFParamLength',0, ...
    'lmftype',char(zeros(1,1)),...
    'origLMFTypeLength',0, ...
    'lmfparams',0,...
    'origLMFParamLength',0, ...
    'lmfscale',1, ...
    'lmflag',[0.2 0.2]...
    );
coder.varsize('mfStruct.umftype',[1 Inf],[false true]);
coder.varsize('mfStruct.umfparams',[1 Inf],[false true]);
coder.varsize('mfStruct.lmftype',[1 Inf],[false true]);
coder.varsize('mfStruct.lmfparams',[1 Inf],[false true]);

varStruct = struct(...
    'mf',mfStruct,...
    'origNumMF',0 ...
    );
coder.varsize('varStruct.mf',[1 Inf],[false true]);

numVar = length(in);
out = repmat(varStruct,1,numVar);

maxNumMF = 0;
maxUMFTypeLength = 0;
maxUMFParamLength = 0;
maxLMFTypeLength = 0;
maxLMFParamLength = 0;
for varID = 1:length(in)
    var = in(varID);
    numMF = var.origNumMF;
    if maxNumMF < numMF
        maxNumMF(1) = numMF;
    end
    for mfID = 1:numMF
        mf = var.mf(mfID);
        % For codegen, it is assumed that MF type is a CHAR vector.
        typeLength = mf.origUMFTypeLength;
        if maxUMFTypeLength < typeLength
            maxUMFTypeLength(1) = typeLength;
        end
        paramLength = mf.origUMFParamLength;
        if maxUMFParamLength < paramLength
            maxUMFParamLength(1) = paramLength;
        end
        typeLength = mf.origLMFTypeLength;
        if maxLMFTypeLength < typeLength
            maxLMFTypeLength(1) = typeLength;
        end
        paramLength = mf.origLMFParamLength;
        if maxLMFParamLength < paramLength
            maxLMFParamLength(1) = paramLength;
        end
    end
end

for varID=1:numVar
    out(varID).origNumMF(1) = in(varID).origNumMF;
    out(varID).mf = repmat(mfStruct,1,maxNumMF);    
    for mfID = 1:maxNumMF
        out(varID).mf(mfID).umftype = char(zeros(1,maxUMFTypeLength));
        out(varID).mf(mfID).umfparams = zeros(1,maxUMFParamLength);
        out(varID).mf(mfID).origUMFTypeLength = 0;
        out(varID).mf(mfID).origUMFParamLength = 0;
        out(varID).mf(mfID).lmftype = char(zeros(1,maxLMFTypeLength));
        out(varID).mf(mfID).lmfparams = zeros(1,maxLMFParamLength);
        out(varID).mf(mfID).origLMFTypeLength = 0;
        out(varID).mf(mfID).origLMFParamLength = 0;
        
        if mfID <= out(varID).origNumMF
            % For codegen, it is assumed that MF type is a CHAR vector.
            out(varID).mf(mfID).umftype(:) = in(varID).mf(mfID).umftype;
            out(varID).mf(mfID).origUMFTypeLength = in(varID).mf(mfID).origUMFTypeLength;

            out(varID).mf(mfID).umfparams(:) = in(varID).mf(mfID).umfparams;
            out(varID).mf(mfID).origUMFParamLength = in(varID).mf(mfID).origUMFParamLength;
            
            out(varID).mf(mfID).lmftype(:) = in(varID).mf(mfID).lmftype;
            out(varID).mf(mfID).origLMFTypeLength = in(varID).mf(mfID).origLMFTypeLength;

            out(varID).mf(mfID).lmfparams(:) = in(varID).mf(mfID).lmfparams;
            out(varID).mf(mfID).origLMFParamLength = in(varID).mf(mfID).origLMFParamLength;
            
            out(varID).mf(mfID).lmfscale(1) = in(varID).mf(mfID).lmfscale;
            out(varID).mf(mfID).lmflag(:) = in(varID).mf(mfID).lmflag;
        end
    end
end

end

function outputSamplePoints = createOutputSamplePoints(fis,numSamples)

coder.internal.prefer_const(fis)
coder.internal.prefer_const(numSamples)


if strcmp(fis.type,'mamdani')
    outputSamplePoints = zeros(length(fis.output),numSamples);
    for outputID = 1:length(fis.output)
        range = fis.output(outputID).range;
        outputSamplePoints(outputID,:) = linspace(range(1),range(2),numSamples);
    end
else
    outputSamplePoints = 0;
end

end