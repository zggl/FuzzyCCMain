function defuzzifiedOutputs = applyMamdaniDefuzzificationMethod(...
    outputSamplePoints,sumAntecedentOutputs,aggregatedOutputs,fis, ...
    diagnostic,varargin) %#codegen
%

% applyMamdaniDefuzzificationMethod - Defuzzifies aggreagted outputs using
% 'mamdani' defuzzification methods.

%   Copyright 2017-2022 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(outputSamplePoints)
coder.internal.prefer_const(diagnostic)
coder.internal.prefer_const(varargin{:})
coder.extrinsic('fuzzy.internal.utility.getEnglishMessage')

if fuzzy.internal.codegen.generateConstantCode(fis.defuzzMethod)
    fh = str2func(char(fis.defuzzMethod));
    
    defuzzifiedOutputs = defuzzifyOutput(true,fh,outputSamplePoints, ...
        sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
else
    if isempty(varargin) || length(varargin)<3
        if isequal(fis.defuzzMethod,uint8('centroid'))
            defuzzifiedOutputs = defuzzifyOutput(true,@centroid,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        elseif isequal(fis.defuzzMethod,uint8('bisector'))
            defuzzifiedOutputs = defuzzifyOutput(true,@bisector,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        elseif isequal(fis.defuzzMethod,uint8('mom'))
            defuzzifiedOutputs = defuzzifyOutput(true,@mom,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        elseif isequal(fis.defuzzMethod,uint8('som'))
            defuzzifiedOutputs = defuzzifyOutput(true,@som,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        elseif isequal(fis.defuzzMethod,uint8('lom'))
            defuzzifiedOutputs = defuzzifyOutput(true,@lom,outputSamplePoints, ...
                sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
        else
            if fuzzy.internal.codegen.isTargetMATLABOrMEX
                % Valid for MATLAB simulation and MEX target.
                defuzzifiedOutputs = defuzzifyOutput(false,@feval,outputSamplePoints, ...
                    sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,true);
            else
                defuzzifiedOutputs = zeros(fis.numOutputs,1,'like',aggregatedOutputs);
                if coder.internal.hasRuntimeErrors()
                    format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                        'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                    fprintf(format,'defuzzification',char(fis.defuzzMethod)); %#ok<CTPCT>
                end
                fuzzy.internal.codegen.runtimeExit
            end
        end
    else
        defuzzifiedOutputs = defuzzifyOutput(varargin{1},varargin{2},outputSamplePoints, ...
            sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,varargin{3});
    end
end

end
%% Helper functions -------------------------------------------------------
function defuzzifiedOutputs = defuzzifyOutput(isConstOrBuiltin,fh,outputSamplePoints, ...
    sumAntecedentOutputs,aggregatedOutputs,fis,diagnostic,notCustomEval)

coder.extrinsic('message','getString')

n = fis.numOutputs;
defuzzifiedOutputs = zeros(n,1,'like',aggregatedOutputs);

for outputID = 1:n
    if sumAntecedentOutputs == 0
        defuzzifiedOutputs(outputID) = mean(fis.outputRange(outputID,:));
        throwNoRuleFiredDiagnostic(outputID,defuzzifiedOutputs(outputID),diagnostic);
    else
        if isConstOrBuiltin
            if notCustomEval
                defuzzifiedOutputs(outputID) = fh(...
                    outputSamplePoints(outputID,:)',aggregatedOutputs(:,outputID));
            else
                defuzzifiedOutputs(outputID) = fh(...
                    fis.defuzzMethod, ...
                    outputSamplePoints(outputID,:)',aggregatedOutputs(:,outputID));
            end
        else
            if fuzzy.internal.codegen.isTargetMATLABOrMEX
                % Valid for MATLAB simulation and MEX target.
                defuzzifiedOutputs(outputID) = fh(...
                    char(fis.defuzzMethod),...
                    outputSamplePoints(outputID,:)',aggregatedOutputs(:,outputID));
            else
                if coder.internal.hasRuntimeErrors()
                    format = coder.const(fuzzy.internal.utility.getEnglishMessage(...
                        'fuzzy:general:errCodegen_Evalfis_CustomFcn'));
                    fprintf(format,'defuzzification',char(fis.defuzzMethod)); %#ok<CTPCT>
                end
                fuzzy.internal.codegen.runtimeExit
            end
        end
        throwEmptyFuzzySetDiagnostic(outputID,aggregatedOutputs(:,outputID), ...
            fis.defuzzMethod,defuzzifiedOutputs(outputID),diagnostic);
    end
end

end