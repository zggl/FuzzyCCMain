function varargout = evalfistype2(fis,x,options)
%

%

%  Copyright 2019 The MathWorks, Inc.

%#codegen

coder.extrinsic('fuzzy.internal.utility.createDiagnosticLevels')
coder.internal.prefer_const(fis)
coder.internal.prefer_const(options)

numSamplePoints = options.NumSamplePoints;

if fuzzy.internal.codegen.generateConstantCode(fis) && ...
        fuzzy.internal.codegen.generateConstantCode(options)
    
    diagnostics = coder.const(fuzzy.internal.utility.createDiagnosticLevels(...
        'OutOfRangeInputValue',options.OutOfRangeInputValueMessage, ...
        'NoRuleFired',options.NoRuleFiredMessage, ...
        'EmptyOutputFuzzySet',options.EmptyOutputFuzzySetMessage ...
        ));
    
    if isa(x,'double')
        fish = getConstantFIS(fis,numSamplePoints,'double');
    else
        fish = getConstantFIS(fis,numSamplePoints,'single');
    end
    
else
    diagnostics = createDiagnosticLevels(...
        'OutOfRangeInputValue',options.OutOfRangeInputValueMessage, ...
        'NoRuleFired',options.NoRuleFiredMessage, ...
        'EmptyOutputFuzzySet',options.EmptyOutputFuzzySetMessage ...
        );
    
    if isa(x,'double')
        fish = fuzzy.internal.codegen.packageAndSetDataType2(...
            fis,numSamplePoints,'double');
    else
        fish = fuzzy.internal.codegen.packageAndSetDataType2(...
            fis,numSamplePoints,'single');
    end
end

[row,col] = size(x);

if row==1 && col==1
    inputValues = x(:,ones(1,fish.numInputs));
    [varargout{1:nargout}] = ...
        fuzzy.internal.codegen.evaluateType2FIS(inputValues,fish,diagnostics);
elseif row==fish.numInputs && col~=fish.numInputs
    inputValues = x.';
    [varargout{1:nargout}] = ...
        fuzzy.internal.codegen.evaluateType2FIS(inputValues,fish,diagnostics);
else
    [varargout{1:nargout}] = ...
        fuzzy.internal.codegen.evaluateType2FIS(x,fish,diagnostics);
end

end
%% Helper functions -------------------------------------------------------
function fish = getConstantFIS(fis,numSamplePoints,dataType)
coder.extrinsic('fuzzy.internal.codegen.packageAndSetDataType2')

fish = coder.const(fuzzy.internal.codegen.packageAndSetDataType2(...
    fis,numSamplePoints,dataType));
end

function diagnosticLevels = createDiagnosticLevels(varargin)

diagnosticLevels = struct(...
    'SimulinkDiagnostic',uint8(0), ...
    'Model',uint8(0), ...
    'Block',uint8(0), ...
    'OutOfRangeInputValue',uint8(2), ...
    'NoRuleFired',uint8(2), ...
    'EmptyOutputFuzzySet',uint8(2) ...    
    );

n = length(varargin);

for i = 1:2:n
    if varargin{i} == "OutOfRangeInputValue"
        diagnosticLevels.OutOfRangeInputValue(1) = convertToIndex(varargin{i+1});
    elseif varargin{i} == "NoRuleFired"
        diagnosticLevels.NoRuleFired(1) = convertToIndex(varargin{i+1});
    elseif varargin{i} == "EmptyOutputFuzzySet"
        diagnosticLevels.EmptyOutputFuzzySet(1) = convertToIndex(varargin{i+1});
    end
end

end

function index = convertToIndex(diagnosticType)

if diagnosticType == "none"
    index = uint8(1);
elseif diagnosticType == "warning"
    index = uint8(2);
else
    index = uint8(3);
end

end