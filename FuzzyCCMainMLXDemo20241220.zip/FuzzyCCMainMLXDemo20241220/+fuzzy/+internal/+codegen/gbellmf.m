function y = gbellmf(x, params) %#codegen
%

% gbellmf - Codegen version of gbellmf.

%   Copyright 2017 The MathWorks, Inc.

a = cast(params(1),'like',x); 
b = cast(params(2),'like',x);
c = cast(params(3),'like',x);

y = zeros(size(x),'like',x);

tmp = zeros('like',x);

for i=1:numel(x)
    tmp(1) = (x(i) - c)*(1/a);
    tmp(1) = tmp(1)*tmp(1);
    if tmp<=0 && b==0
        y(i) = 0.5;
    elseif tmp<=0 && b < 0
        % y is zero.
    else
        tmp(1) = tmp(1)^b;
        y(i) = 1/(ones('like',x) + tmp);
    end
end

end