function n = numParamDsigmf
%% numParamDsigmf Returns number of parameter of dsigmf.

%  Copyright 2018 The MathWorks, Inc.

%#codegen

n = 4;
end