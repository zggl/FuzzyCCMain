function y = zmf(x, params) %#codegen
%

% zmf - Codegen version of zmf.

%   Copyright 2017 The MathWorks, Inc.

x1 = cast(params(1),'like',x);
x0 = cast(params(2),'like',x);

if x1 >= x0
    y = cast(x<=(x0+x1)/2,'like',x);
    return;
end

y = zeros(size(x),'like',x);

value = zeros('like',x);
for i = 1:numel(x)
    if x(i) <= x1
        y(i) = 1;
    end
    
    if (x1 < x(i)) && (x(i) <= (x1+x0)/2)
        value(1) = (x(i)-x1)*(1/(x1-x0));
        y(i) = ones('like',x) - 2*value*value;
    end
    
    if ((x1+x0)/2 < x(i)) && (x(i) <= x0)
        value(1) = (x0-x(i))*(1/(x1-x0));
        y(i) = 2*value*value;
    end
    
    if x0 <= x(i)
        y(i) = 0;
    end
    
end

end