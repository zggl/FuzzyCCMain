function y = linzmf(x,params) %#codegen
%

% linzmf - Codegen version of linzmf.

%   Copyright 2021 The MathWorks, Inc.

a = cast(params(1),'like',x);
b = cast(params(2),'like',x);
y = zeros(size(x),'like',x);

for i=1:numel(x)
    if x(i) < a
        y(i) = 1;
    elseif x(i)<b
        y(i) = (b-x(i))*(1/(b-a));
    end
end

end