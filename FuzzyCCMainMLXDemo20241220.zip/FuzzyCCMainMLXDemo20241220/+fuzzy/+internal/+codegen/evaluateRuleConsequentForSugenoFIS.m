function aggregatedOutputs = evaluateRuleConsequentForSugenoFIS(...
    inputs,antecedentOutputs,fis) %#codegen
%

% evaluateRuleConsequentForSugenoFIS - Generates aggregated output values
% using 'sugeno' implication and aggregation methods.

%   Copyright 2017-2018 The MathWorks, Inc. 

coder.internal.prefer_const(fis)

aggregatedOutputs = zeros(fis.aggSize,'like',inputs);
mfIndex = zeros('like',fis.numCumOutputMFs);

outputMFCache = createSugenoOutputMFCache(inputs,fis);

for ruleID = 1:fis.numRules
    for outputID = 1:fis.numOutputs
        mfIndex(1) = fis.consequent(ruleID,outputID);
        
        % The jth rule has no effect in ith output calculation if MF
        % index is zero.
        if mfIndex == 0
            continue;
        end

        aggregatedOutputs(outputID) = aggregatedOutputs(outputID) + ...
            outputMFCache(...
            fis.numCumOutputMFs(outputID)+mfIndex)* ...
            antecedentOutputs(ruleID);
    end
end

end