function aggregatedOutputs = applySugenoAggregationMethodType2(...
    consequentOutputs,fis,varargin) %#codegen
%

% applySugenoAggregationMethodType2 - Aggreagtes rule outputs using 'sugeno'
% aggregation method.

%   Copyright 2019-2023 The MathWorks, Inc. 

coder.internal.prefer_const(fis)

if isempty(varargin)
    aggregatedOutputs = zeros(fis.aggSize,'like',consequentOutputs);
else
    aggregatedOutputs = varargin{1};
end
n = fis.numOutputs;
aggregatedOutputs(:) = consequentOutputs;
for outputID = 1:n
    for i = 1:fis.numRules-1
        refVal1 = aggregatedOutputs(i,outputID);
        refVal2 = aggregatedOutputs(i,n+outputID);
        refVal3 = aggregatedOutputs(i,2*n+outputID);
        for j = i+1:fis.numRules
            if aggregatedOutputs(j,outputID)<refVal1
                aggregatedOutputs(i,outputID) = aggregatedOutputs(j,outputID);
                aggregatedOutputs(i,n+outputID) = aggregatedOutputs(j,n+outputID);
                aggregatedOutputs(i,2*n+outputID) = aggregatedOutputs(j,2*n+outputID);
                               
                aggregatedOutputs(j,outputID) = refVal1;
                aggregatedOutputs(j,n+outputID) = refVal2;
                aggregatedOutputs(j,2*n+outputID) = refVal3;
                
                refVal1 = aggregatedOutputs(i,outputID);
                refVal2 = aggregatedOutputs(i,n+outputID);
                refVal3 = aggregatedOutputs(i,2*n+outputID);
            end
        end
    end    
end


end