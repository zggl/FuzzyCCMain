function result = isMatlabTarget %#codegen
%

% isMatlabTarget - Returns true of the execution environemnt is MATLAB.
% This is basically a testing hook that can be overloaded for testing
% EML functions in MATLAB.

%  Copyright 2017 The MathWorks, Inc.
result = coder.target('MATLAB');
end