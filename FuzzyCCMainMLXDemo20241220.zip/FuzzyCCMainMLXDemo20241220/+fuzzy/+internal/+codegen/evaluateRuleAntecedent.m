function [antecedentOutputs,sumAntecedentOutputs] = ...
    evaluateRuleAntecedent(inputs,fis,diagnostic) %#codegen
%

% evaluateRuleAntecedent - Generates rule outputs using input values and
% rule antecedents.

%   Copyright 2017-2023 The MathWorks, Inc.

coder.internal.prefer_const(fis)
coder.internal.prefer_const(diagnostic)

antecedentOutputs = zeros(...
    fis.numRules,1,'like',inputs);
sumAntecedentOutputs = zeros('like',inputs);
mfIndex = zeros('like',fis.numCumInputMFs);
mVal = zeros('like',inputs);

inputMFCache = createInputMFCache(fis,inputs,diagnostic);

for ruleID = 1:fis.numRules
    antecedentOutputs(ruleID) = (fis.connection(ruleID) == 1);
    for inputID = 1:fis.numInputs
        mfIndex(1) = abs(fis.antecedent(ruleID,inputID));
        
        % The jth input has no effect in the ith rule if the MF index value
        % is set to 0.
        if mfIndex == 0
            continue;
        end
        
        % If the membership function index is negative, take the complement
        % of the previously calculated value. This corresponds to the NOT
        % logic.
        mVal(1) = inputMFCache(abs(fis.numCumInputMFs(inputID))+mfIndex);
        if fis.antecedent(ruleID,inputID)<0
            mVal(1) = ones('like',inputs) - mVal(1);
        end
                
        if fis.connection(ruleID) == 1
            antecedentOutputs(ruleID) = fuzzy.internal.codegen.evaluateAndMethod(...
                fis.andMethod,[antecedentOutputs(ruleID);mVal]);
        else
            antecedentOutputs(ruleID) = fuzzy.internal.codegen.evaluateOrMethod(...
                fis.orMethod,[antecedentOutputs(ruleID);mVal]);
        end                
    end
    antecedentOutputs(ruleID) = antecedentOutputs(ruleID)*fis.weight(ruleID);
    sumAntecedentOutputs(1) = sumAntecedentOutputs + antecedentOutputs(ruleID);
end

end