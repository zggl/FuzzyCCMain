function [consequentOutputs,unscaledOutputs] = ...
    applySugenoImplicationMethod(inputs,antecedentOutputs,fis) %#codegen
%

% applySugenoImplicationMethod - Generates rule outputs from antecedent
% outputs using 'sugeno' implication method.

%   Copyright 2017-2018 The MathWorks, Inc. 

coder.internal.prefer_const(fis)

consequentOutputs = zeros(fis.orrSize,'like',inputs);
unscaledOutputs = zeros(fis.orrSize,'like',inputs);
mfIndex = zeros('like',fis.numCumOutputMFs);
outputMFCache = createSugenoOutputMFCache(inputs,fis);

for ruleID = 1:fis.numRules
    for outputID = 1:fis.numOutputs
        mfIndex(1) = fis.consequent(ruleID,outputID);
        
        % The jth rule has no effect in ith output calculation if MF
        % index is zero.
        if mfIndex == 0
            continue;
        end

        unscaledOutputs(ruleID,outputID) = outputMFCache(...
            fis.numCumOutputMFs(outputID)+mfIndex);
        consequentOutputs(ruleID,outputID) = outputMFCache(...
            fis.numCumOutputMFs(outputID)+mfIndex)*antecedentOutputs(ruleID);
    end
end

end