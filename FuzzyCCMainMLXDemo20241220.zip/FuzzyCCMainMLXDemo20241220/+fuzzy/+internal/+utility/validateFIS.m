function validateFIS(fis)
%

% validateFIS - Checks FIS data.

%   Copyright 2017-2021 The MathWorks, Inc. 


if isa(fis,'FuzzyInferenceSystem')
    return
end

if isfield(fis,'typeReductionMethod')
    % There is no usecase where a user specifies a custom type-2 fis
    % structure.
    return
end

validateattributes(fis,{'struct'}, ...
    {'nonempty','scalar'},'','FIS');

expectedFieldNames = {...
    'name', ...
    'type', ...
    'andMethod', ...
    'orMethod', ...
    'defuzzMethod', ...
    'impMethod', ...
    'aggMethod', ...
    'input', ...
    'output', ...
    'rule'};
if ~all(isfield(fis,expectedFieldNames))
    error(message('fuzzy:general:errFIS_MissingRequiredFields'));
end

fuzzy.internal.utility.validCharOrString('FIS name',fis.name);
fuzzy.internal.utility.validCharOrString('FIS type',fis.type);
fuzzy.internal.utility.validCharOrString('AND method',fis.andMethod);
fuzzy.internal.utility.validCharOrString('OR method',fis.orMethod);
fuzzy.internal.utility.validCharOrString('Defuzzification method',fis.defuzzMethod);
fuzzy.internal.utility.validCharOrString('Implication method',fis.impMethod);
fuzzy.internal.utility.validCharOrString('Aggregation method',fis.aggMethod);

if ~isempty(fis.input)
    validateattributes(fis.input,{'struct'},{'nonempty'},'','FIS input variable');
end
if ~isempty(fis.output)
    validateattributes(fis.output,{'struct'},{'nonempty'},'','FIS output variable');
end
if ~isempty(fis.rule)
    if isempty(fis.input) || isempty(fis.output)
        error(message("fuzzy:general:errFIS_RuleNonempty"))
    end
    validateattributes(fis.rule,{'struct'},{'nonempty'},'','FIS rule variable');
end

if ~any(fis.type == ["mamdani" "sugeno"])
    error(message('fuzzy:general:errFIS_InvalidType'));
end

if ~any(fis.andMethod == ["min" "prod"]) && exist(fis.andMethod,'file') ~= 2
    error(message('fuzzy:dialogs:flcMaskErr_FIS_NonExistentAndMethod',fis.andMethod));
end

if ~any(fis.orMethod == ["max" "probor" "sum"]) && exist(fis.orMethod,'file') ~= 2
    error(message('fuzzy:dialogs:flcMaskErr_FIS_NonExistentOrMethod',fis.orMethod));
end


if (fis.type == "mamdani")

    if ~any(fis.impMethod==["min" "prod"]) && exist(fis.impMethod,'file')~=2
        error(message('fuzzy:dialogs:flcMaskErr_FIS_NonExistentImplicationMethod', ...
            fis.impMethod));
    end
    
    if ~any(fis.aggMethod==["max" "probor" "sum"]) && exist(fis.aggMethod,'file')~=2
        error(message('fuzzy:dialogs:flcMaskErr_FIS_NonExistentAggregationMethod', ...
            fis.aggMethod));
    end
    
    if any(fis.defuzzMethod == ["wtsum" "wtaver"])
        error(message('fuzzy:general:errMamdaniFIS_InvalidDefuzzificationMethod', ...
            fis.defuzzMethod));
    end
    
    if ~any(fis.defuzzMethod == ["centroid" "bisector" "mom" "lom" "som"]) && ...
        exist(fis.defuzzMethod,'file')~=2
        error(message('fuzzy:dialogs:flcMaskErr_FIS_NonExistentDefuzzMethod', ...
            fis.defuzzMethod));
    end
else
    if fis.impMethod ~= "prod" || fis.aggMethod ~= "sum"
        warning(message('fuzzy:general:errEvalfis_InvalidSugenoImpAggMethod'));
    end    
          
    if ~any(fis.defuzzMethod == ["wtsum" "wtaver"])
        error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidSugenoDefuzzMethod'));
    end
end


for i = 1:length(fis.input)
    if ~all(isfield(fis.input(i),{'name','range','mf'}))
        error(message('fuzzy:dialogs:flcMaskErr_FIS_MissingInputVarFields'));
    end

    fuzzy.internal.utility.validCharOrString(...
        'Input name',fis.input(i).name);
    
    validateattributes(fis.input(i).range,...
        {'double'},...
        {'nonempty','real','finite','vector','numel',2},...
        '',...
        'input range' ...
        )
    
    if fis.input(i).range(1) >= fis.input(i).range(2)
        error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidInputRange',i))
    end
            
    if isempty(fis.input(i).mf)
        % Valid use case. An input may have empty MF.
        continue;
    end
    
    validateattributes(fis.input(i).mf,...
        {'struct'},...
        {},...
        '',...
        'input membership function' ...
        )
    expectedMFs = fuzzy.internal.utility.builtinCommonMFs;
    
    for j = 1:length(fis.input(i).mf)
        if ~all(isfield(fis.input(i).mf(j),{'name','type','params'}))
            error(message('fuzzy:dialogs:flcMaskErr_FIS_MissingInputMFFields',i));
        end
        fuzzy.internal.utility.validCharOrString(...
            'Input membership function name',fis.input(i).mf(j).name);
        fuzzy.internal.utility.validCharOrString('Membership function type',fis.input(i).mf(j).type);
        isExpectedMF = any(fis.input(i).mf(j).type == expectedMFs);
        if ~isExpectedMF && exist(fis.input(i).mf(j).type,'file')~=2
            error(message('fuzzy:dialogs:flcMaskErr_FIS_NonExistentInputMF',...
                fis.input(i).mf(j).type,j,i));
        end
        validateattributes(fis.input(i).mf(j).params,...
            {'double'},...
            {'nonempty','finite','real','vector'},...
            '',...
            'input MF parameters' ...
            );
        if isExpectedMF
            fuzzy.internal.utility.validateMFParameterValues(...
                fis.input(i).mf(j).type,fis.input(i).mf(j).params)
        end
    end
end

numInputs = length(fis.input);
for i = 1:length(fis.output)
    if ~all(isfield(fis.output(i),{'name','range','mf'}))
        error(message('fuzzy:dialogs:flcMaskErr_FIS_MissingOutputVarFields'));
    end
    fuzzy.internal.utility.validCharOrString(...
        'Output name',fis.output(i).name);
    validateattributes(fis.output(i).range,...
        {'double'},...
        {'nonempty','real','finite','vector','numel',2},...
        '',...
        'output range' ...
        )
    
    if (fis.output(i).range(1)>=fis.output(i).range(2))
        error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidOutputRange',i));
    end
    
    if isempty(fis.output(i).mf)
        % Valid use case. An output may have empty MF.
        continue;
    end
    
    validateattributes(fis.output(i).mf,...
        {'struct'},...
        {},...
        '',...
        'output MF' ...
        )
    expectedMFs = fuzzy.internal.utility.builtinCommonMFs;
    
    for j = 1:length(fis.output(i).mf)
        if ~all(isfield(fis.output(i).mf(j),{'name','type','params'}))
            error(message('fuzzy:dialogs:flcMaskErr_FIS_MissingOutputMFFields',i));
        end
        fuzzy.internal.utility.validCharOrString(...
            'Output membership function name',fis.output(i).mf(j).name);
        fuzzy.internal.utility.validCharOrString('Membership function type',fis.output(i).mf(j).type);
        isCommonMF = false;
        if (fis.type == "mamdani")
            isCommonMF = any(fis.output(i).mf(j).type == expectedMFs);
            if ~isCommonMF && exist(fis.output(i).mf(j).type,'file')~=2
                error(message('fuzzy:dialogs:flcMaskErr_FIS_NonExistentOutputMF',...
                    fis.output(i).mf(j).type,j,i));
            end
        end
        isSugenoMF = false;
        if (fis.type == "sugeno")
            isSugenoMF = any(fis.output(i).mf(j).type == ["constant" "linear"]);
            if ~isSugenoMF
                error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidSugenoOutputMF',j,i));
            end
        end
        validateattributes(fis.output(i).mf(j).params,...
            {'double'},...
            {'nonempty','finite','real','vector'},...
            '',...
            'output MF parameters' ...
            )
        if isCommonMF || isSugenoMF
            fuzzy.internal.utility.validateMFParameterValues(...
                fis.output(i).mf(j).type,fis.output(i).mf(j).params,numInputs)
        end
    end
end

for i = 1:length(fis.rule)
    if ~all(isfield(fis.rule(i),{'antecedent','consequent','connection','weight'}))
        error(message('fuzzy:dialogs:flcMaskErr_FIS_MissingRuleVarFields'));
    end

    validateattributes(fis.rule(i).antecedent,...
        {'double'}, ...
        {'nonempty','real','finite','integer','vector','numel',length(fis.input)}, ...
        '', ...
        'rule antecedent' ...
        )
    
    if ~any(abs(fis.rule(i).antecedent))
        error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidRuleAntecedent',i));
    end
    
    for j = 1:length(fis.rule(i).antecedent)
        if abs(fis.rule(i).antecedent(j)) > length(fis.input(j).mf)
            error(message('fuzzy:general:errRule_InputMFIndexBeyondLimit',...
                i,j,length(fis.input(j).mf)));
        end
    end
    validateattributes(fis.rule(i).consequent,...
        {'double'}, ...
        {'nonempty','real','finite','integer','vector','numel',length(fis.output)}, ...
        '', ...
        'rule consequent' ...
        )
    
    if ~any(abs(fis.rule(i).consequent))
        error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidRuleConsequent',i));
    end
    
    for j = 1:length(fis.rule(i).consequent)
        if abs(fis.rule(i).consequent(j)) > length(fis.output(j).mf)
            error(message('fuzzy:general:errRule_OutputMFIndexBeyondLimit',...
                i,j,length(fis.input(j).mf)));
        end
		
        if (fis.type == "sugeno") && fis.rule(i).consequent(j)<0
            error(message('fuzzy:general:errRule_NotOpeartorInSugenoRuleConsequent',i,j))
        end		
    end
    
    validateattributes(fis.rule(i).connection,...
        {'double'}, ...
        {'nonempty','real','finite','integer','scalar','positive','<=',2}, ...
        '', ...
        'rule connection' ...
        )
        
    validateattributes(fis.rule(i).weight,...
        {'double'}, ...
        {'nonempty','real','finite','scalar','>=',0,'<=',1}, ...
        '', ...
        'rule weight' ...
        )
end

end