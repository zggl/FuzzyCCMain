function fisout = convertToHomogenousFISStruct(fisin)
%

% CONVERTTOHOMOGENOUSFISSTRUCT Creates a homogenous FIS structure
%
%   FISOUT = CONVERTTOHOMOGENOUSFISSTRUCT(FISIN) Creates a homogenous fuzzy
%   inference system structure FISOUT from FISIN, where FISIN is a mamfis
%   or sugfis object. The structure arrays in FISOUT contain same size
%   field values.
%
%   Examples
%
%   fis = fuzzy.internal.utility.convertToHomogenousFISStruct( ...
%       mamfis('NumInputs',1,'NumOutputs',1));
%
%   See also
%     mamfis, sugfis

%   Copyright 2018-2019 The MathWorks, Inc.

if isstruct(fisin)
    fisout = fisin;
else
    fisout = fuzzy.internal.utility.convertToStruct(fisin);
end
if isfield(fisout,'typeReductionMethod')
    fisout.input = fuzzy.internal.utility.makeHomogenousVarType2(fisout.input);
    fisout.output = fuzzy.internal.utility.makeHomogenousVarType2(fisout.output);
else
    fisout.input = fuzzy.internal.utility.makeHomogenousVar(fisout.input);
    fisout.output = fuzzy.internal.utility.makeHomogenousVar(fisout.output);
end
end