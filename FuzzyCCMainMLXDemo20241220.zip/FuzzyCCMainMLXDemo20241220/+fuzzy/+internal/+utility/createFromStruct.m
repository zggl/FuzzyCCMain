function fisout = createFromStruct(fis)
%% CREATEFROMSTRUCT Creates a FIS from a structure
%
%   FISOUT = CREATEFROMSTRUCT(FISIN) Creates a FIS object FISOUT from a FIS
%   structure FISIN.

%   Copyright 2017-2019 The MathWorks, Inc.

if isa(fis,'FuzzyInferenceSystem')
    fisout = fis;
    return
end    

if ~fuzzy.internal.utility.isNonemptyScalarFISStructure(fis)
    error(message('fuzzy:general:errFIS_StructureNotSpecified'))
end

fis = fuzzy.internal.utility.updateDuplicateVariableName(fis);
fis = fuzzy.internal.utility.updateDuplicateMFName(fis);
fis = fuzzy.internal.utility.updateSugenoOutputRange(fis);
fis = fuzzy.internal.utility.updateSugenoImplicationAndAggregationMethods(fis);

args = {...
    "Name",fis.name, ...
    "AndMethod",fis.andMethod, ...
    "OrMethod",fis.orMethod, ...
    "ImplicationMethod",fis.impMethod, ...
    "AggregationMethod",fis.aggMethod, ...
    "DefuzzificationMethod",fis.defuzzMethod ...
    };

if fis.type == "mamdani"
    fisout = mamfis(args{:});
else
    fisout = sugfis(args{:});
end

numInputs = length(fis.input);
if numInputs > 0
    fisout.Inputs = createVar(fis.input,numInputs);
end

numOutputs = length(fis.output);
if numOutputs > 0
    fisout.Outputs = createVar(fis.output,numOutputs);
end

numRules = length(fis.rule);
if numRules > 0
    rules = zeros(numRules,numInputs+numOutputs+2);
    for i = 1:numRules
        rules(i,1:numInputs) = fis.rule(i).antecedent;
        rules(i,numInputs+1:numInputs+length(fis.rule(i).consequent)) = ...
            fis.rule(i).consequent;
        rules(i,end-1) = fis.rule(i).weight;
        rules(i,end) = fis.rule(i).connection;
    end
    fisout = addRule(fisout,rules);
end

end
%% Helper functions
function ovar = createVar(svar,n)
ovar = repmat(fisvar,[1 n]);
for i = 1:n
    ovar(i).Name = svar(i).name;
    ovar(i).Range = svar(i).range;
    numMFs = length(svar(i).mf);
    if numMFs > 0
        mf = repmat(fismf,[1 numMFs]);
        for j = 1:numMFs
            mf(j).Name       = svar(i).mf(j).name;
            mf(j).Type       = svar(i).mf(j).type;
            mf(j).Parameters = svar(i).mf(j).params;
        end
        ovar(i).MembershipFunctions = mf;
    end
end
end