function validateGauss2MFParameterValues(params) %#codegen
%

% validateGauss2MFParameterValues - Validates parameter values of
% 'gauss2mf' membership function.

% Copyright 2017-2022 The MathWorks, Inc.

coder.extrinsic('message', 'warning')

if fuzzy.internal.codegen.isMatlabTarget
    if ~fuzzy.internal.utility.isValidInput(params)
        error(message('fuzzy:general:errMFParameters_invalidValue'))
    end
end
n = fuzzy.internal.codegen.numParamGauss2mf;
coder.internal.errorIf(numel(params)<n, ...
    'fuzzy:general:errGauss2mf_InvalidParamLength')

coder.internal.errorIf(params(1)<=0 || params(3)<=0, ...
    'fuzzy:general:errGauss2mf_InvalidParamValue')

if fuzzy.internal.codegen.isTargetMATLABOrMEX
    if numel(params)>n
        warning(message('fuzzy:general:warnFismf_RedundantParamValues','Two sided Gaussian',n))
    end
end
end