function fisout = createType2SugenoFISFromStruct(fis)
%% CREATETYPE2SUGENOFISFROMSTRUCT Creates a type-2 Sugeno FIS from a structure
%
%   FISOUT = CREATETYPE2SUGENOFISFROMSTRUCT(FISIN) Creates a type-2
%   Sugeno FIS object FISOUT from a FIS structure FISIN.

%   Copyright 2019 The MathWorks, Inc.

if isa(fis,'FuzzyInferenceSystem')
    fisout = fis;
    return
end    

if ~isNonemptyScalarFISStructure(fis)
    error(message('fuzzy:general:errFIS_StructureNotSpecified'))
end

fis = fuzzy.internal.utility.updateDuplicateVariableName(fis);
fis = fuzzy.internal.utility.updateDuplicateMFName(fis);
fis = fuzzy.internal.utility.updateSugenoOutputRange(fis);
fis = fuzzy.internal.utility.updateSugenoImplicationAndAggregationMethods(fis);

args = {...
    "Name",fis.name, ...
    "AndMethod",fis.andMethod, ...
    "OrMethod",fis.orMethod, ...
    "ImplicationMethod",fis.impMethod, ...
    "AggregationMethod",fis.aggMethod, ...
    "DefuzzificationMethod",fis.defuzzMethod, ...
    "TypeReductionMethod",fis.typeReductionMethod ...
    };

fisout = sugfistype2(args{:});

numInputs = length(fis.input);
if numInputs > 0
    fisout.Inputs = createVarWithT2MF(fis.input,numInputs);
end

numOutputs = length(fis.output);
if numOutputs > 0
    fisout.Outputs = createVarWithT1MF(fis.output,numOutputs);
end

numRules = length(fis.rule);
if numRules > 0
    rules = zeros(numRules,numInputs+numOutputs+2);
    for i = 1:numRules
        rules(i,1:numInputs) = fis.rule(i).antecedent;
        rules(i,numInputs+1:numInputs+length(fis.rule(i).consequent)) = ...
            fis.rule(i).consequent;
        rules(i,end-1) = fis.rule(i).weight;
        rules(i,end) = fis.rule(i).connection;
    end
    fisout = addRule(fisout,rules);
end

end
%% Helper functions -------------------------------------------------------
function result = isNonemptyScalarFISStructure(fis)
result = false;

if isempty(fis)
    return
end

if ~isscalar(fis)
    return
end

result = isFISStructure(fis);

end

function result = isFISStructure(fis)
result = false;

if ~isstruct(fis)
    return
end

expectedFieldNames = {...
    'name', ...
    'type', ...
    'andMethod', ...
    'orMethod', ...
    'defuzzMethod', ...
    'impMethod', ...
    'aggMethod', ...
    'input', ...
    'output', ...
    'rule', ...
    'typeReductionMethod' ...
    };
if ~all(isfield(fis,expectedFieldNames))
    return
end

if ~isVarValid(fis.input)
    return
end

if ~isVarValid(fis.output)
    return
end

if ~isempty(fis.rule)
    if ~all(isfield(fis.rule,{'antecedent','consequent','weight','connection'}))
        return
    end
end

result = true;

end

function result = isVarValid(var)
if ~isempty(var)
    if ~all(isfield(var,{'name','range','mf'}))
        result = false;
        return
    end
    for i = 1:length(var)
        if ~isempty(var(i).mf)
            if ~all(isfield(var(i).mf,{'name','umftype','umfparams', ...
                    'lmftype','lmfparams','lmfscale','lmflag'}))
                result = false;
                return
            end
        end
    end
end
result = true;
end

function lag = setScalarIfEqual(value)
if diff(value)==0
    lag = value(1);
else
    lag = value;
end
end

function ovar = createVarWithT2MF(svar,n)
ovar = repmat(fisvar,[1 n]);
for i = 1:n
    ovar(i).Name = svar(i).name;
    ovar(i).Range = svar(i).range;
    mf = fismftype2.empty;
    for j = 1:length(svar(i).mf)
       mf(j) = fismftype2(...
           svar(i).mf(j).umftype, ...
           svar(i).mf(j).umfparams, ...
           'Name',svar(i).mf(j).name, ...
           'LowerScale',svar(i).mf(j).lmfscale, ...
           'LowerLag',setScalarIfEqual(svar(i).mf(j).lmflag));
    end
    ovar(i).MembershipFunctions = mf;
end
end

function ovar = createVarWithT1MF(svar,n)
ovar = repmat(fisvar,[1 n]);
for i = 1:n
    ovar(i).Name = svar(i).name;
    ovar(i).Range = svar(i).range;
    numMFs = length(svar(i).mf);
    if numMFs > 0
        mf = repmat(fismf,[1 numMFs]);
        for j = 1:numMFs
            mf(j).Name       = svar(i).mf(j).name;
            mf(j).Type       = svar(i).mf(j).umftype;
            mf(j).Parameters = svar(i).mf(j).umfparams;
        end
        ovar(i).MembershipFunctions = mf;
    end
end

end