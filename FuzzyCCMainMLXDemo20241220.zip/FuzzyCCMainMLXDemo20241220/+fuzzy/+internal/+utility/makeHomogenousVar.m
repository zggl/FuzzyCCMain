function out = makeHomogenousVar(in)
%

% makeHomogenousVar - Creates array of fuzzy variable structures with
% homogenous fields.

%   Copyright 2018 The MathWorks, Inc.

if isempty(in)
    out = in;
    return
end

numVar = length(in);
maxVarNameLength = 0;
maxNumMF = 0;
maxMFNameLength = 0;
maxMFTypeLength = 0;
maxMFParamLength = 0;
for i=1:numVar
    n = numel(in(i).name);
    if n > maxVarNameLength
        maxVarNameLength = n;
    end
    mfs = in(i).mf;
    n = numel(mfs);
    if n > maxNumMF
        maxNumMF = n;
    end
    for j = 1:n
        mf = mfs(j);
        m = numel(mf.name);
        if m > maxMFNameLength
            maxMFNameLength = m;
        end
        m = numel(mf.type);
        if m > maxMFTypeLength
            maxMFTypeLength = m;
        end
        m = numel(mf.params);
        if m > maxMFParamLength
            maxMFParamLength = m;
        end
    end
end

mfTemplate = struct(...
    'name',char(zeros(1,maxMFNameLength)),...
    'origNameLength',zeros(1,1),...
    'type',char(zeros(1,maxMFTypeLength)),...
    'origTypeLength',zeros(1,1),...
    'params',zeros(1,maxMFParamLength),...
    'origParamLength',zeros(1,1)...
    );
mfVal(1:maxNumMF) = mfTemplate;
varTemplate = struct(...
    'name',char(zeros(1,maxVarNameLength)),...
    'origNameLength',zeros(1,1),...
    'range',zeros(1,2),...
    'mf',mfVal,...
    'origNumMF',zeros(1,1)...
    );
out(1:numVar) = varTemplate;

for i=1:numVar
    varName = in(i).name;
    varNameLength = length(varName);
    out(i).name(1:varNameLength) = varName;
    out(i).origNameLength(1) = varNameLength;
    out(i).range(:) = in(i).range;    
    out(i).origNumMF(1) = length(in(i).mf);    
    for j = 1:maxNumMF        
        if j <= out(i).origNumMF
            mfName = in(i).mf(j).name;
            mfNameLength = length(mfName);
            mfType = in(i).mf(j).type;
            mfTypeLength = length(mfType);
            params = in(i).mf(j).params;
            paramsLength = length(params);
            out(i).mf(j).name(1:mfNameLength) = mfName;
            out(i).mf(j).origNameLength(1) = mfNameLength;
            out(i).mf(j).type(1:mfTypeLength) = mfType;
            out(i).mf(j).origTypeLength(1) = mfTypeLength;
            out(i).mf(j).params(1:paramsLength) = params;
            out(i).mf(j).origParamLength(1) = paramsLength;
        end
    end
end

end