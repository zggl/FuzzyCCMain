function [out,errorMsg] = readFISAsStructure(varargin)
%

%READFISASSTRUCTURE Reads fuzzy inference system from a disk file.
%
%  FIS = READFISASSTRUCTURE(FILENAME) Loads FIS from user specfied
%  FILENAME. FIS is returned as a structure.
%
%  FIS = READFISASSTRUCTURE Loads FIS using file open dialog window.
%
%  [FIS,ERRORMSG] = READFISASSTRUCTURE(...) Returns error message ERRORMSG
%  if it fails to load FIS from a disk file.
%
%  Example
%    [out,errorMsg] = READFISASSTRUCTURE('tipper');
%
%  See also
%    fuzzy.internal.utility.readfis

%   Copyright 2017-2019 The MathWorks, Inc.

% ----------------------------------------------------------------------- %
% NOTE: Error handling for edge cases are intentionally ignored with the  %
% assumption that the user will not manually change a .fis file. If the   %
% original file is changed, we may end-up parsing incorrect values.       %
% ----------------------------------------------------------------------- %

try
    [out,errorMsg] = localReadFIS(varargin{:});
catch me
    if nargout > 1
        out = [];
        errorMsg = me.message;
    else
        rethrow(me)
    end
end


end
%% Helper functions -------------------------------------------------------
function [out,errorMsg] = localReadFIS(fileName)
errorMsg = '';
if nargin<1    
    fileName = getFileNameUsingDialog;
    if isempty(fileName)
        out = [];
        errorMsg = getString(message('fuzzy:general:errFIS_FileNameNotSpecified'));
        return
    end
end
fileName = validateAndUpdate(fileName); 
fid = openAndGetFileID(fileName);
closeFile = onCleanup(@()fclose(fid));

[out,missingSystemSection,isType2] = getSystemDescription(fid);
[out,NumInputs] = getVariables(fid,'[Input',out,isType2);
[out,NumOutputs] = getVariables(fid,'[Output',out,isType2);
out = getRules(fid,out,NumInputs,NumOutputs);
out = initSystemDescription(out,missingSystemSection);
out = updateMissingFields(out);
end

function fileName = getFileNameUsingDialog
[fileName,pathName] = uigetfile('*.fis','Read FIS');
if isequal(fileName,0) || isequal(pathName,0)
    fileName = [];
    return
end
fileName = fullfile(pathName, fileName);
end

function fileNameWithPath = validateAndUpdate(fileName)

fuzzy.internal.utility.validCharOrString('File name',fileName);
fileName = convertStringsToChars(fileName);

extension = '.fis';
hasExtension = endsWith(fileName,extension);
if hasExtension
    fileNameWithExtension = fileName;
else
    fileNameWithExtension = [fileName extension];
end

if isempty(which(fileNameWithExtension))
    fileNameWithPath = fileNameWithExtension;
else
    fileNameWithPath = which(fileNameWithExtension);
end
end

function fid = openAndGetFileID(fileName)
fid = fopen(fileName,'r','n','utf8');
if fid < 0
    error(message('fuzzy:general:errFileIO_CanNotOpen',fileName))
end
end

function [out,missingSystemSection,isType2] = getSystemDescription(fid)

% Structure
nextLineVar=' ';
topic='[System]';
topicFound = contains(nextLineVar,topic);
while ~topicFound && ~feof(fid)
    nextLineVar=LocalNextline(fid);
    topicFound = contains(nextLineVar,topic);
end

% These are the system defaults in case the user has omitted them
Name = 'Untitled';
missingSystemSection = false;

if topicFound        
    nextLineVar = ' ';
    % Here we are evaluating everything up till the first "[" bracket
    % The lines we're eval-ing contain their own variable names, so
    % a lot of variables, like "Name" and so on, are getting initialized
    % invisibly
    while systemDescriptionFound(nextLineVar,fid)        
        eval([nextLineVar ';']);
        nextLineVar = LocalNextline(fid);
    end    
else
    missingSystemSection = true;
end

out.name = Name;

version = 2;
if exist('Version','var')
    version = Version;
end

if version>2
    if missingSystemSection
        error(message("fuzzy:general:errReadfis_systemSectionNotFound"))
    end
end

if exist('Type','var')
    out.type = Type;
else
    errorOutForMissingTopic(version,'Type')
end

if exist('AndMethod','var')
    out.andMethod = AndMethod;
else
    errorOutForMissingTopic(version,'AND method')
end

if exist('OrMethod','var')
    out.orMethod = OrMethod;
else
    errorOutForMissingTopic(version,'OR method')
end

if exist('DefuzzMethod','var')
    out.defuzzMethod = DefuzzMethod;
else
    errorOutForMissingTopic(version,'Defuzzification method')
end

if exist('ImpMethod','var')
    out.impMethod = ImpMethod;
else
    errorOutForMissingTopic(version,'Implication method')
end

if exist('AggMethod','var')
    out.aggMethod = AggMethod;
else
    errorOutForMissingTopic(version,'Aggregation method')
end

if exist('TypeReductionMethod','var')
    out.typeReductionMethod = TypeReductionMethod;
    isType2 = true;
else
    isType2 = false;
    errorOutForMissingTopic(version,'Type reduction method')
end

% I have to rewind here to catch the first input. This is because
% I don't know how long the [System] comments are going to be
frewind(fid)

end

function [out,varIndex] = getVariables(fid,topic,out,isType2)
if feof(fid)
    frewind(fid)
end

varType = lower(topic(2:end));
out.(varType) = [];
nextLineVar = ' ';
varFound = contains(nextLineVar,topic);
varIndex = 0;
while ~varFound && ~feof(fid)
    nextLineVar = LocalNextline(fid);
    varFound = contains(nextLineVar,topic);
    if ~varFound
        continue
    end

    varIndex = varIndex + 1;
    
    % Variable name
    Name = 0;
    eval([LocalNextline(fid) ';'])
    if ~Name
        error(message(['fuzzy:general:errFileIO_Missing' topic(2:end) 'Variable'],varIndex))
    end
    
    out.(varType)(varIndex).name=Name;
    out.(varType)(varIndex).range = [];
    out.(varType)(varIndex).mf = [];
    % Input variable range
    Range = 0;
    eval([LocalNextline(fid) ';'])
    if ~Range
        error(message(['fuzzy:general:errFileIO_Missing' topic(2:end) 'Range'], varIndex))
    end
    out.(varType)(varIndex).range = Range;
    
    % Number of membership functions
    eval([LocalNextline(fid) ';']);
    
    for MFIndex = 1:NumMFs
        MFStr = LocalNextline(fid);
        nameStart = strfind(MFStr,'=');
        nameEnd = strfind(MFStr,':');
        MFName = eval(MFStr((nameStart+1):(nameEnd-1)));
        out.(varType)(varIndex).mf(MFIndex).name=MFName;
        typeStart = strfind(MFStr,':');
        if ~isType2
            typeEnd = strfind(MFStr,',');
            MFType = eval(MFStr((typeStart+1):(typeEnd-1)));
            MFParams = eval(MFStr((typeEnd+1):length(MFStr)));
            out.(varType)(varIndex).mf(MFIndex).type=MFType;
            out.(varType)(varIndex).mf(MFIndex).params=MFParams;
        elseif isType2 && out.type=="sugeno" && varType=="output"
            typeEnd = strfind(MFStr,',');
            MFType = eval(MFStr((typeStart+1):(typeEnd-1)));
            MFParams = eval(MFStr((typeEnd+1):length(MFStr)));            
            out.(varType)(varIndex).mf(MFIndex).umftype = MFType;
            out.(varType)(varIndex).mf(MFIndex).umfparams = MFParams;
            out.(varType)(varIndex).mf(MFIndex).lmftype = '';
            out.(varType)(varIndex).mf(MFIndex).lmfparams = [];
            out.(varType)(varIndex).mf(MFIndex).lmfscale = 1;
            out.(varType)(varIndex).mf(MFIndex).lmflag = [0 0];            
        else % isType2 || varType=="input"
            sep = strfind(MFStr,',');
            umfType = eval(MFStr((typeStart+1):(sep(1)-1)));
            umfParams = eval(MFStr(sep(1)+1:(sep(2)-1)));
            lmfType = umfType;
            lmfParams = [];
            lmfScale = eval(MFStr(sep(2)+1:(sep(3)-1)));
            lmfLag = eval(MFStr(sep(3)+1:end));
            out.(varType)(varIndex).mf(MFIndex).umftype = umfType;
            out.(varType)(varIndex).mf(MFIndex).umfparams = umfParams;
            out.(varType)(varIndex).mf(MFIndex).lmftype = lmfType;
            out.(varType)(varIndex).mf(MFIndex).lmfparams = lmfParams;
            out.(varType)(varIndex).mf(MFIndex).lmfscale = lmfScale;
            out.(varType)(varIndex).mf(MFIndex).lmflag = lmfLag;
        end
    end
    varFound = false;
end
end

function out = getRules(fid,out,NumInputs,NumOutputs)
if feof(fid)
    frewind(fid)
end
nextLineVar=' ';
topic='[Rules]';
topicFound = contains(nextLineVar,topic);
while ~topicFound && ~feof(fid)
    nextLineVar=LocalNextline(fid);
    topicFound = contains(nextLineVar,topic);
end

out.rule=[];
if topicFound
    ruleIndex=1;
    txtRuleList='';
    while ~feof(fid)
        ruleStr=LocalNextline(fid);
        if ischar(ruleStr)
            txtRuleList(ruleIndex,1:length(ruleStr))=ruleStr; %#ok<*AGROW>
            ruleIndex=ruleIndex+1;
        end
    end
    
    rules = fuzzy.internal.utility.parseRuleMatrix(out,txtRuleList,'indexed');
    for i=1:size(rules, 1)
        out.rule(i).antecedent=rules(i, 1:NumInputs);
        out.rule(i).consequent=rules(i, (NumInputs+1):(NumInputs+NumOutputs));
        out.rule(i).weight=rules(i, NumInputs+NumOutputs+1);
        out.rule(i).connection=rules(i, NumInputs+NumOutputs+2);
    end
end

end

function outLine = LocalNextline(fid)
%LOCALNEXTLINE Return the next non-empty line of a file.
%	OUTLINE=LOCALNEXTLINE(FID) returns the next non-empty line in the
%	file whose file ID is FID. The file FID must already be open.
%	LOCALNEXTLINE skips all lines that consist only of a carriage
%	return and it returns a -1 when the end of the file has been
%	reached.
%
%	LOCALNEXTLINE ignores all lines that begin with the % comment
%	character (the % character must be in the first column)

outLine = '';
stop = false;
while ~stop    
    if feof(fid)        
        break
    end    
    nextLine = fgetl(fid);    
    stop = ~isempty(nextLine) && ischar(nextLine) && ~strcmp(nextLine(1),'%');
end

if stop
   outLine =  nextLine;
end

end

function result = systemDescriptionFound(token,fid)
result = isempty([strfind(token,'[') strfind(token,':')]) && ~feof(fid);
end

function result = isLinearOrConstant(fis)
result = false;
for i = 1:numel(fis.output)
    for j = 1:numel(fis.output(i).mf)
        type = fis.output(i).mf(j).type;
        if strcmp(type,'constant') || strcmp(type,'linear')
            result = true;
            break
        end
    end
end
end

function out = initSystemDescription(out,descriptionIsMissing)
if descriptionIsMissing
    if isLinearOrConstant(out)
        out.andMethod = 'prod';
        out.orMethod = 'probor';
        out.impMethod = 'prod';
        out.aggMethod = 'sum';
        out.defuzzMethod = 'wtaver';
    else
        out.andMethod = 'min';
        out.orMethod = 'max';
        out.impMethod = 'min';
        out.aggMethod = 'max';
        out.defuzzMethod = 'centroid';
    end
end
end

function out = updateMissingFields(out)

if ~isfield(out,'type')
    if isLinearOrConstant(out)
        out.type = 'sugeno';
    else
        out.type = 'mamdani';
    end
end

if ~isfield(out,'andMethod')
    if strcmp(out.type,'sugeno')
        out.andMethod = 'prod';
    else
        out.andMethod = 'min';
    end        
end

if ~isfield(out,'orMethod')
    if strcmp(out.type,'sugeno')
        out.orMethod = 'probor';
    else
        out.orMethod = 'max';
    end
end

if ~isfield(out,'impMethod')
    if strcmp(out.type,'sugeno')
        out.impMethod = 'prod';
    else
        out.impMethod = 'min';
    end
end

if ~isfield(out,'aggMethod')
    if strcmp(out.type,'sugeno')
        out.aggMethod = 'sum';
    else
        out.aggMethod = 'max';
    end
end

if ~isfield(out,'defuzzMethod')
    if strcmp(out.type,'sugeno')
        out.defuzzMethod = 'wtaver';
    else
        out.defuzzMethod = 'centroid';
    end
end

end

function errorOutForMissingTopic(version,topic)
if version>2
    error(message("fuzzy:general:errReadfis_topicNotFound",topic))
end
end