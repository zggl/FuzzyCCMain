function validateConstantMFParameterValues(params)
%

% validateConstantMFParameterValues - Validates parameter values of
% 'constant' membership function.

% Copyright 2017 The MathWorks, Inc.

if ~isscalar(params)
    error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidConstMFParam'))
end

end