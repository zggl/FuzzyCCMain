function [sameInfo,sameNames] = isSimilar(fis1,fis2)
%

%

%   Copyright 2017-2018 The MathWorks, Inc.

[fis1Info,names1] = getFISInfo(fis1);
[fis2Info,names2] = getFISInfo(fis2);

sameInfo = isequal(fis1Info,fis2Info);
if sameInfo   
    sameNames = isequal(names1,names2);
else
    sameNames = false;
end

end
%% Helper functions -------------------------------------------------------
function [fisInfo,names] = getFISInfo(fis)
fisInfo = struct(...
    'numInputs',length(fis.Inputs), ...
    'numOutputs',length(fis.Outputs), ...
    'numInputMFs',fuzzy.internal.utility.getVarMFs(fis.Inputs), ...
    'numOutputMFs',fuzzy.internal.utility.getVarMFs(fis.Outputs) ...
    );
names = [[fis.Inputs.Name] [fis.Outputs.Name]];
for i = 1:fisInfo.numInputs
    names = [names [fis.Inputs(i).MembershipFunction.Name]]; %#ok<AGROW>
end
for i = 1:fisInfo.numOutputs
    names = [names [fis.Outputs(i).MembershipFunction.Name]]; %#ok<AGROW>
end
end