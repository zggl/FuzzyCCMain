function writeEvaluateCustomMF(fcns)
%% WRITEEVALUATECUSTOMMF Writes evaluation function for custom MFs
%
%   WRITEEVALUATECUSTOMMF(CUSTOMMF) Writes an evaluation function
%   in the current directory for the specified CUSTOMMF.
%
%   Example
%     WRITEEVALUATECUSTOMMF(<customMF>)

%  Copyright 2018-2021 The MathWorks, Inc.

mlock
persistent customMF
if isempty(customMF)
    customMF = {};
end

id = ismember(fcns,[fuzzy.internal.utility.builtinCommonMFs "linear" "constant"]);
if any(id)
    fcns(id) = [];
end
id = cell2mat(cellfun(@(x)~(exist(x,'file')==2 || exist(x,'builtin')==5),fcns,'UniformOutput',false));
if any(id)
    fcns(id) = [];
end

id = ismember(fcns,customMF);
if any(id)
    fcns(id) = [];
end

id = cell2mat(cellfun(@(x)~(exist(x,'file')==2 || exist(x,'builtin')==5),customMF,'UniformOutput',false));
if any(id)
    customMF(id) = [];
end

customMF = [customMF fcns];

evalFcnName = 'evaluateCustomMF';
fileName = fullfile(pwd,[evalFcnName '.m']);
if isempty(customMF)
    if exist(fileName,'file') == 2
        delete(fileName)
    end
    return
end

contents = sprintf("function [y,hasMFType] = %s(mfType,x,params,varargin) %%#codegen\n",evalFcnName);
contents = sprintf("%s%%[Y,HASMFTYPE] = %s(MFTYPE,X,PARAMS) Evaluates custom MFTYPE\n",contents,upper(evalFcnName));
contents = sprintf("%s%%with X and PARAMS; and returns output Y.\n%%\n",contents);
contents = sprintf("%s%%HASMFTYPE is true if MFTYPE exists.\n%%\n",contents);
contents = sprintf("%s%%Generated on %s\n\n",contents,datestr(now));
contents = sprintf("%s%% Copyright %s The MathWorks, Inc.\n\n",contents,datestr(now,'yyyy'));
contents = sprintf("%sy = -ones(size(x),'like',x);\n",contents);
contents = sprintf("%shasMFType = false;\n",contents);
contents = sprintf("%sif isequal(mfType,uint8('%s'))\n",contents,customMF{1});
contents = sprintf("%s\ty(:) = %s(x,params,varargin{:});\n",contents,customMF{1});
contents = sprintf("%s\thasMFType(1) = true;\n",contents);
for i = 2:length(customMF)
    contents = sprintf("%selseif isequal(mfType,uint8('%s'))\n",contents,customMF{i});
    contents = sprintf("%s\ty(:) = %s(x,params,varargin{:});\n",contents,customMF{i});
    contents = sprintf("%s\thasMFType(1) = true;\n",contents);
end
contents = sprintf("%send\n\nend\n",contents);

[f,msg] = fopen(fileName,'w+');
fuzzy.internal.utility.verifyFile(fileName,f,msg)
fprintf(f,"%s",contents);
fclose(f);

end