function yes = isValidInput(x)
%% ISVALIDINPUT Returns true if input is nonempty, finite, real numbers.
%

%  Copyright 2021 The MathWorks, Inc.
yes = fuzzy.internal.utility.isFiniteNonemptyReal(x);
end