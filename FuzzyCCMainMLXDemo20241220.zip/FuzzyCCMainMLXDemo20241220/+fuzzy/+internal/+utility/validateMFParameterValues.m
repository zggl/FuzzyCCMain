function validateMFParameterValues(type,params,numInputs)
%

% validateMFParameterValues - Validates membership function parameters.

%  Copyright 2017-2021 The MathWorks, Inc.

if type == "dsigmf"
    fuzzy.internal.utility.validateDSigMFParameterValues(params)
elseif type == "gaussmf"
    fuzzy.internal.utility.validateGaussMFParameterValues(params)
elseif type == "gauss2mf"
    fuzzy.internal.utility.validateGauss2MFParameterValues(params)
elseif type == "gbellmf"
    fuzzy.internal.utility.validateGBellMFParameterValues(params)
elseif type == "pimf"
    fuzzy.internal.utility.validatePiMFParameterValues(params)
elseif type == "psigmf"
    fuzzy.internal.utility.validatePSigMFParameterValues(params)
elseif type == "sigmf"
    fuzzy.internal.utility.validateSigMFParameterValues(params)
elseif type == "smf"
    fuzzy.internal.utility.validateSMFParameterValues(params)
elseif type == "trapmf"
    fuzzy.internal.utility.validateTrapMFParameterValues(params)
elseif type == "trimf"
    fuzzy.internal.utility.validateTriMFParameterValues(params)
elseif type == "zmf"
    fuzzy.internal.utility.validateZMFParameterValues(params)
elseif type == "constant"
    fuzzy.internal.utility.validateConstantMFParameterValues(params)
elseif type == "linear"
    fuzzy.internal.utility.validateLinearMFParameterValues(params,numInputs)
elseif type == "linsmf"
    fuzzy.internal.utility.validateLinSMFParameterValues(params)
elseif type == "linzmf"
    fuzzy.internal.utility.validateLinZMFParameterValues(params)
end

end