function ruleTabularDisplay(objAry)
%

% Internal function for displaying rule array contents.

%  Copyright 2018 The MathWorks, Inc.

rowNames = fuzzy.internal.utility.getRowNames(size(objAry));
objAry = objAry(:);
Description = [objAry.Description];
Description = Description(:);
tableObj = table(Description,'RowNames',rowNames);

fuzzy.internal.utility.detailDisplay(tableObj)

end