function s = convertToStruct(fis)
%

%

%  Copyright 2019 The MathWorks, Inc.

s = fis.EvalfisData;
s.name = char(fis.Name);
for i = 1:numel(fis.Inputs)
    s.input(i).name = char(fis.Inputs(i).Name);
    for j = 1:numel(fis.Inputs(i).MembershipFunctions)
        s.input(i).mf(j).name = char(fis.Inputs(i).MembershipFunctions(j).Name);
    end
end
for i = 1:numel(fis.Outputs)
    s.output(i).name = char(fis.Outputs(i).Name);
    for j = 1:numel(fis.Outputs(i).MembershipFunctions)
        s.output(i).mf(j).name = char(fis.Outputs(i).MembershipFunctions(j).Name);
    end
end
end
