function y = evalmf(x,params,type)
%EVALMF Evaluate membership function.

%   Copyright 2018-2022 The MathWorks, Inc.

y = feval(type, x, params);

end