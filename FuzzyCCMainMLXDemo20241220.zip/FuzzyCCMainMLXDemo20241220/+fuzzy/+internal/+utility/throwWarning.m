function throwWarning(diagnostics,varargin)
%

% throwWarning - Shows DIAGNOSTICS as a warning message using the message
% catalog arguments specified in VARARGIN.
%
%   The warning message is shown in
%   - Diagnotic Viewer in case of Simulink.
%   - Command Window in case of MATLAB.

% Copyright 2017-2019 The MathWorks, Inc.

if diagnostics.SimulinkDiagnostic
    MSLException(message(['fuzzy:dialogs:' varargin{1}], ...
        char(diagnostics.Block),varargin{2:end})).reportAsWarning;
else
    warning(message(['fuzzy:general:' varargin{1}],varargin{2:end}));
end

end