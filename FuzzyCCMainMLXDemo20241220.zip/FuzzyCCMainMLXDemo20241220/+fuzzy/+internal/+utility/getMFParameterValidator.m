function [fh,n] = getMFParameterValidator(type)
%

% [FH,N] = GETMFPARAMETERVALIDATOR(TYPE) Returns function handle FH to
% validate parameters of membership function TYPE. It also returns, N, the
% number of parameter values.

%  Copyright 2018-2021 The MathWorks, Inc.

if type == "dsigmf"
    fh = @(x,vararg)fuzzy.internal.utility.validateDSigMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamDsigmf;
elseif type == "gaussmf"
    fh = @(x)fuzzy.internal.utility.validateGaussMFParameterValues(x);
     n = fuzzy.internal.codegen.numParamGaussmf;
elseif type == "gauss2mf"
    fh = @(x)fuzzy.internal.utility.validateGauss2MFParameterValues(x);
     n = fuzzy.internal.codegen.numParamGauss2mf;
elseif type == "gbellmf"
    fh = @(x)fuzzy.internal.utility.validateGBellMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamGbellmf;
elseif type == "pimf"
    fh = @(x)fuzzy.internal.utility.validatePiMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamPimf;
elseif type == "psigmf"
    fh = @(x)fuzzy.internal.utility.validatePSigMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamPsigmf;
elseif type == "sigmf"
    fh = @(x)fuzzy.internal.utility.validateSigMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamSigmf;
elseif type == "smf"
    fh = @(x)fuzzy.internal.utility.validateSMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamSmf;
elseif type == "linsmf"
    fh = @(x)fuzzy.internal.utility.validateLinSMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamLinsmf;
elseif type == "trapmf"
    fh = @(x)fuzzy.internal.utility.validateTrapMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamTrapmf;
elseif type == "trimf"
    fh = @(x)fuzzy.internal.utility.validateTriMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamTrimf;
elseif type == "zmf"
    fh = @(x)fuzzy.internal.utility.validateZMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamZmf;
elseif type == "linzmf"
    fh = @(x)fuzzy.internal.utility.validateLinZMFParameterValues(x);
    n = fuzzy.internal.codegen.numParamLinzmf;
elseif type == "constant"
    fh = @(x)fuzzy.internal.utility.validateConstantMFParameterValues(x);
    n = -1;
elseif type == "linear"
    fh = @(x,varargin)fuzzy.internal.utility.validateLinearMFParameterValues(x,varargin{:});
    n = -1;
else
    fh = function_handle.empty;
    n = [];
end

end