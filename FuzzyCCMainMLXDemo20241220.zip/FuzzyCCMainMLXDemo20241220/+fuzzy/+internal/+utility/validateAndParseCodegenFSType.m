function type = validateAndParseCodegenFSType(varargin)
%

%

%  Copyright 2019 The MathWorks, Inc.

p = inputParser;
p.addParameter("FuzzySetType","type1",@validateFuzzySetType)
p.parse(varargin{:})

type = char(p.Results.FuzzySetType);

end
%% Helper functions -------------------------------------------------------
function validateFuzzySetType(value)
fuzzy.internal.utility.validCharOrString('Fuzzy set type',value);
if ~any(value==["type1" "type2"])
    error(message("fuzzy:general:errGetFISCodeGenerationData_invalidFSType"))
end
end