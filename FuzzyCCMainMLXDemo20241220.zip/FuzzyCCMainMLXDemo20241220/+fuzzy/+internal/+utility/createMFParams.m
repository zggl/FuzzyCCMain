function params = createMFParams(mfType,varRange,numMFs,overlap)
%% CREATEMFPARAMS Creates membership function parameters
%
%   PARAMS = CREATEMFPARAMS(VARRANGE,MFTYPE,NUMMFS,OVERLAP) Creates
%   parameters for NUMMFS number of membership functions of type MFTYPE in
%   range VARRANGE with OVERLAP percent overlap.
%
%   Example
%   params = CREATEMFPARAMS([0 1],"trimf",3,80);

%  Copyright 2018 The MathWorks, Inc.

if nargin < 4
    overlap = 80;
end

if nargin < 3
    numMFs = 1;
end

if nargin < 2
    varRange = [0 1];
end

params = [];

rangeDiff = diff(varRange);
rangeDiffHalf = rangeDiff/2;
midRange = varRange(1)+rangeDiffHalf;

mfType = fuzzy.internal.utility.convertToCharIfStringOrFcnHandle(mfType);

if mfType=="trimf"
    params = zeros(numMFs,3);
    if numMFs == 1
        params(1,:) = [varRange(1) midRange varRange(2)];
    else
        peakLocation = varRange(1);
        step = rangeDiff/(numMFs-1);
        mfSupport = getMFSupport(step,overlap);
        for i = 1:numMFs
            params(i,:) = [...
                peakLocation-mfSupport ...
                peakLocation ...
                peakLocation+mfSupport];
            peakLocation = peakLocation + step;
        end
    end
elseif mfType == "gaussmf"
    params = zeros(numMFs,2);
    if numMFs == 1
        params(1,:) = [rangeDiffHalf/3 midRange];
    else
        peakLocation = varRange(1);
        step = rangeDiff/(numMFs-1);
        sigma = (getMFSupport(step,overlap))/3;
        for i = 1:numMFs
            params(i,:) = [sigma peakLocation];
            peakLocation = peakLocation + step;
        end
    end    
elseif mfType == "constant"
    params = zeros(numMFs,1);
    if numMFs == 1
        params(1) = midRange;
    else
        step = rangeDiff/(numMFs-1);
        for i = 1:numMFs
            params(i) = varRange(1) + (i-1)*step;
        end
    end    
end

end
%% Helper functions -------------------------------------------------------
function mfSupport = getMFSupport(step,overlap)
mfSupport = (100*step)/(200-overlap);
end