function validateMFTypeWithReference(value,refValue,msgKey)
%

%

%  Copyright 2018 The MathWorks, Inc.

try
    fuzzy.internal.utility.validateMFType(value)
catch
    error(message("fuzzy:general:"+msgKey))
end

if ischar(value)
    value = string(value);
end

n = numel(refValue);
validValue = true(1,n);
for i = 1:n
    validValue(i) = isequal(value,refValue{i});
end
if ~any(validValue)
    error(message("fuzzy:general:"+msgKey))
end

end