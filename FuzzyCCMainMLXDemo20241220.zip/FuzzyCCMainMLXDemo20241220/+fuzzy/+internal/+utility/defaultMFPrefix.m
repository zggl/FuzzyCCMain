function prefix = defaultMFPrefix
%% DEFAULTMFPREFIX Returns default prefix for a membership function name
%
%   The default MF name prefix is used to uniquely distinguish it from user
%   specified MF names to automatically update an MF name in a fuzzy
%   variable context.

%   Copyright 2017-2018 The MathWorks, Inc.

persistent value

if isempty(value)
    [~,value] = fileparts(tempname);
end

prefix = string(value);
end