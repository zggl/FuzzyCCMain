function validateAddRules(value,msgKey)
%

%

%  Copyright 2018 The MathWorks, Inc.

try
    fuzzy.internal.utility.validCharOrString('AddRules',value);
catch
    error(message("fuzzy:general:"+msgKey))
end

if ~any(value == ["none" "allcombinations"])
    error(message("fuzzy:general:"+msgKey))
end
end