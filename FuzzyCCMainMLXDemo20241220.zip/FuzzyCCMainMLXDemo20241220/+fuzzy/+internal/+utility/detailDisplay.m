function detailDisplay(tableObj)
%

% Internal utility function, which adds 'Details:' header before displaying
% a table for fisvar, fismf, and fisvar objects.

%  Copyright 2018 The MathWorks, Inc.

disp('  Details:')
disp(tableObj)

end