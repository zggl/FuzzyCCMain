function range = updateRangeIfEqual(range,dvLeft,dvRight)
%

%

%   Copyright 2017 The MathWorks, Inc.

idx = diff(range,1,2)==0;
if any(idx)
    v  = range(idx,1);
    if nargin == 1
        dv = 0.1*abs(v)+0.1;
        range(idx,:) = [v-dv, v+dv];
    else
        range(idx,:) = [v-dvLeft, v+dvRight];
    end
end

end
