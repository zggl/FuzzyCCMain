function msg = getEnglishMessage(id,varargin)
%

%

% Copyright 2018 The MathWorks, Inc.

msg = getString(...
    message(id,varargin{:}), ...
    matlab.internal.i18n.locale('en_US'));
end