function fisout = setDataType(fisin,outDataTypeStr)
%

% setDataType - Sets FIS data types for using in a Fuzzy Logic Controller
% block.

%   Copyright 2017-2019 The MathWorks, Inc.

% Simulink does not allow CHAR data types. SO, we need to convert CHAR
% values to UINT8 values. Moreover, if the name fields are specified as
% strings, we need to, first, convert string values to CHAR values.
fisout.type = convertToUint8(fisin.type);
fisout.andMethod = convertToUint8(fisin.andMethod);
fisout.orMethod = convertToUint8(fisin.orMethod);
fisout.defuzzMethod = convertToUint8(fisin.defuzzMethod);
fisout.impMethod = convertToUint8(fisin.impMethod);
fisout.aggMethod = convertToUint8(fisin.aggMethod);
if isfield(fisin,'typeReductionMethod')
    fisout.typeReductionMethod = convertToUint8(fisin.typeReductionMethod);
    isType2 = true;
else
    isType2 = false;
end

fisout.inputRange = setMatDataType(fisin.inputRange,outDataTypeStr);
fisout.outputRange = setMatDataType(fisin.outputRange,outDataTypeStr);

if isType2
    fisout.inputMF = setMFDataType2(fisin.inputMF,outDataTypeStr);
    fisout.outputMF = setMFDataType2(fisin.outputMF,outDataTypeStr);
else
    fisout.inputMF = setMFDataType(fisin.inputMF,outDataTypeStr);
    fisout.outputMF = setMFDataType(fisin.outputMF,outDataTypeStr);
end

fisout.antecedent = setMatDataType(fisin.antecedent,outDataTypeStr);
fisout.consequent = setMatDataType(fisin.consequent,outDataTypeStr);
fisout.connection = setMatDataType(fisin.connection,outDataTypeStr);
fisout.weight = setMatDataType(fisin.weight,outDataTypeStr);

fisout.numSamples = int32(fisin.numSamples);
fisout.numInputs = int32(fisin.numInputs);
fisout.numOutputs = int32(fisin.numOutputs);
fisout.numRules = int32(fisin.numRules);
fisout.numInputMFs = int32(fisin.numInputMFs);
fisout.numCumInputMFs = int32(fisin.numCumInputMFs);
fisout.numOutputMFs = int32(fisin.numOutputMFs);
fisout.numCumOutputMFs = int32(fisin.numCumOutputMFs);

fisout.outputSamplePoints = setMatDataType(fisin.outputSamplePoints, ...
    outDataTypeStr);

fisout.orrSize = int32(fisin.orrSize);
fisout.aggSize = int32(fisin.aggSize);
fisout.irrSize = int32(fisin.irrSize);
fisout.rfsSize = int32(fisin.rfsSize);
fisout.sumSize = int32(fisin.sumSize);
fisout.inputFuzzySetType = int32(fisin.inputFuzzySetType);

end
%% Helper functions -------------------------------------------------------
function out = convertToUint8(in)
out = uint8(convertStringsToChars(in));
end