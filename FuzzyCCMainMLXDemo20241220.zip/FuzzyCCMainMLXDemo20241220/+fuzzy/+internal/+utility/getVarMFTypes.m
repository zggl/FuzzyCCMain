function label = getVarMFTypes(var)
%

%

%   Copyright 2017-2018 The MathWorks, Inc.

label = string.empty;
for i = 1:numel(var)
    if ~isempty(var(i).MembershipFunction)
        label = [label;[var(i).MembershipFunction.Type]']; %#ok<AGROW>
    end
end
label = char(label);

end
