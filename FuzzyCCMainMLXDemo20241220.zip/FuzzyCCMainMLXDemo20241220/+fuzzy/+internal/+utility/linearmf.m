function y = linearmf(x,param)
%% LINEARMF Linear membership function
%
%   Y = LINEARMF(X,PARAMS) Evaluates X using PARAMS to generate Y.X can be
%   specified as follows:
%     - As a scalar. In this case, the same value will be used for N time,
%       where N is the number inputs. N is equal to [LENGTH(PARAMS)-1].
%     - As a vector. In this case, if the vector length is N, then X is
%       used as an input set. Otherwise, the same vector will be used for
%       all inputs.
%     - As a 2D matrix. In this case,
%         - If number of rows is equal to N, each column of X is used as an
%           input set.
%         - If number of columns is equal to N, each row of X is used as an
%           input set.
%         - Otherwise, the same matrix will be used for all inputs.
%   Y is returned as
%     - A scalar if X is a scalar or X is specified as an input set.
%     - A row vector if input sets are specified as column vectors in X.
%     - A column vector if input sets are specified as row vectors in X.
%     - A matrix if number of rows or columns does not match with N.

%  Copyright 2018 The MathWorks, Inc.

% if isrow(param)
%     param = param';
% end
numInputs = length(param)-1;
if isscalar(x)
    y = evalScalarX(x,param,numInputs);
elseif isvector(x)
    y = evalVectorX(x,param,numInputs);
else
    y = eval2DX(x,param,numInputs);
end

end
%% Helper functions -------------------------------------------------------
function y = evalScalarX(x,param,numInputs)
y = zeros('like',x);
if numInputs > 1
    x = repmat(x,[numInputs 1]);
    if isrow(param)
        param = param';
    end
end
y(1) = sum(x.*param(1:numInputs)) + param(end);
end

function y = evalVectorX(x,param,numInputs)
if length(x) == numInputs
    y = zeros('like',x);
    if size(x) ~= size(param(1:numInputs))
        param = param';
    end
    y(1) = sum(x.*param(1:numInputs)) + param(end);
else
    y = zeros(size(x),'like',x);
    if numInputs == 1
        y(:) = x*param(1) + param(2);
    else
        if iscolumn(x)
            x = x';
        end
        x = repmat(x,[numInputs 1]);
        if isrow(param)
            param = param';
        end
        y(:) = sum(x(:,:).*param(1:numInputs)) + param(end);
    end
end
end

function y = eval2DX(x,param,numInputs)
if size(x,1)==numInputs
    y = zeros(1,size(x,2),'like',x);
    if isrow(param)
        param = param';
    end
elseif size(x,2)==numInputs
    y = zeros(size(x,1),1,'like',x);
    x = x';
    if isrow(param)
        param = param';
    end
else
    y = zeros(size(x),'like',x);
    if numInputs > 1
        x = x(:);
        x = x';
        x = repmat(x,[numInputs 1]);
        if isrow(param)
            param = param';
        end
    end
end
if numInputs == 1
    y(:) = x*param(1) + param(2);
else
    y(:) = sum(x(:,:).*param(1:numInputs)) + param(end);
end

end