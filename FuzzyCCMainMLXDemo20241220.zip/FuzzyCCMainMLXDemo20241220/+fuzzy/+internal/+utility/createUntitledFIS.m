function fis = createUntitledFIS(type)
% CREATEUNTITLEDFIS  Creates default untitled FIS for internal use-only.
%   FIS = CREATEUNTITLEDFIS(TYPE) Creates an untitled FIS with the
%   specified TYPE. 

%   Copyright 2017-2018 The MathWorks, Inc.

if nargin == 0
    type = "mamdani";
end

args = {'Name','Untitled','NumInputs',1,'NumOutputs',1,'AddRules',"none"};
if type == "mamdani"
    fis = mamfis(args{:});
else
    fis = sugfis(args{:});
end

end