function rowNames = getRowNames(dimension)
%% getRowNames - Generates row names
%
%    ROWNAMES = getRowNames(DIMENSION) Generates ROWNAMES using
%    DIMENSION.
%  
%    DIMENSION is the size of a variable. ROWNAMES is cell array of char
%    values, which are used for detail display of fisvar, fismf, and
%    fisvar.

%  Copyright 2018 The MathWorks, Inc.

numElements = prod(dimension);
numDimension = length(dimension);
rowNames = cell(numElements,1);
if numDimension==2 && (dimension(1)==1 || dimension(2)==1)
    for i = 1:numElements
        rowNames{i} = sprintf('%d',i);
    end
else
    indices = (1:numElements)'; %#ok<NASGU>
    subscripts = sprintf('i%d,',1:numDimension);
    subscripts(end) = ']';
    subscripts = ['[' subscripts];
    cmd = [subscripts '=ind2sub(dimension,indices);'];
    eval(cmd)
    format = repmat('%d,',[1 numDimension]);
    format(end) = ')';
    format = ['(' format];
    subs = eval(subscripts);
    for i = 1:numElements
        rowNames{i} = sprintf(format,subs(i,:));
    end
end

end