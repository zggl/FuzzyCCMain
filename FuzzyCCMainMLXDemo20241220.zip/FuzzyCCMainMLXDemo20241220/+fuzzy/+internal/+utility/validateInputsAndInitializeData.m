function fisout = validateInputsAndInitializeData(fis,numSamples,...
    OutDataTypeStr)
%

% validateInputsAndInitializeData - Validates mask parameter values of a
% Fuzzy Logic Controller (FLC) block and packages necessary data required
% for the FLC block.
% 
%     This function ensures that the packaged data -
%         - is homogenous, and
%         - does not use CHAR data type since Simulink does not accept it.

%   Copyright 2017-2018 The MathWorks, Inc. 

narginchk(3,3)

fuzzy.internal.utility.validateNumOutputSample(numSamples);
fuzzy.internal.utility.validateOutputDataType(OutDataTypeStr);

if ~isstruct(fis) && ~isa(fis,'FuzzyInferenceSystem')
    fis = readfis(fis);
end
if fuzzy.internal.utility.isHomogenousFISStructure(fis)
    fis = fuzzy.internal.utility.convertToNonhomogenousFISStruct(fis);
end
fuzzy.internal.utility.validateFISForEvaluation(fis)

fisout = fuzzy.internal.utility.setDataType(...
    fuzzy.internal.utility.packageData(fis,numSamples),...
    OutDataTypeStr);
end