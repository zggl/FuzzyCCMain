function fis = updateSugenoImplicationAndAggregationMethods(fis)
%

%

%   Copyright 2018 The MathWorks, Inc.

if fis.type == "mamdani"
    return
end

issueWarning = false;
if fis.impMethod ~= "prod"
    fis.impMethod = 'prod';
    issueWarning = true;
end

if fis.aggMethod ~= "sum"
    fis.aggMethod = 'sum';
    issueWarning = true;
end

if issueWarning
    warning(message('fuzzy:general:errEvalfis_InvalidSugenoImpAggMethod'))
end

end