function validateType2CompatibleMFParam(type,params)
%%

%  Copyright 2022 The MathWorks, Inc.

if type=="trapmf"
    if ~all(diff(params)>=0)
        error(message("fuzzy:general:errFismftype2_invalidUMFParamsForTrapmf"))
    end
elseif type=="gauss2mf"
    if params(2) > params(4)
        error(message("fuzzy:general:errFismftype2_invalidUMFParamsForGauss2mf"))
    end
elseif type=="psigmf"
    if params(1)<=0
        error(message("fuzzy:general:errFismftype2_invalid1stUMFParamsForPsigmf"))
    end
    if params(3)>=0
        error(message("fuzzy:general:errFismftype2_invalid3rdUMFParamsForPsigmf"))
    end
    if params(2) > params(4)
        error(message("fuzzy:general:errFismftype2_invalid2ndUMFParamsForPsigmf"))
    end
    f = @(a,y)(1/a)*log(y/(1-y));
    x1 = params(2) + f(params(1),0.99);
    x2 = params(4) + f(params(3),0.99);
    if x2 < x1
        error(message("fuzzy:general:errFismftype2_maxMFNotOneMixedSigmf"))
    end
elseif type=="sigmf"
    if params(1)==0
        error(message("fuzzy:general:errFismftype2_invalid1stUMFParamsForSigmf"))
    end
elseif type=="dsigmf"
    if params(1)<=0
        error(message("fuzzy:general:errFismftype2_invalid1stUMFParamsForDsigmf"))
    end
    if params(3)<=0
        error(message("fuzzy:general:errFismftype2_invalid3rdUMFParamsForDsigmf"))
    end
    if params(2) > params(4)
        error(message("fuzzy:general:errFismftype2_invalid2ndUMFParamsForDsigmf"))
    end
    f = @(a,y)(1/a)*log(y/(1-y));
    x1 = params(2) + f(params(1),0.99);
    x2 = params(4) + f(params(3),0.01);
    if x2 < x1
        error(message("fuzzy:general:errFismftype2_maxMFNotOneMixedSigmf"))
    end
elseif type=="pimf"
    if max(params(1:2)) > min(params(3:4))
        error(message("fuzzy:general:errFismftype2_maxMFNotOnePimf"))
    end
elseif type=="gbellmf"
    if params(2) <= 0
        error(message("fuzzy:general:errFismftype2_invalid2ndUpperParamGbellmf"))
    end
end
end
