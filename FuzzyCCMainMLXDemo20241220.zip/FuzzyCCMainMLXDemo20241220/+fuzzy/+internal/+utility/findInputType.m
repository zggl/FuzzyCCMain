function inputType = findInputType(paramList,varargin)
% INPUTTYPE = FINDINPUTTYPE(PARAMLIST,VARARGIN) returns 'params' if any
% parameter name listed in PARAMLIST partially matches (ignoring case)
% and starts with the first optional input. Otherwise, it returns
% 'optional'.
    
%  Copyright 2016-2020 The MathWorks, Inc.

import fuzzy.internal.utility.isCharRowVector

if isempty(varargin) || ...
        ((isCharRowVector(varargin{1}) || ...
        (isStringScalar(varargin{1}) && ~isempty(varargin{1}.char))) && ...
        any(startsWith(paramList,varargin{1},'IgnoreCase',true)))
    inputType = 'params';
else
    inputType = 'optional';
end
end