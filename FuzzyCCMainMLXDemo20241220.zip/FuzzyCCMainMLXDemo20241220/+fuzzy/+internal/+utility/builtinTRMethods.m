function names = builtinTRMethods
%

%

%   Copyright 2019 The MathWorks, Inc.

names = ["karnikmendel" "ekm" "eiasc"];

end