function checkMinInOutRuleRequirement(fis)
%

%

%   Copyright 2017-2022 The MathWorks, Inc.

if isempty(fis.input) || isempty(fis.output)
    error(message('fuzzy:general:errFIS_MissingInputOrOutputVariable'))
end
if isempty(fis.rule)
    error(message('fuzzy:general:errFIS_MissingRule'))
end
if fis.type=="sugeno" && any([fis.rule.consequent]<0)
    error(message('fuzzy:general:errSugenoFIS_ruleConsequentNegative'))
end

end
