function mfs = builtinCommonMFs
%

% builtinMFs - Returns builtin MFs.

% Copyright 20172021 The MathWorks, Inc.

mfs = ["dsigmf" "gauss2mf" "gaussmf" "gbellmf" "pimf" "psigmf" "sigmf" ...
    "smf" "trapmf" "trimf" "zmf" "linsmf" "linzmf"];

end