function value = convertToCharIfStringOrFcnHandle(value)
%

%

%   Copyright 2017 The MathWorks, Inc.

if isa(value,'function_handle')
    value = func2str(value);
elseif isstring(value)
    value = char(value);
end

end