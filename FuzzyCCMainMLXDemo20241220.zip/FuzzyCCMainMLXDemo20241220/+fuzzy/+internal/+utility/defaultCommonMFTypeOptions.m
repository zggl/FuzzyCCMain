function [refValue,msgKey] = defaultCommonMFTypeOptions(varargin)
%

%

%  Copyright 2018 The MathWorks, Inc.

if isempty(varargin)
    value = "";
else
    value = varargin{1};
end
if isa(value,'function_handle')
    refValue = {@trimf @gaussmf};
    msgKey = "errFIS_InvalidDefaultMFTypeHandle";
else
    refValue = {"trimf","gaussmf"};
    msgKey = "errFIS_InvalidDefaultMFTypeName";
end
end