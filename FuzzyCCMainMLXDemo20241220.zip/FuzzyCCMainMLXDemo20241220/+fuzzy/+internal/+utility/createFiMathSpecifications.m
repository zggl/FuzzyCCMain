function fmSpec = createFiMathSpecifications(dataType)
%

% createFiMathSpecifications - Creates FIMATH specifications according to
% user-specified fixed-point DATATYPE. Default FIMATH specifications are
% used when DATATYPE is non fixed-point type.
%
%     The user will provide a fixed-point data type that can hold all the
%     FIS data. Hence, we can use the same fixed-point spec for
%     'multiplication' and 'sum' operations since generally, they don't
%     produce a number greater than any FIS data. 
%   
%     There are few "catches", though, e.g. 
%         - if the number of rules is greater than the largest number of
%           the FIS data and each rule has a firing strength 1, then the
%           sum of rule firing strengths cannot be stored with specified
%           fixed-point specification.
%         - if the sum of rule outputs in a 'sugeno' FIS goes far beyond
%           higher output ranges, then the specified fixed-point spec
%           cannot hold this data.
%     The user, however, can try different fixed-point data type to ensure
%     that the output values are comparable with that obtained using double
%     data.
%    
%     There is another reason why we need to use the user-specified
%     precisions: a 'product' or 'sum' operation may result in a larger bit
%     precision which is not supported on the current platform. For
%     example, the user may use fixdt(1,64,x) and this may result in a
%     number that requires more than 128 bit precision which is not
%     supported by Simulink on a 64-bit platform.
%    

%   Copyright 2017 The MathWorks, Inc.

if ~(ischar(dataType) || isstring(dataType))
    % Rounds +ive numbers to +Inf and -ive numbers to -Inf.
    fmSpec.RoundingMethod = 'Round'; 
    % Using the user-specified precision for 'product' operation.
    fmSpec.ProductMode = 'SpecifyPrecision';
    fmSpec.ProductWordLength = int32(dataType.WordLength);
    fmSpec.ProductFractionLength = int32(dataType.FractionLength);
    % Using the user-specified precision for 'sum' operation.
    fmSpec.SumMode = 'SpecifyPrecision';
    fmSpec.SumWordLength = int32(dataType.WordLength);
    fmSpec.SumFractionLength = int32(dataType.FractionLength);
else
    defaultSpec = fimath;
    fmSpec.RoundingMethod = defaultSpec. RoundingMethod;
    fmSpec.ProductMode = defaultSpec.ProductMode;
    fmSpec.ProductWordLength = int32(defaultSpec.ProductWordLength);
    fmSpec.ProductFractionLength = int32(defaultSpec.ProductFractionLength);
    fmSpec.SumMode = defaultSpec.SumMode;
    fmSpec.SumWordLength = int32(defaultSpec.SumWordLength);
    fmSpec.SumFractionLength = int32(defaultSpec.SumFractionLength);
end

end