function fisout = convertToNonhomogenousFISStruct(fisin, varargin)
%% CONVERTTONONHOMOGENOUSFISSTRUCT Converts to a nonhomogenous FIS structure
%
%   FISOUT = CONVERTTONONHOMOGENOUSFISSTRUCT(FISIN) Converts FISIN to a
%   nonhomogenous FIS structure with empty names.
%
%   FISOUT = CONVERTTONONHOMOGENOUSFISSTRUCT(FISIN, addNames) Converts FISIN to a
%   nonhomogenous FIS structure with names if addNames is true. Default
%   value is false.


%  Copyright 2018-2022 The MathWorks, Inc.

if isempty(varargin)
    addNames = false;
else
    addNames = varargin{1};
end


fisout = fisin;
if isfield(fisout,'typeReductionMethod')
    fisout.input = convertVarType2(fisin.input, addNames);
    fisout.output = convertVarType2(fisin.output, addNames);
else
    fisout.input = convertVar(fisin.input, addNames);
    fisout.output = convertVar(fisin.output, addNames);
end
end
%% Helper functions -------------------------------------------------------
function varout = convertVar(varin, addNames)
if isempty(varin)
    varout = varin;
    return
end

numVars = length(varin);
mfStruct = struct('name',' ','type','','params',[]);
varout(1:numVars) = struct('name',' ','range',[],'mf',repmat(mfStruct,[1 0]));
for i = 1:numVars
    var = varin(i);
    if addNames
        varout(i).name = var.name(1:var.origNameLength);
    end
    varout(i).range = var.range;
    numMF = var.origNumMF;
    
    if numMF > 0
        varout(i).mf(1:numMF) = mfStruct;
        for j = 1:numMF
            mf = var.mf(j);
            if addNames
                varout(i).mf(j).name = mf.name(1:mf.origNameLength);
            end
            varout(i).mf(j).type = mf.type(1:mf.origTypeLength);
            varout(i).mf(j).params = mf.params(1:mf.origParamLength);
        end
    else
        varout(i).mf = [];
    end
end

end

function varout = convertVarType2(varin, addNames)
if isempty(varin)
    varout = varin;
    return
end

numVars = length(varin);
mfStruct = struct('name',' ','umftype','','umfparams',[],'lmftype','', ...
    'lmfparams',[],'lmfscale',[],'lmflag',[]);
varout(1:numVars) = struct('name',' ','range',[],'mf',repmat(mfStruct,[1 0]));
for i = 1:numVars
    var = varin(i);
    if addNames
        varout(i).name = var.name(1:var.origNameLength);
    end
    varout(i).range = var.range;
    numMF = var.origNumMF;
    
    if numMF > 0
        varout(i).mf(1:numMF) = mfStruct;
        for j = 1:numMF
            mf = var.mf(j);
            if addNames
                varout(i).mf(j).name = mf.name(1:mf.origNameLength);
            end
            varout(i).mf(j).umftype = mf.umftype(1:mf.origUMFTypeLength);
            varout(i).mf(j).umfparams = mf.umfparams(1:mf.origUMFParamLength);
            varout(i).mf(j).lmftype = mf.lmftype(1:mf.origLMFTypeLength);
            varout(i).mf(j).lmfparams = mf.lmfparams(1:mf.origLMFParamLength);
            varout(i).mf(j).lmfscale = mf.lmfscale;            
            varout(i).mf(j).lmflag = mf.lmflag;            
        end
    else
        varout(i).mf = [];
    end
end

end