function varargout = readfis(varargin)
%

%READFIS Reads fuzzy inference system from a disk file.
%
%  FIS = READFIS(FILENAME) Loads FIS from user specfied FILENAME. FIS is
%  returned as an object. READFIS also updates 
%    - duplicate input/output names,
%    - duplicate input/output membership function names, and
%    - invalid output range of Sugeno FIS.
%
%  FIS = READFIS Loads FIS using file open dialog window.
%
%  [FIS,ERRORMSG] = READFIS(...) Returns error message ERRORMSG if it fails
%  to load FIS from a disk file.
%
%  Example
%    [out,errorMsg] = READFIS('tipper');
%
%  See also
%    fuzzy.internal.utility.updateDuplicateVariableName,
%    fuzzy.internal.utility.updateDuplicateMFName,
%    fuzzy.internal.utility.updateSugenoOutputRange, convertfis

%   Copyright 2017-2018 The MathWorks, Inc.

[varargout{1:nargout}] = fuzzy.internal.utility.readFISAsStructure(varargin{:});

if length(varargout)>1 && ~isempty(varargout{2})
    return
end

if ~isempty(varargout) && ~isempty(varargout{1})
    varargout{1} = fuzzy.internal.utility.updateDuplicateVariableName(varargout{1});
    varargout{1} = fuzzy.internal.utility.updateDuplicateMFName(varargout{1});
    varargout{1} = fuzzy.internal.utility.updateSugenoOutputRange(varargout{1});
    varargout{1} = fuzzy.internal.utility.updateSugenoImplicationAndAggregationMethods(varargout{1});
    s = warning('off','fuzzy:general:warnFismf_RedundantParamValues');
    restoreWarning = onCleanup(@()warning(s));
    if isfield(varargout{1},'typeReductionMethod')
        if varargout{1}.type=="mamdani"
            varargout{1} = fuzzy.internal.utility.createType2MamdaniFISFromStruct(varargout{1});
        else
            varargout{1} = fuzzy.internal.utility.createType2SugenoFISFromStruct(varargout{1});
        end
    else
        varargout{1} = fuzzy.internal.utility.createFromStruct(varargout{1});
        %varargout{1} = convertfis(varargout{1});
    end
end

end