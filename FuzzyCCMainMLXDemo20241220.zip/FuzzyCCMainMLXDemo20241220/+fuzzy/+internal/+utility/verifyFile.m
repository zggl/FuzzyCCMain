function verifyFile(fileName,fid,msg)
%% VERIFYFILE Verifies the specified file indentifier.
%
%  VERIFYFILE(FILENAME,FID,MSG) Throws error if FID is equal to -1. It adds
%  MSG as the cause of the error.

%  Copyright 2020 The MathWorks, Inc.

if fid == -1
    me = MException(message('fuzzy:general:errFileIO_CanNotOpen',fileName));
    me = addCause(me,MException(message('fuzzy:general:errCustomErrorMsg',msg)));
    throw(me)
end

end