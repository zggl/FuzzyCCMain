function range = getFISTreeInputRange(fisT,varargin)
%%

%  Copyright 2023 The MathWorks, Inc.

if isempty(varargin)
    numInputs = numel(fisT.Inputs);
    inputIds = 1:numInputs;
else
    numInputs = numel(varargin{1});
    inputIds = sort(varargin{1});
end
range = zeros(numInputs,2);
ct = 0;
for inId = inputIds
    ct = ct + 1;
    tokens = strsplit(fisT.Inputs(inId),'/');
    fisName = tokens(1);
    varName = tokens(2);
    fisId = find([fisT.FIS.Name]==fisName,1);
    varId = find([fisT.FIS(fisId).Inputs.Name]==varName,1);
    range(ct,:) = fisT.FIS(fisId).Inputs(varId).Range;
end

end