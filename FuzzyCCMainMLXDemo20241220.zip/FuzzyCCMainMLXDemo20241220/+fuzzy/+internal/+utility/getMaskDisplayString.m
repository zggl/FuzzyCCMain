function iconStr = getMaskDisplayString
%

%

%   Copyright 2017 The MathWorks, Inc.

iconStr = [...
    'plot(' ...
    '-2, -0.5, 9, -0.5, 0, 1.5, 6, 1.5,' ... % Bounding box
    '[0 6], [0 0],' ...                      % X axis
    '[1 2 3],[0 1 0],' ...                   % First triangle
    '[2 3 4],[0 1 0],' ...                   % Second triangle
    '[3 4 5],[0 1 0]' ...                    % Third triangle
    ')'];