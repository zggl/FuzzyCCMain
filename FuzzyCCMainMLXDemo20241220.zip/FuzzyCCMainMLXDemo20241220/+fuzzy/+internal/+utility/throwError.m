function throwError(diagnostics,varargin)
%

% throwError - Shows DIAGNOSTICS as an error message using the message
% catalog arguments specified in VARARGIN.
%
%   The error message is shown in
%   - Diagnotic Viewer in case of Simulink.
%   - Command Window in case of MATLAB.

% Copyright 2017-2019 The MathWorks, Inc.

if diagnostics.SimulinkDiagnostic
    MSLException(message(['fuzzy:dialogs:' varargin{1}], ...
        char(diagnostics.Block),varargin{2:end})).throw;
else
    error(message(['fuzzy:general:' varargin{1}],varargin{2:end}));
end

end