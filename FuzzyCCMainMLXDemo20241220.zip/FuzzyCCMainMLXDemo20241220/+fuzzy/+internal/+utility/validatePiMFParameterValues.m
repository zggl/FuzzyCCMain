function validatePiMFParameterValues(params) %#codegen
%

% validatePiMFParameterValues - Validates parameter values of 'pimf'
% membership function.

% Copyright 2017-2021 The MathWorks, Inc.

coder.extrinsic('message', 'warning')

if fuzzy.internal.codegen.isMatlabTarget
    if ~fuzzy.internal.utility.isValidInput(params)
        error(message('fuzzy:general:errMFParameters_invalidValue'))
    end
end
n = fuzzy.internal.codegen.numParamPimf;
coder.internal.errorIf(numel(params)<n, ...
    'fuzzy:general:errPimf_InvalidParamLength')

if fuzzy.internal.codegen.isTargetMATLABOrMEX
    if numel(params) > n
        warning(message('fuzzy:general:warnFismf_RedundantParamValues','Pi-shaped curve',n))
    end
end
end