function result = isFISStructure(fis)
%

%

% ISFISSTRUCTURE(FIS) - Returns true if FIS is a valid fuzzy inference
% system structure, false otherwise.

%   Copyright 2017 The MathWorks, Inc.

result = false;

if ~isstruct(fis)
    return
end

expectedFieldNames = {...
    'name', ...
    'type', ...
    'andMethod', ...
    'orMethod', ...
    'defuzzMethod', ...
    'impMethod', ...
    'aggMethod', ...
    'input', ...
    'output', ...
    'rule'};
if ~all(isfield(fis,expectedFieldNames))
    return
end

if ~isVarValid(fis.input)
    return
end

if ~isVarValid(fis.output)
    return
end

if ~isempty(fis.rule)
    if ~all(isfield(fis.rule,{'antecedent','consequent','weight','connection'}))
        return
    end
end

result = true;

end
%% Helper functions -------------------------------------------------------
function result = isVarValid(var)
if ~isempty(var)
    if ~all(isfield(var,{'name','range','mf'}))
        result = false;
        return
    end
    for i = 1:length(var)
        if ~isempty(var(i).mf)
            if ~all(isfield(var(i).mf,{'name','type','params'}))
                result = false;
                return
            end
        end
    end
end
result = true;
end