function errorIfType2FIS(fis)
%

% errorIfType2FIS(FIS) - Validates FIS input for the FLC block
% with rule viewer. Type-2 FIS is not supported in this block.

%   Copyright 2019 The MathWorks, Inc. 


if isa(fis,'mamfistype2') || isa(fis,'sugfistype2')
    error(message("fuzzy:general:errFIS_unsupportedType2FIS"))
end
end