function fisout = createFromMatrix(fisin)
%

%

%   Copyright 2017 The MathWorks, Inc.

fisout.name = getfisold(fisin, 'name');
fisout.type = getfisold(fisin,'type');
fisout.andMethod = getfisold(fisin,'andMethod');
fisout.orMethod = getfisold(fisin,'orMethod');
fisout.impMethod = getfisold(fisin,'impMethod');
fisout.aggMethod = getfisold(fisin,'aggMethod');
fisout.defuzzMethod = getfisold(fisin,'defuzzMethod');

if fisout.type == "sugeno"
    if fisout.impMethod ~= "prod"
        fisout.impMethod = 'prod';
    end
    if fisout.aggMethod ~= "sum"
        fisout.aggMethod = 'sum';
    end
end

fisout.input = [];
fisout = addVariable(fisin,fisout,'in');
fisout.output = [];
fisout = addVariable(fisin,fisout,'out');

numInputs = length(fisout.input);
numOutputs = length(fisout.output);
numRules = getfisold(fisin,'numRules');
ruleList = getfisold(fisin,'ruleList');
fisout.rule = [];
for ruleIndex=1:numRules
    fisout.rule(ruleIndex).antecedent = ruleList(ruleIndex, 1:numInputs);
    fisout.rule(ruleIndex).consequent = ruleList(ruleIndex, 1+numInputs:numInputs+numOutputs);
    fisout.rule(ruleIndex).weight = ruleList(ruleIndex, 1+numInputs+numOutputs:1+numInputs+numOutputs);
    fisout.rule(ruleIndex).connection = ruleList(ruleIndex, 2+numInputs+numOutputs:end);
end


end
%% Helper functions -------------------------------------------------------
function fisout = addVariable(fisin,fisout,varType)

numVars = getfisold(fisin,['num' varType 'puts']);
numVarMFs = getfisold(fisin,['num' varType 'putmfs']);
varLabels = getfisold(fisin,[varType 'Labels']);
varRange = getfisold(fisin,[varType 'Range']);
varMFLabels = getfisold(fisin,[varType 'MFLabels']);
varMFTypes = getfisold(fisin,[varType 'MFTypes']);
varType = [varType 'put'];

for varIndex = 1:numVars
    fisout.(varType)(varIndex).name = deblank(varLabels(varIndex,:));
    fisout.(varType)(varIndex).range = varRange(varIndex,:);
    for mfIndex = 1:numVarMFs(varIndex)
        MFIndex2 = sum(numVarMFs(1:(varIndex-1)))+mfIndex;
        fisout.(varType)(varIndex).mf(mfIndex).name = deblank(varMFLabels(MFIndex2,:));
        fisout.(varType)(varIndex).mf(mfIndex).type = deblank(varMFTypes(MFIndex2,:));
        p = getfisold(fisin,varType,varIndex,'MF',mfIndex,'params');
        fisout.(varType)(varIndex).mf(mfIndex).params = p;
    end
end

end