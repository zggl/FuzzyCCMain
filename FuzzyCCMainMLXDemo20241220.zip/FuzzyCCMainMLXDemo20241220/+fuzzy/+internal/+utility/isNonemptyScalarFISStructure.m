function result = isNonemptyScalarFISStructure(fis)
%

%

% ISNONEMPTYSCALARFISSTRUCTURE(FIS) - Returns true if FIS is a nonempty
% scalar fuzzy inference system structure, false otherwise.

%   Copyright 2017 The MathWorks, Inc.

result = false;

if isempty(fis)
    return
end

if ~isscalar(fis)
    return
end

result = fuzzy.internal.utility.isFISStructure(fis);

end