function validateZMFParameterValues(params) %#codegen
%

% validateZMFParameterValues - Validates parameter values of 'zmf'
% membership function.

% Copyright 2017-2021 The MathWorks, Inc.

coder.extrinsic('message', 'warning')

if fuzzy.internal.codegen.isMatlabTarget
    if ~fuzzy.internal.utility.isValidInput(params)
        error(message('fuzzy:general:errMFParameters_invalidValue'))
    end
end
n = fuzzy.internal.codegen.numParamZmf;
coder.internal.errorIf(numel(params)<n, ...
    'fuzzy:general:errZmf_InvalidParamLength')

if fuzzy.internal.codegen.isTargetMATLABOrMEX
    if numel(params) > n
        warning(message('fuzzy:general:warnFismf_RedundantParamValues','Z-shaped curve',n))
    end
end
end