function fuzblockmask(CB,irr,rfs,orr,arr)
%

% fuzblockmask - Dynamically add outports according user inputs.

%   Copyright 2017 The MathWorks, Inc. 

Model = bdroot(CB);
if ~any(strcmp(get_param(Model,'SimulationStatus'),...
        {'initializing','updating','stopped'}))
    % Abort any call during simulation (can be triggered by any change in
    % some parent masked subsystem)
    return
end

if strcmp(get_param(Model,'SimulationMode'),'external') && ...
        strcmp(get_param(Model,'SimulationStatus'),'initializing')
    % Abort when initializing in external mode.
    return;
end

% Port names and block names
portNames = {'fi','rfs','ro','ao'};
emlBlockNames = {'Fuzzify Inputs','Apply Operators',...
    'Apply Implication Method','Aggregate Outputs','Defuzzify Outputs',...
    'Evaluate Rule Antecedents','Evaluate Rule Consequents'};

% Expected changes
expectedPortStates = [irr rfs orr arr];
expectedPortNumbers = getExpectedPortNumbers(double(expectedPortStates));
[expectedEMLBlockStates,portToBlock] = getEMLBlockStates(expectedPortStates);

% Find previous port states (presence/absence).
currentPortStates = getCurrentStates(CB,portNames);

% If the current and next port states are the same then return.
if all(currentPortStates == expectedPortStates)
    return;
end

% Current model and warning states
dirtyState = get_param(Model,'Dirty');
restoreDirtyState = onCleanup(@()set_param(Model,'Dirty',dirtyState));

warnOff = ctrlMsgUtils.SuspendWarnings;
restoreWarnState = onCleanup(@()delete(warnOff));

% Find the EML blocks that exist in the model based on current port states.
currentEMLBlockStates = getEMLBlockStates(currentPortStates);

% Delete the lines connected to the EML blocks' I/O ports.
deleteLinesConnectedWithEMLBlocks(CB,currentEMLBlockStates,portNames,...
    currentPortStates);

% Delete the EML blocks.
deleteEMLBlocks(CB,emlBlockNames,currentEMLBlockStates);

% Delete an output port if it is present in the current state and absent in
% the next state.
deleteOutputPortsNotPresentInNextState(CB,portNames,currentPortStates,...
    expectedPortStates);

% Add EML blocks based on the next port states.
addEMLBlocks(CB,emlBlockNames,expectedEMLBlockStates);

% Add an output port if it is absent in the current state and present in
% the next state.
addOutputPortsNotPresentInCurrentState(CB,emlBlockNames,portNames,...
    currentPortStates,expectedPortStates,portToBlock,expectedPortNumbers);

% Connect lines from source output ports to EML input ports.
connectLinesToEMLInputPorts(CB,emlBlockNames,expectedEMLBlockStates);

end
%% Helper functions -------------------------------------------------------
function [currentStates,currentPortNumbers] = getCurrentStates(CB,portNames)
n = length(portNames);
currentStates = zeros(1,n);
currentPortNumbers = zeros(1,n);
for i = 1:n
    port = find_system(CB,'LookUnderMasks','all','FollowLinks','on',...
        'Name',portNames{i});
    currentStates(i) = ~isempty(port);
    if currentStates(i)
        portNumber = get_param(port,'Port');
        currentPortNumbers(i) = eval(portNumber{1});
    end
end
end
% -------------------------------------------------------------------------
function expectedPortNumbers = getExpectedPortNumbers(currentStates)
expectedPortNumbers = currentStates.*(1+cumsum(currentStates));
end
% -------------------------------------------------------------------------
function [emlBlockStates,portToBlock] = getEMLBlockStates(portStates)
emlBlockStates = zeros(1,7);
emlBlockStates(5) = 1; % We always need 'Defuzzify Outputs' block.
portToBlock = zeros(size(portStates));

if portStates(1) % 'fi'
    emlBlockStates(1) = 1; % 'Fuzzify Inputs'
    emlBlockStates(2) = 1; % 'Apply Operators'
    
    portToBlock(1) = 1;
    
    if portStates(2)
        portToBlock(2) = 2;
    end
end

if portStates(2) && ~portStates(1)% only 'rfs'
    emlBlockStates(6) = 1; % 'Evaluate Rule Antecedents'
    
    portToBlock(2) = 6;
end

if ~portStates(1) && ~portStates(2) % Both 'fi' and 'rfs' are absent
    emlBlockStates(6) = 1; % Need 'Evaluate Rule Antecedents' block
end

if portStates(3) % 'ro'
    emlBlockStates(3) = 1; % 'Apply Implication Method'
    emlBlockStates(4) = 1; % 'Aggregate Outputs'
    
    portToBlock(3) = 3;
    
    if portStates(4)
        portToBlock(4) = 4;
    end
end

if portStates(4) && ~portStates(3) % only 'ao'
    emlBlockStates(7) = 1; % 'Evaluate Rule Consequents'
    
    portToBlock(4) = 7;
end

if ~portStates(3) && ~portStates(4) % Both 'ro' and 'ao' are absent
    emlBlockStates(7) = 1; % Need 'Evaluate Rule Consequents' block
end

end
% -------------------------------------------------------------------------
function deleteLinesConnectedWithEMLBlocks(CB,currentEMLBlockStates,...
    portNames,portStates)
if currentEMLBlockStates(1)
    delete_line(CB,'InputConversion/1','Fuzzify Inputs/1');
    if portStates(1)
        delete_line(CB,'Fuzzify Inputs/1',[portNames{1} '/1']);
    end
end

if currentEMLBlockStates(2)
    delete_line(CB,'Fuzzify Inputs/1','Apply Operators/1');
    
    delete_line(CB,'Apply Operators/2','Defuzzify Outputs/1');
    
    if portStates(2)
        delete_line(CB,'Apply Operators/1',[portNames{2} '/1']);
    end
    
end

if currentEMLBlockStates(3)
    delete_line(CB,'InputConversion/1','Apply Implication Method/1');
    if currentEMLBlockStates(2)
        delete_line(CB,'Apply Operators/1','Apply Implication Method/2');
    elseif currentEMLBlockStates(6)
        delete_line(CB,'Evaluate Rule Antecedents/1',...
            'Apply Implication Method/2');
    end
    delete_line(CB,'Output Sample Points/1','Apply Implication Method/3');
    
    if portStates(3)
        delete_line(CB,'Apply Implication Method/1',[portNames{3} '/1']);
    end
end

if currentEMLBlockStates(4)
    delete_line(CB,'Apply Implication Method/1','Aggregate Outputs/1');
    delete_line(CB,'Aggregate Outputs/1','Defuzzify Outputs/2');
    
    if portStates(4)
        delete_line(CB,'Aggregate Outputs/1',[portNames{4} '/1']);
    end
end

if currentEMLBlockStates(6)
    delete_line(CB,'InputConversion/1','Evaluate Rule Antecedents/1');
    delete_line(CB,'Evaluate Rule Antecedents/2','Defuzzify Outputs/1');
    
    if portStates(2)
        delete_line(CB,'Evaluate Rule Antecedents/1',[portNames{2} '/1']);
    end
    
end

if currentEMLBlockStates(7)
    delete_line(CB,'InputConversion/1','Evaluate Rule Consequents/1');
    if currentEMLBlockStates(6)
        delete_line(CB,'Evaluate Rule Antecedents/1',...
            'Evaluate Rule Consequents/2');
    elseif currentEMLBlockStates(2)
        delete_line(CB,'Apply Operators/1','Evaluate Rule Consequents/2');
    end
    delete_line(CB,'Output Sample Points/1','Evaluate Rule Consequents/3');
    delete_line(CB,'Evaluate Rule Consequents/1','Defuzzify Outputs/2');
    
    if portStates(4)
        delete_line(CB,'Evaluate Rule Consequents/1',[portNames{4} '/1']);
    end
    
end

end
% -------------------------------------------------------------------------
function deleteEMLBlocks(CB,emlBlockNames,currentEMLBlockStates)
for i = 1:length(currentEMLBlockStates)
    if currentEMLBlockStates(i) && i~=5
        delete_block([CB '/' emlBlockNames{i}]);
    end
end
end
% -------------------------------------------------------------------------
function deleteOutputPortsNotPresentInNextState(CB,portNames,...
    currentPortStates,expectedPortStates)
for i = 1:length(currentPortStates)
    if currentPortStates(i) && ~expectedPortStates(i)
        delete_block([CB '/' portNames{i}]);
    end
end
end
% -------------------------------------------------------------------------
function addEMLBlocks(CB,emlBlockNames,expectedEMLBlockStates)
position1 = get_param([CB '/InputConversion'],'Position');
position2 = get_param([CB '/Defuzzify Outputs'],'Position');
X = position2(1);
Y = position1(2);
width = position2(3) - position2(1);
height = position2(4) - position2(2);
for i = 1:length(expectedEMLBlockStates)
    if i ~= 5
        if expectedEMLBlockStates(i)
            position = [X Y X+width Y+height];
            add_block([getLibName '/' emlBlockNames{i}],...
                [CB '/' emlBlockNames{i}],'Position',position);
            Y = position(4) + 0.25*height;
        end
    end
end
end
% -------------------------------------------------------------------------
function addOutputPortsNotPresentInCurrentState(CB,emlBlockNames,portNames,...
    currentPortStates,expectedPortStates,portToBlock,portNumbers)

portPosition = get_param([CB '/out'],'Position');
portHeight = portPosition(4) - portPosition(2);

for i = 1:length(expectedPortStates)
    if expectedPortStates(i)
        position = get_param([CB '/' emlBlockNames{portToBlock(i)}],'Position');
        height = position(4) - position(2);
        portPosition(2) = position(2)+height*2/5;
        portPosition(4) = portPosition(2) + portHeight;
        if currentPortStates(i)
            set_param([CB '/' portNames{i}],'Position',portPosition);
            set_param([CB '/' portNames{i}],'Port',num2str(portNumbers(i)));
        else
            add_block('built-in/Outport',[CB '/' portNames{i}],...
                'Position',portPosition,'Port',num2str(portNumbers(i)));
        end
        
        add_line(CB,[emlBlockNames{portToBlock(i)} '/1'],[portNames{i} '/1'],...
            'autorouting','on');
    end
end
end
% -------------------------------------------------------------------------
function connectLinesToEMLInputPorts(CB,emlBlockNames,expectedEMLBlockStates)

% Fuzzify Inputs
if expectedEMLBlockStates(1)
    add_line(CB,'InputConversion/1',[emlBlockNames{1} '/1'],...
        'autorouting','on');
end

% Apply Operators
if expectedEMLBlockStates(2)
    add_line(CB,[emlBlockNames{1} '/1'],[emlBlockNames{2} '/1'],...
        'autorouting','on');
end

% Apply Implication Method
if expectedEMLBlockStates(3)
    add_line(CB,'InputConversion/1',[emlBlockNames{3} '/1'],...
        'autorouting','on');
    if expectedEMLBlockStates(2)
        add_line(CB,[emlBlockNames{2} '/1'],[emlBlockNames{3} '/2'],...
            'autorouting','on');
    elseif expectedEMLBlockStates(6)
        add_line(CB,[emlBlockNames{6} '/1'],[emlBlockNames{3} '/2'],...
            'autorouting','on');
    end
    add_line(CB,'Output Sample Points/1',[emlBlockNames{3} '/3'],...
        'autorouting','on');
end

% Aggregate Outputs
if expectedEMLBlockStates(4)
    add_line(CB,[emlBlockNames{3} '/1'],[emlBlockNames{4} '/1'],...
        'autorouting','on');
end

% Evaluate Rule Antecedents
if expectedEMLBlockStates(6)
    add_line(CB,'InputConversion/1',[emlBlockNames{6} '/1'],...
        'autorouting','on');
end

% Evaluate Rule Consequents
if expectedEMLBlockStates(7)
    add_line(CB,'InputConversion/1',[emlBlockNames{7} '/1'],...
        'autorouting','on');
    if expectedEMLBlockStates(2)
        add_line(CB,[emlBlockNames{2} '/1'],[emlBlockNames{7} '/2'],...
            'autorouting','on');
    elseif expectedEMLBlockStates(6)
        add_line(CB,[emlBlockNames{6} '/1'],[emlBlockNames{7} '/2'],...
        'autorouting','on');
    end
    add_line(CB,'Output Sample Points/1',[emlBlockNames{7} '/3'],...
        'autorouting','on');
end

% Defuzzify Outputs
if expectedEMLBlockStates(2)
    add_line(CB,[emlBlockNames{2} '/2'],[emlBlockNames{5} '/1'],...
        'autorouting','on');
elseif expectedEMLBlockStates(6)
    add_line(CB,[emlBlockNames{6} '/2'],[emlBlockNames{5} '/1'],...
        'autorouting','on');
end
if expectedEMLBlockStates(4)
    add_line(CB,[emlBlockNames{4} '/1'],[emlBlockNames{5} '/2'],...
        'autorouting','on');
elseif expectedEMLBlockStates(7)
    add_line(CB,[emlBlockNames{7} '/1'],[emlBlockNames{5} '/2'],...
        'autorouting','on');
end

end
% -------------------------------------------------------------------------
function libName = getLibName
libName = 'fuzwiz';
end