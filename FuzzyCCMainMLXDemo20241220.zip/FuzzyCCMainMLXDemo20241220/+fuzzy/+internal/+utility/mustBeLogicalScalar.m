function mustBeLogicalScalar(name,value)
%%

%  Copyright 2023 The MathWorks, Inc.

yes = ~isempty(value) && isscalar(value) && ...
    (islogical(value) || isnumeric(value)) && isreal(value) && ...
    (value==1 || value==0 || value==true || value==false);

if ~yes
    error(message('fuzzy:general:errLogicalFlag_InvalidValue',name))
end

end