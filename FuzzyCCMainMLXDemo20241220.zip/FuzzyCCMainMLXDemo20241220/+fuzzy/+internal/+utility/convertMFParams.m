function [outParams,errorStr] = convertMFParams(inParams,inType,outType,tol)
%% CONVERTMFPARAMS Convert MF parameter values to a different type.
%
%   OUTPARAMS = CONVERTMFPARAMS(INPARAMS,INTYPE,OUTTYPE) Converts INPARAMS
%   of INTYPE MF to OUTTYPE MF parameter values.
%
%   Examples
%     outParams = convertMFParams([1 2 3],"trimf","trapmf");

%  Copyright 2018-2022 The MathWorks, Inc.

yWaist=0.5;
yShoulder=0.90;
errorStr=[];
throwError = (nargout<2);
if inType == "trimf"
    lftWaist=yWaist*(inParams(2)-inParams(1))+inParams(1);
    lftShoulder=yShoulder*(inParams(2)-inParams(1))+inParams(1);
    rtShoulder=(1-yShoulder)*(inParams(3)-inParams(2))+inParams(2);
    rtWaist=(1-yWaist)*(inParams(3)-inParams(2))+inParams(2);

elseif any(inType == ["trapmf" "pimf"])
    lftWaist=yWaist*(inParams(2)-inParams(1))+inParams(1);
    lftShoulder=yShoulder*(inParams(2)-inParams(1))+inParams(1);
    rtShoulder=(1-yShoulder)*(inParams(4)-inParams(3))+inParams(3);
    rtWaist=(1-yWaist)*(inParams(4)-inParams(3))+inParams(3);

elseif inType == "gaussmf"
    lftWaist=-abs(inParams(1))*sqrt(-2*log(yWaist))+inParams(2);
    lftShoulder=-abs(inParams(1))*sqrt(-2*log(yShoulder))+inParams(2);
    rtShoulder=2*inParams(2)-lftShoulder;
    rtWaist=2*inParams(2)-lftWaist;

elseif inType == "gauss2mf"
    lftWaist=-abs(inParams(1))*sqrt(-2*log(yWaist))+inParams(2);
    lftShoulder=inParams(2);
    rtShoulder=inParams(4);
    rtWaist=abs(inParams(3))*sqrt(-2*log(yWaist))+inParams(4);

elseif inType == "gbellmf"
    lftWaist=-inParams(1)*((1/yWaist-1)^(1/(2*inParams(2))))+inParams(3);
    lftShoulder=-inParams(1)*((1/yShoulder-1)^(1/(2*inParams(2))))+inParams(3);
    rtShoulder=2*inParams(3)-lftShoulder;
    rtWaist=2*inParams(3)-lftWaist;

elseif inType  == "sigmf"
    if inParams(1)>0
        lftWaist=inParams(2);
        lftShoulder=-1/inParams(1)*log(1/yShoulder-1)+inParams(2);
        rtShoulder=2*lftShoulder-lftWaist;
        rtWaist=2*rtShoulder-lftWaist;
    else
        rtWaist=inParams(2);
        rtShoulder=-1/inParams(1)*log(1/yShoulder-1)+inParams(2);
        lftShoulder=rtShoulder;
        lftWaist=2*lftShoulder-rtWaist;
    end

elseif inType  == "dsigmf"
    lftWaist=inParams(2);
    lftShoulder=-1/inParams(1)*log(1/yShoulder-1)+inParams(2);
    rtWaist=inParams(4);
    rtShoulder=1/inParams(3)*log(1/yShoulder-1)+inParams(4);

elseif inType  == "psigmf"
    lftWaist=inParams(2);
    lftShoulder=-1/inParams(1)*log(1/yShoulder-1)+inParams(2);
    rtWaist=inParams(4);
    rtShoulder=-1/inParams(3)*log(1/yShoulder-1)+inParams(4);

elseif any(inType  == ["smf" "linsmf"])
    lftShoulder=yShoulder*(inParams(2)-inParams(1))+inParams(1);
    rtShoulder=inParams(2);
    if inParams(1)<inParams(2)
        lftWaist=inParams(1);
        rtWaist=2*inParams(2)-inParams(1);
    else
        lftWaist=2*inParams(2)-inParams(1);
        rtWaist=inParams(1);
    end

elseif any(inType  == ["zmf" "linzmf"])
    lftShoulder=inParams(2);
    rtShoulder=inParams(2);
    if inParams(1)<inParams(2)
        lftWaist=inParams(1);
        rtWaist=2*inParams(2)-inParams(1);
    else
        lftWaist=2*inParams(2)-inParams(1);
        rtWaist=inParams(1);
    end
else
    % Input MF type is unknown
    outParams=[];    
    errorStr=fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
        'errInputMembershipFunction_UnknownType');
    return
end

% We've translated into generalized coordinates, now translate back into
% MF specific parameters...

if nargin<4
    tol=max(eps, 1e-3*(rtShoulder-lftShoulder));
end


if outType == "trimf"
    center=(rtShoulder+lftShoulder)/2;
    % Assumes yWaist=0.5
    outParams=sort([2*lftWaist-center center 2*rtWaist-center]);

elseif outType == "trapmf"
    % Assumes yWaist=0.5
    outParams=sort([2*lftWaist-lftShoulder lftShoulder rtShoulder 2*rtWaist-rtShoulder]);
    
elseif outType == "pimf"
    % Assumes yWaist=0.5
    outParams=[2*lftWaist-lftShoulder lftShoulder rtShoulder max(tol,2*rtWaist-rtShoulder)];

elseif outType == "gbellmf"
    center=(rtShoulder+lftShoulder)/2;
    a=max(tol,center-lftWaist);
    b=2*a/(max(tol,lftShoulder-lftWaist));
    outParams=[a b center];

elseif outType == "gaussmf"
    center=(rtShoulder+lftShoulder)/2;
    sigma=max(tol,(rtWaist-center)/sqrt(-2*log(yWaist)));
    outParams=[sigma center];

elseif outType == "gauss2mf"
    lftSigma=max(tol,lftShoulder-lftWaist)/sqrt(-2*log(yWaist));
    rtSigma=max(tol,rtWaist-rtShoulder)/sqrt(-2*log(yWaist));
    outParams=[lftSigma lftShoulder rtSigma rtShoulder];

elseif outType == "sigmf"
    center=lftWaist;
    a=-1/max(tol,lftShoulder-center)*log(1/yShoulder-1);
    outParams=[a center];

elseif outType == "dsigmf"
    lftCenter=lftWaist;
    lftA=-1/max(tol,lftShoulder-lftCenter)*log(1/yShoulder-1);
    rtCenter=rtWaist;
    rtA=-1/max(tol,rtCenter-rtShoulder)*log(1/yShoulder-1);
    k = 2;
    outParams=[k*lftA lftCenter k*rtA rtCenter];

elseif outType == "psigmf"
    lftCenter=lftWaist;
    lftA=-1/max(tol,lftShoulder-lftCenter)*log(1/yShoulder-1);
    rtCenter=rtWaist;
    rtA=1/max(tol,rtCenter-rtShoulder)*log(1/yShoulder-1);
    k = 2;
    outParams=[k*lftA lftCenter k*rtA rtCenter];


elseif outType == "smf"
    % Assumes yWaist=0.5
    outParams=[2*lftWaist-lftShoulder lftShoulder];

elseif outType == "zmf"
    % Assumes yWaist=0.5
    outParams=[rtShoulder 2*rtWaist-rtShoulder];

elseif outType == "linsmf"
    outParams = sort([2*lftWaist-lftShoulder lftShoulder]);

elseif outType == "linzmf"
    outParams = sort([rtShoulder 2*rtWaist-rtShoulder]);

else
    % Output MF type is unknown
    outParams=[];
    errorStr=fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
        'errOutputMembershipFunction_UnknownType');
    return
end

outParams = eval(mat2str(outParams,4));

end