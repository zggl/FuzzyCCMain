function plotfis(fis,varargin)
%%

%  Copyright 2021-2023 The MathWorks, Inc.

[fis,fig] = init(fis,varargin{:});

[xi,yi,xo,yo,r] = discfis(fis,181);

[ax,axCenterX,axCenterY] = createMainAxes(fis,fig);

% Use of plot commands requires a few reconfigurations of the figure and
% main axes properties.
hold(ax,"on")
resetHold = onCleanup(@()hold(ax,"off"));
setNextPlot = onCleanup(@()set(fig,'NextPlot','replace'));

createInputAxes(fis,ax,axCenterX,axCenterY,xi,yi,r)

createOutputAxes(fis,ax,axCenterX,axCenterY,xo,yo,r)

createSystemAxes(fis,ax)

drawnow

hndlList = findobj(fig,'Units','pixels');
set(hndlList,'Units','normalized')
end

%% Local functions --------------------------------------------------------
function [fis,fig] = init(fis,varargin)
%% Takes appropriate steps for setup.

if ~isempty(varargin)
    warning(message('fuzzy:general:warnParamNotSupported'))
end

if ~isa(fis,'FuzzyInferenceSystem')
    warning(message('fuzzy:general:warnDeprecation_FISStructure'))
    fis = convertfis(fis);
end

if isempty(fis.input) || isempty(fis.output)
    error(message('fuzzy:general:errFIS_MissingInputOrOutputVariable'));
end

fig = gcf;
if strcmp(get(fig,'NextPlot'),'new')
    fig = figure;
else
    delete(findobj(allchild(fig),'type','Axes','tag','oneOfPlotFisAxes'));
end

set(fig,'NextPlot','replace')
end

function [mainAxes,xCenter,yCenter] = createMainAxes(fis,figNumber)
%% Creates main axes.

% Get current axes handle.
mainAxes = gca;
mainAxes.Units = 'pixel';
mainAxPos = mainAxes.Position;
axList = findobj(figNumber,'Type','axes');
delete(axList) % Delete existing axes

% Constructs an axes.
mainAxes = axes( ...
    'Visible','off', ...
    'Units','pixel', ...
    'HandleVisibility','on',...
    'Position',mainAxPos,...
    'XLim',[mainAxPos(1) mainAxPos(1)+mainAxPos(3)],...
    'YLim',[mainAxPos(2) mainAxPos(2)+mainAxPos(4)],...
    'Tag','oneOfPlotFisAxes');

% Set properties
mainAxes.Toolbar.Visible = 'off';
mainAxes.XLabel.Interpreter = 'none';
matlab.graphics.interaction.disableDefaultAxesInteractions(mainAxes)

XlabelStr = sprintf(getString(message('fuzzy:general:msgPlotfisXLabelFormat')),...
    fis.Name,numel(fis.Inputs),numel(fis.Outputs),numel(fis.Rules));
fontSize = get(0,'DefaultUIControlFontSize');
mainAxes.XLabel.String = XlabelStr;
mainAxes.XLabel.Visible = 'on';
mainAxes.XLabel.FontSize = fontSize;

% Get axes properties.
xCenter=mainAxPos(1)+mainAxPos(3)/2;
yCenter=mainAxPos(2)+mainAxPos(4)/2;
end

function createInputAxes(fis,ax,axCenterX,axCenterY,xi,yi,r)
%% Creates input axes.

left = ax.Position(1);
top = ax.Position(2);
axWidth = ax.Position(3);
axHeight = ax.Position(4);

boxWid = (1/3)*axWidth;
xInset = boxWid/5;

numInputs = numel(fis.Inputs);
numInputMFs = fuzzy.internal.utility.getVarMFs(fis.input);
numRules = numel(fis.Rules);

if numInputs>0
    boxHt=(1/(numInputs))*axHeight;
    yInset=boxHt*.3;
end

n = sum(numInputMFs);
for varIndex = 1:numInputs
    boxLft = left;
    boxBtm = top+axHeight-boxHt*varIndex;
    axPos=[boxLft+xInset boxBtm+yInset boxWid-2*xInset max(boxHt/2,boxHt-2*yInset)];
    % Draw the line that connects the input to the main block
    % Make it a dotted line if the variable is not used in the rule base
    if numRules==0 || ~any(r(:,varIndex))
        lineStyle = '--';
    else
        lineStyle = '-';
    end
    xInputCenter = axPos(1)+axPos(3);
    yInputCenter = axPos(2)+axPos(4)/2;
    line(...
        'Parent',ax,...
        'XData',[xInputCenter axCenterX], ...
        'YData',[yInputCenter axCenterY], ...
        'LineStyle',lineStyle, ... 
        'LineWidth',2 ...
        );

    varName = fis.input(varIndex).name;
    mfIndex = (1:numInputMFs(varIndex))+sum(numInputMFs(1:(varIndex-1)));

    axHndl = axes( ...
        'Units','pixel', ...
        'Position',axPos, ...
        'HandleVisibility','on' ...
        );
    axHndl.XLabel.Interpreter = 'none';

    if isa(fis,'fuzzy.internal.fis.Type1FuzzyInferenceSystem')
        x = xi(:,mfIndex);
        y = yi(:,mfIndex);
    else
        x = [xi(:,mfIndex);flip(xi(:,n+mfIndex))];
        y = [yi(:,mfIndex);flip(yi(:,n+mfIndex))];
    end
    plot(axHndl,x,y);
    set(get(axHndl,'xLabel'),...
        'String',sprintf('%s (%d)',varName,numInputMFs(varIndex)),...
        'FontSize',get(0,'DefaultUIControlFontSize'))
    xMin = min(x,[],"all");
    xMax = max(x,[],"all");
    xiInset = (xMax(1)-xMin(1))/10;
    axHndl.XLim = [xMin-xiInset xMax+xiInset];
    axHndl.YLim = [-0.1 1.1];
    % PLOT command resets the following axes properties. So, set these
    % property values at the end.
    axHndl.Toolbar.Visible = 'off';
    axHndl.Box = 'on';
    axHndl.XTick = [];
    axHndl.YTick = [];
    axHndl.LineWidth = 2;
    axHndl.Tag = 'oneOfPlotFisAxes';
    matlab.graphics.interaction.disableDefaultAxesInteractions(axHndl)
end

end

function createOutputAxes(fis,ax,axCenterX,axCenterY,xo,yo,r)
%% Creates output axes.

numInputs = numel(fis.Inputs);
numOutputs = numel(fis.Outputs);
numOutputMFs = fuzzy.internal.utility.getVarMFs(fis.Outputs);
numRules = numel(fis.Rules);

left = ax.Position(1);
top = ax.Position(2);
axWidth = ax.Position(3);
axHeight = ax.Position(4);
fontSize = get(0,'DefaultUIControlFontSize');
boxWid = (1/3)*axWidth;
xInset = boxWid/5;

if numOutputs>0
    boxHt = (1/(numOutputs))*axHeight;
    yInset = boxHt/(numOutputs+2);
end

n = sum(numOutputMFs);
for varIndex = 1:numOutputs
    boxLft = left+2*boxWid;
    boxBtm = top+axHeight-boxHt*varIndex;
    axPos = [boxLft+xInset boxBtm+yInset boxWid-2*xInset boxHt-2*yInset];

    % Draw the line connect the center block to the output
    % Make it a dotted line if the variable is not used in the rule base
    if numRules==0 || ~any(r(:,varIndex+numInputs))
        lineStyle='--';
    else
        lineStyle='-';
    end
    line(...
        'Parent',ax,...
        'XData',[axPos(1) axCenterX], ...
        'YData',[axPos(2)+axPos(4)/2 axCenterY], ...
        'LineWidth',2, ...
        'LineStyle',lineStyle ...
        );

    varName = fis.output(varIndex).name;
    axHndl = axes( ...
        'Units','pixel', ...
        'Position',axPos,...
        'HandleVisibility','on' ...
        );
    axHndl.XLabel.Interpreter = 'none';
    mfIndex = (1:numOutputMFs(varIndex))+sum(numOutputMFs(1:(varIndex-1)));
    if ~isempty(yo)
        % Don't try to plot outputs it if it's a Sugeno-style system
        if isa(fis,'fuzzy.internal.fis.Type1FuzzyInferenceSystem')
            x = xo(:,mfIndex);
            y = yo(:,mfIndex);
        else
            x = [xo(:,mfIndex);flip(xo(:,n+mfIndex))];
            y = [yo(:,mfIndex);flip(yo(:,n+mfIndex))];
        end
        plot(axHndl,x,y);
        xMin = min(x,[],"all");
        xMax = max(x,[],"all");
        xoInset = (xMax(1)-xMin(1))/10;
        axHndl.XLim = [xMin-xoInset xMax+xoInset];
        axHndl.YLim = [-0.1 1.1];
    else
        set(axHndl,'XLim',[-1 1],'YLim',[-1 1])
        text(0,0,'f(u)', ...
            'Parent',axHndl,...
            'FontSize',fontSize, ...
            'HorizontalAlignment','center');
    end
    set(get(axHndl,'XLabel'),...
        'String',sprintf('%s (%d)',varName,numOutputMFs(varIndex)), ...
        'FontSize',fontSize)
    % PLOT command resets the following axes properties. So, set these
    % property values at the end.
    axHndl.Toolbar.Visible = 'off';
    axHndl.Box = 'on';
    axHndl.XTick = [];
    axHndl.YTick = [];
    axHndl.LineWidth = 2;
    axHndl.Tag = 'oneOfPlotFisAxes';
    matlab.graphics.interaction.disableDefaultAxesInteractions(axHndl)
end
end

function createSystemAxes(fis,ax)
%% Creates system box.

numInputs = numel(fis.Inputs);
numOutputs = numel(fis.Outputs);
numRules = numel(fis.Rules);

left = ax.Position(1);
top = ax.Position(2);
axWidth = ax.Position(3);
axHeight = ax.Position(4);
fontSize = get(0,'DefaultUIControlFontSize');
boxWid = (1/3)*axWidth;
xInset = boxWid/5;


boxLft = left+boxWid;
boxBtm = top;
boxHt = axHeight;
yInset=boxHt/(max(numInputs,numOutputs)+2);
axPos=[boxLft+xInset boxBtm+yInset boxWid-2*xInset boxHt-2*yInset];
axHndl=axes( ...
    'Units','pixel', ...
    'Box','on', ...
    'XTick',[],'YTick',[], ...
    'YLim',[-1 1],'XLim',[-1 1], ...
    'LineWidth',2, ...
    'Position',axPos,...
    'HandleVisibility','on',...
    'Tag','oneOfPlotFisAxes' ...
    );
axHndl.XLabel.String = fis.Name+" ("+num2str(numRules)+" )";
axHndl.Toolbar.Visible = 'off';
matlab.graphics.interaction.disableDefaultAxesInteractions(axHndl)

fisType = [string(getString(message('fuzzy:general:msgSugeno'))) ...
    string(getString(message('fuzzy:general:msgMamdani')))];
mfType = [string(getString(message('fuzzy:general:msgType1'))) ...
    string(getString(message('fuzzy:general:msgType2')))];
label = sprintf('%s\n%s', ...
    fisType(double(isa(fis,'fuzzy.internal.fis.MamdaniFuzzyInferenceSystem'))+1), ...
    mfType(double(isa(fis,'fuzzy.internal.fis.Type2FuzzyInferenceSystem'))+1));
text(0,0,label, ...
    'Parent',axHndl,...
    'FontSize',fontSize, ...
    'HorizontalAlignment','center');
set(get(axHndl,'Title'),'FontSize',fontSize)
end
