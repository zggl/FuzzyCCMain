function validateFISForEvaluation(fis)
%

%

%   Copyright 2017-2023 The MathWorks, Inc.

if isa(fis,'fistree')
    for fs = fis.FIS
        fuzzy.internal.utility.validateFIS(fs)
        fuzzy.internal.utility.checkMinInOutRuleRequirement(fs)
    end
else
    fuzzy.internal.utility.validateFIS(fis)
    fuzzy.internal.utility.checkMinInOutRuleRequirement(fis)
end

end
