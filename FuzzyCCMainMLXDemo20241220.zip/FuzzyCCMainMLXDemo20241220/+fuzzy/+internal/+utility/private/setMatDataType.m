function out = setMatDataType(in,dataType)
%

% setMatDataType - Sets numeric data to the specified data type.

%   Copyright 2017 The MathWorks, Inc.

if ischar(dataType) || isstring(dataType)
    out = cast(in,convertStringsToChars(dataType));
else   
    out = fi(in,dataType);
end

end