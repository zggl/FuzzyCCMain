function out = makeHomogenousMF(in)
%

% makeHomogenousMF - Creates MF array structures with homogenous fields.

%   Copyright 2017-2018 The MathWorks, Inc.

numVar = length(in);

maxNumMF = 0;
maxMFTypeLength = 0;
maxMFParamLength = 0;
for i=1:numVar
    n = numel(in(i).mf);
    if  n > maxNumMF
        maxNumMF = n;
    end
    % Using CHAR inside the LENGTH function to get it working for STRING
    % values as well.
    for ii = 1:n
        mf = in(i).mf(ii);
        n = numel(char(mf.type));
        if n > maxMFTypeLength
            maxMFTypeLength = n;
        end
        n = numel(mf.params);
        if n > maxMFParamLength
            maxMFParamLength = n;
        end
    end
end

mfStruct = struct(...
    'type',char(zeros(1,maxMFTypeLength)),...
    'origTypeLength',0, ...
    'params',zeros(1,maxMFParamLength),...
    'origParamLength',0);

mfVal(1:maxNumMF) = mfStruct;
varStruct = struct(...
    'mf',mfVal,...
    'origNumMF',0 ...
    );
out(1:numVar) = varStruct;

for i=1:numVar
    out(i).origNumMF = numel(in(i).mf);
    for j=1:out(i).origNumMF
        % Using CHAR to get it working for STRING values as well.
        mf = in(i).mf(j);
        type = char(mf.type);
        typeLength = length(type);
        out(i).mf(j).type(1:typeLength) = type;
        out(i).mf(j).origTypeLength = typeLength;
        paramLength = length(mf.params);
        out(i).mf(j).params(1:paramLength) = mf.params;
        out(i).mf(j).origParamLength = paramLength;
    end
end

end