function out = makeHomogenousMFType2(in)
%

% makeHomogenousMFType2 - Creates MF array structures with homogenous fields.

%   Copyright 2019 The MathWorks, Inc.

numVar = length(in);

maxNumMF = 0;
maxUMFTypeLength = 0;
maxUMFParamLength = 0;
maxLMFTypeLength = 0;
maxLMFParamLength = 0;
for i=1:numVar
    n = numel(in(i).mf);
    if  n > maxNumMF
        maxNumMF = n;
    end
    % Using CHAR inside the LENGTH function to get it working for STRING
    % values as well.
    for ii = 1:n
        mf = in(i).mf(ii);
        n = numel(char(mf.umftype));
        if n > maxUMFTypeLength
            maxUMFTypeLength = n;
        end
        n = numel(mf.umfparams);
        if n > maxUMFParamLength
            maxUMFParamLength = n;
        end
        n = numel(char(mf.lmftype));
        if n > maxLMFTypeLength
            maxLMFTypeLength = n;
        end
        n = numel(mf.lmfparams);
        if n > maxLMFParamLength
            maxLMFParamLength = n;
        end
    end
end

mfStruct = struct(...
    'umftype',char(zeros(1,maxUMFTypeLength)),...
    'origUMFTypeLength',0, ...
    'umfparams',zeros(1,maxUMFParamLength),...
    'origUMFParamLength',0, ...
    'lmftype',char(zeros(1,maxLMFTypeLength)),...
    'origLMFTypeLength',0, ...
    'lmfparams',zeros(1,maxLMFParamLength),...
    'origLMFParamLength',0, ...
    'lmfscale',1, ...
    'lmflag',[0.2 0.2] ...
    );

mfVal(1:maxNumMF) = mfStruct;
varStruct = struct(...
    'mf',mfVal,...
    'origNumMF',0 ...
    );
out(1:numVar) = varStruct;

for i=1:numVar
    out(i).origNumMF = numel(in(i).mf);
    for j=1:out(i).origNumMF
        % Using CHAR to get it working for STRING values as well.
        mf = in(i).mf(j);
        % Upper MF
        type = char(mf.umftype);
        typeLength = length(type);
        out(i).mf(j).umftype(1:typeLength) = type;
        out(i).mf(j).origUMFTypeLength = typeLength;
        paramLength = length(mf.umfparams);
        out(i).mf(j).umfparams(1:paramLength) = mf.umfparams;
        out(i).mf(j).origUMFParamLength = paramLength;
        % Lower MF
        type = char(mf.lmftype);
        typeLength = length(type);
        out(i).mf(j).lmftype(1:typeLength) = type;
        out(i).mf(j).origLMFTypeLength = typeLength;
        paramLength = length(mf.lmfparams);
        out(i).mf(j).lmfparams(1:paramLength) = mf.lmfparams;
        out(i).mf(j).origLMFParamLength = paramLength;        
        out(i).mf(j).lmfscale = mf.lmfscale;
        out(i).mf(j).lmflag = mf.lmflag;
    end
end

end