function outputSamplePoints = createOutputSamplePoints(fis,numSamples)
%

% createOutputSamplePoints - Creates sample points for output
% discretization.

%   Copyright 2017-2018 The MathWorks, Inc.

if strcmp(fis.type,'mamdani')
    numOutputs = numel(fis.output);
    outputSamplePoints = zeros(numOutputs,numSamples);
    for outputID = 1:numOutputs
        range = fis.output(outputID).range;
        outputSamplePoints(outputID,:) = linspace(range(1),range(2),numSamples);
    end
else
    outputSamplePoints = 0;
end

end