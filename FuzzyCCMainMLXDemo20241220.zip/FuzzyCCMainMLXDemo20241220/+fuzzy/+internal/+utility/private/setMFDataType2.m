function var = setMFDataType2(var,dataType)
%

% setMFDataType2 - Sets data types of MF structure fields. 
% 
%     The 'umftype' and 'lmftype' fields are set to UINT8 since Simulink
%     does not allow CHAR values. Note that the 'umftype' and 'lmftype'
%     values are not in STRING format since MAKEHOMOGENOUSMF function
%     creates these fields with CHAR data types. 

%   Copyright 2019 The MathWorks, Inc.

for i = 1:length(var)
    var(i).origNumMF = int32(var(i).origNumMF);
    for j = 1:length(var(i).mf)
        var(i).mf(j).umftype = uint8(var(i).mf(j).umftype);
        var(i).mf(j).origUMFTypeLength = int32(var(i).mf(j).origUMFTypeLength);
        var(i).mf(j).umfparams = setMatDataType(var(i).mf(j).umfparams,dataType);
        var(i).mf(j).origUMFParamLength = int32(var(i).mf(j).origUMFParamLength);
        
        var(i).mf(j).lmftype = uint8(var(i).mf(j).lmftype);
        var(i).mf(j).origLMFTypeLength = int32(var(i).mf(j).origLMFTypeLength);
        var(i).mf(j).lmfparams = setMatDataType(var(i).mf(j).lmfparams,dataType);
        var(i).mf(j).origLMFParamLength =int32(var(i).mf(j).origLMFParamLength);
        var(i).mf(j).lmfscale = setMatDataType(var(i).mf(j).lmfscale,dataType);
        var(i).mf(j).lmflag = setMatDataType(var(i).mf(j).lmflag,dataType);
    end
end

end