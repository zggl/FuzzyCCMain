function var = setMFDataType(var,dataType)
%

% setMFDataType - Sets data types of MF structure fields. 
% 
%     The 'type' field is set to UINT8 since Simulink does not allow CHAR
%     values. Note that the 'type' values are not in STRING format since
%     MAKEHOMOGENOUSMF function creates 'type' fields with CHAR data types.

%   Copyright 2017 The MathWorks, Inc.

for i = 1:length(var)
    var(i).origNumMF = int32(var(i).origNumMF);
    for j = 1:length(var(i).mf)
        var(i).mf(j).type = uint8(var(i).mf(j).type);
        var(i).mf(j).origTypeLength = int32(var(i).mf(j).origTypeLength);
        var(i).mf(j).origParamLength =int32(var(i).mf(j).origParamLength);
        var(i).mf(j).params = setMatDataType(var(i).mf(j).params,dataType);
    end
end

end