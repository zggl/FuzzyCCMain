function writeEvaluateCustomImpMethod(fcn)
%% WRITEEVALUATECUSTOMIMPMETHOD Writes evaluation function for custom implication method
%
%   WRITEEVALUATECUSTOMIMPMETHOD(IMPMETHOD) Writes an evaluation
%   function in the current directory for the specified custom
%   IMPMETHOD.
%
%   Example
%     WRITEEVALUATECUSTOMIMPMETHOD(<customImpMethod>)

%  Copyright 2018-2021 The MathWorks, Inc.

mlock
persistent impMethod
if isempty(impMethod)
    impMethod = {};
end

if ~isempty(fcn) && ~any(fcn{1} == ["min" "prod"]) && ...
        ~ismember(fcn{1},impMethod) && ...
        (exist(fcn{1},'file')==2 || exist(fcn{1},'builtin')==5)
    impMethod{end+1} = fcn{1};
end

id = cell2mat(cellfun(@(x)~(exist(x,'file')==2 || exist(x,'builtin')==5),impMethod,'UniformOutput',false));
if any(id)
    impMethod(id) = [];
end

evalFcnName = 'evaluateCustomImpMethod';
fileName = fullfile(pwd,[evalFcnName '.m']);
if isempty(impMethod)
    if exist(fileName,'file') == 2
        delete(fileName)
    end
    return
end

contents = sprintf("function [y,hasImpMethod] = %s(impMethod,x,varargin) %%#codegen\n",evalFcnName);
contents = sprintf("%s%%[Y,HASIMPMETHOD] = %s(X) Evaluates custom implication method with\n",contents,upper(evalFcnName));
contents = sprintf("%s%%input X and returns output Y.\n%%\n",contents);
contents = sprintf("%s%%HASIMPMETHOD is true if IMPMETHOD exists.\n%%\n",contents);
contents = sprintf("%s%%Generated on %s\n\n",contents,datestr(now));
contents = sprintf("%s%% Copyright %s The MathWorks, Inc.\n\n",contents,datestr(now,'yyyy'));
contents = sprintf("%sy = -ones('like',x);\n",contents);
contents = sprintf("%shasImpMethod = false;\n",contents);
contents = sprintf("%sif isequal(impMethod,uint8('%s'))\n",contents,impMethod{1});
contents = sprintf("%s\ty(1) = %s(x,varargin{:});\n",contents,impMethod{1});
contents = sprintf("%s\thasImpMethod(1) = true;\n",contents);
for i = 2:length(impMethod)
    contents = sprintf("%selseif isequal(impMethod,uint8('%s'))\n",contents,impMethod{i});
    contents = sprintf("%s\ty(1) = %s(x,varargin{:});\n",contents,impMethod{i});
    contents = sprintf("%s\thasImpMethod(1) = true;\n",contents);
end
contents = sprintf("%send\n\nend\n",contents);

[f,msg] = fopen(fileName,'w+');
fuzzy.internal.utility.verifyFile(fileName,f,msg)
fprintf(f,"%s",contents);
fclose(f);

end