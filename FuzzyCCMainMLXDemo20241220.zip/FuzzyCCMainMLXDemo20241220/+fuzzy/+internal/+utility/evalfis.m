function varargout =  evalfis(arg1,arg2,varargin)
%

%EVALFIS Internal workhorse for FIS evaluation.

%   Copyright 2017-2022 The MathWorks, Inc.

narginchk(2,3)

persistent defaultDiagnostics
if isempty(defaultDiagnostics)
    defaultDiagnostics = fuzzy.internal.utility.createDiagnosticLevels();
end

ni = nargin; 



if isnumeric(arg1)
    warning(message('fuzzy:general:warnDeprecation_Evalfis'))
    input = arg1;
    fis = arg2;
else
    input = arg2;
    fis = arg1;
end

% If a fistree is being evaluated from FIS tree data structure
if isstruct(fis) && isfield(fis,'FIS') && isfield(fis,'Connections') && isfield(fis,'Outputs') && isfield(fis,'EvaluationFcn') && ...
    isstruct(fis.EvaluationFcn) && isfield(fis.EvaluationFcn,'Name') && isfield(fis.EvaluationFcn,'Body')
    fisArray = [];
    fisArrayStruct = fis.FIS;
    for i = 1:numel(fisArrayStruct)
        fisStructNH = fuzzy.internal.utility.convertToNonhomogenousFISStruct(fisArrayStruct{i}, true);
        fisArray = [fisArray fuzzy.internal.utility.convertfis(fisStructNH)];
    end
    con = string(fis.Connections);
    fisT = fistree(fisArray, con);
    fisT.Outputs = string(fis.Outputs);
    in = input;
    if isempty(varargin)
        options = evalfisOptions;
    else
        options = varargin{1};
    end
    [varargout{1:nargout}] = evalfis(fisT, in, options);
    return
end

if ~fuzzy.internal.utility.isHomogenousFISStructure(fis) && ...
        ~isa(fis,'FuzzyInferenceSystem')
    if fuzzy.internal.utility.isFISStructure(fis)
        isType2 = false;
        warning(message('fuzzy:general:warnDeprecation_FISStructure'))
    else
        error(message("fuzzy:general:errEvalfis_onlyType1FISStructureSupported"))
    end
end

if isa(fis,'FuzzyInferenceSystem')
    % If fis ia an object, convert it to a nonhomogenous structure and
    % check input, output, and rule number requirements.
    %fis = convertToStruct(fis);
    fis = fis.EvalfisData;
    fuzzy.internal.utility.checkMinInOutRuleRequirement(fis)
    isType2 = isfield(fis,'typeReductionMethod');
elseif fuzzy.internal.utility.isHomogenousFISStructure(fis)
    % If fis is a homogenous structure, convert it to a nonhomogenous
    % structure. This use case supports getFISCodeGenerationData().
    fis = fuzzy.internal.utility.convertToNonhomogenousFISStruct(fis);
    isType2 = isfield(fis,'typeReductionMethod');
end

% Nonhomogenous FIS structure will not be validated since its use is not
% recommended. Following code path and MEX will error out if the FIS input
% is not a valid nonhomogenous structure.

% Validate input data.
if isempty(input) || ~isfloat(input) || ~isreal(input) || ~ismatrix(input)
    error(message('fuzzy:general:errEvalfis_InvalidDataType'))
end
[M,N] = size(input);
Nin = length(fis.input);
if M==1 && N==1
   input = input(:,ones(1,Nin));
elseif M==Nin && N~=Nin
   input = input.';
elseif N~=Nin
   error(message('fuzzy:general:errEvalfis_IncorrectInputData'))
end

% Validate and extract optional input arguments.
if ni==2
   numofpoints = 101;
   diagnostics = defaultDiagnostics;
end

if ni >= 3
    if isa(varargin{1},'fuzzy.internal.fis.EvalFISOptions')
        [numofpoints,diagnostics] = extractArgumentValues(varargin{1});
    else
        warning(message('fuzzy:general:warnDeprecation_Evalfis'))
        fuzzy.internal.utility.validateNumOutputSample(varargin{1});
        numofpoints = double(varargin{1});
        diagnostics = defaultDiagnostics;
    end    
end

% Convert fis data to input data type and evaluate FIS.
if isType2
    if isa(input,'double')
        [varargout{1:nargout}] = fuzzy.internal.codegen. ...
            evaluateNonhomogenousFISType2_double_mex(input,fis,diagnostics,numofpoints);
    else
        fis = fuzzy.internal.utility.setNonhomogenousFISType2DataType(fis,'single');
        [varargout{1:nargout}] = fuzzy.internal.codegen. ...
            evaluateNonhomogenousFISType2_single_mex(input,fis,diagnostics,numofpoints);
    end    
else
    if isa(input,'double')
        [varargout{1:nargout}] = fuzzy.internal.codegen. ...
            evaluateNonhomogenousFIS_double_mex(input,fis,diagnostics,numofpoints);
    else
        fis = fuzzy.internal.utility.setNonhomogenousFISDataType(fis,'single');
        [varargout{1:nargout}] = fuzzy.internal.codegen. ...
            evaluateNonhomogenousFIS_single_mex(input,fis,diagnostics,numofpoints);
    end
end
    
end
%% Helper functions -------------------------------------------------------
function [numofpoints,diagnostics] = extractArgumentValues(argValues)

persistent localArgValues localDiagnostics localNumofpoints

if isempty(localArgValues) || ~isequal(localArgValues,argValues)
    localArgValues = argValues;
    localNumofpoints = double(argValues.NumSamplePoints);
    localDiagnostics = fuzzy.internal.utility.createDiagnosticLevels(...
        'OutOfRangeInputValue',argValues.OutOfRangeInputValueMessage, ...
        'NoRuleFired',argValues.NoRuleFiredMessage, ...
        'EmptyOutputFuzzySet',argValues.EmptyOutputFuzzySetMessage ...
        );
end

numofpoints = localNumofpoints;
diagnostics = localDiagnostics;

end
