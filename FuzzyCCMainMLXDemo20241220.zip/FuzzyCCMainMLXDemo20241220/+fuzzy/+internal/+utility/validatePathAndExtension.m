function validatePathAndExtension(value,name)
%

% VALIDATEPATHANDEXTENSION - Validates that the specified function name
% does not include path and extension.

%  Copyright 2019 The MathWorks, Inc.

[typePath,~,typeExt] = fileparts(char(value));
if ~(isempty(typePath) && isempty(typeExt))
    error(message("fuzzy:general:errFIS_MethodPathOrExtNotAllowed",name,name))
end

end
