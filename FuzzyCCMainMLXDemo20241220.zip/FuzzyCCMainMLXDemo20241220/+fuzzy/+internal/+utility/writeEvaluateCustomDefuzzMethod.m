function writeEvaluateCustomDefuzzMethod(fcn)
%% WRITEEVALUATECUSTOMDEFUZZMETHOD Writes evaluation function for custom defuzzification method
%
%   WRITEEVALUATECUSTOMDEFUZZMETHOD(DEFUZZMETHOD) Writes an evaluation
%   function in the current directory for the specified custom
%   DEFUZZMETHOD.
%
%   Example
%     WRITEEVALUATECUSTOMDEFUZZMETHOD(<customDefuzzMethod>)

%  Copyright 2018-2021 The MathWorks, Inc.

mlock
persistent defuzzMethod
if isempty(defuzzMethod)
    defuzzMethod = {};
end

if ~isempty(fcn) && ~any(fcn{1} == fuzzy.internal.utility.builtinDefuzzMethods) && ...
        ~ismember(fcn{1},defuzzMethod) && ...
        (exist(fcn{1},'file')==2 || exist(fcn{1},'builtin')==5)
    defuzzMethod{end+1} = fcn{1};
end

id = cell2mat(cellfun(@(x)~(exist(x,'file')==2 || exist(x,'builtin')==5),defuzzMethod,'UniformOutput',false));
if any(id)
    defuzzMethod(id) = [];
end

evalFcnName = 'evaluateCustomDefuzzMethod';
fileName = fullfile(pwd,[evalFcnName '.m']);
if isempty(defuzzMethod)
    if exist(fileName,'file') == 2
        delete(fileName)
    end
    return
end

contents = sprintf("function [z,hasDefuzzMethod] = %s(defuzzMethod,x,y,varargin) %%#codegen\n",evalFcnName);
contents = sprintf("%s%%[Z,HASDEFUZZMETHOD] = %s(DEFUZZMETHOD,X,Y) Evaluates DEFUZZMETHOD\n",contents,upper(evalFcnName));
contents = sprintf("%s%%with input X and Y; and returns output Z.\n%%\n",contents);
contents = sprintf("%s%%HASDEFUZZMETHOD is true if DEFUZZMETHOD exists.\n%%\n",contents);
contents = sprintf("%s%%Generated on %s\n\n",contents,datestr(now));
contents = sprintf("%s%% Copyright %s The MathWorks, Inc.\n\n",contents,datestr(now,'yyyy'));
contents = sprintf("%sz = zeros('like',x);\n",contents);
contents = sprintf("%shasDefuzzMethod = false;\n",contents);
contents = sprintf("%sif isequal(defuzzMethod,uint8('%s'))\n",contents,defuzzMethod{1});
contents = sprintf("%s\tz(1) = %s(x,y,varargin{:});\n",contents,defuzzMethod{1});
contents = sprintf("%s\thasDefuzzMethod(1) = true;\n",contents);
for i = 2:length(defuzzMethod)
    contents = sprintf("%selseif isequal(defuzzMethod,uint8('%s'))\n",contents,defuzzMethod{i});
    contents = sprintf("%s\tz(1) = %s(x,y,varargin{:});\n",contents,defuzzMethod{i});
    contents = sprintf("%s\thasDefuzzMethod(1) = true;\n",contents);
end
contents = sprintf("%send\n\nend\n",contents);

[f,msg] = fopen(fileName,'w+');
fuzzy.internal.utility.verifyFile(fileName,f,msg)
fprintf(f,"%s",contents);
fclose(f);

end