function [fisName,pathName,errorStr] = writesugfistype2(fis,fileName,dlgStr)
%

%

%   Copyright 2019 The MathWorks, Inc.

no = nargout;
if no >= 1
    fisName = '';
end
if no >= 2
    pathName = '';
end
if no >= 3
    errorStr = '';
end
throwError = (no<3);

ni = nargin;
if ni<2
    fileName = '';
    DLGStr='dialog';
else
    fileName = convertStringsToChars(fileName);
    if ~ischar(fileName)
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errInput_InvalidCharOrString', 'File name');
        return
    end
    if isempty(fileName)
        DLGStr = 'dialog';
    else
        DLGStr = '';
    end
    if ni>2
        dlgStr = convertStringsToChars(dlgStr);
        if ~ischar(dlgStr)
            errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
                'errInput_InvalidCharOrString', '"Dialog" flag');
            return
        elseif ~strcmpi(dlgStr,'dialog')
            errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
                'errWritefis_IncorrectDialogFlag');
            return;
        else
            DLGStr = dlgStr;
        end
    end
end

% Add .fis if not specified
name = '';
pName = '';
if ~isempty(fileName)
    [pName, name, ext] = fileparts(fileName);
    if ~strcmp(ext,'.fis')
        name = [name ext];
        ext = '.fis';
    end
    fileName = fullfile(pName, [name ext]);
end

% Launch dialog
if strcmp(DLGStr,'dialog')
    % Open dialog to get file name
    [fileName,pName]=uiputfile('*.fis','Save FIS',fileName);
    if isequal(fileName,0) || isequal(pName,0)
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errFIS_FileNameNotSpecified');
        return
    end
    fileName = fullfile(pName, fileName);
    [~, name] = fileparts(fileName);
end

if no >= 1
    fisName = name;
end

if no >= 2
    pathName = pName;
end

% Write data to file
fid=fopen(fileName,'w','n','utf8');
if fid==-1
    errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
        'errFileIO_CanNotOpen', fileName);
    return
end
fprintf(fid,'[System]\n');

str=['Name=''' name '''\n'];
fprintf(fid,str);

% Structure
str=['Type=''' convertToChar(fis.Type) '''\n'];
fprintf(fid,str);
str='Version=3.0\n';
fprintf(fid,str);

str=['NumInputs=' num2str(length(fis.Inputs)) '\n'];
fprintf(fid,str);

str=['NumOutputs=' num2str(length(fis.Outputs)) '\n'];
fprintf(fid,str);


str=['NumRules=' num2str(length(fis.Rules)) '\n'];
fprintf(fid,str);
str=['AndMethod=''' convertToChar(fis.AndMethod) '''\n'];
fprintf(fid,str);

str=['OrMethod=''' convertToChar(fis.OrMethod) '''\n'];
fprintf(fid,str);

str=['ImpMethod=''' convertToChar(fis.ImplicationMethod) '''\n'];
fprintf(fid,str);

str=['AggMethod=''' convertToChar(fis.AggregationMethod) '''\n'];
fprintf(fid,str);

str=['DefuzzMethod=''' convertToChar(fis.DefuzzificationMethod) '''\n'];
fprintf(fid,str);

str=['TypeReductionMethod=''' convertToChar(fis.TypeReductionMethod) '''\n'];
fprintf(fid,str);

for varIndex=1:length(fis.Inputs)
    fprintf(fid,['\n[Input' num2str(varIndex) ']\n']);
    str=['Name=''' convertToChar(fis.Inputs(varIndex).Name) '''\n'];
    fprintf(fid,str);
    str=['Range=' mat2str(fis.Inputs(varIndex).range) '\n'];
    fprintf(fid,str);
    str=['NumMFs=' num2str(length(fis.Inputs(varIndex).MembershipFunctions)) '\n'];
    fprintf(fid,str);

    for mfIndex=1:length(fis.Inputs(varIndex).MembershipFunctions)
        str=['MF' num2str(mfIndex) '=''' convertToChar(fis.Inputs(varIndex).MembershipFunctions(mfIndex).Name) ''':'];
        fprintf(fid,str);
        str=['''' convertToChar(fis.Inputs(varIndex).MembershipFunctions(mfIndex).Type) ''','];
        fprintf(fid,str);
        parstr = sprintf('%.15g ', fis.Inputs(varIndex).MembershipFunctions(mfIndex).UpperParameters);
        str = ['[' parstr(1:end-1) '],'];
        fprintf(fid,str);
        str = sprintf('[%.15g],', fis.Inputs(varIndex).MembershipFunctions(mfIndex).LowerScale);
        fprintf(fid,str);
        lag = fis.Inputs(varIndex).MembershipFunctions(mfIndex).LowerLag;
        if isscalar(lag)
            lag = lag(ones(1,2));
        end
        str = sprintf('[%.15g %.15g]\n',lag(1),lag(2));
        fprintf(fid,str);
    end
end
for varIndex=1:length(fis.Outputs)
    fprintf(fid,['\n[Output' num2str(varIndex) ']\n']);
    str=['Name=''' convertToChar(fis.Outputs(varIndex).Name) '''\n'];
    fprintf(fid,str);
    str=['Range=' mat2str(fis.Outputs(varIndex).range) '\n'];
    fprintf(fid,str);
    str=['NumMFs=' num2str(length(fis.Outputs(varIndex).MembershipFunctions)) '\n'];
    fprintf(fid,str);

    for mfIndex=1:length(fis.Outputs(varIndex).MembershipFunctions)
        str=['MF' num2str(mfIndex) '=''' convertToChar(fis.Outputs(varIndex).MembershipFunctions(mfIndex).Name) ''':'];
        fprintf(fid,str);
        str=['''' convertToChar(fis.Outputs(varIndex).MembershipFunctions(mfIndex).Type) ''','];
        fprintf(fid,str);
        parstr = sprintf('%.15g ', fis.Outputs(varIndex).MembershipFunctions(mfIndex).Parameters);
        str = ['[' parstr(1:end-1) ']\n'];
        fprintf(fid,str);
    end
end

str='\n[Rules]\n';
fprintf(fid,str);
for ruleIndex=1:length(fis.Rules)
    antecedent=mat2str(fis.Rules(ruleIndex).Antecedent);
    if length(fis.Inputs)>1
        antecedent=antecedent(2:end-1);
    end
    consequent=mat2str(fis.Rules(ruleIndex).Consequent);
    if length(fis.Outputs)>1
        consequent=consequent(2:end-1);
    end
    str=[antecedent ', ' consequent ' ('...
        mat2str(fis.Rules(ruleIndex).Weight) ') : '...
        mat2str(fis.Rules(ruleIndex).Connection)...
        '\n'];
    fprintf(fid,str);
end

fclose(fid);

end
%% Helper functions -------------------------------------------------------
function value = convertToChar(value)
if isstring(value)
    value = char(value);
    return
end
end