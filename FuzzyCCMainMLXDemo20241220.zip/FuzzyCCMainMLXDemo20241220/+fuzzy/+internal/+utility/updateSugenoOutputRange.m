function fis = updateSugenoOutputRange(fis)
%

%

%   Copyright 2017-2018 The MathWorks, Inc.

if fis.type == "mamdani"
    return
end

numOutputs = length(fis.output);
showWarning = false;
for i = 1:numOutputs
    if fis.output(i).range(2) <= fis.output(i).range(1)
        fis.output(i).range(2) = fis.output(i).range(1) + 1;
        if ~showWarning
            showWarning = true;
        end
    end
end

if showWarning
    warning(message("fuzzy:general:warnReadfis_InvalidSugenoOutputRange"))
end

end