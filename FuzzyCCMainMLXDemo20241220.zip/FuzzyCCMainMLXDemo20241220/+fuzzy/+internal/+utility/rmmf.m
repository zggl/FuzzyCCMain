function [out,errorStr]=rmmf(fis,varType,varIndex,mfFlag,mfIndex, warningDlgEnabled)
%

%

%  Copyright 2018 The MathWorks, Inc.

out = [];
errorStr = [];

varType = convertStringsToChars(varType);

numInputs=length(fis.input);
numOutputs=length(fis.output);

numInputMFs = [];
for i=1:numInputs
    numInputMFs(i)=length(fis.input(i).mf); %#ok<*AGROW>
end

numOutputMFs=[];
for i=1:length(fis.output)
    numOutputMFs(i)=length(fis.output(i).mf);
end

numRules=length(fis.rule);

if nargin<6
    warningDlgEnabled=false;
end

throwError = (nargout<2);

switch lower(varType(1))
    case 'i'
        if  numInputs==0
            errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
                'errInputVariable_NonExistent');
            return;
        end
    case 'o'
        if numOutputs==0
            errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
                'errOutputVariable_NonExistent');
            return;
        end
    otherwise
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errVariable_InvalidType');
        return;
end


% Get the rule matrix

if isempty(fis.rule) && isempty(mfIndex)
    errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
        'errMembershipFunction_NotSelected');
    return;
end

%
% For removal of an input membership function
%
if strcmp(varType,'input')
    if any(varIndex<1) || any(varIndex>numInputs)
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errInputVariable_IndexOutOfRange', numInputs);
        return;
    end
    
    currNumMFs=numInputMFs(varIndex);
    if currNumMFs==0
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errInputMembershipFunction_NonExistent', varIndex);
        return;
    end
    
    if any(mfIndex<1) || any(mfIndex>currNumMFs)
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errInputMembershipFunction_IndexOutOfRange', varIndex, currNumMFs);
        return;
    end
    
    % Find out which rules these membership functions are used in
    if numRules>0
        RulemfIndex = cat(1,fis.rule.antecedent);
        RulemfIndex = RulemfIndex(:,varIndex); %RulemfIndex = vector of MF's from varIndex
        hasDeletedMF = ismember(RulemfIndex,mfIndex); % mfIndex = indices of deleted MF's
    else
        hasDeletedMF = false(0,1);
    end
    ruleWithDeletedMF = (find(hasDeletedMF))';       %indices of rules with a deleted MF
    
    if any(hasDeletedMF) && warningDlgEnabled
        array = [];
        for loop = ruleWithDeletedMF
            array = [ array num2str(loop) ', '];
        end
        anws=questdlg({['This membership function is used in rule ' array ' now do you really want to remove it?']}, '', 'Yes', 'No', 'No');
        if strcmp(anws, 'No')
            out=fis;
            return
        end
    end
    
    % Remove the membership function(s) from the specified input variable
    fis.input(varIndex).mf(mfIndex)=[];
elseif strcmp(varType,'output')
    %For removal of an output membership function
    
    if any(varIndex<1) || any(varIndex>numOutputs)
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errOutputVariable_IndexOutOfRange', numOutputs);
        return;
    end
    
    currNumMFs=numOutputMFs(varIndex);
    if currNumMFs==0
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errOutputMembershipFunction_NonExistent', varIndex);
        return;
    end
    
    if any(mfIndex<1) || any(mfIndex>currNumMFs)
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errOutputMembershipFunction_IndexOutOfRange', varIndex, currNumMFs);
        return;
    end
    
    % Make sure the MF is not currently being used in the rules
    if numRules>0
        RulemfIndex = cat(1,fis.rule.consequent);
        RulemfIndex = RulemfIndex(:,varIndex); %RulemfIndex = vector of MF's from varIndex
        hasDeletedMF = ismember(RulemfIndex,mfIndex); % mfIndex = indices of deleted MF's
    else
        hasDeletedMF = false(0,1);
    end
    ruleWithDeletedMF = find(hasDeletedMF)';      %indices of rules with a deleted MF
    
    if any(hasDeletedMF) && warningDlgEnabled
        array = [];
        for loop = ruleWithDeletedMF
            array = [ array num2str(loop) ', '];
        end
        anws=questdlg({['This membership function is used in rule ' array ' now,'],...
            'do you really want to remove it?'}, '', 'Yes', 'No', 'No');
        if strcmp(anws, 'No')
            out=fis;
            return
        end
    end
    
    % Remove the membership function(s) from the specified input variable
    fis.output(varIndex).mf(mfIndex)=[];
end

out = fis;

end