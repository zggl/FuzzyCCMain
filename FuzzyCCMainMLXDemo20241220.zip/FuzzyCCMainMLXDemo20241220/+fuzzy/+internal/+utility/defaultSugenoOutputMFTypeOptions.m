function [refValue,msgKey] = defaultSugenoOutputMFTypeOptions(varargin)
%

%

%  Copyright 2018 The MathWorks, Inc.

if isempty(varargin)
    value = "";
else
    value = varargin{1};
end

if isa(value,'function_handle')
    refValue = {@constant @linear};
    msgKey = "errFIS_InvalidDefaultSugenoMFTypeHandle";
else
    refValue = {"constant","linear"};
    msgKey = "errFIS_InvalidDefaultSugenoMFTypeName";
end
end