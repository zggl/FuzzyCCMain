function checkFISRequirementForANFIS(fis)
%

%

%   Copyright 2017-2021 The MathWorks, Inc.

if isa(fis,'fuzzy.internal.fis.Type2FuzzyInferenceSystem')
    error(message("fuzzy:general:errAnfisedit_type2NotSupported"))
end
if fis.type~="sugeno" || fis.defuzzMethod ~= "wtaver"
    error(message("fuzzy:general:errAnfisInitialFIS_NotSugenoWithWtAverDefuzz"))
end
fuzzy.internal.utility.checkMinInOutRuleRequirement(fis)
if length(fis.output) > 1
    error(message("fuzzy:general:errAnfisInitialFIS_MultipleOutputs"))
end
if isa(fis,'FuzzyInferenceSystem')
    mfTypes = [fis.output(1).mf.Type];
else
    mfTypes = string({fis.output(1).mf.type});
end
if ~all(ismember(mfTypes,["constant" "linear"])) || length(unique(mfTypes))>1
    error(message("fuzzy:general:errAnfisInitialFIS_NotSameOutputMFType"))
end

numOutputMFs = length(fis.output(1).mf);
if numOutputMFs ~= length(fis.rule)
    error(message("fuzzy:general:Anfis_WrongNumberOfRules"))
end

consequent = sort([fis.rule.consequent]);
if ~all(consequent == 1:numOutputMFs)
    error(message("fuzzy:general:Anfis_WrongConsequents"))
end

end