function isValid = validCharOrString(name,value)
% ISVALID = VALIDCHARORSTRING(NAME,VALUE) Returns true if VALUE is a
% character row vector or a string scalar having non-empty character
% contents. Otherwise, it throws an error.
    
%  Copyright 2016-2020 The MathWorks, Inc.
    
import fuzzy.internal.utility.isCharRowVector

isValid = isCharRowVector(value) || ...
    (isStringScalar(value) && ~isempty(value.char));
if ~isValid
    error(message('fuzzy:general:errInput_InvalidCharOrString',name));
end
end