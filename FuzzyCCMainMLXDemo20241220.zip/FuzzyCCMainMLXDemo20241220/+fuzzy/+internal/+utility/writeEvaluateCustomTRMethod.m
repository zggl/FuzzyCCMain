function writeEvaluateCustomTRMethod(fcn)
%% WRITEEVALUATECUSTOMTRMETHOD Writes evaluation function for custom type reduction method
%
%   WRITEEVALUATECUSTOMTRMETHOD(TRMETHOD) Writes an evaluation
%   function in the current directory for the specified custom
%   TRMETHOD.
%
%   Example
%     WRITEEVALUATECUSTOMTRMETHOD(<customTRMethod>)

%  Copyright 2019-2021 The MathWorks, Inc.

mlock
persistent trMethod
if isempty(trMethod)
    trMethod = {};
end

if ~isempty(fcn) && ~any(fcn{1} == fuzzy.internal.utility.builtinTRMethods) && ...
        ~ismember(fcn{1},trMethod) && ...
        (exist(fcn{1},'file')==2 || exist(fcn{1},'builtin')==5)
    trMethod{end+1} = fcn{1};
end

id = cell2mat(cellfun(@(x)~(exist(x,'file')==2 || exist(x,'builtin')==5),trMethod,'UniformOutput',false));
if any(id)
    trMethod(id) = [];
end

evalFcnName = 'evaluateCustomTRMethod';
fileName = fullfile(pwd,[evalFcnName '.m']);
if isempty(trMethod)
    if exist(fileName,'file') == 2
        delete(fileName)
    end
    return
end

contents = sprintf("function [z,hasTRMethod] = %s(trMethod,x,umf,lmf,varargin) %%#codegen\n",evalFcnName);
contents = sprintf("%s%%[Z,HASTRMETHOD] = %s(TRMETHOD,X,UMF,LMF) Evaluates TRMETHOD\n",contents,upper(evalFcnName));
contents = sprintf("%s%%with inputs X, UMF, and LMF; and returns output Z.\n%%\n",contents);
contents = sprintf("%s%%HASTRMETHOD is true if TRMETHOD exists.\n%%\n",contents);
contents = sprintf("%s%%Generated on %s\n\n",contents,datestr(now));
contents = sprintf("%s%% Copyright %s The MathWorks, Inc.\n\n",contents,datestr(now,'yyyy'));
contents = sprintf("%sz = zeros(1,2,'like',x);\n",contents);
contents = sprintf("%shasTRMethod = false;\n",contents);
contents = sprintf("%sif isequal(trMethod,uint8('%s'))\n",contents,trMethod{1});
contents = sprintf("%s\tz(:) = %s(x,umf,lmf,varargin{:});\n",contents,trMethod{1});
contents = sprintf("%s\thasTRMethod(1) = true;\n",contents);
for i = 2:length(trMethod)
    contents = sprintf("%selseif isequal(trMethod,uint8('%s'))\n",contents,trMethod{i});
    contents = sprintf("%s\tz(:) = %s(x,umf,lmf,varargin{:});\n",contents,trMethod{i});
    contents = sprintf("%s\thasTRMethod(1) = true;\n",contents);
end
contents = sprintf("%send\n\nend\n",contents);

[f,msg] = fopen(fileName,'w+');
fuzzy.internal.utility.verifyFile(fileName,f,msg)
fprintf(f,"%s",contents);
fclose(f);

end