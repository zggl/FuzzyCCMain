function fis = writeCustomFunctions(fis)
%

%

%  Copyright 2018-2019 The MathWorks, Inc.


fuzzy.internal.utility.writeEvaluateCustomAndMethod({fis.andMethod})
fuzzy.internal.utility.writeEvaluateCustomOrMethod({fis.orMethod})
fuzzy.internal.utility.writeEvaluateCustomImpMethod({fis.impMethod})
fuzzy.internal.utility.writeEvaluateCustomAggMethod({fis.aggMethod})
fuzzy.internal.utility.writeEvaluateCustomDefuzzMethod({fis.defuzzMethod})

if isfield(fis,'typeReductionMethod')
    fuzzy.internal.utility.writeEvaluateCustomTRMethod({fis.typeReductionMethod})
    
    inputUMFs = arrayfun(@(x){x.mf.umftype},fis.input,'UniformOutput',false);
    if isempty(inputUMFs)
        inputUMFs = {};
    end
    inputLMFs = arrayfun(@(x){x.mf.lmftype},fis.input,'UniformOutput',false);
    if isempty(inputLMFs)
        inputLMFs = {};
    end
    outputUMFs = arrayfun(@(x){x.mf.umftype},fis.output,'UniformOutput',false);
    if isempty(outputUMFs)
        outputUMFs = {};
    end
    outputLMFs = arrayfun(@(x){x.mf.lmftype},fis.output,'UniformOutput',false);
    if isempty(outputLMFs)
        outputLMFs = {};
    end
    mfs = [inputUMFs{:} inputLMFs{:} outputUMFs{:} outputLMFs{:}];
else
    inputMFs = arrayfun(@(x){x.mf.type},fis.input,'UniformOutput',false);
    if isempty(inputMFs)
        inputMFs = {};
    end
    outputMFs = arrayfun(@(x){x.mf.type},fis.output,'UniformOutput',false);
    if isempty(outputMFs)
        outputMFs = {};
    end
    mfs = [inputMFs{:} outputMFs{:}];
end

if isempty(mfs)
    mfs = {};
end
flatList = cellfun(@(x)deblank(x),mfs,'UniformOutput',false);
id = cell2mat(cellfun(@(x)isempty(x),flatList,'UniformOutput',false));
if any(id)
    flatList(id) = [];
end
fuzzy.internal.utility.writeEvaluateCustomMF(unique(flatList))

end