function diagnosticLevels = createDiagnosticLevels(varargin)
%

% createDiagnosticLevels - Creates diagnostic levels for fuzzy inference
% process. You can specify the following Name/Value parameter pairs:
%
%     SimulinkDiagnostic - Boolean value that indicates if diagnostics are
%     intended for Simulink context. Default value is false which indicates
%     MATLAB context.
%
%     Model                - Model name when context is Simulink.
%
%     Block                - Block name for which diagnostics are genrated
%                            in Simulink context.
%
%     OutOfRangeInputValue - Diagnostic level for out of range input
%                            values. It can be either "none", "warning", or
%                            "error". The default value is "warning".
%
%     NoRuleFired          - Diagnostic level for no-rule-fired condition.
%                            It can be either "none", "warning", or
%                            "error". The default value is "warning".
%
%     EmptyOutputFuzzySet  - Diagnostic level for an empty output fuzzy
%                            set. It can be either "none", "warning", or
%                            "error". The default value is "warning".
%
% The parameter values are stored as uint8 values for efficient use in the
% MEX files.

%  Copyright 2017 The MathWorks, Inc.

parser = inputParser();
parser.addParameter("SimulinkDiagnostic",0);
parser.addParameter("Model",0);
parser.addParameter("Block",0);
parser.addParameter("OutOfRangeInputValue","warning");
parser.addParameter("NoRuleFired","warning");
parser.addParameter("EmptyOutputFuzzySet","warning");
parser.parse(varargin{:});


diagnosticLevels.SimulinkDiagnostic = uint8(...
    parser.Results.SimulinkDiagnostic);
diagnosticLevels.Model = uint8(parser.Results.Model);
diagnosticLevels.Block = uint8(parser.Results.Block);
diagnosticLevels.OutOfRangeInputValue = convertToIndex(...
    parser.Results.OutOfRangeInputValue);
diagnosticLevels.NoRuleFired = convertToIndex(...
    parser.Results.NoRuleFired);
diagnosticLevels.EmptyOutputFuzzySet = convertToIndex(...
    parser.Results.EmptyOutputFuzzySet);

end
%% Helper functions -------------------------------------------------------
function index = convertToIndex(diagnosticType)

whichType = (diagnosticType == fuzzy.internal.utility.getDiagnosticLevels);
index = uint8(find(whichType,1));

end