function fisout = convertfis(fisin)
%% CONVERTFIS Converts type-1 or type-2 FIS data into object

% Copyright 2022 The MathWorks, Inc.

isType1 = ~isfield(fisin, 'typeReductionMethod');
% Type-1
if isType1
    fisout = fuzzy.internal.utility.createFromStruct(fisin);
% Type-2
else
    if fisin.type=="mamdani"
        fisout = fuzzy.internal.utility.createType2MamdaniFISFromStruct(fisin);
    else
        fisout = fuzzy.internal.utility.createType2SugenoFISFromStruct(fisin);
    end
end
end