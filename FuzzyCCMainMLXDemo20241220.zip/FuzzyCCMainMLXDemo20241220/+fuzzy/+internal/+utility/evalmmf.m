function out = evalmmf(x, mf_para, mf_type)
%EVALMMF Multiple membership functions evaluation.

%   Copyright 2018 The MathWorks, Inc.

mf_type = fuzzy.internal.utility.convertToCharArrayIfInputIsString(mf_type);

if size(mf_type, 1) == 1
    mf_type = mf_type(ones(size(mf_para, 1), 1), :);
end

x = x(:)';
out = zeros(size(mf_type, 1), length(x));

for i = 1:size(mf_type, 1)
    out(i,:) = evalmf(x, mf_para(i,:), deblank(mf_type(i,:)));
end

end