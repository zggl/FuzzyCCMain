function validateMFNumber(value,msgKey)
%

%

%  Copyright 2018 The MathWorks, Inc.

try
    validateattributes(...
        value, ...
        {'numeric'}, ...
        {'nonempty','vector','real','positive','finite','integer'}, ...
        '', ...
        '')
catch me
    error(message("fuzzy:general:"+msgKey))
end
end