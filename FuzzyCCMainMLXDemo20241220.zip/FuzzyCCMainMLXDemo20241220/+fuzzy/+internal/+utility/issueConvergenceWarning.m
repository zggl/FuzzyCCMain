function [fis,warningNotShown] = issueConvergenceWarning(fis,varType,warningNotShown)
%

%

%   Copyright 2017 The MathWorks, Inc.

for i = 1:length(fis.(varType))
    for j = 1:length(fis.(varType)(i).mf)
        id = ~isfinite(fis.(varType)(i).mf(j).params);
        if any(id)
            if warningNotShown
                warning("fuzzy:general:warnAnfis_DidNotConverge",...
                    "ANFIS did not converge to a valid FIS.")
                warningNotShown = false;
            end
            fis.(varType)(i).mf(j).params(id) = 0;
        end
    end
end

end