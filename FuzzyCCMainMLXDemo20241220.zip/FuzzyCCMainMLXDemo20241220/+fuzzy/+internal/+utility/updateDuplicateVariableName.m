function fis = updateDuplicateVariableName(fis)
%

%

%   Copyright 2017-2019 The MathWorks, Inc.

fis = removeAndUpdateName(fis,'input');
fis = removeAndUpdateName(fis,'output');

end

%% Helper functions -------------------------------------------------------
function fis = removeAndUpdateName(fis,varType)

if isempty(fis.(varType))
    return
end

% Here assumption is all names are specified with character values. 
[~,~,id] = unique(string({fis.(varType).name}));
varIDWithSameName = find(histcounts(id,max(id))>1);

if ~isempty(varIDWithSameName)
    if varType == "input"
        warning(message("fuzzy:general:warnReadfis_DuplicateInputName"))
    else
        warning(message("fuzzy:general:warnReadfis_DuplicateOutputName"))
    end
end

for i = 1:numel(varIDWithSameName)
    varID = varIDWithSameName(i);
    name = fis.(varType)(varID).name;
    sameNameID = find(id==varID);
    for j = 1:numel(sameNameID)
        [~,postfix] = fileparts(tempname);
        fis.(varType)(sameNameID(j)).name = [name '_' postfix];
    end
end

end