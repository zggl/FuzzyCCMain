function names = builtinDefuzzMethods
%

%

%   Copyright 2017 The MathWorks, Inc.

names = ["centroid" "bisector" "lom" "mom" "som" "wtaver" "wtsum"];

end