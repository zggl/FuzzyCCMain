function yes = isNonemptyScalarLogical(value)
%

%

%  Copyright 2019 The MathWorks, Inc.

yes = ~isempty(value) && isscalar(value) && (islogical(value) || ...
        (isnumeric(value)&&isreal(value)&&(value==0||value==1)));

end