function validateTriMFParameterValues(params) %#codegen
%

% validateTriMFParameterValues - Validates parameter values of 'trimf'
% membership function.

% Copyright 2017-2021 The MathWorks, Inc.

coder.extrinsic('message', 'warning')

if fuzzy.internal.codegen.isMatlabTarget
    if ~fuzzy.internal.utility.isValidInput(params)
        error(message('fuzzy:general:errMFParameters_invalidValue'))
    end
end
n = fuzzy.internal.codegen.numParamTrimf;
coder.internal.errorIf(numel(params)<n, ...
    'fuzzy:general:errTrimf_InvalidParamLength')

coder.internal.errorIf(params(1) > params(2), ...
    'fuzzy:general:errTrimf_InvalidParamA')

coder.internal.errorIf(params(2) > params(3), ...
    'fuzzy:general:errTrimf_InvalidParamB')

if fuzzy.internal.codegen.isTargetMATLABOrMEX
    if numel(params) > n
        warning(message('fuzzy:general:warnFismf_RedundantParamValues','Triangular',n))
    end
end
end