function [param,paramLength] = getVarMFParams(var)
%

%

%   Copyright 2017-2018 The MathWorks, Inc.

paramLength = [];
numVars = numel(var);
numMFs = zeros(1,numVars);
totalNumMFs = 0;
maxParamLength = 0;
for i = 1:numVars
    numMFs(i) = numel(var(i).MembershipFunctions);
    totalNumMFs = totalNumMFs + numMFs(i);
    for j = 1:numMFs(i)
        n = numel(var(i).MembershipFunctions(j).Parameters);
        paramLength(end+1) = n; %#ok<AGROW>
        if n > maxParamLength
            maxParamLength = n;
        end        
    end
end
param = zeros(totalNumMFs,maxParamLength);
id = 0;
for varID = 1:numVars
    for mfID = 1:numMFs(varID)
        id = id + 1;
        param(id,1:paramLength(id)) = var(varID).MembershipFunctions(mfID).Parameters;
    end
end

end