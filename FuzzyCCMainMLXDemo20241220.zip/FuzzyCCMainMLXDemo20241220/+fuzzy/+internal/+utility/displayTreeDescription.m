function displayTreeDescription(obj)
%

%

%  Copyright 2018 The MathWorks, Inc.

description = sprintf('\nFIS Names:\n');
for i = 1:numel(obj.FIS)
    description = sprintf('%s\t%s\n',description,obj.FIS(i).Name);
end

description = sprintf('%s\nConnections:\n',description);
if isempty(obj.Connections)
    description = sprintf('%s\t%s\n',description, ...
        '[]');
else
    from = obj.Connections(:,1);
    to = obj.Connections(:,2);
    maxFromWidth = max(strlength(from));
    maxToWidth = max(strlength(to));
    from = pad(from,maxFromWidth,'right',' ');
    description = sprintf('%s\t%s\t%s\n',description, ...
        pad('From',maxFromWidth,'right'),'To');
    description = sprintf('%s\t%s\t%s\n',description, ...
        repmat('-',[1 maxFromWidth]),repmat('-',[1 maxToWidth]));
    for i = 1:size(obj.Connections,1)
        description = sprintf('%s\t%s\t%s\n',description, ...
            from(i),to(i));
    end
end

description = sprintf('%s\nInputs:\n',description);
for i = 1:length(obj.Inputs)
    description = sprintf('%s\t%s\n',description,obj.Inputs(i));
end

description = sprintf('%s\nOutputs:\n',description);
for i = 1:length(obj.Outputs)
    description = sprintf('%s\t%s\n',description,obj.Outputs(i));
end

fprintf('%s',description);
end
