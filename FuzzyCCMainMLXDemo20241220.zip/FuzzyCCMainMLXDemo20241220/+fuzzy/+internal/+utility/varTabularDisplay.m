function varTabularDisplay(objAry)
%

% Internal function for displaying variable array contents.

%  Copyright 2018 The MathWorks, Inc.

rowNames = fuzzy.internal.utility.getRowNames(size(objAry));
if ~isvector(objAry)    
    objAry = objAry(:);
end
n = numel(objAry);
Name = string.empty;
Range = zeros(n,2);
MembershipFunctions = cell(n,1);
for i = 1:n
    Name = [Name;objAry(i).Name]; %#ok<AGROW>
    Range(i,:) = objAry(i).Range;
    MembershipFunctions{i} = objAry(i).MembershipFunctions;
end

tableObj = table(Name,Range,MembershipFunctions,'RowNames',rowNames);

fuzzy.internal.utility.detailDisplay(tableObj)

end