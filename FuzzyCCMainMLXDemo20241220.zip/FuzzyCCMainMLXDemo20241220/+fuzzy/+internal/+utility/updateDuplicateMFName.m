function fis = updateDuplicateMFName(fis)
%

%

%   Copyright 2017-2019 The MathWorks, Inc.

fis = removeAndUpdateName(fis,'input');
fis = removeAndUpdateName(fis,'output');

end
%% Helper functions -------------------------------------------------------
function fis = removeAndUpdateName(fis,varType)

warningNotShown = true;
for varID = 1:length(fis.(varType))
    var = fis.(varType)(varID);
    
    if isempty(var.mf)
        continue
    end
    
    % Here assumption is all names are specified with character values. 
    [~,~,id] = unique(string({var.mf.name}));
    mfIDWithSameName = find(histcounts(id,max(id))>1);
    
    if warningNotShown && ~isempty(mfIDWithSameName)
        if varType == "input"
            warning(message("fuzzy:general:warnReadfis_DuplicateInputMFName"))
        else
            warning(message("fuzzy:general:warnReadfis_DuplicateOutputMFName"))
        end
        warningNotShown = false;
    end
    
    for i = 1:numel(mfIDWithSameName)
        mfID = mfIDWithSameName(i);
        name = var.mf(mfID).name;
        sameNameID = find(id==mfID);
        for j = 1:numel(sameNameID)
            [~,postfix] = fileparts(tempname);
            var.mf(sameNameID(j)).name = [name '_' postfix];
        end
    end
    fis.(varType)(varID) = var;
end

end

