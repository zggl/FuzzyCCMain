function validateOutputDataType(dataType)
%

% validateOutputDataType - Validates user-specified data type.

%   Copyright 2017 The MathWorks, Inc. 

if ischar(dataType) || isstring(dataType)
    if ~any(dataType == ["single" "double"])
        error(message('fuzzy:dialogs:flcMaskErr_DataType_Unsupported'));
    end
else
    if isa(dataType,'Simulink.NumericType') || isa(dataType,'embedded.numerictype')
        if ~dataType.isfixed
            error(message('fuzzy:dialogs:flcMaskErr_DataType_Unsupported'));
        end
    else
        error(message('fuzzy:dialogs:flcMaskErr_DataType_Unsupported'));
    end
end

end
