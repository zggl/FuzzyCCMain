function validateMethod(name,value)
%

%  VALIDATEMETHOD - Validates that a FIS method name is either a nonempty
%  char, string, or a function handle.

%  Copyright 2019 The MathWorks, Inc.

if isempty(value) || ~(ischar(value)||isstring(value)||isa(value,'function_handle'))
    error(message("fuzzy:general:errFIS_InvalidMethodDataType",name))
end

end