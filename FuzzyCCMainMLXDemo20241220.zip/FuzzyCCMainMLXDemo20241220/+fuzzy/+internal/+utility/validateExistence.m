function validateExistence(value,msgID)
%

% VALIDATEEXISTENCE - Validates existence of the specified file.

%  Copyright 2019 The MathWorks, Inc.

if isdeployed
    return
end

if exist(value,'file')~=2 && exist(value,'builtin')~=5
    error(message(msgID,value))
end

end