function out = makeHomogenousVarType2(in)
%

% makeHomogenousVarType2 - Creates array of fuzzy variable structures with
% homogenous fields.

%   Copyright 2019 The MathWorks, Inc.

if isempty(in)
    out = in;
    return
end

numVar = length(in);
maxVarNameLength = 0;
maxNumMF = 0;
maxMFNameLength = 0;
maxUMFTypeLength = 0;
maxUMFParamLength = 0;
maxLMFTypeLength = 0;
maxLMFParamLength = 0;
for i=1:numVar
    n = numel(in(i).name);
    if n > maxVarNameLength
        maxVarNameLength = n;
    end
    mfs = in(i).mf;
    n = numel(mfs);
    if n > maxNumMF
        maxNumMF = n;
    end
    for j = 1:n
        mf = mfs(j);
        m = numel(mf.name);
        if m > maxMFNameLength
            maxMFNameLength = m;
        end
        m = numel(mf.umftype);
        if m > maxUMFTypeLength
            maxUMFTypeLength = m;
        end
        m = numel(mf.umfparams);
        if m > maxUMFParamLength
            maxUMFParamLength = m;
        end
        m = numel(mf.lmftype);
        if m > maxLMFTypeLength
            maxLMFTypeLength = m;
        end
        m = numel(mf.lmfparams);
        if m > maxLMFParamLength
            maxLMFParamLength = m;
        end
    end
end

mfTemplate = struct(...
    'name',char(zeros(1,maxMFNameLength)),...
    'origNameLength',zeros(1,1),...
    'umftype',char(zeros(1,maxUMFTypeLength)),...
    'origUMFTypeLength',zeros(1,1),...
    'umfparams',zeros(1,maxUMFParamLength),...
    'origUMFParamLength',zeros(1,1),...
    'lmftype',char(zeros(1,maxLMFTypeLength)),...
    'origLMFTypeLength',zeros(1,1),...
    'lmfparams',zeros(1,maxLMFParamLength),...
    'origLMFParamLength',zeros(1,1),...
    'lmfscale',zeros(1,1), ...
    'lmflag',zeros(1,2) ...
    );
mfVal(1:maxNumMF) = mfTemplate;
varTemplate = struct(...
    'name',char(zeros(1,maxVarNameLength)),...
    'origNameLength',zeros(1,1),...
    'range',zeros(1,2),...
    'mf',mfVal,...
    'origNumMF',zeros(1,1)...
    );
out(1:numVar) = varTemplate;

for i=1:numVar
    varName = in(i).name;
    varNameLength = length(varName);
    out(i).name(1:varNameLength) = varName;
    out(i).origNameLength(1) = varNameLength;
    out(i).range(:) = in(i).range;    
    out(i).origNumMF(1) = length(in(i).mf);    
    for j = 1:maxNumMF        
        if j <= out(i).origNumMF
            mfName = in(i).mf(j).name;
            mfNameLength = length(mfName);
            
            out(i).mf(j).name(1:mfNameLength) = mfName;
            out(i).mf(j).origNameLength(1) = mfNameLength;
            out(i).mf(j).lmfscale(1) = in(i).mf(j).lmfscale;
            out(i).mf(j).lmflag(:) = in(i).mf(j).lmflag;
            
            mfType = in(i).mf(j).umftype;
            mfTypeLength = length(mfType);
            params = in(i).mf(j).umfparams;
            paramsLength = length(params);            
            out(i).mf(j).umftype(1:mfTypeLength) = mfType;
            out(i).mf(j).origUMFTypeLength(1) = mfTypeLength;
            out(i).mf(j).umfparams(1:paramsLength) = params;
            out(i).mf(j).origUMFParamLength(1) = paramsLength;
            
            mfType = in(i).mf(j).lmftype;
            mfTypeLength = length(mfType);
            params = in(i).mf(j).lmfparams;
            paramsLength = length(params);            
            out(i).mf(j).lmftype(1:mfTypeLength) = mfType;
            out(i).mf(j).origLMFTypeLength(1) = mfTypeLength;
            out(i).mf(j).lmfparams(1:paramsLength) = params;
            out(i).mf(j).origLMFParamLength(1) = paramsLength;
        end
    end
end

end