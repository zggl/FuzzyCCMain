function rule = getRuleList(fis)
%

%

%   Copyright 2017-2018 The MathWorks, Inc.

numRules = numel(fis.Rules);
if numRules > 0
    rule = zeros(numRules,numel(fis.Inputs)+numel(fis.Outputs)+2);
    for i = 1:numRules
        r = fis.Rules(i);
        rule(i,:) = [r.Antecedent r.Consequent r.Weight r.Connection];
    end
else
    rule = [];
end

end