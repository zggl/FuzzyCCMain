function validateLinSMFParameterValues(params) %#codegen
%

% validateLINSMFParameterValues - Validates parameter values of 'linsmf'
% membership function.

% Copyright 2021 The MathWorks, Inc.

if fuzzy.internal.codegen.isMatlabTarget
    if ~fuzzy.internal.utility.isValidInput(params)
        error(message('fuzzy:general:errMFParameters_invalidValue'))
    end
end
n = fuzzy.internal.codegen.numParamLinsmf;
coder.internal.errorIf(numel(params)~=n, ...
    'fuzzy:general:errLinsmf_InvalidParamLength')
coder.internal.errorIf(params(1)>params(2), ...
    'fuzzy:general:errLinsmf_InvalidParamA')

end