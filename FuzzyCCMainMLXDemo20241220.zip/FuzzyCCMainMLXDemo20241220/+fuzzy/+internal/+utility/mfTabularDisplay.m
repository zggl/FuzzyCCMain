function mfTabularDisplay(objAry)
%

% Internal function for displaying MF array contents.

%  Copyright 2018 The MathWorks, Inc.

rowNames = fuzzy.internal.utility.getRowNames(size(objAry));
if ~isvector(objAry)
    objAry = objAry(:);
end
n = numel(objAry);
Parameters = cell(n,1);
sameLength = zeros(n,1);
Name = string.empty;
Type = string.empty;
for i = 1:n
    Name = [Name;objAry(i).Name]; %#ok<AGROW>
    Type = [Type;objAry(i).Type]; %#ok<AGROW>
    params = objAry(i).Parameters;
    Parameters{i} = params;
    sameLength(i) = numel(params);
end
if ~any(diff(sameLength))
    Parameters = cell2mat(Parameters);
end
tableObj = table(Name,Type,Parameters,'RowNames',rowNames);

fuzzy.internal.utility.detailDisplay(tableObj)

end