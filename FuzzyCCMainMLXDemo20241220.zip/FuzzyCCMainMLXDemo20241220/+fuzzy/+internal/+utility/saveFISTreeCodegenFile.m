function file = saveFISTreeCodegenFile(s)
%% SAVEFISTREECODEGENFILE Saves the input text function to a disk file for evaluating a FIS tree.

%   Copyright 2022 The MathWorks, Inc.
try
    fcnname = s.EvaluationFcn.Name;
    filepath = tempname;
    validateFilePath(filepath)
    filelocation = fullfile(filepath,[fcnname '.m']);
    f = fopen(filelocation,'w+');
    checkFileOpenSuccess(f)
    fprintf(f,'%s',s.EvaluationFcn.Body);
    v = fclose(f);
    checkFileCloseSuccess(v)
    validateFileExistence(filelocation)

    addpath(filepath)
    file = struct('name',fcnname,'dir',filepath,'path',filelocation);
catch me
    msgStruct.identifier = me.identifier;
    msgStruct.message = me.message;
    error(msgStruct)
end

end

function validateFilePath(filePath)
%% Create a new directory with the given file path
if exist(filePath,"dir")~=7
    success = mkdir(filePath);
    if ~success
        error(message('fuzzy:general:errEvalfis_fistreeFileCreation'))
    end
end
end

function checkFileOpenSuccess(fid)
%% Validate file is opened successfully
if fid<0
    error(message('fuzzy:general:errEvalfis_fistreeFileCreation'))
end
end

function checkFileCloseSuccess(st)
%% Validate file is closed successfully
if st<0
    error(message('fuzzy:general:errEvalfis_fistreeFileCreation'))
end
end

function validateFileExistence(fileLocation)
%% Validate file is created
st = tic;
timeout = 0;
timeoutThreshold = 30; % sec
while(timeout<timeoutThreshold)
    if isfile(fileLocation)
        break
    end
    pause(0.1)
    timeout = toc(st);
end
if timeout>=timeoutThreshold
    error(message('fuzzy:general:errEvalfis_fistreeFileCreation'))
end
end