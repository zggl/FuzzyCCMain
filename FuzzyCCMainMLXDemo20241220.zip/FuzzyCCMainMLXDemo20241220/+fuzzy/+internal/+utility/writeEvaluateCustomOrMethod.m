function writeEvaluateCustomOrMethod(fcn)
%% WRITEEVALUATECUSTOMORMETHOD Writes evaluation function for custom OR method
%
%   WRITEEVALUATECUSTOMORMETHOD(ORMETHOD) Writes an evaluation function
%   in the current directory for the specified custom ORMETHOD.
%
%   Example
%     WRITEEVALUATECUSTOMORMETHOD(<customOrMethod>)

%  Copyright 2018-2021 The MathWorks, Inc.

mlock
persistent orMethod
if isempty(orMethod)
    orMethod = {};
end

if ~isempty(fcn) && ~any(fcn{1} == ["max" "probor" "sum"]) && ...
        ~ismember(fcn{1},orMethod) && ...
        (exist(fcn{1},'file')==2 || exist(fcn{1},'builtin')==5)
    orMethod{end+1} = fcn{1};
end

id = cell2mat(cellfun(@(x)~(exist(x,'file')==2 || exist(x,'builtin')==5),orMethod,'UniformOutput',false));
if any(id)
    orMethod(id) = [];
end

evalFcnName = 'evaluateCustomOrMethod';
fileName = fullfile(pwd,[evalFcnName '.m']);
if isempty(orMethod)
    if exist(fileName,'file') == 2
        delete(fileName)
    end
    return
end

contents = sprintf("function [y,hasOrMethod] = %s(orMethod,x,varargin) %%#codegen\n",evalFcnName);
contents = sprintf("%s%%[Y,HASORMETHOD] = %s(ORMETHOD,X) Evaluates ORMETHOD with\n",contents,upper(evalFcnName));
contents = sprintf("%s%%input X and returns output Y.\n%%\n",contents);
contents = sprintf("%s%%HASORMETHOD is true if ORMETHOD exists.\n%%\n",contents);
contents = sprintf("%s%%Generated on %s\n\n",contents,datestr(now));
contents = sprintf("%s%% Copyright %s The MathWorks, Inc.\n\n",contents,datestr(now,'yyyy'));
contents = sprintf("%sy = -ones('like',x);\n",contents);
contents = sprintf("%shasOrMethod = false;\n",contents);
contents = sprintf("%sif isequal(orMethod,uint8('%s'))\n",contents,orMethod{1});
contents = sprintf("%s\ty(1) = %s(x,varargin{:});\n",contents,orMethod{1});
contents = sprintf("%s\thasOrMethod(1) = true;\n",contents);
for i = 2:length(orMethod)
    contents = sprintf("%selseif isequal(orMethod,uint8('%s'))\n",contents,orMethod{i});
    contents = sprintf("%s\ty(1) = %s(x,varargin{:});\n",contents,orMethod{i});
    contents = sprintf("%s\thasOrMethod(1) = true;\n",contents);
end
contents = sprintf("%send\n\nend\n",contents);

[f,msg] = fopen(fileName,'w+');
fuzzy.internal.utility.verifyFile(fileName,f,msg)
fprintf(f,"%s",contents);
fclose(f);

end