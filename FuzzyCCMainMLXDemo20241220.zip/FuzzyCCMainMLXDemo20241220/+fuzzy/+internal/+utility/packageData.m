function fisout = packageData(fisin,numSamples)
%

% packageData - Packages additional data to an FIS structure for using in a
% Fuzzy Logoc Controller block.

%   Copyright 2017-2019 The MathWorks, Inc. 

if isa(fisin,'FuzzyInferenceSystem')
    fisin = fisin.EvalfisData;
end

fisout.type = fisin.type;
fisout.andMethod = fisin.andMethod;
fisout.orMethod = fisin.orMethod;
fisout.defuzzMethod = fisin.defuzzMethod;
fisout.impMethod = fisin.impMethod;
fisout.aggMethod = fisin.aggMethod;
if isfield(fisin,'typeReductionMethod')
    fisout.typeReductionMethod = fisin.typeReductionMethod;
    fisout.inputMF = makeHomogenousMFType2(fisin.input);
    fisout.outputMF = makeHomogenousMFType2(fisin.output);
    isType2 = true;
else
    fisout.inputMF = makeHomogenousMF(fisin.input);
    fisout.outputMF = makeHomogenousMF(fisin.output);
    isType2 = false;
end

% Input ranges are not used in the inference process, however, we need to
% throw warnings during simulation if input values are out of range.

numInputs = numel(fisin.input);
numMFs = zeros(1,numInputs);
range = zeros(numInputs,2);
for i = 1:numInputs
    range(i,:) = fisin.input(i).range;
    numMFs(i) = numel(fisin.input(i).mf);
end
fisout.inputRange = range;
fisout.numInputMFs = numMFs;
fisout.numCumInputMFs = cumsum(fisout.numInputMFs) - fisout.numInputMFs;

numOutputs = length(fisin.output);
range = zeros(numOutputs,2);
numMFs = zeros(1,numOutputs);
for i = 1:numOutputs
    range(i,:) = fisin.output(i).range;
    numMFs(i) = length(fisin.output(i).mf);
end
fisout.outputRange = range;
fisout.numOutputMFs = numMFs;
fisout.numCumOutputMFs = cumsum(fisout.numOutputMFs) - fisout.numOutputMFs;

numRules = numel(fisin.rule);
ant = zeros(numRules,numInputs);
con = zeros(numRules,numOutputs);
w = zeros(numRules,1);
c = zeros(numRules,1);
for i = 1:numRules
    rule = fisin.rule(i);
    ant(i,:) = rule.antecedent;
    con(i,:) = rule.consequent;
    w(i,:) = rule.weight;
    c(i,:) = rule.connection;
end
fisout.antecedent = ant;
fisout.consequent = con;
fisout.connection = c;
fisout.weight = w;

fisout.numSamples = numSamples;
fisout.numInputs = numInputs;
fisout.numOutputs = numOutputs;
fisout.numRules = numRules;

fisout.outputSamplePoints = createOutputSamplePoints(fisin,numSamples);

if isType2
    if strcmp(fisin.type,'mamdani')
        fisout.orrSize = [numSamples 2*numRules*numOutputs];
        fisout.aggSize = [numSamples 2*numOutputs];
    else
        fisout.orrSize = [numRules 3*numOutputs];
        fisout.aggSize = [numRules 3*numOutputs];
    end
    fisout.irrSize = [numRules 2*numInputs];
    fisout.rfsSize = [numRules 2];
    fisout.sumSize = [1 2];
    fisout.inputFuzzySetType = 2;
else
    if strcmp(fisin.type,'mamdani')
        fisout.orrSize = [numSamples,numRules*numOutputs];
        fisout.aggSize = [numSamples numOutputs];
    else
        fisout.orrSize = [numRules,numOutputs];
        fisout.aggSize = [1 numOutputs];
    end
    fisout.irrSize = [numRules numInputs];
    fisout.rfsSize = [numRules 1];
    fisout.sumSize = [1 1];
    fisout.inputFuzzySetType = 1;
end

end