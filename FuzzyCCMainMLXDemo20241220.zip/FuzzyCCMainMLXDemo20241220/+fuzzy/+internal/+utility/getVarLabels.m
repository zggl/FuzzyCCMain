function label = getVarLabels(var)
%

%

%   Copyright 2017 The MathWorks, Inc.

label = fuzzy.internal.utility.convertToCharArrayIfInputIsString([var.Name]);
end