function errorStr = getStringIfErrorIsNotThrown(throwError, msgKey, varargin)
% Undocumented API for internal use only.

% getStringIfErrorIsNotThrown(THROWERROR, MSGKEY, VARARGIN) creates a
% message object using MSGKEY and VARARGIN to throw an error if THROWERROR
% is true. Otherwise, it returns the error string of the message object.

% Copyright 2016 The MathWorks, Inc.

msgObj = message(['fuzzy:general:' msgKey], varargin{:});
if throwError
    error(msgObj);
end
errorStr = getString(msgObj);
end