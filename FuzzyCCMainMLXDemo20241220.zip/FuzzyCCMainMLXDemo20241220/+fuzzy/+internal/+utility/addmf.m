function out = addmf(fis,varType,varIndex,MFLabel,MFType,MFParams)
%ADDMF Add membership function to Fuzzy Inference System
%  
%  a = addmf(a,varType,varIndex,mfName,mfType,mfParams)
%  
%  A membership function can only be added to a variable name for a Fuzzy
%  Inference System (FIS) that already exists. Indices are assigned to
%  membership functions in the order in which they are added, so the first
%  membership function added to a variable will always be known as
%  membership function number one for that variable. You cannot add a
%  membership function to input variable number two of a system if only one
%  input has been defined.
%
%  addmf requires six input arguments in this order: 
%      a        - A MATLAB variable name of a FIS structure in the workspace 
%      varType  - A character row vector or string scalar representing the
%                 type of the variable you want to add the membership
%                 function to (input or output)
%      varIndex - The index of the variable you want to add the membership
%                 function to
%      mfName   - A character row vector or string scalar representing the
%                 name of the new membership function
%      mfType   - A character row vector or string scalar representing the
%                 type of the new membership function
%      mfParams - The vector of parameters that specify the membership function.
%  
%  Examples:
%
%     fis = mamfis('Name','tipper');
%     fis = addInput(fis,[0 10],'Name','service');
%     fis = fuzzy.internal.utility.addmf(fis,'input',1,'poor','gaussmf',[1.5 0]);
%     fis = fuzzy.internal.utility.addmf(fis,'input',1,'good','gaussmf',[1.5 5]);
%     fis = fuzzy.internal.utility.addmf(fis,'input',1,'excellent','gaussmf',[1.5 10]);
%     plotmf(fis,'input',1)
%  
%  See also ADDRULE, ADDVAR, PLOTMF, RMMF, RMVAR

%  Copyright 1994-2018 The MathWorks, Inc.

out = fis;
if ~isempty(fis.input)    
    varType = convertStringsToChars(varType);
    MFLabel = convertStringsToChars(MFLabel);
    MFType = convertStringsToChars(MFType);
    if strcmp(varType,'input')
        out = addMF(out,fis.input(varIndex).name,MFType,MFParams, ...
            'Name',MFLabel);
    elseif strcmp(varType,'output')
        out = addMF(out,fis.output(varIndex).name,MFType,MFParams, ...
            'Name',MFLabel);
    end
else
    disp('No Input Variable yet');
end
end