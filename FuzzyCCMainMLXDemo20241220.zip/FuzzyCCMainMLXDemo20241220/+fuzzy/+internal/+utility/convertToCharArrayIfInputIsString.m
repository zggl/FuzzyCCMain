function value = convertToCharArrayIfInputIsString(value)
% Undocumented API for internal use only.

% convertToCharArrayIfInputIsString(VALUE) creates a char array from string
% input VALUE. A string element is selected column-wise to construct the
% char array. It returns the input as the output if VALUE is not a string.

% Copyright 2016 - 2018 The MathWorks, Inc.

% Return if value is not a string.
if ~isstring(value), return; end

value = strrep(value,"'","''");

% Creates a 2-D char array from a string array by adding the content of
% each string to a new row of the output char array. The 'genfis1' API
% requires this string to char conversion.
args = sprintf('''%s'',', value(:));
cmd = ['char(' args(1:end-1) ');'];
value = eval(cmd);

end