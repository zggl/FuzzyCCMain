function mfTabularDisplayType2(objAry)
%

% Internal function for displaying interval type 2 MF array contents.

%  Copyright 2019 The MathWorks, Inc.

rowNames = fuzzy.internal.utility.getRowNames(size(objAry));
if ~isvector(objAry)
    objAry = objAry(:);
end
n = numel(objAry);
UMF_Parameters = cell(n,1);
umfParamsSameLength = zeros(n,1);
Name = string.empty;
Type = string.empty;
LMF_Scale = zeros(n,1);
LMF_Lag = cell(n,1);
lmfLagSameLength = zeros(n,1);
for i = 1:n
    Name = [Name;objAry(i).Name]; %#ok<AGROW>
    Type = [Type;objAry(i).Type]; %#ok<AGROW>
    umfParams = objAry(i).UpperParameters;
    UMF_Parameters{i} = umfParams;
    umfParamsSameLength(i) = numel(umfParams);

    LMF_Scale(i) = objAry(i).LowerScale;
    LMF_Lag{i} = objAry(i).LowerLag;
    lmfLagSameLength(i) = numel(objAry(i).LowerLag);
end

if ~any(diff(umfParamsSameLength))
    UMF_Parameters = cell2mat(UMF_Parameters);
end

if ~any(diff(lmfLagSameLength))
    LMF_Lag = cell2mat(LMF_Lag);
end


tableObj = table(Name,Type,UMF_Parameters,LMF_Scale,LMF_Lag, ...
    'RowNames',rowNames);

tableObj.Properties.VariableNames{2} = 'Type';
tableObj.Properties.VariableNames{3} = 'Upper Parameters';
tableObj.Properties.VariableNames{4} = 'Lower Scale';
tableObj.Properties.VariableNames{5} = 'Lower Lag';

fuzzy.internal.utility.detailDisplay(tableObj)

end