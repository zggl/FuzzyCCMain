function range = getVarRange(var)
%

%

%   Copyright 2017 The MathWorks, Inc.

range = reshape([var.Range],2,length(var))';
end
