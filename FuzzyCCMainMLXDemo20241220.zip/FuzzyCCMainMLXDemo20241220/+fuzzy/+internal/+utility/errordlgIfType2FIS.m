function isType2 = errordlgIfType2FIS(fis,dlgName)
%

% errordlgIfType2FIS(FIS) - Shows errordlg if input is a type-2 FIS.

%   Copyright 2021 The MathWorks, Inc. 

isType2FIS = isa(fis,'fuzzy.internal.fis.Type2FuzzyInferenceSystem');
if nargout > 0
    isType2 = isType2FIS;
end
if isType2FIS
    msg = getString(message("fuzzy:general:errFIS_unsupportedType2FIS"));
    uiwait(errordlg(msg,dlgName,'modal'))
end
end