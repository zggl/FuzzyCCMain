function [fisName,pathName,errorStr] = writefis(fis,fileName,dlgStr)
%

%

%   Copyright 2018 The MathWorks, Inc.

no = nargout;
if no >= 1
    fisName = '';
end
if no >= 2
    pathName = '';
end
if no >= 3
    errorStr = '';
end
throwError = (no<3);

ni = nargin;
if ni<2
    fileName = '';
    DLGStr='dialog';
else
    fileName = convertStringsToChars(fileName);
    if ~ischar(fileName)
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errInput_InvalidCharOrString', 'File name');
        return
    end
    if isempty(fileName)
        DLGStr = 'dialog';
    else
        DLGStr = '';
    end
    if ni>2
        dlgStr = convertStringsToChars(dlgStr);
        if ~ischar(dlgStr)
            errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
                'errInput_InvalidCharOrString', '"Dialog" flag');
            return
        elseif ~strcmpi(dlgStr,'dialog')
            errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
                'errWritefis_IncorrectDialogFlag');
            return;
        else
            DLGStr = dlgStr;
        end
    end
end

% Add .fis if not specified
name = '';
pName = '';
if ~isempty(fileName)
    [pName, name, ext] = fileparts(fileName);
    if ~strcmp(ext,'.fis')
        name = [name ext];
        ext = '.fis';
    end
    fileName = fullfile(pName, [name ext]);
end

% Launch dialog
if strcmp(DLGStr,'dialog')
    % Open dialog to get file name
    [fileName,pName]=uiputfile('*.fis','Save FIS',fileName);
    if isequal(fileName,0) || isequal(pName,0)
        errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
            'errFIS_FileNameNotSpecified');
        return
    end
    fileName = fullfile(pName, fileName);
    [~, name] = fileparts(fileName);
end

if no >= 1
    fisName = name;
end

if no >= 2
    pathName = pName;
end

% Write data to file
fid=fopen(fileName,'w','n','utf8');
if fid==-1
    errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
        'errFileIO_CanNotOpen', fileName);
    return
end
fprintf(fid,'[System]\n');

str=['Name=''' name '''\n'];
fprintf(fid,str);

% Structure
str=['Type=''' convertToChar(fis.type) '''\n'];
fprintf(fid,str);
str='Version=2.0\n';
fprintf(fid,str);

str=['NumInputs=' num2str(length(fis.input)) '\n'];
fprintf(fid,str);

str=['NumOutputs=' num2str(length(fis.output)) '\n'];
fprintf(fid,str);


str=['NumRules=' num2str(length(fis.rule)) '\n'];
fprintf(fid,str);
str=['AndMethod=''' convertToChar(fis.andMethod) '''\n'];
fprintf(fid,str);

str=['OrMethod=''' convertToChar(fis.orMethod) '''\n'];
fprintf(fid,str);

str=['ImpMethod=''' convertToChar(fis.impMethod) '''\n'];
fprintf(fid,str);

str=['AggMethod=''' convertToChar(fis.aggMethod) '''\n'];
fprintf(fid,str);

str=['DefuzzMethod=''' convertToChar(fis.defuzzMethod) '''\n'];
fprintf(fid,str);

for varIndex=1:length(fis.input)
    fprintf(fid,['\n[Input' num2str(varIndex) ']\n']);
    str=['Name=''' convertToChar(fis.input(varIndex).name) '''\n'];
    fprintf(fid,str);
    str=['Range=' mat2str(fis.input(varIndex).range) '\n'];
    fprintf(fid,str);
    str=['NumMFs=' num2str(length(fis.input(varIndex).mf)) '\n'];
    fprintf(fid,str);

    for mfIndex=1:length(fis.input(varIndex).mf)
        str=['MF' num2str(mfIndex) '=''' convertToChar(fis.input(varIndex).mf(mfIndex).name) ''':'];
        fprintf(fid,str);
        str=['''' convertToChar(fis.input(varIndex).mf(mfIndex).type) ''','];
        fprintf(fid,str);
        parstr = sprintf('%.15g ', fis.input(varIndex).mf(mfIndex).params);
        str = ['[' parstr(1:end-1) ']\n'];
        fprintf(fid,str);
    end
end
for varIndex=1:length(fis.output)
    fprintf(fid,['\n[Output' num2str(varIndex) ']\n']);
    str=['Name=''' convertToChar(fis.output(varIndex).name) '''\n'];
    fprintf(fid,str);
    str=['Range=' mat2str(fis.output(varIndex).range) '\n'];
    fprintf(fid,str);
    str=['NumMFs=' num2str(length(fis.output(varIndex).mf)) '\n'];
    fprintf(fid,str);

    for mfIndex=1:length(fis.output(varIndex).mf)
        str=['MF' num2str(mfIndex) '=''' convertToChar(fis.output(varIndex).mf(mfIndex).name) ''':'];
        fprintf(fid,str);
        str=['''' convertToChar(fis.output(varIndex).mf(mfIndex).type) ''','];
        fprintf(fid,str);
        parstr = sprintf('%.15g ', fis.output(varIndex).mf(mfIndex).params);
        str = ['[' parstr(1:end-1) ']\n'];
        fprintf(fid,str);
    end
end

str='\n[Rules]\n';
fprintf(fid,str);
for ruleIndex=1:length(fis.rule)
    antecedent=mat2str(fis.rule(ruleIndex).antecedent);
    if length(fis.input)>1
        antecedent=antecedent(2:end-1);
    end
    consequent=mat2str(fis.rule(ruleIndex).consequent);
    if length(fis.output)>1
        consequent=consequent(2:end-1);
    end
    str=[antecedent ', ' consequent ' ('...
        mat2str(fis.rule(ruleIndex).weight) ') : '...
        mat2str(fis.rule(ruleIndex).connection)...
        '\n'];
    fprintf(fid,str);
end

fclose(fid);

end
%% Helper functions -------------------------------------------------------
function value = convertToChar(value)
if isstring(value)
    value = char(value);
    return
end
end