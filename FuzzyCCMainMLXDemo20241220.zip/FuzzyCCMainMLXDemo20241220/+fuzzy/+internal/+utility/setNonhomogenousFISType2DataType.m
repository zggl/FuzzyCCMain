function fis = setNonhomogenousFISType2DataType(fis,dataType)
%

%  Copyright 2019 The MathWorks, Inc.

fis.input = setVarDataType(fis.input,dataType);
fis.output = setVarDataType(fis.output,dataType);
fis.rule = setRuleDataType(fis.rule,dataType);
end
%% Helper files
function varout = setVarDataType(varin,dataType)

varout = varin;
for i = 1:length(varin)
    varout(i).range = cast(varout(i).range,dataType);
    for j = 1:length(varout(i).mf)
        varout(i).mf(j).umfparams = cast(varout(i).mf(j).umfparams,dataType);
        varout(i).mf(j).lmfparams = cast(varout(i).mf(j).lmfparams,dataType);
        varout(i).mf(j).lmfscale = cast(varout(i).mf(j).lmfscale,dataType);
        varout(i).mf(j).lmflag = cast(varout(i).mf(j).lmflag,dataType);
    end
end

end

function rules = setRuleDataType(rules,dataType)

for i = 1:length(rules)
    rules(i).antecedent = cast(rules(i).antecedent,dataType);
    rules(i).consequent = cast(rules(i).consequent,dataType);
    rules(i).weight = cast(rules(i).weight,dataType);
    rules(i).connection = cast(rules(i).connection,dataType);
end


end