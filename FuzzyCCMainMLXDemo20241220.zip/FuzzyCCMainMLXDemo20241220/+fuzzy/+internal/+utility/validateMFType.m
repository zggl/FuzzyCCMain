function validateMFType(value)
%

%

%  Copyright 2017-2018 The MathWorks, Inc.

try
    validateattributes(...
        value, ...
        {'char','string','function_handle'}, ...
        {'nonempty'}, ...
        '', ...
        'membership function type')
catch me
    error(message('fuzzy:general:errFismf_InvalidType'))
end

if isa(value,'function_handle')
    try
        validateattributes(...
            value, ...
            {'function_handle'}, ...
            {'nonempty','scalar'}, ...
            '', ...
            'membership function type')
    catch me
        error(message('fuzzy:general:errFismf_InvalidType'))
    end
    fcnHandleInfo = functions(value);
    if fcnHandleInfo.type == "anonymous"
        error(message("fuzzy:general:errFismf_InvalidFcnHandle"))
    end
else
    fuzzy.internal.utility.validCharOrString(...
        'Membership function type',value);
    [typePath,~,typeExt] = fileparts(char(value));
    if ~(isempty(typePath) && isempty(typeExt))
        error(message("fuzzy:general:errFismf_InvalidMFFormat"))
    end    
end

end