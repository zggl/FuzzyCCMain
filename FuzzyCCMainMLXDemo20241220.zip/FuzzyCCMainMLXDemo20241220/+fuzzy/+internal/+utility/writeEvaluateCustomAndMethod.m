function writeEvaluateCustomAndMethod(fcn)
%% WRITEEVALUATECUSTOMANDMETHOD Writes evaluation function for custom AND method
%
%   WRITEEVALUATECUSTOMANDMETHOD(ANDMETHOD) Writes an evaluation function
%   in the current directory for the specified custom ANDMETHOD.
%
%   Example
%     WRITEEVALUATECUSTOMANDMETHOD(<customAndMethod>)

%  Copyright 2018-2021 The MathWorks, Inc.

mlock
persistent andMethod
if isempty(andMethod)
    andMethod = {};
end

if ~isempty(fcn) && ~any(fcn{1} == ["min" "prod"]) && ...
        ~ismember(fcn{1},andMethod) && ...
        (exist(fcn{1},'file')==2 || exist(fcn{1},'builtin')==5)
    andMethod{end+1} = fcn{1};
end

id = cell2mat(cellfun(@(x)~(exist(x,'file')==2 || exist(x,'builtin')==5),andMethod,'UniformOutput',false));
if any(id)
    andMethod(id) = [];
end

evalFcnName = 'evaluateCustomAndMethod';
fileName = fullfile(pwd,[evalFcnName '.m']);
if isempty(andMethod)
    if exist(fileName,'file') == 2
        delete(fileName)
    end
    return
end

contents = sprintf("function [y,hasAndMethod] = %s(andMethod,x,varargin) %%#codegen\n",evalFcnName);
contents = sprintf("%s%%[Y,HASANDMETHOD] = %s(ANDMETHOD,X) Evaluates ANDMETHOD with\n",contents,upper(evalFcnName));
contents = sprintf("%s%%input X and returns output Y.\n%%\n",contents);
contents = sprintf("%s%%HASANDMETHOD is true if ANDMETHOD exists.\n%%\n",contents);
contents = sprintf("%s%%Generated on %s\n\n",contents,datestr(now));
contents = sprintf("%s%% Copyright %s The MathWorks, Inc.\n\n",contents,datestr(now,'yyyy'));
contents = sprintf("%sy = -ones('like',x);\n",contents);
contents = sprintf("%shasAndMethod = false;\n",contents);
contents = sprintf("%sif isequal(andMethod,uint8('%s'))\n",contents,andMethod{1});
contents = sprintf("%s\ty(1) = %s(x,varargin{:});\n",contents,andMethod{1});
contents = sprintf("%s\thasAndMethod(1) = true;\n",contents);
for i = 2:length(andMethod)
    contents = sprintf("%selseif isequal(andMethod,uint8('%s'))\n",contents,andMethod{i});
    contents = sprintf("%s\ty(1) = %s(x,varargin{:});\n",contents,andMethod{i});
    contents = sprintf("%s\thasAndMethod(1) = true;\n",contents);
end
contents = sprintf("%send\n\nend\n",contents);

[f,msg] = fopen(fileName,'w+');
fuzzy.internal.utility.verifyFile(fileName,f,msg)
fprintf(f,"%s",contents);
fclose(f);

end