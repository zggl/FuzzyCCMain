function y = constantmf(x,param)
%% CONSTANTMF Constant membership function
%
%   Y = CONSTANTMF(X,params) Returns param irrespective of X. Size of Y is
%   same as X.

%  Copyright 2018 The MathWorks, Inc.
y = repmat(param,size(x));
end