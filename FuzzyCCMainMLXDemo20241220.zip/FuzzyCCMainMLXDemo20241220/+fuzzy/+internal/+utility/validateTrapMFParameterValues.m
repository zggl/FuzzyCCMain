function validateTrapMFParameterValues(params) %#codegen
%

% validateTrapMFParameterValues - Validates parameter values of 'trapmf'
% membership function.

% Copyright 2017-2021 The MathWorks, Inc.

coder.extrinsic('message', 'warning')

if fuzzy.internal.codegen.isMatlabTarget
    if ~fuzzy.internal.utility.isValidInput(params)
        error(message('fuzzy:general:errMFParameters_invalidValue'))
    end
end
n = fuzzy.internal.codegen.numParamTrapmf;
coder.internal.errorIf(numel(params)<n, ...
    'fuzzy:general:errTrapmf_InvalidParamLength')

coder.internal.errorIf(params(1) > params(2), ...
    'fuzzy:general:errTrapmf_InvalidParamA')

coder.internal.errorIf(params(3) > params(4), ...
    'fuzzy:general:errTrapmf_InvalidParamC')

if fuzzy.internal.codegen.isTargetMATLABOrMEX
    if numel(params) > n
        warning(message('fuzzy:general:warnFismf_RedundantParamValues','Trapezoidal',n))
    end
end
end