function prefix = defaultVarPrefix
%% DEFAULTVARPREFIX Returns default prefix for a fuzzy variable name
%
%   The default fuzzy variable name prefix is used to uniquely distinguish
%   it from user specified variable names to automatically update a
%   variable name in a FuzzyInferenceSystem context.

%   Copyright 2017-2018 The MathWorks, Inc.

persistent value

if isempty(value)
    [~,value] = fileparts(tempname);
end

prefix = string(value);
end