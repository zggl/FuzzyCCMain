function levels = getDiagnosticLevels
%

%

% Copyright 2017 The MathWorks, Inc.

levels = ["none" "warning" "error"];

end