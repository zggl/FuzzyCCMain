function bool = isCharRowVector(x)
% BOOL = ISCHARROWVECTOR(X) returns true if X is a character row vector.
% Otherwise, it returns false;
    
%  Copyright 2016-2020 The MathWorks, Inc.
    
bool = ischar(x) && isrow(x);
end