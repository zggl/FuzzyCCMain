function yes = isFiniteNonemptyReal(x)
% ISFINITENONEMPTYREAL Returns true if input is finite, nonempty, real
% values.
%
%  Copyright 2021-2022 The MathWorks, Inc.

yes = ~isempty(x) && isnumeric(x) && isreal(x) && all(isfinite(x),'all');
end