function validateFcnSignature(fcn,minNumInputs,fcnType,isFcnHandle)
%% VALIDATEFCNSIGNATURE Validates a function signature
%
%   VALIDATEFCNSIGNATURE(FCN,MINNUMINPUTS,FCNTYPE,ISFCNHANDLE) Validates
%   that the specified function FCN has at least MINNUMINPUTS number of
%   input arguments and 1 output argument. FCNTYPE and ISFCNHANDLE are used
%   to select appropriate message catalog identifier.

%   Copyright 2017-2018 The MathWorks, Inc.

if isdeployed
    return
end

if any(fcn == ["linear" "constant" "bisector" "centroid" "mom" "som" "lom" ...
        "wtsum" "wtaver" fuzzy.internal.utility.builtinCommonMFs])
    return
end 

numInputArguments = abs(nargin(fcn));
if numInputArguments < minNumInputs
    if isFcnHandle
        if minNumInputs > 1
            error(message("fuzzy:general:errFIS_InvalidNumInputsHandlePlural",fcnType,fcn,minNumInputs))
        else
            error(message("fuzzy:general:errFIS_InvalidNumInputsHandle",fcnType,fcn))
        end
    else
        if minNumInputs > 1
            error(message("fuzzy:general:errFIS_InvalidNumInputsNamePlural",fcnType,fcn,minNumInputs))
        else
            error(message("fuzzy:general:errFIS_InvalidNumInputsName",fcnType,fcn))
        end        
    end
end
numOutputArguments = abs(nargout(fcn));
if numOutputArguments < 1
    if isFcnHandle
        error(message("fuzzy:general:errFIS_InvalidNumOutputsHandle",fcnType,fcn))
    else
        error(message("fuzzy:general:errFIS_InvalidNumOutputsName",fcnType,fcn))
    end
end

end