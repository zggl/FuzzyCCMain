function validateLinearMFParameterValues(params,numInputs)
%

% validateLinearMFParameterValues - Validates parameter values of
% 'linear' membership function.

% Copyright 2017 The MathWorks, Inc.

if nargin == 1
    numInputs = 1;
end

if numel(params) < (numInputs+1)
    error(message('fuzzy:dialogs:flcMaskErr_FIS_InvalidLinearMFParam'))
end

end