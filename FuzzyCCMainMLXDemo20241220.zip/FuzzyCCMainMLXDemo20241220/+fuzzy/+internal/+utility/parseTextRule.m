function rule = parseTextRule(description,format,language)
%

%

%   Copyright 2017-2018 The MathWorks, Inc.

if language == "english"
    keyWords = fuzzy.internal.fis.EnglishRuleKeyWords;
elseif language == "francais"
    keyWords = fuzzy.internal.fis.FrancaisRuleKeyWords;
else
    keyWords = fuzzy.internal.fis.DeutschRuleKeyWords;
end

keySet = getKeySet(keyWords);
description = char(description);

if format == "symbolic"
    symbFlag = 1;
else
    symbFlag = 0;
end

% String pre-processing
% Use "lower" to make it case insensitive
% description = lower(description);

rule = struct(...
    'input',struct('name',[],'mf',[],'complement',false), ...
    'output',struct('name',[],'mf',[],'complement',false), ...
    'weight',1, ...
    'connection',1 ...
    );

    if symbFlag
        % If the rules are in symbolic format, a little pre-processing
        % will save the day
        symKeyWords = fuzzy.internal.fis.SymbolicRuleKeyWords;
        description = strrep(description,symKeyWords.Then,keyWords.Then);
        description = strrep(description,symKeyWords.And,keyWords.And);
        description = strrep(description,symKeyWords.Or,keyWords.Or);
        description = strrep(description,symKeyWords.Not,keyWords.Not);
        description = strrep(description,symKeyWords.Is,' ');
    else
        description = [' ' description];
        description = regexprep(description,keyWords.If,' ','ignorecase');
        description = regexprep(description,keyWords.And,keyWords.And,'ignorecase');
        description = regexprep(description,keyWords.Or,keyWords.Or,'ignorecase');
        description = regexprep(description,keyWords.Then,keyWords.Then,'ignorecase');
        description = regexprep(description,keyWords.Equal,keyWords.Equal,'ignorecase');
        description = regexprep(description,keyWords.Is,' ','ignorecase');
        description = regexprep(description,keyWords.Not,keyWords.Not,'ignorecase');
        description = regexprep(description,keyWords.IsNot,keyWords.IsNot,'ignorecase');
    end
    
    % Compress all multiple spaces down into one space.
    spaceIndex = find(description==' ');
    dblSpaceIndex = find(diff(spaceIndex)==1);
    description(spaceIndex(dblSpaceIndex)) = []; %#ok<FNDSB>
    
    % Form the antecedent and consequent strings
    antStart = 1;
    antEnd = strfind(description,keyWords.Then);
    if isempty(antEnd)
        antEnd = strfind(lower(description),keyWords.Then);
    end
    if isempty(antEnd)
        error(message("fuzzy:general:errFisrule_InvalidIfThenRuleFormat"))
    end
    
    antStr = deblank(description((antStart):(antEnd-1)));
    consStr = deblank(description((antEnd+length(keyWords.Then)):size(description,2)));
    
    % Decode the antecedent
    spaceIndex = [strfind(antStr,' ') length(antStr)];
    if spaceIndex(1)~=1
        spaceIndex=[1 spaceIndex];
    end
    
    % Ignore the first word if it's a line number
    firstWord = antStr(spaceIndex(1):spaceIndex(2));
    if all(abs(firstWord)<58)
        % If all characters are less than ASCII 58 ('9') then it's a number,
        % so start reading from the second word.
        antPtr = 2;
    else
        antPtr = 1;
    end
    
    % You need at least two words in your antecedent.
    if (length(spaceIndex)-antPtr)<2
        error(message("fuzzy:general:errFisrule_IncompleteAntecedent"))
    end
    
    inputIndex = 1;
    connectionAlreadySet = false;
    while antPtr<length(spaceIndex)
        nextWord = antStr(spaceIndex(antPtr):spaceIndex(antPtr+1));
        nextWord(find(nextWord==32)) = []; %#ok<FNDSB>
        if strcmpi(nextWord,strtrim(keyWords.And))
            if connectionAlreadySet
                if rule.connection==2
                    error(message("fuzzy:general:errFisrule_AndOrMixedUse"))
                end
            else
                rule.connection = 1;
                connectionAlreadySet = true;
            end
        elseif strcmpi(nextWord,strtrim(keyWords.Or))
            if connectionAlreadySet
                if rule.connection==1
                    error(message("fuzzy:general:errFisrule_AndOrMixedUse"))
                end
            else
                rule.connection = 2;
                connectionAlreadySet = true;
            end
        else
            varName = string(strtrim(nextWord));
            if any(strcmpi(keySet,varName))
                error(message("fuzzy:general:errFisrule_KeyUsedAsVarName"))
            end
            rule.input(inputIndex).name = varName;
            
            antPtr = antPtr+1;
            nextWord = antStr(spaceIndex(antPtr):spaceIndex(antPtr+1));
            nextWord(find(nextWord==32)) = []; %#ok<FNDSB>
            % Handle potential usage of the word NOT
            if strcmpi(nextWord,strtrim(keyWords.Not)) || ...
                    strcmpi(nextWord,strtrim(strrep(keyWords.Not,'''','''''')))
                rule.input(inputIndex).complement = true;
                antPtr = antPtr+1;
                nextWord = antStr(spaceIndex(antPtr):spaceIndex(antPtr+1));
            else
                rule.input(inputIndex).complement = false;
            end
            
            mfName = string(strtrim(nextWord));
            if any(strcmpi(keySet,mfName))
                error(message("fuzzy:general:errFisrule_KeyUsedAsMFName"))
            end
            rule.input(inputIndex).mf = mfName;
            
            inputIndex = inputIndex + 1;
        end
        antPtr = antPtr+1;
    end
    
    % Decode the consequent
    spaceIndex=[1 strfind(consStr,' ') length(consStr)];
    consPtr=1;
    
    % You need at least two words in your consequent.
    if (length(spaceIndex)-consPtr)<2
        error(message("fuzzy:general:errFisrule_IncompleteConsequent"))
    end
    
    outputIndex = 1;
    while consPtr<length(spaceIndex)
        nextWord=consStr(spaceIndex(consPtr):spaceIndex(consPtr+1));
        nextWord(find(nextWord==32)) = []; %#ok<FNDSB>
        
        if all((nextWord>=32) & (nextWord<=57)) && ~isempty(nextWord)
            weight = eval(nextWord);
            rule.weight = weight;
        elseif ~isempty(nextWord)
            varName = string(strtrim(nextWord));
            if any(strcmpi(keySet,varName))
                error(message("fuzzy:general:errFisrule_KeyUsedAsVarName"))
            end
            rule.output(outputIndex).name = varName;
            
            consPtr = consPtr+1;
            nextWord = consStr(spaceIndex(consPtr):spaceIndex(consPtr+1));
            nextWord(find(nextWord==32)) = []; %#ok<FNDSB>
            % Handle potential usage of the word NOT
            if strcmpi(nextWord,strtrim(keyWords.Not)) || ...
                    strcmpi(nextWord,strtrim(strrep(keyWords.Not,'''','''''')))
                rule.output(outputIndex).complement = true;
                consPtr = consPtr+1;
                nextWord = consStr(spaceIndex(consPtr):spaceIndex(consPtr+1));
            else
                rule.output(outputIndex).complement = false;
            end
            
            mfName = string(strtrim(nextWord));
            if any(strcmpi(keySet,mfName))
                error(message("fuzzy:general:errFisrule_KeyUsedAsMFName"))
            end
            rule.output(outputIndex).mf = mfName;
            
            outputIndex = outputIndex + 1;
        end
        consPtr = consPtr+1;
    end

end