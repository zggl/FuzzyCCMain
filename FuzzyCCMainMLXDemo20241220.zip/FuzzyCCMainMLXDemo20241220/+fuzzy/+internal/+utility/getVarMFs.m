function numMFs = getVarMFs(var)
%

%

%   Copyright 2017-2018 The MathWorks, Inc.

numVars = numel(var);
numMFs = zeros(1,numVars);

for i = 1:numVars
    numMFs(i) = numel(var(i).MembershipFunctions);
end

end