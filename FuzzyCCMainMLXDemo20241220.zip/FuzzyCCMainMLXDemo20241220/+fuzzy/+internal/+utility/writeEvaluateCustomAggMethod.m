function writeEvaluateCustomAggMethod(fcn)
%% WRITEEVALUATECUSTOMAGGMETHOD Writes evaluation function for custom aggregation method
%
%   WRITEEVALUATECUSTOMAGGMETHOD(AGGMETHOD) Writes an evaluation function
%   in the current directory for the specified custom AGGMETHOD.
%
%   Example
%     WRITEEVALUATECUSTOMAGGMETHOD(<customAggMethod>)

%  Copyright 2018-2021 The MathWorks, Inc.

mlock
persistent aggMethod
if isempty(aggMethod)
    aggMethod = {};
end

if ~isempty(fcn) && ~any(fcn{1} == ["max" "probor" "sum"]) && ...
        ~ismember(fcn{1},aggMethod) && ...
        (exist(fcn{1},'file')==2 || exist(fcn{1},'builtin')==5)
    aggMethod{end+1} = fcn{1};
end

id = cell2mat(cellfun(@(x)~(exist(x,'file')==2 || exist(x,'builtin')==5),aggMethod,'UniformOutput',false));
if any(id)
    aggMethod(id) = [];
end

evalFcnName = 'evaluateCustomAggMethod';
fileName = fullfile(pwd,[evalFcnName '.m']);
if isempty(aggMethod)
    if exist(fileName,'file') == 2
        delete(fileName)
    end
    return
end

contents = sprintf("function [y,hasAggMethod] = %s(aggMethod,x,varargin) %%#codegen\n",evalFcnName);
contents = sprintf("%s%%[Y,HASAGGMETHOD] = %s(AGGMETHOD,X) Evaluates AGGMETHOD with\n",contents,upper(evalFcnName));
contents = sprintf("%s%%input X and returns output Y.\n%%\n",contents);
contents = sprintf("%s%%HASAGGMETHOD is true if AGGMETHOD exists.\n%%\n",contents);
contents = sprintf("%s%%Generated on %s\n\n",contents,datestr(now));
contents = sprintf("%s%% Copyright %s The MathWorks, Inc.\n\n",contents,datestr(now,'yyyy'));
contents = sprintf("%sy = -ones('like',x);\n",contents);
contents = sprintf("%shasAggMethod = false;\n",contents);
contents = sprintf("%sif isequal(aggMethod,uint8('%s'))\n",contents,aggMethod{1});
contents = sprintf("%s\ty(1) = %s(x,varargin{:});\n",contents,aggMethod{1});
contents = sprintf("%s\thasAggMethod(1) = true;\n",contents);
for i = 2:length(aggMethod)
    contents = sprintf("%selseif isequal(aggMethod,uint8('%s'))\n",contents,aggMethod{i});
    contents = sprintf("%s\ty(1) = %s(x,varargin{:});\n",contents,aggMethod{i});
    contents = sprintf("%s\thasAggMethod(1) = true;\n",contents);
end
contents = sprintf("%send\n\nend\n",contents);

[f,msg] = fopen(fileName,'w+');
fuzzy.internal.utility.verifyFile(fileName,f,msg)
fprintf(f,"%s",contents);
fclose(f);

end