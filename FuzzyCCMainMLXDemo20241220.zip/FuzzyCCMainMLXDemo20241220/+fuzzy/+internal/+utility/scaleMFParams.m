function [outParams,errorStr] = scaleMFParams(inParams,inType,ratio, ...
    oldOffset,newOffset)
%%

%  Copyright 2022 The MathWorks, Inc.

errorStr=[];
outParams = inParams;

if strcmp(inType,'trimf') || strcmp(inType,'trapmf') || strcmp(inType,'pimf') || ...
    strcmp(inType,'smf') || strcmp(inType,'zmf') || strcmp(inType,'linsmf') || ...
    strcmp(inType,'linzmf') || strcmp(inType,'constant')
    outParams=(inParams-oldOffset)*ratio+newOffset;

elseif strcmp(inType,'gbellmf')
    outParams(1)=inParams(1)*ratio;
    outParams(2)=inParams(2);
    outParams(3)=(inParams(3)-oldOffset)*ratio+newOffset;

elseif strcmp(inType,'gaussmf')
    outParams(1)=inParams(1)*ratio;
    outParams(2)=(inParams(2)-oldOffset)*ratio+newOffset;

elseif strcmp(inType,'gauss2mf')
    outParams([1 3])=inParams([1 3])*ratio;
    outParams([2 4])=(inParams([2 4])-oldOffset)*ratio+newOffset;

elseif strcmp(inType,'sigmf')
    outParams(1)=inParams(1)/ratio;
    outParams(2)=(inParams(2)-oldOffset)*ratio+newOffset;

elseif strcmp(inType,'dsigmf') || strcmp(inType,'psigmf')
    outParams([1 3])=inParams([1 3])/ratio;
    outParams([2 4])=(inParams([2 4])-oldOffset)*ratio+newOffset;

else
    % Output MF type is unknown
    outParams = inParams;
    msg = message('fuzzy:general:errScaleMFParams',inType);
    if nargout<2
        error(msg)
    end
    errorStr = getString(msg);
    return
end

end