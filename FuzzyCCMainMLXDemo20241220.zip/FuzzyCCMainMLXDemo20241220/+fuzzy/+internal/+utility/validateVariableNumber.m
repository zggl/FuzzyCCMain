function validateVariableNumber(value,msgKey)
%

%

%  Copyright 2018 The MathWorks, Inc.

try
    validateattributes(...
        value, ...
        {'numeric'}, ...
        {'nonempty','scalar','real','positive','finite','integer'}, ...
        '', ...
        '')
catch me
    error(message("fuzzy:general:"+msgKey))
end
end