function validateFISToUpdateRule(fis)
%

% Internal function to validate a FIS for updating a fuzzy rule.

%  Copyright 2018 The MathWorks, Inc.

if ~(~isempty(fis) && isscalar(fis) && isa(fis,'FuzzyInferenceSystem'))
    error(message("fuzzy:general:errFisrule_InvalidFIS"))
end

if isempty(fis.Input)
    error(message("fuzzy:general:errFisrule_MissingInput"))
end

if isempty(fis.Output)
    error(message("fuzzy:general:errFisrule_MissingOutput"))
end

numInputMFs = fuzzy.internal.utility.getVarMFs(fis.Inputs);
if all(numInputMFs == 0)
    error(message("fuzzy:general:errFisrule_MissingInputMF"))
end

numOutputMFs = fuzzy.internal.utility.getVarMFs(fis.Outputs);
if all(numOutputMFs == 0)
    error(message("fuzzy:general:errFisrule_MissingOutputMF"))
end

end
