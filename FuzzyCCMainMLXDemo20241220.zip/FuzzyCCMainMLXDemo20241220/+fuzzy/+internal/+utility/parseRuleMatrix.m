function [ruleList,goodRuleIndex,errRuleIndex,errorStr] = parseRuleMatrix(...
    fis,inTxtRuleList,ruleFormat,lang)
%

%

%   Copyright 2017-2018 The MathWorks, Inc.

import fuzzy.internal.utility.getStringIfErrorIsNotThrown

ruleFormat = convertStringsToChars(ruleFormat);
if nargin > 3
    lang = convertStringsToChars(lang);
else
    lang = 'english';
end

ruleList = [];
errRuleIndex = [];
goodRuleIndex = [];
errorStr = [];

throwError = (nargout<4);
if ruleFormat ~= "indexed"
    if lang == "english"
        keyWords = fuzzy.internal.fis.EnglishRuleKeyWords;
    elseif lang == "francais"
        keyWords = fuzzy.internal.fis.FrancaisRuleKeyWords;
    else
        keyWords = fuzzy.internal.fis.DeutschRuleKeyWords;
    end
end

% Determine all the necessary constants
numInputs = length(fis.input);
numOutputs = length(fis.output);
numInputMFs = [];
for i = 1:length(fis.input)
    numInputMFs(i) = length(fis.input(i).mf); %#ok<*AGROW>
end
numOutputMFs = [];
for i = 1:length(fis.output)
    numOutputMFs(i) = length(fis.output(i).mf);
end

inTxtRuleList = fuzzy.internal.utility. ...
    convertToCharArrayIfInputIsString(inTxtRuleList);
if isempty(inTxtRuleList)
    return
end

% Remove any rows that are nothing but blanks
index=find(inTxtRuleList==0);
inTxtRuleList(index)=32*ones(size(index));
inTxtRuleList(all(inTxtRuleList'==32),:)=[];
if isempty(inTxtRuleList)
    return
end

% Replace all punctuation (and <=zeros) with spaces (ASCII 32)
inTxtRuleList2=inTxtRuleList;
index=[find(inTxtRuleList2==','),...
    find(inTxtRuleList2=='#'),...
    find(inTxtRuleList2==':'),...
    find(inTxtRuleList2=='('),...
    find(inTxtRuleList2==')'),...
    find(inTxtRuleList2<0)];
inTxtRuleList2(index)=32*ones(size(index));
inTxtRuleList2(all(inTxtRuleList2'==32),:)=[];

if isempty(inTxtRuleList2)
    ruleList = [];
    return
end

inTxtRuleList2 = char(inTxtRuleList2);
numRules = size(inTxtRuleList2,1);

if strcmp(ruleFormat,'symbolic')
    symbFlag=1;
else
    symbFlag=0;
end

if ruleFormat == "indexed"
    ruleList = zeros(numRules,numInputs+numOutputs+2);
    errorFlag = 0;
    for ruleIndex = 1:numRules
        str = ['[' inTxtRuleList2(ruleIndex,:) ']'];
        rule = eval(str,'[]');        
        if length(rule)<(numInputs+numOutputs)+2 || length(rule)>(numInputs+numOutputs)+2
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_Incomplete',(numInputs+numOutputs)+2);
            errorFlag = 1;
        elseif any(abs(rule(1:numInputs))>numInputMFs)
            varIndex = find(abs(rule(1:numInputs))>numInputMFs,1);
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_InputMFIndexBeyondLimit', ruleIndex,varIndex, ...
                numInputMFs(varIndex));
            errorFlag = 1;
        elseif ~any(rule(1:numInputs))
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_ZeroAntecedent',ruleIndex);
            errorFlag = 1;
        elseif any(abs(rule((1:numOutputs)+numInputs))>numOutputMFs)
            varIndex = find( ...
                abs(rule((1:numOutputs)+numInputs))>numOutputMFs,1);
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_OutputMFIndexBeyondLimit',ruleIndex,varIndex, ...
                numOutputMFs(varIndex));
            errorFlag = 1;
        elseif ~any(rule((1:numOutputs)+numInputs))
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_ZeroConsequent',ruleIndex);
            errorFlag = 1;
        elseif rule(numOutputs+numInputs+1)>1 || rule(numOutputs+numInputs+1)<0
            errorStr=getStringIfErrorIsNotThrown(throwError, ...
                'errRule_InvalidWeight', ruleIndex);
            errorFlag = 1;
        elseif rule(numOutputs+numInputs+2)~=1 && rule(numOutputs+numInputs+2)~=2
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_InvalidOperator', ruleIndex);
            errorFlag = 1;
        else
            ruleList(ruleIndex,:) = rule;
        end
        if errorFlag
            errRuleIndex = [errRuleIndex ruleIndex];
        else
            goodRuleIndex = [goodRuleIndex ruleIndex];
        end
        errorFlag = 0;
    end
    
else
    % symbolic format is first converted to verbose and then
    % everything is parsed as verbose text
    
    inLabels = lower(fuzzy.internal.utility.getVarLabels(fis.input));
    inMFLabels = lower(fuzzy.internal.utility.getVarMFLabels(fis.input));
    outLabels = lower(fuzzy.internal.utility.getVarLabels(fis.output));
    outMFLabels = lower(fuzzy.internal.utility.getVarMFLabels(fis.output));
    
    % String pre-processing
    % Use "lower" to make it case insensitive
    inTxtRuleList2 = lower(inTxtRuleList2);
    
    antCode = zeros(numRules,numInputs);
    consCode = zeros(numRules,numOutputs);
    andOrCode = ones(numRules,1);
    wtCode = ones(numRules,1);
    
    errorFlag = 0;
    errRuleIndex = [];
    goodRuleIndex = [];
    
    for ruleIndex = 1:numRules
        txtRule = inTxtRuleList2(ruleIndex,:);
        
        if symbFlag
            % If the rules are in symbolic format, a little pre-processing
            % will save the day
            symKeyWords = fuzzy.internal.fis.SymbolicRuleKeyWords;
            txtRule = strrep(txtRule,symKeyWords.Then,keyWords.Then);
            txtRule = strrep(txtRule,symKeyWords.And,keyWords.And);
            txtRule = strrep(txtRule,symKeyWords.Or,keyWords.Or);
            txtRule = strrep(txtRule,symKeyWords.Not,keyWords.Not);
            txtRule = strrep(txtRule,symKeyWords.Is,' ');
        else
            txtRule = [' ' txtRule];
            txtRule = strrep(txtRule,lower(keyWords.If),' ');
            txtRule = strrep(txtRule,keyWords.Is,' ');
        end
        
        % Compress all multiple spaces down into one space
        % This is a crucial maneuver that allows me to separate words
        % quickly and painlessly.
        spaceIndex = find(txtRule==' ');
        dblSpaceIndex = find(diff(spaceIndex)==1);
        txtRule(spaceIndex(dblSpaceIndex)) = [];
        
        % Form the antecedent and consequent strings
        antStart = 1;
        antEnd = findstr(txtRule,keyWords.Then);
        if isempty(antEnd)
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_NotImplication', ruleIndex);
            errorFlag = 1;
        end
        
        antStr = deblank(txtRule((antStart):(antEnd-1)));
        consStr = deblank(txtRule((antEnd+6):size(txtRule,2)));
        
        % Decode the antecedent
        spaceIndex = [findstr(antStr,' ') length(antStr)];
        if spaceIndex(1) ~= 1
            spaceIndex = [1 spaceIndex];
        end
        
        % Ignore the first word if it's a line number
        firstWord = antStr(spaceIndex(1):spaceIndex(2));
        if all(abs(firstWord) < 58)
            % If all characters are less than ASCII 58 ('9') then it's a number,
            % so start reading from the second word.
            antPtr = 2;
        else
            antPtr = 1;
        end
        
        % You need at least two words in your antecedent in order to play
        if (length(spaceIndex)-antPtr)<2 && ~errorFlag
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_IncompleteAntecedent', ruleIndex);
            errorFlag = 1;
        end
        
        while antPtr<length(spaceIndex) && ~errorFlag
            nextWord = antStr(spaceIndex(antPtr):spaceIndex(antPtr+1));
            nextWord(find(nextWord==32)) = [];
            if strcmp(nextWord,strtrim(keyWords.And))
                andOrCode(ruleIndex) = 1;
            elseif strcmp(nextWord,strtrim(keyWords.Or))
                andOrCode(ruleIndex) = 2;
            else
                varName = nextWord;
                varIndex = findrow(varName,inLabels);
                if isempty(varIndex)
                    errorStr = getStringIfErrorIsNotThrown(throwError, ...
                        'errRule_InvalidInputVariableName',ruleIndex,varName);
                    errorFlag = 1;
                end
                
                antPtr = antPtr+1;
                nextWord = antStr(spaceIndex(antPtr):spaceIndex(antPtr+1));
                nextWord(find(nextWord==32)) = [];
                % Handle potential usage of the word NOT
                if strcmp(nextWord,strtrim(keyWords.Not)) || ...
                        strcmp(nextWord,strtrim(strrep(keyWords.Not,'''','''''')))
                    mfIndexMultiplier = -1;
                    antPtr = antPtr+1;
                    nextWord = antStr(spaceIndex(antPtr):spaceIndex(antPtr+1));
                else
                    mfIndexMultiplier=1;
                end
                
                mfIndexBegin = sum(numInputMFs(1:(varIndex-1)))+1;
                mfIndexEnd = mfIndexBegin+numInputMFs(varIndex)-1;
                mfList = inMFLabels(mfIndexBegin:mfIndexEnd,:);
                mfIndex = findrow(nextWord,mfList)*mfIndexMultiplier;
                if isempty(mfIndex) && ~errorFlag
                    errorStr = getStringIfErrorIsNotThrown(throwError, ...
                        'errRule_InvalidInputMFName',ruleIndex,nextWord,varName);
                    errorFlag = 1;
                end
                if ~errorFlag
                    antCode(ruleIndex,varIndex) = mfIndex;
                end
            end
            
            antPtr = antPtr+1;
        end
        
        % Decode the consequent
        spaceIndex = [1 findstr(consStr,' ') length(consStr)];
        consPtr = 1;
        
        % You need at least two words in your consequent in order to play
        if (length(spaceIndex)-consPtr)<2 && ~errorFlag
            errorStr = getStringIfErrorIsNotThrown(throwError, ...
                'errRule_IncompleteConsequent', ruleIndex);
            errorFlag = 1;
        end
        
        while consPtr<length(spaceIndex) && ~errorFlag
            nextWord = consStr(spaceIndex(consPtr):spaceIndex(consPtr+1));
            nextWord(find(nextWord==32)) = [];
            
            if all((nextWord>=32) & (nextWord<=57)) && ~isempty(nextWord)
                wtCode(ruleIndex) = eval(nextWord);
            elseif ~isempty(nextWord)
                varName = nextWord;
                varIndex = findrow(varName,outLabels);
                if isempty(varIndex)
                    errorStr = fuzzy.internal.utility.getStringIfErrorIsNotThrown(throwError, ...
                        'errRule_InvalidOutputVariableName',ruleIndex,varName);
                    errorFlag = 1;
                end
                
                consPtr = consPtr+1;
                nextWord = consStr(spaceIndex(consPtr):spaceIndex(consPtr+1));
                nextWord(find(nextWord==32)) = [];
                % Handle potential usage of the word NOT
                if strcmp(nextWord,strtrim(keyWords.Not)) || ...
                        strcmp(nextWord,strtrim(strrep(keyWords.Not,'''','''''')))
                    mfIndexMultiplier = -1;
                    consPtr = consPtr+1;
                    nextWord = consStr(spaceIndex(consPtr):spaceIndex(consPtr+1));
                else
                    mfIndexMultiplier = 1;
                end
                
                mfIndexBegin = sum(numOutputMFs(1:(varIndex-1)))+1;
                mfIndexEnd = mfIndexBegin+numOutputMFs(varIndex)-1;
                mfList = outMFLabels(mfIndexBegin:mfIndexEnd,:);
                mfIndex = findrow(nextWord,mfList)*mfIndexMultiplier;
                if isempty(mfIndex) && ~errorFlag
                    errorStr = getStringIfErrorIsNotThrown(throwError, ...
                        'errRule_InvalidOutputMFName',ruleIndex,nextWord,varName);
                    errorFlag = 1;
                end
                if ~errorFlag
                    consCode(ruleIndex,varIndex) = mfIndex;
                end
            end
            
            consPtr = consPtr+1;
        end
        
        if errorFlag
            errRuleIndex = [errRuleIndex ruleIndex];
        else
            goodRuleIndex = [goodRuleIndex ruleIndex];
        end
        errorFlag = 0;
        
    end
    ruleList = [antCode consCode wtCode andOrCode];
    
end    % if strcmp(ruleFormat, ...

% At this point, we're nearly done. Compile the parsed rules along with
% the rules that have been flagged with errors. Make sure and
% don't include any error-ridden rules in the parsed output
% Get back the cleaned rules that were properly parsed

ruleList(errRuleIndex,:) = [];


end