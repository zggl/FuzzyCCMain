function [centers, memberships] = FKMs(data, k, m, maxIter, tol)
    % Fuzzy k-Means Clustering
    % Inputs:
    % - data: Matrix of data points (n x d)
    % - k: Number of clusters
    % - m: Fuzziness parameter (> 1)
    % - maxIter: Maximum number of iterations
    % - tol: Convergence tolerance
    
    [n, d] = size(data); % Number of points (n) and dimensions (d)
    
    % Initialize cluster centers randomly
    centers = data(randperm(n, k), :);
    
    % Initialize membership matrix (n x k)
    memberships = rand(n, k);
    memberships = memberships ./ sum(memberships, 2); % Normalize
    
    for iter = 1:maxIter
        % Update cluster centers
        for j = 1:k
            numerator = sum((memberships(:, j).^m) .* data, 1);
            denominator = sum(memberships(:, j).^m);
            centers(j, :) = numerator / denominator;
        end
        
        % Update memberships
        distances = zeros(n, k);
        for j = 1:k
            distances(:, j) = sqrt(sum((data - centers(j, :)).^2, 2));
        end
        distances = distances + eps; % Avoid division by zero
        for j = 1:k
            memberships(:, j) = 1 ./ sum((distances(:, j) ./ distances).^((2/(m-1))), 2);
        end
        
        % Check for convergence
        if max(max(abs(diff(memberships)))) < tol
            fprintf('Converged in %d iterations.\n', iter);
            break;
        end
    end
end