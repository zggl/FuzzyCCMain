% 设置每类的样本数量
num_samples_per_class = 100;

% 设置数据维度
dim = 4;

% 初始化空矩阵以存储所有数据
data = [];
labels = [];

% 生成 4 类数据
for i = 1:4
    % 设置每个类的均值和协方差矩阵
    mu = rand(1, dim) * 10; % 随机生成均值向量
    sigma = cov(randn(dim)); % 使用随机矩阵生成正定协方差矩阵
    
    % 生成多元正态分布数据
    class_data = mvnrnd(mu, sigma, num_samples_per_class);
    
    % 存储数据和标签
    data = [data; class_data];
    labels = [labels; i * ones(num_samples_per_class, 1)];
end

% 绘制数据（仅可视化维数为2或3时）
h=figure(1)
subplot(2, 2, 1); 
scatter3(data(:,1), data(:,2), data(:,3), 15, labels, 'filled');
xlabel('Dim 1');ylabel('Dim 2');zlabel('Dim 3');
view(40,35)
subplot(2, 2, 2); 
scatter3(data(:,1), data(:,2), data(:,4), 15, labels, 'filled');
xlabel('Dim 1');ylabel('Dim 2');zlabel('Dim 4');
view(40,35)
subplot(2, 2, 3); 
scatter3(data(:,1), data(:,3), data(:,4), 15, labels, 'filled');
xlabel('Dim 1');ylabel('Dim 3');zlabel('Dim 4');
view(40,35)
subplot(2, 2, 4); 
scatter3(data(:,2), data(:,3), data(:,4), 15, labels, 'filled');
xlabel('Dim 2');ylabel('Dim 3');zlabel('Dim 4');
view(40,35)
% 显示结果
disp('Data generated:');
disp(data);
disp('Labels:');
disp(labels);


save('SyntacticData4DimData.dat','data', '-ascii')
save('SyntacticData4DimLabel.dat','labels', '-ascii')
saveas(h,'SyntacticData4Dim','pdf')

% for ofFCM use
 
dataLabel=[data,labels];
writematrix(dataLabel,'SyntacticData4DimDatL.csv','Delimiter',',')
pause(20)
close all