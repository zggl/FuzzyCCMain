# my_script.py
print("Received data:", data)