"""Version specifier.

DON'T TOUCH THIS FILE.
This file is replaced during the release process.
"""

__version__ = "0.0.0a0"
